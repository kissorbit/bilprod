-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1:3306
-- Généré le : ven. 30 déc. 2022 à 13:20
-- Version du serveur :  5.7.31
-- Version de PHP : 7.4.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `ibilling`
--

-- --------------------------------------------------------

--
-- Structure de la table `account_balances`
--

DROP TABLE IF EXISTS `account_balances`;
CREATE TABLE IF NOT EXISTS `account_balances` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `account_id` int(11) NOT NULL DEFAULT '0',
  `currency_id` int(11) NOT NULL DEFAULT '0',
  `balance` decimal(16,4) NOT NULL DEFAULT '0.0000',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `clx_integrations`
--

DROP TABLE IF EXISTS `clx_integrations`;
CREATE TABLE IF NOT EXISTS `clx_integrations` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `url` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `secret` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `is_default` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `cmr_groups1`
--

DROP TABLE IF EXISTS `cmr_groups1`;
CREATE TABLE IF NOT EXISTS `cmr_groups1` (
  `id` int(11) NOT NULL DEFAULT '0',
  `gname` varchar(200) CHARACTER SET utf8 DEFAULT NULL,
  `color` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `discount` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `parent` varchar(200) CHARACTER SET utf8 DEFAULT NULL,
  `pid` int(10) DEFAULT NULL,
  `exempt` text CHARACTER SET utf8,
  `description` text CHARACTER SET utf8,
  `separateinvoices` text CHARACTER SET utf8,
  `sorder` int(10) DEFAULT NULL,
  `c1` varchar(200) CHARACTER SET utf8 DEFAULT NULL,
  `c2` varchar(200) CHARACTER SET utf8 DEFAULT NULL,
  `c3` varchar(200) CHARACTER SET utf8 DEFAULT NULL,
  `c4` varchar(200) CHARACTER SET utf8 DEFAULT NULL,
  `c5` varchar(200) CHARACTER SET utf8 DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `cmr_groups1`
--

INSERT INTO `cmr_groups1` (`id`, `gname`, `color`, `discount`, `parent`, `pid`, `exempt`, `description`, `separateinvoices`, `sorder`, `c1`, `c2`, `c3`, `c4`, `c5`) VALUES
(1, 'nkjnk', '', '', '', 0, '', '', '', 0, '', '', '', '', ''),
(1, 'nkjnk', '', '', '', 0, '', '', '', 0, '', '', '', '', '');

-- --------------------------------------------------------

--
-- Structure de la table `cmr_groups2`
--

DROP TABLE IF EXISTS `cmr_groups2`;
CREATE TABLE IF NOT EXISTS `cmr_groups2` (
  `id` int(11) NOT NULL DEFAULT '0',
  `gname` varchar(200) CHARACTER SET utf8 DEFAULT NULL,
  `color` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `discount` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `parent` varchar(200) CHARACTER SET utf8 DEFAULT NULL,
  `pid` int(10) DEFAULT NULL,
  `exempt` text CHARACTER SET utf8,
  `description` text CHARACTER SET utf8,
  `separateinvoices` text CHARACTER SET utf8,
  `sorder` int(10) DEFAULT NULL,
  `c1` varchar(200) CHARACTER SET utf8 DEFAULT NULL,
  `c2` varchar(200) CHARACTER SET utf8 DEFAULT NULL,
  `c3` varchar(200) CHARACTER SET utf8 DEFAULT NULL,
  `c4` varchar(200) CHARACTER SET utf8 DEFAULT NULL,
  `c5` varchar(200) CHARACTER SET utf8 DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `cmr_groups2`
--

INSERT INTO `cmr_groups2` (`id`, `gname`, `color`, `discount`, `parent`, `pid`, `exempt`, `description`, `separateinvoices`, `sorder`, `c1`, `c2`, `c3`, `c4`, `c5`) VALUES
(1, 'nkjnk', '', '', '', 0, '', '', '', 0, '', '', '', '', ''),
(1, 'nkjnk', '', '', '', 0, '', '', '', 0, '', '', '', '', '');

-- --------------------------------------------------------

--
-- Structure de la table `conversation_message`
--

DROP TABLE IF EXISTS `conversation_message`;
CREATE TABLE IF NOT EXISTS `conversation_message` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `trade_conversation_id` int(11) DEFAULT NULL,
  `sender_id` int(11) NOT NULL DEFAULT '0',
  `sender_table` varchar(50) NOT NULL DEFAULT '0',
  `recipient_id` int(11) NOT NULL DEFAULT '0',
  `recipient_table` varchar(50) NOT NULL DEFAULT '0',
  `content` text NOT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `file_token` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=145 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `conversation_message`
--

INSERT INTO `conversation_message` (`id`, `trade_conversation_id`, `sender_id`, `sender_table`, `recipient_id`, `recipient_table`, `content`, `created_at`, `updated_at`, `file_token`) VALUES
(111, 72, 1, 'sys_users', 23, 'crm_accounts_1', 'gfghfhffg', '2022-12-11 09:43:18', '2022-12-11 09:43:18', NULL),
(112, 72, 1, 'sys_users', 23, 'crm_accounts_1', 'bvcvcv', '2022-12-11 10:26:36', '2022-12-11 10:26:36', ''),
(113, 72, 1, 'sys_users', 23, 'crm_accounts_1', 'bvbvbv', '2022-12-11 10:26:50', '2022-12-11 10:26:50', ''),
(114, 72, 1, 'sys_users', 23, 'crm_accounts_1', 'vbvbbv', '2022-12-11 10:27:14', '2022-12-11 10:27:14', 'puxil63kq9vg2bkny1jv81hqlf7i21'),
(115, 72, 1, 'sys_users', 23, 'crm_accounts_1', 'nbvbvbvb', '2022-12-11 10:27:23', '2022-12-11 10:27:23', ''),
(116, 72, 1, 'sys_users', 23, 'crm_accounts_1', 'fgfgfg', '2022-12-11 10:27:26', '2022-12-11 10:27:26', ''),
(117, 73, 1, 'sys_users', 23, 'crm_accounts_1', 'ghffgfhg ffhfh', '2022-12-11 10:42:29', '2022-12-11 10:42:29', NULL),
(118, 74, 1, 'sys_users', 15, 'crm_accounts_1', 'cxxcxcx', '2022-12-11 16:18:18', '2022-12-11 16:18:18', 'w2062x8nmfjrpjk6235h87xh80nyzy'),
(119, 75, 1, 'sys_users', 23, 'crm_accounts_1', 'cxcxc', '2022-12-11 16:24:00', '2022-12-11 16:24:00', '9njxsmvhq5g3639f8cny5j19fodvrm'),
(120, 76, 1, 'sys_users', 22, 'crm_accounts_1', 'bvbvbvb', '2022-12-11 16:25:01', '2022-12-11 16:25:01', '04mtqguusqo6djcl6uae0no5fzri5r'),
(121, 76, 1, 'sys_users', 22, 'crm_accounts_1', 'bvvvb', '2022-12-11 16:32:12', '2022-12-11 16:32:12', ''),
(122, 76, 1, 'sys_users', 22, 'crm_accounts_1', 'vbbvbv', '2022-12-11 16:32:20', '2022-12-11 16:32:20', ''),
(123, 76, 1, 'sys_users', 22, 'crm_accounts_1', 'cbbcbcb', '2022-12-11 16:32:27', '2022-12-11 16:32:27', ''),
(124, 76, 1, 'sys_users', 22, 'crm_accounts_1', 'bbccbbc', '2022-12-11 16:32:35', '2022-12-11 16:32:35', ''),
(125, 76, 1, 'sys_users', 22, 'crm_accounts_1', 'cbcbbccb', '2022-12-11 16:32:39', '2022-12-11 16:32:39', ''),
(126, 76, 1, 'sys_users', 22, 'crm_accounts_1', 'tets nb', '2022-12-11 16:32:47', '2022-12-11 16:32:47', ''),
(127, 76, 1, 'sys_users', 22, 'crm_accounts_1', 'bbbvbv', '2022-12-11 16:32:58', '2022-12-11 16:32:58', ''),
(128, 77, 1, 'sys_users', 22, 'crm_accounts_1', 'bvbvvbbvvb', '2022-12-11 16:40:24', '2022-12-11 16:40:24', 'rcxmn2mt84b8y0cxij164isyzwl4lz'),
(129, 78, 1, 'sys_users', 18, 'crm_accounts_1', 'cbvcvvv', '2022-12-11 16:41:34', '2022-12-11 16:41:34', 'zt2pabpqyw01acptf4gquz3qrxps55'),
(130, 79, 1, 'sys_users', 15, 'crm_accounts_1', 'bbvbvbvbvbv', '2022-12-11 16:42:44', '2022-12-11 16:42:44', NULL),
(131, 80, 1, 'sys_users', 19, 'crm_accounts_1', 'ghcbvcbvcbv', '2022-12-11 16:46:33', '2022-12-11 16:46:33', NULL),
(132, 81, 1, 'sys_users', 23, 'crm_accounts_1', 'bvbvbv', '2022-12-11 16:54:36', '2022-12-11 16:54:36', NULL),
(133, 82, 1, 'sys_users', 23, 'crm_accounts_1', 'bvcbvcvbcv', '2022-12-11 16:55:09', '2022-12-11 16:55:09', NULL),
(134, 83, 1, 'sys_users', 22, 'crm_accounts_1', 'gffgfgfg', '2022-12-11 17:04:37', '2022-12-11 17:04:37', NULL),
(135, 84, 1, 'sys_users', 21, 'crm_accounts_1', 'gffgfg', '2022-12-11 17:16:58', '2022-12-11 17:16:58', '9rp3r564qubm5cdg03nkob87xq9pij'),
(136, 85, 1, 'sys_users', 56, 'crm_accounts', '<p>ghfgfhf</p>', '2022-12-13 04:40:22', '2022-12-13 04:40:22', 'edtec98cdmsoalv2trif5i3nhcgyfn'),
(137, 86, 1, 'sys_users', 62, 'crm_accounts', '<p>ghfgfhf</p>', '2022-12-13 04:40:23', '2022-12-13 04:40:23', 'edtec98cdmsoalv2trif5i3nhcgyfn'),
(138, 85, 56, 'crm_accounts', 1, 'sys_users', 'gffgfgfg', '2022-12-13 22:21:16', '2022-12-13 22:21:16', ''),
(139, 85, 1, 'sys_users', 56, 'crm_accounts', 'hggghhg', '2022-12-14 04:34:09', '2022-12-14 04:34:09', ''),
(140, 85, 1, 'sys_users', 56, 'crm_accounts', 'ghghgh', '2022-12-14 04:37:00', '2022-12-14 04:37:00', ''),
(141, 85, 56, 'crm_accounts', 1, 'sys_users', 'ghghghhg', '2022-12-14 04:52:32', '2022-12-14 04:52:32', ''),
(142, 85, 1, 'sys_users', 56, 'crm_accounts', 'ghghgh', '2022-12-14 04:53:51', '2022-12-14 04:53:51', ''),
(143, 72, 23, 'crm_accounts_1', 1, 'sys_users', 'bnnvvvn', '2022-12-14 05:36:48', '2022-12-14 05:36:48', ''),
(144, 85, 1, 'sys_users', 56, 'crm_accounts', 'vvv', '2022-12-14 05:37:31', '2022-12-14 05:37:31', '');

-- --------------------------------------------------------

--
-- Structure de la table `crm_accounts`
--

DROP TABLE IF EXISTS `crm_accounts`;
CREATE TABLE IF NOT EXISTS `crm_accounts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `account` varchar(200) DEFAULT NULL,
  `fname` varchar(100) NOT NULL,
  `lname` varchar(100) NOT NULL,
  `company` varchar(200) NOT NULL,
  `jobtitle` varchar(100) DEFAULT NULL,
  `cid` int(11) NOT NULL,
  `o` int(11) NOT NULL DEFAULT '0',
  `phone` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `username` varchar(100) DEFAULT NULL,
  `address` varchar(200) NOT NULL,
  `city` varchar(100) NOT NULL,
  `state` varchar(100) NOT NULL,
  `zip` varchar(100) NOT NULL,
  `country` varchar(100) NOT NULL,
  `balance` decimal(16,2) NOT NULL,
  `status` enum('Active','Inactive') NOT NULL DEFAULT 'Active',
  `notes` text NOT NULL,
  `options` text,
  `tags` text NOT NULL,
  `password` text NOT NULL,
  `token` text NOT NULL,
  `ts` text NOT NULL,
  `img` varchar(100) NOT NULL,
  `web` varchar(200) NOT NULL,
  `facebook` varchar(100) NOT NULL,
  `google` varchar(100) NOT NULL,
  `linkedin` varchar(100) NOT NULL,
  `twitter` varchar(100) DEFAULT NULL,
  `skype` varchar(100) DEFAULT NULL,
  `tax_number` varchar(100) DEFAULT NULL,
  `entity_number` varchar(100) DEFAULT NULL,
  `currency` int(11) DEFAULT '0',
  `pmethod` varchar(100) DEFAULT NULL,
  `autologin` varchar(100) DEFAULT NULL,
  `lastlogin` datetime DEFAULT NULL,
  `lastloginip` varchar(100) DEFAULT NULL,
  `stage` varchar(50) DEFAULT NULL,
  `timezone` varchar(50) DEFAULT NULL,
  `isp` varchar(100) DEFAULT NULL,
  `lat` varchar(50) DEFAULT NULL,
  `lon` varchar(50) DEFAULT NULL,
  `gname` varchar(200) DEFAULT NULL,
  `gid` int(11) NOT NULL DEFAULT '0',
  `sid` varchar(200) DEFAULT NULL,
  `role` varchar(200) DEFAULT NULL,
  `country_code` varchar(20) DEFAULT NULL,
  `country_idd` varchar(20) DEFAULT NULL,
  `signed_up_by` varchar(100) DEFAULT NULL,
  `signed_up_ip` varchar(20) DEFAULT NULL,
  `dob` date DEFAULT NULL,
  `ct` varchar(200) DEFAULT NULL,
  `assistant` varchar(200) DEFAULT NULL,
  `asst_phone` varchar(100) DEFAULT NULL,
  `second_email` varchar(100) DEFAULT NULL,
  `second_phone` varchar(100) DEFAULT NULL,
  `taxexempt` varchar(50) DEFAULT NULL,
  `latefeeoveride` varchar(50) DEFAULT NULL,
  `overideduenotices` varchar(50) DEFAULT NULL,
  `separateinvoices` varchar(50) DEFAULT NULL,
  `disableautocc` varchar(50) DEFAULT NULL,
  `billingcid` int(10) NOT NULL DEFAULT '0',
  `securityqid` int(10) NOT NULL DEFAULT '0',
  `securityqans` text,
  `cardtype` varchar(200) DEFAULT NULL,
  `cardlastfour` varchar(20) DEFAULT NULL,
  `cardnum` text,
  `startdate` varchar(50) DEFAULT NULL,
  `expdate` varchar(50) DEFAULT NULL,
  `issuenumber` varchar(200) DEFAULT NULL,
  `bankname` varchar(200) DEFAULT NULL,
  `banktype` varchar(200) DEFAULT NULL,
  `bankcode` varchar(200) DEFAULT NULL,
  `bankacct` varchar(200) DEFAULT NULL,
  `gatewayid` int(10) NOT NULL DEFAULT '0',
  `language` text,
  `pwresetkey` varchar(100) DEFAULT NULL,
  `emailoptout` varchar(50) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `pwresetexpiry` datetime DEFAULT NULL,
  `c1` varchar(200) DEFAULT NULL,
  `c2` varchar(200) DEFAULT NULL,
  `c3` varchar(200) DEFAULT NULL,
  `c4` varchar(200) DEFAULT NULL,
  `c5` varchar(200) DEFAULT NULL,
  `is_email_verified` int(1) NOT NULL DEFAULT '0',
  `is_phone_veirifed` int(1) NOT NULL DEFAULT '0',
  `photo_id_type` varchar(100) DEFAULT NULL,
  `photo_id` varchar(100) DEFAULT NULL,
  `admin_file_token` varchar(255) DEFAULT NULL,
  `trucks_files_token` varchar(255) DEFAULT NULL,
  `transport_license_file_token` varchar(255) DEFAULT NULL,
  `trucks` varchar(255) DEFAULT NULL,
  `user_lang` varchar(50) NOT NULL DEFAULT 'en',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=63 DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `crm_accounts`
--

INSERT INTO `crm_accounts` (`id`, `account`, `fname`, `lname`, `company`, `jobtitle`, `cid`, `o`, `phone`, `email`, `username`, `address`, `city`, `state`, `zip`, `country`, `balance`, `status`, `notes`, `options`, `tags`, `password`, `token`, `ts`, `img`, `web`, `facebook`, `google`, `linkedin`, `twitter`, `skype`, `tax_number`, `entity_number`, `currency`, `pmethod`, `autologin`, `lastlogin`, `lastloginip`, `stage`, `timezone`, `isp`, `lat`, `lon`, `gname`, `gid`, `sid`, `role`, `country_code`, `country_idd`, `signed_up_by`, `signed_up_ip`, `dob`, `ct`, `assistant`, `asst_phone`, `second_email`, `second_phone`, `taxexempt`, `latefeeoveride`, `overideduenotices`, `separateinvoices`, `disableautocc`, `billingcid`, `securityqid`, `securityqans`, `cardtype`, `cardlastfour`, `cardnum`, `startdate`, `expdate`, `issuenumber`, `bankname`, `banktype`, `bankcode`, `bankacct`, `gatewayid`, `language`, `pwresetkey`, `emailoptout`, `created_at`, `updated_at`, `pwresetexpiry`, `c1`, `c2`, `c3`, `c4`, `c5`, `is_email_verified`, `is_phone_veirifed`, `photo_id_type`, `photo_id`, `admin_file_token`, `trucks_files_token`, `transport_license_file_token`, `trucks`, `user_lang`) VALUES
(26, 'kingue', '', '', 'kp campany', '', 0, 0, '6666666', 'rolandkp7@gmail.com', NULL, 'Douala,bepanda', 'kribi', 'ddd', 'ddd', 'Cameroon', '0.00', 'Active', '', NULL, '', 'ibLJRKHoI8Qfk', 'pofrvf0pr3ec595fpbj2df3585e289df249dec9aaac36f5cba79', '', '', '', '', '', '', NULL, NULL, NULL, NULL, 0, NULL, '6urgghwdylyugzn30qnf261663430912', NULL, NULL, NULL, NULL, 'DESKTOP-V58I9E2', NULL, NULL, '', 0, NULL, NULL, NULL, NULL, NULL, '::1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, 'en'),
(27, 'maurice', '', '', 'bm-tracking', '', 0, 0, '95959595595', 'maurice@maurice.ba', NULL, 'bepanda', 'Douala', 'ouest', '365556', 'Afghanistan', '0.00', 'Active', '', NULL, '', 'ibLJRKHoI8Qfk', '', '', '', '', '', '', '', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, 'DESKTOP-V58I9E2', NULL, NULL, '', 0, NULL, NULL, NULL, NULL, NULL, '::1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, 'en'),
(28, 'kapscampany', '', '', '', '', 0, 0, '', 'rkapekem@gmail.com', NULL, '', '', '', '', '', '0.00', 'Active', '', NULL, '', 'ibpJMWvP93LDs', '', '', '', '', '', '', '', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, 'DESKTOP-V58I9E2', NULL, NULL, '', 0, NULL, NULL, NULL, NULL, NULL, '::1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, 'en'),
(30, 'afm', '', '', '', '', 0, 0, '', 'support@bm-tracking.com', NULL, '', '', '', '', '', '0.00', 'Active', '', NULL, '', 'ibpJMWvP93LDs', '', '', '', '', '', '', '', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, 'DESKTOP-V58I9E2', NULL, NULL, '', 0, NULL, NULL, NULL, NULL, NULL, '::1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, 'en'),
(31, 'kp campany', '', '', 'kp campany', '', 0, 0, '+237680668907', 'rolankp7@gmail.com', NULL, 'Douala,bepanda', '5', '5', 'bp544', 'Cameroon', '0.00', 'Active', '', NULL, '', 'ibLJRKHoI8Qfk', '', '', '', '', '', '', '', NULL, NULL, NULL, NULL, 0, NULL, 'qtxvf5pctubdyix9j472311666796898', NULL, NULL, NULL, NULL, 'DESKTOP-V58I9E2', NULL, NULL, '', 0, NULL, NULL, NULL, NULL, NULL, '::1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, '+237680668907', 'yes', '2022-09-22', NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, 'en'),
(33, 'kp campany', 'kapekem', 'roland', 'kp campany', '', 0, 1, '+237680665555', 'testp7@gmail.com', NULL, '', 'Douala', '', 'hhh', 'Cameroon', '0.00', 'Active', '', NULL, '', 'ibLJRKHoI8Qfk', '', '', '', '', '', '', '', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, '2022-11-02 08:59:11', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, 'en'),
(34, 'kingue', 'admin', 'test', 'kingue', '', 0, 1, '8888999666', 'kingue@lol.vf', NULL, '', 'lol', '', 'B.P. 15398', 'Uganda', '0.00', 'Active', '', NULL, '', '', '', '', '', '', '', '', '', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, '2022-11-02 09:33:06', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, 'en'),
(35, 'fullstack .net', 'fullstack', 'fullstack', 'fullstack .net', '', 0, 1, '+23768066666', 'fullstack@gmail.com', NULL, '', 'Douala', '', 'B.P. 15398', 'Cameroon', '0.00', 'Active', '', NULL, '', '', '', '', '', '', '', '', '', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, '2022-11-02 09:48:17', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, 'en'),
(36, 'fulllstack.comlt', 'fullstack', 'fullstack', '', '', 0, 1, '879556', 'full-stack@gmail.com', NULL, '', 'douala', '', 'hjjkkjkj', 'United States', '0.00', 'Active', '55228', NULL, '', '', '', '', '', '', '', '', '', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, '2022-11-02 09:57:35', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, 'en'),
(37, 'rolandtracking', '', '', '', '', 0, 0, '', 'ka@gmail.com', NULL, '', '', '', '', '', '0.00', 'Active', '', NULL, '', 'ibLJRKHoI8Qfk', '', '', '', '', '', '', '', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, 'DESKTOP-V58I9E2', NULL, NULL, '', 0, NULL, NULL, NULL, NULL, NULL, '::1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, 'en'),
(38, 'rolandtracking', '', '', 'younde', '', 0, 0, '55667789', 'kap@gmail.com', NULL, '', 'yaounde', '', '', 'Afghanistan', '0.00', 'Active', '', NULL, '', 'ibLJRKHoI8Qfk', 'me73qyn4f6i48lyr26z3b3899f833e15bfcc604cf880c8a0dad7', '', '', '', '', '', '', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, 'DESKTOP-V58I9E2', NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, '::1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, 'en'),
(39, 'kp campany', '', '', 'Douala,bepanda', '', 0, 0, '+2376668907', 'ro7@gmail.com', NULL, '', 'douala', '', 'B.P. 15398', 'Cameroon', '0.00', 'Active', '', NULL, '', 'ibLJRKHoI8Qfk', 'k9x8g35vv1i2zktmpk0h0b681edab2402379024fa678a63ce6f5', '', '', '', '', '', '', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, 'DESKTOP-V58I9E2', NULL, NULL, '', 0, NULL, NULL, NULL, NULL, NULL, '::1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, 'en'),
(40, 'kingsleylogistics', '', '', '', '', 0, 0, '1232545565', 'roland@gmail.com', NULL, '', 'Douala', '', 'B.P. 15398', 'Cameroon', '0.00', 'Active', '12', NULL, '', 'ibLJRKHoI8Qfk', '', '', '', '', '', '', '', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, 'DESKTOP-V58I9E2', NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, '::1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, 'en'),
(41, 'raoultrading', '', '', '', '', 0, 0, '', 'raoultrading@gmail.com', NULL, '', '', '', '', '', '0.00', 'Active', '', NULL, '', 'ibLJRKHoI8Qfk', 'sfitbcls3elqmk6shxp26f5abd9e52c6379acf61fab429849370', '', '', '', '', '', '', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, 'DESKTOP-V58I9E2', NULL, NULL, '', 0, NULL, NULL, NULL, NULL, NULL, '::1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, 'en'),
(42, 'kp', '', '', '', '', 0, 0, '', 'kp@gmail.com', NULL, '', '', '', '', '', '0.00', 'Active', '', NULL, '', 'ibLJRKHoI8Qfk', '2e59b2jr2ohacg6clqlae9ecb2fc358471c10c2a360bfabb33c3', '', '', '', '', '', '', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, 'DESKTOP-V58I9E2', NULL, NULL, '', 0, NULL, NULL, NULL, NULL, NULL, '::1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, 'en'),
(44, 'kp campany', 'kp', 'rolo', '', '', 0, 0, '455555', 'rola7@gmail.com', NULL, '', '', '', '', 'Cameroon', '0.00', 'Active', '45', NULL, '', 'ibLJRKHoI8Qfk', 'o8pob0abpl5eqlsj3pb3d6c62f79883cbb55b6451b06e9468d96', '', '', '', '', '', '', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, 'DESKTOP-V58I9E2', NULL, NULL, '', 0, NULL, NULL, NULL, NULL, NULL, '::1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, 'en'),
(48, 'uhhhh', 'fullstack', 'roland', 'uhhhh', '', 0, 1, '8887452', 'roso@gmail.com', NULL, '', 'yaounde', '', 'ee', 'United States', '0.00', 'Active', '5522', NULL, '', '', '', '', '', '', '', '', '', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, '2022-11-08 04:04:09', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, NULL, '', '', '', NULL, 'en'),
(49, 'the', 'fullstack', 'test', 'the', '', 0, 1, '456', 'testlsp@gmail.com', NULL, '', 'douala', '', '55', 'United States', '0.00', 'Active', '', NULL, '', '', '', '', '', '', '', '', '', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, '2022-11-08 04:10:12', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, NULL, '', '', '', NULL, 'en'),
(50, 'test', 'fullstack', 'roland', '', '', 0, 1, '555555', 'k@mail.com', NULL, '', '', '', '', '', '0.00', 'Active', '5522', NULL, '', '', '', '', '', '', '', '', '', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, '2022-11-08 04:15:51', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, NULL, '', '', '', NULL, 'en'),
(51, 'rol', 'dd', 'ddd', '', '', 0, 1, '5555', 'ddd@gmail.com', NULL, '', '', '', '', 'Aland Islands', '0.00', 'Active', '5555', NULL, '', 'ibHYFYNIfPoZg', '', '', '', '', '', '', '', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, '2022-11-08 05:41:37', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, NULL, 'uqtlh5ibslayk1xxsh3bih75z0bqwp', 'er8qfny4m8tclib3hm9kto2aubieed', '3fv7sry1rdehpd4slcoyun91jpbvl8', NULL, 'en'),
(52, 'afm', '', '', '', '', 0, 0, '', 'afmroland@gmail.com', NULL, '', '', '', '', '', '0.00', 'Active', '', NULL, '', 'ibLJRKHoI8Qfk', '', '', '', '', '', '', '', NULL, NULL, NULL, NULL, 0, NULL, 'o0a06dactdm5hikomtpe521668441212', NULL, NULL, NULL, NULL, 'DESKTOP-V58I9E2', NULL, NULL, '', 0, NULL, NULL, NULL, NULL, NULL, '::1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, 'en'),
(53, 'kingue', '', '', '', '', 0, 0, '', 'kingue@lol.cm', NULL, '', '', '', '', '', '0.00', 'Active', '', NULL, '', 'ibLJRKHoI8Qfk', '', '', '', '', '', '', '', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, 'DESKTOP-V58I9E2', NULL, NULL, '', 0, NULL, NULL, NULL, NULL, NULL, '::1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, NULL, '', '', '', NULL, 'en'),
(54, 'kaps design', 'kapekem', 'fullstack', 'kaps design', '', 0, 1, '', 'fstack@gmai.com', NULL, '', 'yaounde', '', '', 'United Kingdom', '0.00', 'Active', '', NULL, '', '', '', '', '', '', '', '', '', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, '2022-11-15 07:39:18', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, NULL, '475r2xmpr8z6ag7vg99pqml654j32x', 'ty6hdrkljfgyrrmz4nmlbdibw0ndm5', 'jgov2yubnsu5dhkiaezwzg24igyt12', NULL, 'en'),
(55, 'abakartruking', 'siddick', 'aboubakar', 'abakartruking', '', 0, 1, '566859490', 'siddick@gmail.com', NULL, '', 'douala', '', '', '', '0.00', 'Active', '', NULL, '', 'ibLJRKHoI8Qfk', '', '', '', '', '', '', '', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, '2022-11-15 07:59:41', NULL, NULL, NULL, NULL, NULL, NULL, '', 0, 0, NULL, NULL, NULL, NULL, NULL, '45', 'fr'),
(56, 'Barker Rojas Plc', 'Samuel', 'Kirsten Tate', 'Barker Rojas Plc', '', 0, 1, '+1 (506) 853-6671', 'dugere@mailinator.com', NULL, '', 'At ut nesciunt rati', '', '84534', 'Qatar', '0.00', 'Active', '', NULL, '', '$2b$10$.vWJz4hX0TW5Z7hK.hYkB.JdXXiz7zceyJbPo3hm.jxtbTNp05oQi', '', '', '', '', '', '', '', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, '2022-11-27 04:00:53', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, NULL, '74l2yng16fvs0wmazl6tyjxxlf46ac', 'p0kjjr871kbglrrf8c1c5prapgb2lv', '1ge9q9vbn5td8zyquely5ekjblc9r8', NULL, 'en'),
(61, 'kp campany', 'fullstack', 'kapekem roland', 'Douala,bepanda', '', 0, 0, '+237680668907', 'abcde@gmail.com', NULL, '', 'douala', '', '5545665', 'Cameroon', '0.00', 'Active', '', NULL, '', 'ibLJRKHoI8Qfk', '', '', '', '', '', '', '', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, 'DESKTOP-V58I9E2', NULL, NULL, '', 0, NULL, NULL, NULL, NULL, NULL, '::1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', 0, 0, NULL, NULL, NULL, NULL, NULL, '1245', 'en'),
(62, 'Huber and Potter LLC', 'Sean', 'Myles Frank', 'Huber and Potter LLC', '', 0, 1, '+1 (247) 308-9298', 'quzobyza@mailinator.com', NULL, '', 'Minim quia consectet', '', '93120', 'Lebanon', '0.00', 'Active', '', NULL, '', 'ibCvzbrmJn8Ko', '', '', '', '', '', '', '', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, '2022-12-11 02:06:41', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, NULL, 'pat8iu9r10oqqqnnk9w8r0hd7hdvkq', 'zrj5fmus7zk7k138ww5h0hrtv8mhss', 'ihqwt8chsy7ebfvaqonkl3ngwpz7is', '62', 'en');

-- --------------------------------------------------------

--
-- Structure de la table `crm_accounts2`
--

DROP TABLE IF EXISTS `crm_accounts2`;
CREATE TABLE IF NOT EXISTS `crm_accounts2` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `account` varchar(200) CHARACTER SET utf8 DEFAULT NULL,
  `fname` varchar(100) CHARACTER SET utf8 NOT NULL,
  `lname` varchar(100) CHARACTER SET utf8 NOT NULL,
  `company` varchar(200) CHARACTER SET utf8 NOT NULL,
  `jobtitle` varchar(100) CHARACTER SET utf8 NOT NULL,
  `cid` int(11) NOT NULL,
  `o` int(11) NOT NULL DEFAULT '0',
  `phone` varchar(100) CHARACTER SET utf8 NOT NULL,
  `email` varchar(100) CHARACTER SET utf8 NOT NULL,
  `username` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `address` varchar(200) CHARACTER SET utf8 NOT NULL,
  `city` varchar(100) CHARACTER SET utf8 NOT NULL,
  `state` varchar(100) CHARACTER SET utf8 NOT NULL,
  `zip` varchar(100) CHARACTER SET utf8 NOT NULL,
  `country` varchar(100) CHARACTER SET utf8 NOT NULL,
  `balance` decimal(16,2) NOT NULL,
  `status` enum('Active','Inactive') CHARACTER SET utf8 NOT NULL DEFAULT 'Active',
  `notes` text CHARACTER SET utf8 NOT NULL,
  `options` text CHARACTER SET utf8,
  `tags` text CHARACTER SET utf8 NOT NULL,
  `password` text CHARACTER SET utf8 NOT NULL,
  `token` text CHARACTER SET utf8 NOT NULL,
  `ts` text CHARACTER SET utf8 NOT NULL,
  `img` varchar(100) CHARACTER SET utf8 NOT NULL,
  `web` varchar(200) CHARACTER SET utf8 NOT NULL,
  `facebook` varchar(100) CHARACTER SET utf8 NOT NULL,
  `google` varchar(100) CHARACTER SET utf8 NOT NULL,
  `linkedin` varchar(100) CHARACTER SET utf8 NOT NULL,
  `twitter` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `skype` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `tax_number` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `entity_number` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `currency` int(11) DEFAULT '0',
  `pmethod` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `autologin` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `lastlogin` datetime DEFAULT NULL,
  `lastloginip` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `stage` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `timezone` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `isp` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `lat` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `lon` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `gname` varchar(200) CHARACTER SET utf8 DEFAULT NULL,
  `gid` int(11) NOT NULL DEFAULT '0',
  `sid` varchar(200) CHARACTER SET utf8 DEFAULT NULL,
  `role` varchar(200) CHARACTER SET utf8 DEFAULT NULL,
  `country_code` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `country_idd` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `signed_up_by` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `signed_up_ip` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `dob` date DEFAULT NULL,
  `ct` varchar(200) CHARACTER SET utf8 DEFAULT NULL,
  `assistant` varchar(200) CHARACTER SET utf8 DEFAULT NULL,
  `asst_phone` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `second_email` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `second_phone` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `taxexempt` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `latefeeoveride` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `overideduenotices` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `separateinvoices` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `disableautocc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `billingcid` int(10) NOT NULL DEFAULT '0',
  `securityqid` int(10) NOT NULL DEFAULT '0',
  `securityqans` text CHARACTER SET utf8,
  `cardtype` varchar(200) CHARACTER SET utf8 DEFAULT NULL,
  `cardlastfour` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `cardnum` text CHARACTER SET utf8,
  `startdate` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `expdate` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `issuenumber` varchar(200) CHARACTER SET utf8 DEFAULT NULL,
  `bankname` varchar(200) CHARACTER SET utf8 DEFAULT NULL,
  `banktype` varchar(200) CHARACTER SET utf8 DEFAULT NULL,
  `bankcode` varchar(200) CHARACTER SET utf8 DEFAULT NULL,
  `bankacct` varchar(200) CHARACTER SET utf8 DEFAULT NULL,
  `gatewayid` int(10) NOT NULL DEFAULT '0',
  `language` text CHARACTER SET utf8,
  `pwresetkey` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `emailoptout` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `pwresetexpiry` datetime DEFAULT NULL,
  `c1` varchar(200) CHARACTER SET utf8 DEFAULT NULL,
  `c2` varchar(200) CHARACTER SET utf8 DEFAULT NULL,
  `c3` varchar(200) CHARACTER SET utf8 DEFAULT NULL,
  `c4` varchar(200) CHARACTER SET utf8 DEFAULT NULL,
  `c5` varchar(200) CHARACTER SET utf8 DEFAULT NULL,
  `is_email_verified` int(1) NOT NULL DEFAULT '0',
  `is_phone_veirifed` int(1) NOT NULL DEFAULT '0',
  `photo_id_type` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `photo_id` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `picture_permit_token` varchar(255) DEFAULT NULL,
  `picture_of_truck_token` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=33 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `crm_accounts2`
--

INSERT INTO `crm_accounts2` (`id`, `account`, `fname`, `lname`, `company`, `jobtitle`, `cid`, `o`, `phone`, `email`, `username`, `address`, `city`, `state`, `zip`, `country`, `balance`, `status`, `notes`, `options`, `tags`, `password`, `token`, `ts`, `img`, `web`, `facebook`, `google`, `linkedin`, `twitter`, `skype`, `tax_number`, `entity_number`, `currency`, `pmethod`, `autologin`, `lastlogin`, `lastloginip`, `stage`, `timezone`, `isp`, `lat`, `lon`, `gname`, `gid`, `sid`, `role`, `country_code`, `country_idd`, `signed_up_by`, `signed_up_ip`, `dob`, `ct`, `assistant`, `asst_phone`, `second_email`, `second_phone`, `taxexempt`, `latefeeoveride`, `overideduenotices`, `separateinvoices`, `disableautocc`, `billingcid`, `securityqid`, `securityqans`, `cardtype`, `cardlastfour`, `cardnum`, `startdate`, `expdate`, `issuenumber`, `bankname`, `banktype`, `bankcode`, `bankacct`, `gatewayid`, `language`, `pwresetkey`, `emailoptout`, `created_at`, `updated_at`, `pwresetexpiry`, `c1`, `c2`, `c3`, `c4`, `c5`, `is_email_verified`, `is_phone_veirifed`, `photo_id_type`, `photo_id`, `picture_permit_token`, `picture_of_truck_token`) VALUES
(17, 'le pacha', '', '', '', '', 0, 1, '45786411', 'lopache@gmail.com', NULL, '657885', 'yaounde', '', '', '', '0.00', 'Active', 'C', NULL, '', 'ibHYFYNIfPoZg', 'yosilp0l23z38vt2vudg5169550f34b3a289ef68d0a9decf9d0e', '', '', '', '', '', '', NULL, NULL, NULL, NULL, 1, NULL, 'c91fkm2y5k3pmi33p7ky171667388302', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, '2022-11-01 11:29:06', NULL, NULL, '', '', NULL, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL),
(19, 'rolandtracking', '', '', '', '', 0, 0, '789995566', 'ka@gmail.com', NULL, '126', 'douala', '', '', '', '0.00', 'Active', 'B', NULL, 'edhwbjm,n', 'ibHYFYNIfPoZg', '', '', '', '', '', '', '', NULL, NULL, NULL, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, 'DESKTOP-V58I9E2', NULL, NULL, '', 0, NULL, NULL, NULL, NULL, NULL, '::1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL),
(20, 'kpk', '', '', '', '', 0, 0, '', 'kpk@gmail.com', NULL, '', '', '', '', '', '0.00', 'Active', '', NULL, '', 'ibHYFYNIfPoZg', '', '', '', '', '', '', '', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, 'DESKTOP-V58I9E2', NULL, NULL, '', 0, NULL, NULL, NULL, NULL, NULL, '::1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL),
(18, 'bm tracking', '', '', '', '', 0, 1, '+237680668907', 'rolandkp7@gmail.com', NULL, 'Douala,bepanda', 'Douala', '', '', '', '0.00', 'Active', 'B', NULL, '', 'ibLJRKHoI8Qfk', '', '', '', '', '', '', '', NULL, NULL, NULL, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, '2022-11-02 07:37:57', NULL, NULL, '', '', NULL, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL),
(29, 'rolandtracking', '', '', '', '', 0, 0, '', 'aboubakar@gmail.com', NULL, '', '', '', '', '', '0.00', 'Active', '', NULL, '', 'ibLJRKHoI8Qfk', 'md8ffsfro8qoh3t9utqm46509e1671203f565dfe14ded6e58241', '', '', '', '', '', '', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, 'DESKTOP-V58I9E2', NULL, NULL, '', 0, NULL, NULL, NULL, NULL, NULL, '::1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL),
(27, 'admin', '', '', '', '', 0, 1, '5555', 'kingue@lol.vf', NULL, 'ici', 'lol', '', '', 'Aland Islands', '0.00', 'Active', 'B', NULL, 'Chandigarh', 'ibLJRKHoI8Qfk', 'k9vpfprqe7f7k33w2efm0d339cc9ca7286d0f31023e1c31584fe', '', '', '', '', '', '', NULL, NULL, NULL, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, '2022-11-08 08:17:45', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, NULL, 'p3g83b57wtn6qs1pkpey38p8ed287i', 'ur1wbkx9a2fwy09pv8pzipjbd6pd84'),
(28, 'fulllstack.com', '', '', 'fulllstack.com', '', 0, 1, '', 'roott@gmail.com', NULL, '1234', 'yaounde', '', '', '', '0.00', 'Active', '', NULL, '', 'ibHYFYNIfPoZg', '', '', '', '', '', '', '', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, '2022-11-09 06:18:31', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, NULL, 'ntnrzmhiol0ed5xjbquohw6asisghu', 'rhaolrn08tqtub7y6ugwjw6bph5xut'),
(30, 'raoultrading', '', '', '', '', 0, 0, '', 'dd@gmail11.com', NULL, '', '', '', '', '', '0.00', 'Active', '', NULL, '', 'ibLJRKHoI8Qfk', '', '', '', '', '', '', '', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, 'DESKTOP-V58I9E2', NULL, NULL, '', 0, NULL, NULL, NULL, NULL, NULL, '::1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL),
(31, 'admin', 'fname', 'fname', '', '', 0, 0, '555545544ll522144', 'kingue@lol.vff7ll44545454', NULL, '', '', '', '', '', '0.00', 'Active', '', NULL, '', 'ibLJRKHoI8Qfk', '', '', '', '', '', '', '', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, '2022-12-06 11:07:55', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL),
(32, 'admin', 'fname', '', '', '', 0, 0, '555545544ll522144vv', 'kingue@lol.vff7ll44545454v', NULL, '', '', '', '', '', '0.00', 'Active', '', NULL, '', 'ibLJRKHoI8Qfk', '', '', '', '', '', '', '', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, '2022-12-06 11:25:11', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, NULL, '', '');

-- --------------------------------------------------------

--
-- Structure de la table `crm_accounts_1`
--

DROP TABLE IF EXISTS `crm_accounts_1`;
CREATE TABLE IF NOT EXISTS `crm_accounts_1` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `account` varchar(200) CHARACTER SET utf8 DEFAULT NULL,
  `fname` varchar(100) CHARACTER SET utf8 NOT NULL,
  `lname` varchar(100) CHARACTER SET utf8 NOT NULL,
  `company` varchar(200) CHARACTER SET utf8 NOT NULL,
  `jobtitle` varchar(100) CHARACTER SET utf8 NOT NULL,
  `cid` int(11) NOT NULL,
  `o` int(11) NOT NULL DEFAULT '0',
  `phone` varchar(100) CHARACTER SET utf8 NOT NULL,
  `email` varchar(100) CHARACTER SET utf8 NOT NULL,
  `username` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `address` varchar(200) CHARACTER SET utf8 NOT NULL,
  `city` varchar(100) CHARACTER SET utf8 NOT NULL,
  `state` varchar(100) CHARACTER SET utf8 NOT NULL,
  `zip` varchar(100) CHARACTER SET utf8 NOT NULL,
  `country` varchar(100) CHARACTER SET utf8 NOT NULL,
  `balance` decimal(16,2) NOT NULL,
  `status` enum('Active','Inactive') CHARACTER SET utf8 NOT NULL DEFAULT 'Active',
  `notes` text CHARACTER SET utf8 NOT NULL,
  `options` text CHARACTER SET utf8,
  `tags` text CHARACTER SET utf8 NOT NULL,
  `password` text CHARACTER SET utf8 NOT NULL,
  `token` text CHARACTER SET utf8 NOT NULL,
  `ts` text CHARACTER SET utf8 NOT NULL,
  `img` varchar(100) CHARACTER SET utf8 NOT NULL,
  `web` varchar(200) CHARACTER SET utf8 NOT NULL,
  `facebook` varchar(100) CHARACTER SET utf8 NOT NULL,
  `google` varchar(100) CHARACTER SET utf8 NOT NULL,
  `linkedin` varchar(100) CHARACTER SET utf8 NOT NULL,
  `twitter` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `skype` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `tax_number` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `entity_number` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `currency` int(11) DEFAULT '0',
  `pmethod` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `autologin` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `lastlogin` datetime DEFAULT NULL,
  `lastloginip` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `stage` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `timezone` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `isp` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `lat` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `lon` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `gname` varchar(200) CHARACTER SET utf8 DEFAULT NULL,
  `gid` int(11) NOT NULL DEFAULT '0',
  `sid` varchar(200) CHARACTER SET utf8 DEFAULT NULL,
  `role` varchar(200) CHARACTER SET utf8 DEFAULT NULL,
  `country_code` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `country_idd` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `signed_up_by` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `signed_up_ip` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `dob` date DEFAULT NULL,
  `ct` varchar(200) CHARACTER SET utf8 DEFAULT NULL,
  `assistant` varchar(200) CHARACTER SET utf8 DEFAULT NULL,
  `asst_phone` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `second_email` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `second_phone` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `taxexempt` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `latefeeoveride` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `overideduenotices` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `separateinvoices` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `disableautocc` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `billingcid` int(10) NOT NULL DEFAULT '0',
  `securityqid` int(10) NOT NULL DEFAULT '0',
  `securityqans` text CHARACTER SET utf8,
  `cardtype` varchar(200) CHARACTER SET utf8 DEFAULT NULL,
  `cardlastfour` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `cardnum` text CHARACTER SET utf8,
  `startdate` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `expdate` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `issuenumber` varchar(200) CHARACTER SET utf8 DEFAULT NULL,
  `bankname` varchar(200) CHARACTER SET utf8 DEFAULT NULL,
  `banktype` varchar(200) CHARACTER SET utf8 DEFAULT NULL,
  `bankcode` varchar(200) CHARACTER SET utf8 DEFAULT NULL,
  `bankacct` varchar(200) CHARACTER SET utf8 DEFAULT NULL,
  `gatewayid` int(10) NOT NULL DEFAULT '0',
  `language` text CHARACTER SET utf8,
  `pwresetkey` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `emailoptout` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `pwresetexpiry` datetime DEFAULT NULL,
  `c1` varchar(200) CHARACTER SET utf8 DEFAULT NULL,
  `c2` varchar(200) CHARACTER SET utf8 DEFAULT NULL,
  `c3` varchar(200) CHARACTER SET utf8 DEFAULT NULL,
  `c4` varchar(200) CHARACTER SET utf8 DEFAULT NULL,
  `c5` varchar(200) CHARACTER SET utf8 DEFAULT NULL,
  `is_email_verified` int(1) NOT NULL DEFAULT '0',
  `is_phone_veirifed` int(1) NOT NULL DEFAULT '0',
  `photo_id_type` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `photo_id` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `user_lang` varchar(50) NOT NULL DEFAULT 'en',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=26 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `crm_accounts_1`
--

INSERT INTO `crm_accounts_1` (`id`, `account`, `fname`, `lname`, `company`, `jobtitle`, `cid`, `o`, `phone`, `email`, `username`, `address`, `city`, `state`, `zip`, `country`, `balance`, `status`, `notes`, `options`, `tags`, `password`, `token`, `ts`, `img`, `web`, `facebook`, `google`, `linkedin`, `twitter`, `skype`, `tax_number`, `entity_number`, `currency`, `pmethod`, `autologin`, `lastlogin`, `lastloginip`, `stage`, `timezone`, `isp`, `lat`, `lon`, `gname`, `gid`, `sid`, `role`, `country_code`, `country_idd`, `signed_up_by`, `signed_up_ip`, `dob`, `ct`, `assistant`, `asst_phone`, `second_email`, `second_phone`, `taxexempt`, `latefeeoveride`, `overideduenotices`, `separateinvoices`, `disableautocc`, `billingcid`, `securityqid`, `securityqans`, `cardtype`, `cardlastfour`, `cardnum`, `startdate`, `expdate`, `issuenumber`, `bankname`, `banktype`, `bankcode`, `bankacct`, `gatewayid`, `language`, `pwresetkey`, `emailoptout`, `created_at`, `updated_at`, `pwresetexpiry`, `c1`, `c2`, `c3`, `c4`, `c5`, `is_email_verified`, `is_phone_veirifed`, `photo_id_type`, `photo_id`, `user_lang`) VALUES
(21, 'afm', '', '', '', '', 0, 0, '4328545666', 'afm@gmail.com', NULL, 'douala', 'doala', '', '', '', '0.00', 'Active', '', NULL, '', 'ibLJRKHoI8Qfk', '', '', '', '', '', '', '', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, 'DESKTOP-V58I9E2', NULL, NULL, '', 0, NULL, NULL, NULL, NULL, NULL, '::1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, NULL, 'en'),
(15, 'deposit account', '', '', '', '', 0, 1, '556677898908', 'root@gmail.com', NULL, 'douala', 'yaounde', '', '', 'United Kingdom', '0.00', 'Active', '', NULL, '', 'ibLJRKHoI8Qfk', '', '', '', '', '', '', '', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, '2022-11-01 12:20:18', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, NULL, 'en'),
(16, 'kingue', '', '', '', '', 0, 1, '8888999666', 'kingue@lol.vf', NULL, 'ici', 'lol', '', '', 'United Arab Emirates', '0.00', 'Active', '', NULL, '', 'ibLJRKHoI8Qfk', '', '', '', '', '', '', '', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, '2022-11-02 07:59:25', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, NULL, 'en'),
(17, 'Aimetracking', '', '', '', '', 0, 1, '4755666', 'aime@gmai.com', NULL, 'Douala,bepanda', 'Douala', '', '', 'Cameroon', '0.00', 'Active', '', NULL, '', 'ibLJRKHoI8Qfk', 'rve62x2ces4fn2qmp24t5dfff52635161dbdb6c41ab37b5475bc', '', '', '', '', '', '', NULL, NULL, NULL, NULL, 0, NULL, 'nywqdr2i52pjfgvrbxg4171667481613', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, '2022-11-03 09:16:38', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, NULL, 'fr'),
(22, 'abc', '', '', '', '', 0, 0, '', 'ab@yahoo.fr', NULL, '', '', '', '', '', '0.00', 'Active', '', NULL, '', 'ibLJRKHoI8Qfk', 'janu8m3j3yr81ig7s05i936ed3b82aa7aed50458d90cd9ed368a', '', '', '', '', '', '', NULL, NULL, NULL, NULL, 0, NULL, '3n9orqx4hi0iumcuem5y221668441346', NULL, NULL, NULL, NULL, 'DESKTOP-V58I9E2', NULL, NULL, '', 0, NULL, NULL, NULL, NULL, NULL, '::1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, NULL, 'en'),
(18, 'raoultrading', '', '', '', '', 0, 1, '86555555', 'raoultrading@gmail.com', NULL, 'Douala,bepanda', 'Douala', '', '', 'Cameroon', '0.00', 'Active', '', NULL, '', 'ibLJRKHoI8Qfk', '', '', '', '', '', '', '', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, '2022-11-04 08:29:56', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, NULL, 'en'),
(19, 'kp campany', '', '', 'kingue', '', 25, 0, '68888888', 'kpk@gmail.com', NULL, 'douala', 'uuhyuhy', '', '', 'Cameroon', '0.00', 'Active', '', NULL, '', 'ibLJRKHoI8Qfk', '', '', '', '', '', '', '', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, 'DESKTOP-V58I9E2', NULL, NULL, '', 0, NULL, NULL, NULL, NULL, NULL, '::1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, NULL, 'en'),
(20, 'abc', '', '', '', '', 0, 0, '6888888888', 'abc@yahoo.fr', NULL, 'douala', 'douala', '', '', 'Cameroon', '0.00', 'Active', '', NULL, '', 'ibLJRKHoI8Qfk', 'hclvv84uunts6ymx8kh5cb86486a3b58b81849ec7962a14a00a4', '', '', '', '', '', '', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, 'DESKTOP-V58I9E2', NULL, NULL, '', 0, NULL, NULL, NULL, NULL, NULL, '::1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, NULL, 'en'),
(23, 'Clarke Rosales LLC', '', '', '', '', 0, 1, 'Hooper Avila Co', 'nywu@mailinator.com', NULL, 'Consequatur provide', 'Et unde amet eaque', '', '', 'gguuuhjjkkj', '0.00', 'Active', '', NULL, '', 'ibLJRKHoI8Qfk', '2wedw84tcquonluew1o94a45d0833ab3a4d4b3f97c061390e66e', '', '', '', '', '', '', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, '2022-11-27 03:48:16', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, NULL, 'en'),
(24, 'admin', 'fname', 'fname', '', '', 0, 0, '555545544ll522', 'kingue@lol.vff7ll44', NULL, '', '', '', '', '', '0.00', 'Active', '', NULL, '', 'ibLJRKHoI8Qfk', '', '', '', '', '', '', '', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, '2022-12-06 10:42:32', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, NULL, 'en'),
(25, 'admin', 'fname', 'fname', '', '', 0, 0, '555545544ll522144', 'kingue@lol.vff7ll44545454', NULL, '', '', '', '', '', '0.00', 'Active', '', NULL, '', 'ibLJRKHoI8Qfk', '', '', '', '', '', '', '', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, '2022-12-06 10:56:36', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, NULL, 'en');

-- --------------------------------------------------------

--
-- Structure de la table `crm_customfields`
--

DROP TABLE IF EXISTS `crm_customfields`;
CREATE TABLE IF NOT EXISTS `crm_customfields` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `ctype` text,
  `relid` int(10) NOT NULL DEFAULT '0',
  `fieldname` text,
  `fieldtype` text,
  `description` text,
  `fieldoptions` text,
  `regexpr` text,
  `adminonly` text,
  `required` text,
  `showorder` text,
  `showinvoice` text,
  `sorder` int(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `crm_customfieldsvalues`
--

DROP TABLE IF EXISTS `crm_customfieldsvalues`;
CREATE TABLE IF NOT EXISTS `crm_customfieldsvalues` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `fieldid` int(10) NOT NULL,
  `relid` int(10) NOT NULL,
  `fvalue` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `crm_groups`
--

DROP TABLE IF EXISTS `crm_groups`;
CREATE TABLE IF NOT EXISTS `crm_groups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `gname` varchar(200) DEFAULT NULL,
  `color` varchar(50) DEFAULT NULL,
  `discount` varchar(50) DEFAULT NULL,
  `parent` varchar(200) DEFAULT NULL,
  `pid` int(10) DEFAULT NULL,
  `exempt` text,
  `description` text,
  `separateinvoices` text,
  `sorder` int(10) DEFAULT NULL,
  `c1` varchar(200) DEFAULT NULL,
  `c2` varchar(200) DEFAULT NULL,
  `c3` varchar(200) DEFAULT NULL,
  `c4` varchar(200) DEFAULT NULL,
  `c5` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `crm_groups`
--

INSERT INTO `crm_groups` (`id`, `gname`, `color`, `discount`, `parent`, `pid`, `exempt`, `description`, `separateinvoices`, `sorder`, `c1`, `c2`, `c3`, `c4`, `c5`) VALUES
(1, 'nkjnk', '', '', '', 0, '', '', '', 2, '', '', '', '', ''),
(2, 'hhhh', '', '', '', 0, '', '', '', 1, '', '', '', '', ''),
(3, 'kapsenterprise', '', '', '', 0, '', '', '', 3, '', '', '', '', ''),
(4, 'kmr enterpris', '', '', '', 0, '', '', '', 0, '', '', '', '', '');

-- --------------------------------------------------------

--
-- Structure de la table `crm_industries`
--

DROP TABLE IF EXISTS `crm_industries`;
CREATE TABLE IF NOT EXISTS `crm_industries` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `industry` varchar(200) DEFAULT NULL,
  `is_active` int(1) NOT NULL DEFAULT '1',
  `is_default` int(1) NOT NULL DEFAULT '0',
  `sorder` int(11) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `crm_industries`
--

INSERT INTO `crm_industries` (`id`, `industry`, `is_active`, `is_default`, `sorder`, `created_at`, `updated_at`) VALUES
(1, 'Agriculture', 1, 0, 0, NULL, NULL),
(2, 'Apparel', 1, 0, 0, NULL, NULL),
(3, 'Banking', 1, 0, 0, NULL, NULL),
(4, 'Biotechnology', 1, 0, 0, NULL, NULL),
(5, 'Chemicals', 1, 0, 0, NULL, NULL),
(6, 'Communications', 1, 0, 0, NULL, NULL),
(7, 'Construction', 1, 0, 0, NULL, NULL),
(8, 'Consulting', 1, 0, 0, NULL, NULL),
(9, 'Education', 1, 0, 0, NULL, NULL),
(10, 'Electronics', 1, 0, 0, NULL, NULL),
(11, 'Energy', 1, 0, 0, NULL, NULL),
(12, 'Engineering', 1, 0, 0, NULL, NULL),
(13, 'Entertainment', 1, 0, 0, NULL, NULL),
(14, 'Environmental', 1, 0, 0, NULL, NULL),
(15, 'Finance', 1, 0, 0, NULL, NULL),
(16, 'Food & Beverage', 1, 0, 0, NULL, NULL),
(17, 'Government', 1, 0, 0, NULL, NULL),
(18, 'Healthcare', 1, 0, 0, NULL, NULL),
(19, 'Hospitality', 1, 0, 0, NULL, NULL),
(20, 'Insurance', 1, 0, 0, NULL, NULL),
(21, 'Machinery', 1, 0, 0, NULL, NULL),
(22, 'Manufacturing', 1, 0, 0, NULL, NULL),
(23, 'Media', 1, 0, 0, NULL, NULL),
(24, 'Not For Profit', 1, 0, 0, NULL, NULL),
(25, 'Other', 1, 0, 0, NULL, NULL),
(26, 'Recreation', 1, 0, 0, NULL, NULL),
(27, 'Retail', 1, 0, 0, NULL, NULL),
(28, 'Shipping', 1, 0, 0, NULL, NULL),
(29, 'Technology', 1, 0, 0, NULL, NULL),
(30, 'Telecommunications', 1, 0, 0, NULL, NULL),
(31, 'Transportation', 1, 0, 0, NULL, NULL),
(32, 'Utilities', 1, 0, 0, NULL, NULL);

-- --------------------------------------------------------

--
-- Structure de la table `crm_leads`
--

DROP TABLE IF EXISTS `crm_leads`;
CREATE TABLE IF NOT EXISTS `crm_leads` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `secret` varchar(200) DEFAULT NULL,
  `status` varchar(200) DEFAULT NULL,
  `o` varchar(200) DEFAULT NULL,
  `oid` int(11) NOT NULL DEFAULT '0',
  `salutation` varchar(200) DEFAULT NULL,
  `first_name` varchar(200) DEFAULT NULL,
  `middle_name` varchar(200) DEFAULT NULL,
  `last_name` varchar(200) DEFAULT NULL,
  `suffix` varchar(200) DEFAULT NULL,
  `title` varchar(200) DEFAULT NULL,
  `company` varchar(200) DEFAULT NULL,
  `company_id` int(11) NOT NULL DEFAULT '0',
  `website` varchar(200) DEFAULT NULL,
  `industry` varchar(200) DEFAULT NULL,
  `employees` varchar(200) DEFAULT NULL,
  `email` varchar(200) DEFAULT NULL,
  `phone` varchar(50) DEFAULT NULL,
  `color` varchar(20) DEFAULT NULL,
  `source` varchar(200) DEFAULT NULL,
  `added_from` varchar(200) DEFAULT NULL,
  `mobile` varchar(200) DEFAULT NULL,
  `address` varchar(200) DEFAULT NULL,
  `street` varchar(200) DEFAULT NULL,
  `city` varchar(200) DEFAULT NULL,
  `state` varchar(200) DEFAULT NULL,
  `zip` varchar(50) DEFAULT NULL,
  `country` varchar(50) DEFAULT NULL,
  `created_by` varchar(200) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `updated_by` varchar(200) DEFAULT NULL,
  `viewed_at` datetime DEFAULT NULL,
  `cid` int(11) NOT NULL DEFAULT '0',
  `aid` int(11) NOT NULL DEFAULT '0',
  `iid` int(11) NOT NULL DEFAULT '0',
  `rid` int(11) NOT NULL DEFAULT '0',
  `sorder` int(11) NOT NULL DEFAULT '0',
  `assigned` int(11) NOT NULL DEFAULT '0',
  `last_contact` datetime DEFAULT NULL,
  `last_contact_by` varchar(200) DEFAULT NULL,
  `date_converted` datetime DEFAULT NULL,
  `public` int(1) NOT NULL DEFAULT '0',
  `ratings` varchar(50) DEFAULT NULL,
  `flag` int(1) NOT NULL DEFAULT '0',
  `lost` int(1) NOT NULL DEFAULT '0',
  `junk` int(1) NOT NULL DEFAULT '0',
  `trash` int(1) NOT NULL DEFAULT '0',
  `archived` int(1) NOT NULL DEFAULT '0',
  `memo` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `crm_lead_sources`
--

DROP TABLE IF EXISTS `crm_lead_sources`;
CREATE TABLE IF NOT EXISTS `crm_lead_sources` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sname` varchar(200) DEFAULT NULL,
  `is_active` int(1) NOT NULL DEFAULT '1',
  `is_default` int(1) NOT NULL DEFAULT '1',
  `sorder` int(11) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `crm_lead_sources`
--

INSERT INTO `crm_lead_sources` (`id`, `sname`, `is_active`, `is_default`, `sorder`, `created_at`, `updated_at`) VALUES
(1, 'Advertisement', 1, 1, 0, NULL, NULL),
(2, 'Customer Event', 1, 1, 0, NULL, NULL),
(3, 'Employee Referral', 1, 1, 0, NULL, NULL),
(4, 'Google AdWords', 1, 1, 0, NULL, NULL),
(5, 'Other', 1, 1, 0, NULL, NULL),
(6, 'Partner', 1, 1, 0, NULL, NULL),
(7, 'Purchased List', 1, 1, 0, NULL, NULL),
(8, 'Trade Show', 1, 1, 0, NULL, NULL),
(9, 'Webinar', 1, 1, 0, NULL, NULL),
(10, 'Website', 1, 1, 0, NULL, NULL),
(11, 'Facebook', 1, 1, 0, NULL, NULL);

-- --------------------------------------------------------

--
-- Structure de la table `crm_lead_status`
--

DROP TABLE IF EXISTS `crm_lead_status`;
CREATE TABLE IF NOT EXISTS `crm_lead_status` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sname` varchar(200) DEFAULT NULL,
  `is_active` int(1) NOT NULL DEFAULT '1',
  `is_default` int(1) NOT NULL DEFAULT '0',
  `is_converted` int(1) NOT NULL DEFAULT '0',
  `sorder` int(11) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `crm_lead_status`
--

INSERT INTO `crm_lead_status` (`id`, `sname`, `is_active`, `is_default`, `is_converted`, `sorder`, `created_at`, `updated_at`) VALUES
(1, 'Unqualified', 1, 0, 0, 0, NULL, NULL),
(2, 'New', 1, 1, 0, 0, NULL, NULL),
(3, 'Working', 1, 0, 0, 0, NULL, NULL),
(4, 'Nurturing', 1, 0, 0, 0, NULL, NULL),
(5, 'Qualified', 1, 0, 0, 0, NULL, NULL);

-- --------------------------------------------------------

--
-- Structure de la table `crm_salutations`
--

DROP TABLE IF EXISTS `crm_salutations`;
CREATE TABLE IF NOT EXISTS `crm_salutations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sname` varchar(200) DEFAULT NULL,
  `is_active` int(1) NOT NULL DEFAULT '1',
  `is_default` int(1) NOT NULL DEFAULT '0',
  `sorder` int(11) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `crm_salutations`
--

INSERT INTO `crm_salutations` (`id`, `sname`, `is_active`, `is_default`, `sorder`, `created_at`, `updated_at`) VALUES
(1, 'Mr.', 1, 0, 0, NULL, NULL),
(2, 'Ms.', 1, 0, 0, NULL, NULL),
(3, 'Mrs.', 1, 0, 0, NULL, NULL),
(4, 'Dr.', 1, 0, 0, NULL, NULL),
(5, 'Prof.', 1, 0, 0, NULL, NULL);

-- --------------------------------------------------------

--
-- Structure de la table `events`
--

DROP TABLE IF EXISTS `events`;
CREATE TABLE IF NOT EXISTS `events` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(50) NOT NULL DEFAULT '0',
  `text` varchar(50) NOT NULL DEFAULT '0',
  `link` varchar(50) NOT NULL DEFAULT '0',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `ib_doc_rel`
--

DROP TABLE IF EXISTS `ib_doc_rel`;
CREATE TABLE IF NOT EXISTS `ib_doc_rel` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rtype` varchar(100) NOT NULL DEFAULT 'contact',
  `rid` int(11) NOT NULL DEFAULT '0',
  `did` int(11) NOT NULL DEFAULT '0',
  `can_download` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `ib_doc_rel`
--

INSERT INTO `ib_doc_rel` (`id`, `rtype`, `rid`, `did`, `can_download`) VALUES
(1, 'contact', 26, 1, 0),
(2, 'contact', 26, 5, 0),
(3, 'contact', 3, 1, 0);

-- --------------------------------------------------------

--
-- Structure de la table `ib_invoice_access_log`
--

DROP TABLE IF EXISTS `ib_invoice_access_log`;
CREATE TABLE IF NOT EXISTS `ib_invoice_access_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `lid` int(11) NOT NULL DEFAULT '0',
  `cid` int(11) NOT NULL DEFAULT '0',
  `iid` int(11) NOT NULL DEFAULT '0',
  `company_id` int(11) NOT NULL DEFAULT '0',
  `customer` varchar(200) DEFAULT NULL,
  `ip` varchar(50) DEFAULT NULL,
  `browser` varchar(200) DEFAULT NULL,
  `referer` varchar(200) DEFAULT NULL,
  `city` varchar(200) DEFAULT NULL,
  `postal_code` varchar(50) DEFAULT NULL,
  `country` varchar(200) DEFAULT NULL,
  `country_iso` varchar(20) DEFAULT NULL,
  `viewed_at` varchar(200) DEFAULT NULL,
  `lat` varchar(100) DEFAULT NULL,
  `lon` varchar(100) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `notifications`
--

DROP TABLE IF EXISTS `notifications`;
CREATE TABLE IF NOT EXISTS `notifications` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_to_notify` int(11) DEFAULT NULL,
  `user_to_notify_table` varchar(50) NOT NULL DEFAULT '0',
  `user_who_fired_event` int(11) DEFAULT NULL,
  `user_who_fired_event_table` varchar(50) NOT NULL DEFAULT '0',
  `event_id` int(11) DEFAULT NULL,
  `seen_by_user` varchar(50) NOT NULL DEFAULT 'No',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `relations`
--

DROP TABLE IF EXISTS `relations`;
CREATE TABLE IF NOT EXISTS `relations` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `source_id` int(11) NOT NULL,
  `target_id` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `sys_accounts`
--

DROP TABLE IF EXISTS `sys_accounts`;
CREATE TABLE IF NOT EXISTS `sys_accounts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `account` varchar(100) NOT NULL,
  `description` varchar(200) NOT NULL,
  `balance` decimal(18,2) NOT NULL DEFAULT '0.00',
  `bank_name` varchar(200) DEFAULT NULL,
  `account_number` varchar(200) DEFAULT NULL,
  `currency` varchar(20) DEFAULT NULL,
  `branch` varchar(200) DEFAULT NULL,
  `address` varchar(200) DEFAULT NULL,
  `contact_person` varchar(200) DEFAULT NULL,
  `contact_phone` varchar(100) DEFAULT NULL,
  `website` varchar(200) DEFAULT NULL,
  `ib_url` varchar(200) DEFAULT NULL,
  `created` date DEFAULT NULL,
  `notes` text,
  `sorder` int(11) DEFAULT NULL,
  `e` varchar(200) DEFAULT NULL,
  `token` varchar(200) DEFAULT NULL,
  `status` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `sys_accounts`
--

INSERT INTO `sys_accounts` (`id`, `account`, `description`, `balance`, `bank_name`, `account_number`, `currency`, `branch`, `address`, `contact_person`, `contact_phone`, `website`, `ib_url`, `created`, `notes`, `sorder`, `e`, `token`, `status`) VALUES
(1, 'deposit account', 'for deposit', '3740644.00', '', '123456', '', '', '', '334445566', '33445566', '', '', '2022-09-13', '', 1, '', '', '');

-- --------------------------------------------------------

--
-- Structure de la table `sys_activity`
--

DROP TABLE IF EXISTS `sys_activity`;
CREATE TABLE IF NOT EXISTS `sys_activity` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cid` int(11) NOT NULL DEFAULT '0',
  `msg` text NOT NULL,
  `icon` varchar(100) NOT NULL DEFAULT '',
  `stime` varchar(50) NOT NULL,
  `sdate` date NOT NULL,
  `o` int(11) NOT NULL DEFAULT '0',
  `oname` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `sys_api`
--

DROP TABLE IF EXISTS `sys_api`;
CREATE TABLE IF NOT EXISTS `sys_api` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `label` text,
  `ip` text,
  `apikey` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `sys_api`
--

INSERT INTO `sys_api` (`id`, `label`, `ip`, `apikey`) VALUES
(1, 'export', '', '8p5sfjovosh574h5wzggxrpd5lu93o97o95mynfh'),
(2, 'kjkklnknl', '', '9jdvslyyul9edmc8xrfiyavqzjddsowq7san2kl3'),
(3, 'hello', '', 'qxzh1t05mdt5ekcz1gek69agmqa7ik11v5hhomot'),
(4, 'hhhjhjh', '', 'wrs96e76hera7jftt8b1hk3idcnplhncuyfz0nqk');

-- --------------------------------------------------------

--
-- Structure de la table `sys_appconfig`
--

DROP TABLE IF EXISTS `sys_appconfig`;
CREATE TABLE IF NOT EXISTS `sys_appconfig` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `setting` text NOT NULL,
  `value` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=139 DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `sys_appconfig`
--

INSERT INTO `sys_appconfig` (`id`, `setting`, `value`) VALUES
(1, 'CompanyName', 'Motodey'),
(29, 'theme', 'ibilling'),
(37, 'currency_code', 'FCFA'),
(56, 'language', 'en'),
(57, 'show-logo', '1'),
(58, 'nstyle', 'green'),
(63, 'dec_point', '.'),
(64, 'thousands_sep', ','),
(65, 'timezone', 'America/New_York'),
(66, 'country', 'United States'),
(67, 'country_code', 'US'),
(68, 'df', 'Y-m-d'),
(69, 'caddress', 'Motodey<br> 424 Grandview Avenue <br>Staten Island <br> NYC - 10301'),
(70, 'account_search', '1'),
(71, 'redirect_url', 'dashboard'),
(72, 'rtl', '0'),
(73, 'ckey', '0982995697'),
(74, 'networth_goal', '200000'),
(75, 'sysEmail', 'customercare@motodey.com'),
(76, 'url_rewrite', '0'),
(77, 'build', '4900'),
(78, 'animate', '0'),
(79, 'pdf_font', 'dejavusanscondensed'),
(80, 'accounting', '1'),
(81, 'invoicing', '1'),
(82, 'quotes', '1'),
(83, 'client_dashboard', '1'),
(84, 'contact_set_view_mode', 'search'),
(85, 'invoice_terms', ''),
(86, 'console_notify_invoice_created', '0'),
(87, 'i_driver', 'v2'),
(88, 'purchase_code', ''),
(89, 'c_cache', ''),
(90, 'mininav', '0'),
(91, 'hide_footer', '0'),
(92, 'design', 'default'),
(93, 'default_landing_page', 'login'),
(94, 'recaptcha', '0'),
(95, 'recaptcha_sitekey', ''),
(96, 'recaptcha_secretkey', ''),
(97, 'home_currency', 'USD'),
(98, 'currency_decimal_digits', 'true'),
(99, 'currency_symbol_position', 's'),
(100, 'thousand_separator_placement', '3'),
(101, 'dashboard', 'canvas'),
(102, 'header_scripts', ''),
(103, 'footer_scripts', ''),
(104, 'ib_key', 'vLBLfhA6DNi1R2MFHO8IvFWr4Cn9665eHUF+L/sqAKM='),
(105, 'ib_s', 'PNhjeZ0sOFF3JNfzT2mLxvNNKPeh6ltqpE+G5LVSDSvgp/z79Sco7W4tJEoXYIl8'),
(106, 'ib_u_t', '1672328645'),
(107, 'ib_u_a', '0'),
(108, 'momentLocale', 'en'),
(109, 'contentAnimation', 'animated fadeIn'),
(110, 'calendar', '1'),
(111, 'leads', '1'),
(112, 'tasks', '1'),
(113, 'orders', '1'),
(114, 'show_quantity_as', ''),
(115, 'gmap_api_key', ''),
(116, 'license_key', ''),
(117, 'local_key', ''),
(118, 'add_fund', '0'),
(119, 'add_fund_minimum_deposit', '100'),
(120, 'add_fund_maximum_deposit', '2500'),
(121, 'add_fund_maximum_balance', '25000'),
(122, 'add_fund_require_active_order', '0'),
(123, 'sales_target', '10000'),
(124, 'industry', 'default'),
(125, 'inventory', '1'),
(126, 'secondary_currency', ''),
(127, 'customer_custom_username', '0'),
(128, 'documents', '1'),
(129, 'projects', '1'),
(130, 'purchase', '1'),
(131, 'suppliers', '1'),
(132, 'support', '1'),
(133, 'hrm', '1'),
(134, 'companies', '1'),
(135, 'plugins', '1'),
(136, 'country_flag_code', 'us'),
(137, 'graph_primary_color', '2196f3'),
(138, 'graph_secondary_color', 'eb3c00');

-- --------------------------------------------------------

--
-- Structure de la table `sys_cart`
--

DROP TABLE IF EXISTS `sys_cart`;
CREATE TABLE IF NOT EXISTS `sys_cart` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `secret` varchar(100) DEFAULT NULL,
  `items` text,
  `total` decimal(16,2) NOT NULL DEFAULT '0.00',
  `discount` decimal(16,2) NOT NULL DEFAULT '0.00',
  `ip` varchar(100) DEFAULT NULL,
  `fullname` varchar(200) DEFAULT NULL,
  `phone` varchar(200) DEFAULT NULL,
  `email` varchar(200) DEFAULT NULL,
  `status` varchar(200) DEFAULT NULL,
  `browser` varchar(200) DEFAULT NULL,
  `country` varchar(200) DEFAULT NULL,
  `currency` varchar(200) DEFAULT NULL,
  `language` varchar(200) DEFAULT NULL,
  `coupon` varchar(200) DEFAULT NULL,
  `lat` varchar(50) DEFAULT NULL,
  `lon` varchar(50) DEFAULT NULL,
  `item_count` int(11) NOT NULL DEFAULT '0',
  `cid` int(11) NOT NULL DEFAULT '0',
  `aid` int(11) NOT NULL DEFAULT '0',
  `lid` int(11) NOT NULL DEFAULT '0',
  `currency_id` int(11) NOT NULL DEFAULT '0',
  `company_id` int(11) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `expiry` datetime DEFAULT NULL,
  `memo` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `sys_cats`
--

DROP TABLE IF EXISTS `sys_cats`;
CREATE TABLE IF NOT EXISTS `sys_cats` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `type` enum('Income','Expense') NOT NULL,
  `sorder` int(11) NOT NULL DEFAULT '0',
  `total_amount` decimal(16,4) DEFAULT '0.0000',
  `budget` decimal(16,4) DEFAULT '0.0000',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=71 DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `sys_cats`
--

INSERT INTO `sys_cats` (`id`, `name`, `type`, `sorder`, `total_amount`, `budget`, `created_at`, `updated_at`) VALUES
(14, 'Advertising', 'Expense', 1, '0.0000', '0.0000', NULL, NULL),
(15, 'Bank and Credit Card Interest', 'Expense', 23, '0.0000', '0.0000', NULL, NULL),
(16, 'Car and Truck', 'Expense', 24, '0.0000', '0.0000', NULL, NULL),
(17, 'Commissions and Fees', 'Expense', 25, '0.0000', '0.0000', NULL, NULL),
(18, 'Contract Labor', 'Expense', 26, '0.0000', '0.0000', NULL, NULL),
(19, 'Contributions', 'Expense', 27, '0.0000', '0.0000', NULL, NULL),
(20, 'Cost of Goods Sold', 'Expense', 28, '0.0000', '0.0000', NULL, NULL),
(21, 'Credit Card Interest', 'Expense', 29, '0.0000', '0.0000', NULL, NULL),
(22, 'Depreciation', 'Expense', 31, '0.0000', '0.0000', NULL, NULL),
(23, 'Dividend Payments', 'Expense', 32, '0.0000', '0.0000', NULL, NULL),
(24, 'Employee Benefit Programs', 'Expense', 33, '0.0000', '0.0000', NULL, NULL),
(25, 'Entertainment', 'Expense', 34, '0.0000', '0.0000', NULL, NULL),
(26, 'Gift', 'Expense', 35, '0.0000', '0.0000', NULL, NULL),
(27, 'Insurance', 'Expense', 36, '0.0000', '0.0000', NULL, NULL),
(28, 'Legal, Accountant &amp; Other Professional Services', 'Expense', 37, '0.0000', '0.0000', NULL, NULL),
(29, 'Meals', 'Expense', 38, '0.0000', '0.0000', NULL, NULL),
(30, 'Mortgage Interest', 'Expense', 39, '0.0000', '0.0000', NULL, NULL),
(31, 'Non-Deductible Expense', 'Expense', 40, '0.0000', '0.0000', NULL, NULL),
(33, 'Other Business Property Leasing', 'Expense', 22, '0.0000', '0.0000', NULL, NULL),
(34, 'Owner Draws', 'Expense', 21, '0.0000', '0.0000', NULL, NULL),
(35, 'Payroll Taxes', 'Expense', 8, '0.0000', '0.0000', NULL, NULL),
(37, 'Phone', 'Expense', 9, '0.0000', '0.0000', NULL, NULL),
(38, 'Postage', 'Expense', 10, '0.0000', '0.0000', NULL, NULL),
(39, 'Rent', 'Expense', 12, '0.0000', '0.0000', NULL, NULL),
(40, 'Repairs &amp; Maintenance', 'Expense', 11, '0.0000', '0.0000', NULL, NULL),
(41, 'Supplies', 'Expense', 13, '0.0000', '0.0000', NULL, NULL),
(42, 'Taxes and Licenses', 'Expense', 14, '0.0000', '0.0000', NULL, NULL),
(43, 'Transfer Funds', 'Expense', 15, '0.0000', '0.0000', NULL, NULL),
(44, 'Travel', 'Expense', 16, '0.0000', '0.0000', NULL, NULL),
(45, 'Utilities', 'Expense', 17, '0.0000', '0.0000', NULL, NULL),
(46, 'Vehicle, Machinery &amp; Equipment Rental or Leasing', 'Expense', 18, '0.0000', '0.0000', NULL, NULL),
(47, 'Wages', 'Expense', 19, '0.0000', '0.0000', NULL, NULL),
(48, 'Regular Income', 'Income', 1, '0.0000', '0.0000', NULL, NULL),
(49, 'Owner Contribution', 'Income', 12, '0.0000', '0.0000', NULL, NULL),
(50, 'Interest Income', 'Income', 11, '0.0000', '0.0000', NULL, NULL),
(51, 'Expense Refund', 'Income', 10, '0.0000', '0.0000', NULL, NULL),
(52, 'Other Income', 'Income', 9, '0.0000', '0.0000', NULL, NULL),
(53, 'Salary', 'Income', 8, '0.0000', '0.0000', NULL, NULL),
(54, 'Equities', 'Income', 7, '0.0000', '0.0000', NULL, NULL),
(55, 'Rent &amp; Royalties', 'Income', 6, '0.0000', '0.0000', NULL, NULL),
(56, 'Home equity', 'Income', 5, '0.0000', '0.0000', NULL, NULL),
(57, 'Part Time Work', 'Income', 3, '0.0000', '0.0000', NULL, NULL),
(58, 'Account Transfer', 'Income', 4, '0.0000', '0.0000', NULL, NULL),
(60, 'Health Care', 'Expense', 20, '0.0000', '0.0000', NULL, NULL),
(63, 'Loans', 'Expense', 30, '0.0000', '0.0000', NULL, NULL),
(64, 'Selling Software', 'Income', 2, '0.0000', '0.0000', NULL, NULL),
(65, 'Software Customization', 'Income', 13, '0.0000', '0.0000', NULL, NULL),
(66, 'Envato', 'Income', 0, '0.0000', '0.0000', NULL, NULL),
(67, 'Salary', 'Expense', 7, '0.0000', '0.0000', NULL, NULL),
(68, 'Paypal', 'Expense', 6, '0.0000', '0.0000', NULL, NULL),
(69, 'Office Equipment', 'Expense', 5, '0.0000', '0.0000', NULL, NULL),
(70, 'Staff Entertaining', 'Expense', 3, '0.0000', '0.0000', NULL, NULL);

-- --------------------------------------------------------

--
-- Structure de la table `sys_companies`
--

DROP TABLE IF EXISTS `sys_companies`;
CREATE TABLE IF NOT EXISTS `sys_companies` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `company_name` varchar(200) DEFAULT NULL,
  `url` varchar(200) DEFAULT NULL,
  `logo_url` varchar(200) DEFAULT NULL,
  `logo_path` varchar(200) DEFAULT NULL,
  `email` varchar(200) DEFAULT NULL,
  `phone` varchar(200) DEFAULT NULL,
  `emails` text,
  `phones` text,
  `tags` text,
  `description` text,
  `notes` text,
  `address1` varchar(200) DEFAULT NULL,
  `address2` varchar(200) DEFAULT NULL,
  `city` varchar(200) DEFAULT NULL,
  `state` varchar(200) DEFAULT NULL,
  `zip` varchar(50) DEFAULT NULL,
  `country` varchar(100) DEFAULT NULL,
  `source` varchar(200) DEFAULT NULL,
  `added_from` varchar(200) DEFAULT NULL,
  `o` varchar(200) DEFAULT NULL,
  `cid` int(11) NOT NULL DEFAULT '0',
  `aid` int(11) NOT NULL DEFAULT '0',
  `pid` int(11) NOT NULL DEFAULT '0',
  `oid` int(11) NOT NULL DEFAULT '0',
  `rid` int(11) NOT NULL DEFAULT '0',
  `assigned` int(11) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `created_by` varchar(200) DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `updated_by` varchar(200) DEFAULT NULL,
  `last_contact` datetime DEFAULT NULL,
  `last_contact_by` varchar(200) DEFAULT NULL,
  `ratings` varchar(50) DEFAULT NULL,
  `trash` int(1) NOT NULL DEFAULT '0',
  `archived` int(1) NOT NULL DEFAULT '0',
  `c1` text,
  `c2` text,
  `c3` text,
  `c4` text,
  `c5` text,
  `picture1_file_token` varchar(255) DEFAULT NULL,
  `picture2_file_token` varchar(255) DEFAULT NULL,
  `picture3_file_token` varchar(255) DEFAULT NULL,
  `lsr_id` int(11) DEFAULT NULL,
  `status` int(11) NOT NULL DEFAULT '1',
  `picture4_file_token` varchar(255) DEFAULT NULL,
  `delivery_time` varchar(255) DEFAULT NULL,
  `type_of_materials` varchar(255) DEFAULT NULL,
  `quantity` varchar(255) DEFAULT NULL,
  `weight` varchar(255) DEFAULT NULL,
  `observations` varchar(255) DEFAULT NULL,
  `delivery_location` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `sys_companies`
--

INSERT INTO `sys_companies` (`id`, `company_name`, `url`, `logo_url`, `logo_path`, `email`, `phone`, `emails`, `phones`, `tags`, `description`, `notes`, `address1`, `address2`, `city`, `state`, `zip`, `country`, `source`, `added_from`, `o`, `cid`, `aid`, `pid`, `oid`, `rid`, `assigned`, `created_at`, `created_by`, `updated_at`, `updated_by`, `last_contact`, `last_contact_by`, `ratings`, `trash`, `archived`, `c1`, `c2`, `c3`, `c4`, `c5`, `picture1_file_token`, `picture2_file_token`, `picture3_file_token`, `lsr_id`, `status`, `picture4_file_token`, `delivery_time`, `type_of_materials`, `quantity`, `weight`, `observations`, `delivery_location`) VALUES
(2, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, '', '', '', 21, 2, '', '00:07', 'Pouzzolan', '331', 'Omnis et similique u', 'Non consequuntur min', 'Quam necessitatibus'),
(3, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, '', '', '', 15, 2, '', '00:46', 'Pouzzolan', '403', 'Elit soluta quia vo', 'Rerum voluptas qui d', 'Magnam eos et sit u'),
(4, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, '', '', '', 17, 1, '', '23:36', 'Cement', '254', 'Dolores natus rem no', 'Ullamco temporibus v', 'Sit sunt iusto solut'),
(5, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 'zmzm7tqv6mv0zbjhyrfy6s1qzcjxum', 't8jbvpu1aq1wm7w5tqr303wx4yfsgo', '3tk4q1k5lmfeiw5nsqed9lcv7ab5gx', 23, 1, 'm5o4042j5lkdxk5azdbtu4farduglh', '18:58', 'Sand', '946', 'Corrupti cumque ull', 'Impedit aut omnis e', 'Tempor dolore facere');

-- --------------------------------------------------------

--
-- Structure de la table `sys_companies1`
--

DROP TABLE IF EXISTS `sys_companies1`;
CREATE TABLE IF NOT EXISTS `sys_companies1` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `company_name` varchar(200) CHARACTER SET utf8 DEFAULT NULL,
  `url` varchar(200) CHARACTER SET utf8 DEFAULT NULL,
  `logo_url` varchar(200) CHARACTER SET utf8 DEFAULT NULL,
  `logo_path` varchar(200) CHARACTER SET utf8 DEFAULT NULL,
  `email` varchar(200) CHARACTER SET utf8 DEFAULT NULL,
  `phone` varchar(200) CHARACTER SET utf8 DEFAULT NULL,
  `emails` text CHARACTER SET utf8,
  `phones` text CHARACTER SET utf8,
  `tags` text CHARACTER SET utf8,
  `description` text CHARACTER SET utf8,
  `notes` text CHARACTER SET utf8,
  `address1` varchar(200) CHARACTER SET utf8 DEFAULT NULL,
  `address2` varchar(200) CHARACTER SET utf8 DEFAULT NULL,
  `city` varchar(200) CHARACTER SET utf8 DEFAULT NULL,
  `state` varchar(200) CHARACTER SET utf8 DEFAULT NULL,
  `zip` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `country` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `source` varchar(200) CHARACTER SET utf8 DEFAULT NULL,
  `added_from` varchar(200) CHARACTER SET utf8 DEFAULT NULL,
  `o` varchar(200) CHARACTER SET utf8 DEFAULT NULL,
  `cid` int(11) NOT NULL DEFAULT '0',
  `aid` int(11) NOT NULL DEFAULT '0',
  `pid` int(11) NOT NULL DEFAULT '0',
  `oid` int(11) NOT NULL DEFAULT '0',
  `rid` int(11) NOT NULL DEFAULT '0',
  `assigned` int(11) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `created_by` varchar(200) CHARACTER SET utf8 DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `updated_by` varchar(200) CHARACTER SET utf8 DEFAULT NULL,
  `last_contact` datetime DEFAULT NULL,
  `last_contact_by` varchar(200) CHARACTER SET utf8 DEFAULT NULL,
  `ratings` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `trash` int(1) NOT NULL DEFAULT '0',
  `archived` int(1) NOT NULL DEFAULT '0',
  `c1` text CHARACTER SET utf8,
  `c2` text CHARACTER SET utf8,
  `c3` text CHARACTER SET utf8,
  `c4` text CHARACTER SET utf8,
  `c5` text CHARACTER SET utf8,
  `picture1_file_token` varchar(255) DEFAULT NULL,
  `picture2_file_token` varchar(222) DEFAULT NULL,
  `types_of_equipment` varchar(255) DEFAULT NULL,
  `pprice_per_hour` varchar(255) DEFAULT NULL,
  `lsr_id` int(11) DEFAULT NULL,
  `other_type` varchar(255) DEFAULT NULL,
  `start_date` varchar(255) DEFAULT NULL,
  `number_of_rental_day` varchar(255) DEFAULT NULL,
  `end_date` varchar(255) DEFAULT NULL,
  `delivery_location` varchar(255) DEFAULT NULL,
  `observations` varchar(255) DEFAULT NULL,
  `status` int(11) DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=62 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `sys_companies1`
--

INSERT INTO `sys_companies1` (`id`, `company_name`, `url`, `logo_url`, `logo_path`, `email`, `phone`, `emails`, `phones`, `tags`, `description`, `notes`, `address1`, `address2`, `city`, `state`, `zip`, `country`, `source`, `added_from`, `o`, `cid`, `aid`, `pid`, `oid`, `rid`, `assigned`, `created_at`, `created_by`, `updated_at`, `updated_by`, `last_contact`, `last_contact_by`, `ratings`, `trash`, `archived`, `c1`, `c2`, `c3`, `c4`, `c5`, `picture1_file_token`, `picture2_file_token`, `types_of_equipment`, `pprice_per_hour`, `lsr_id`, `other_type`, `start_date`, `number_of_rental_day`, `end_date`, `delivery_location`, `observations`, `status`) VALUES
(58, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 'zagqn73pmtlxhfkukq25r7a9ed8mpf', 'hkur4y7ygiugktgms32og656gchp3x', 'Cultivator', '856', 15, 'Eius debitis et simi', '2019-09-04', '169', '1981-05-26', 'Eos molestiae suscip', 'kmmmmmm', 1),
(56, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, '', '', 'Harrow', '23', 17, 'A nihil qui a obcaec', '1979-01-04', '794', '1990-05-20', 'Beatae voluptatem do', 'Amet officia repreh', 1),
(57, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, '', '', 'Harrow', '820', 21, 'Officiis ipsa quo a', '1986-12-15', '935', '1983-05-15', 'Repudiandae praesent', 'Modi odio illo sed e', 1),
(59, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, '', '', 'Cultivator', '', 21, '', '', '', '', '', '', 1),
(60, '', '', NULL, NULL, NULL, '555545544ll522144vv', NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, '2022-12-08 02:35:50', NULL, '2022-12-08 02:35:50', NULL, NULL, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, '', '', '', '1000', 1, 'admin', '', 'fname', '', '', '', 1),
(61, '', '', NULL, NULL, NULL, '555545544ll522144vv', NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, '2022-12-08 02:44:04', NULL, '2022-12-08 02:44:04', NULL, NULL, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, '', '', '', '1000', 1, 'admin', '', 'fname', '', '', '', 1);

-- --------------------------------------------------------

--
-- Structure de la table `sys_companies2`
--

DROP TABLE IF EXISTS `sys_companies2`;
CREATE TABLE IF NOT EXISTS `sys_companies2` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `company_name` varchar(200) CHARACTER SET utf8 DEFAULT NULL,
  `url` varchar(200) CHARACTER SET utf8 DEFAULT NULL,
  `logo_url` varchar(200) CHARACTER SET utf8 DEFAULT NULL,
  `logo_path` varchar(200) CHARACTER SET utf8 DEFAULT NULL,
  `email` varchar(200) CHARACTER SET utf8 DEFAULT NULL,
  `phone` varchar(200) CHARACTER SET utf8 DEFAULT NULL,
  `emails` text CHARACTER SET utf8,
  `phones` text CHARACTER SET utf8,
  `tags` text CHARACTER SET utf8,
  `description` text CHARACTER SET utf8,
  `notes` text CHARACTER SET utf8,
  `address1` varchar(200) CHARACTER SET utf8 DEFAULT NULL,
  `address2` varchar(200) CHARACTER SET utf8 DEFAULT NULL,
  `city` varchar(200) CHARACTER SET utf8 DEFAULT NULL,
  `state` varchar(200) CHARACTER SET utf8 DEFAULT NULL,
  `zip` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `country` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `source` varchar(200) CHARACTER SET utf8 DEFAULT NULL,
  `added_from` varchar(200) CHARACTER SET utf8 DEFAULT NULL,
  `o` varchar(200) CHARACTER SET utf8 DEFAULT NULL,
  `cid` int(11) NOT NULL DEFAULT '0',
  `aid` int(11) NOT NULL DEFAULT '0',
  `pid` int(11) NOT NULL DEFAULT '0',
  `oid` int(11) NOT NULL DEFAULT '0',
  `rid` int(11) NOT NULL DEFAULT '0',
  `assigned` int(11) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `created_by` varchar(200) CHARACTER SET utf8 DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `updated_by` varchar(200) CHARACTER SET utf8 DEFAULT NULL,
  `last_contact` datetime DEFAULT NULL,
  `last_contact_by` varchar(200) CHARACTER SET utf8 DEFAULT NULL,
  `ratings` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `trash` int(1) NOT NULL DEFAULT '0',
  `archived` int(1) NOT NULL DEFAULT '0',
  `c1` text CHARACTER SET utf8,
  `c2` text CHARACTER SET utf8,
  `c3` text CHARACTER SET utf8,
  `c4` text CHARACTER SET utf8,
  `c5` text CHARACTER SET utf8,
  `picture1_file_token` varchar(255) DEFAULT NULL,
  `picture2_file_token` varchar(255) DEFAULT NULL,
  `picture3_file_token` varchar(255) DEFAULT NULL,
  `picture4_file_token` varchar(255) DEFAULT NULL,
  `types_of_machine` varchar(255) DEFAULT NULL,
  `lsr_id` int(11) DEFAULT NULL,
  `other_type` varchar(255) DEFAULT NULL,
  `start_date` varchar(255) DEFAULT NULL,
  `number_of_working_hours` varchar(255) DEFAULT NULL,
  `number_of_rental_day` varchar(255) DEFAULT NULL,
  `end_date` varchar(255) DEFAULT NULL,
  `delivery_location` varchar(255) DEFAULT NULL,
  `status` int(11) DEFAULT '1',
  `observations` varchar(255) DEFAULT NULL,
  `proposed_price_per_hours` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=38 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `sys_companies2`
--

INSERT INTO `sys_companies2` (`id`, `company_name`, `url`, `logo_url`, `logo_path`, `email`, `phone`, `emails`, `phones`, `tags`, `description`, `notes`, `address1`, `address2`, `city`, `state`, `zip`, `country`, `source`, `added_from`, `o`, `cid`, `aid`, `pid`, `oid`, `rid`, `assigned`, `created_at`, `created_by`, `updated_at`, `updated_by`, `last_contact`, `last_contact_by`, `ratings`, `trash`, `archived`, `c1`, `c2`, `c3`, `c4`, `c5`, `picture1_file_token`, `picture2_file_token`, `picture3_file_token`, `picture4_file_token`, `types_of_machine`, `lsr_id`, `other_type`, `start_date`, `number_of_working_hours`, `number_of_rental_day`, `end_date`, `delivery_location`, `status`, `observations`, `proposed_price_per_hours`) VALUES
(34, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'Compactors', 15, 'Voluptatem Est aper', '1970-07-18', '719', '419', '1979-07-03', NULL, 1, 'Id veniam incidunt', '908'),
(35, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'Motor graders', 23, 'Qui iure et est qua', '2017-01-08', '158', '45', '1997-12-28', NULL, 1, 'Non magnam enim fugi', '759'),
(36, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 'mrdi2zw0mflta2mueocb5ut2pkutaa', 'y9pii00kaiukn876wd29hmyx6v9p6t', 'mtljimxc04huok4xs2ef52d9w1nnck', '3pgv2y5k6arbc4ph3nhuaiht0aci4i', 'Motor graders', 21, 'Aperiam quis ut numq', '1979-06-26', '716', '743', '1976-07-27', NULL, 1, 'nm', '34');

-- --------------------------------------------------------

--
-- Structure de la table `sys_companies3`
--

DROP TABLE IF EXISTS `sys_companies3`;
CREATE TABLE IF NOT EXISTS `sys_companies3` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `company_name` varchar(200) CHARACTER SET utf8 DEFAULT NULL,
  `url` varchar(200) CHARACTER SET utf8 DEFAULT NULL,
  `logo_url` varchar(200) CHARACTER SET utf8 DEFAULT NULL,
  `logo_path` varchar(200) CHARACTER SET utf8 DEFAULT NULL,
  `email` varchar(200) CHARACTER SET utf8 DEFAULT NULL,
  `phone` varchar(200) CHARACTER SET utf8 DEFAULT NULL,
  `emails` text CHARACTER SET utf8,
  `phones` text CHARACTER SET utf8,
  `tags` text CHARACTER SET utf8,
  `description` text CHARACTER SET utf8,
  `notes` text CHARACTER SET utf8,
  `address1` varchar(200) CHARACTER SET utf8 DEFAULT NULL,
  `address2` varchar(200) CHARACTER SET utf8 DEFAULT NULL,
  `city` varchar(200) CHARACTER SET utf8 DEFAULT NULL,
  `state` varchar(200) CHARACTER SET utf8 DEFAULT NULL,
  `zip` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `country` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `source` varchar(200) CHARACTER SET utf8 DEFAULT NULL,
  `added_from` varchar(200) CHARACTER SET utf8 DEFAULT NULL,
  `o` varchar(200) CHARACTER SET utf8 DEFAULT NULL,
  `cid` int(11) NOT NULL DEFAULT '0',
  `aid` int(11) NOT NULL DEFAULT '0',
  `pid` int(11) NOT NULL DEFAULT '0',
  `oid` int(11) NOT NULL DEFAULT '0',
  `rid` int(11) NOT NULL DEFAULT '0',
  `assigned` int(11) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `created_by` varchar(200) CHARACTER SET utf8 DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `updated_by` varchar(200) CHARACTER SET utf8 DEFAULT NULL,
  `last_contact` datetime DEFAULT NULL,
  `last_contact_by` varchar(200) CHARACTER SET utf8 DEFAULT NULL,
  `ratings` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `trash` int(1) NOT NULL DEFAULT '0',
  `archived` int(1) NOT NULL DEFAULT '0',
  `c1` text CHARACTER SET utf8,
  `c2` text CHARACTER SET utf8,
  `c3` text CHARACTER SET utf8,
  `c4` text CHARACTER SET utf8,
  `c5` text CHARACTER SET utf8,
  `lsp_id` int(11) DEFAULT NULL,
  `status` int(11) DEFAULT '1',
  `truck_id` int(11) DEFAULT NULL,
  `expiry_date` date DEFAULT NULL,
  `permit_category` varchar(255) DEFAULT NULL,
  `permit_number` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `picture_permit_file_token` varchar(255) DEFAULT NULL,
  `comment` varchar(255) DEFAULT NULL,
  `suspend` varchar(222) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=47 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `sys_companies3`
--

INSERT INTO `sys_companies3` (`id`, `company_name`, `url`, `logo_url`, `logo_path`, `email`, `phone`, `emails`, `phones`, `tags`, `description`, `notes`, `address1`, `address2`, `city`, `state`, `zip`, `country`, `source`, `added_from`, `o`, `cid`, `aid`, `pid`, `oid`, `rid`, `assigned`, `created_at`, `created_by`, `updated_at`, `updated_by`, `last_contact`, `last_contact_by`, `ratings`, `trash`, `archived`, `c1`, `c2`, `c3`, `c4`, `c5`, `lsp_id`, `status`, `truck_id`, `expiry_date`, `permit_category`, `permit_number`, `name`, `picture_permit_file_token`, `comment`, `suspend`) VALUES
(28, 'Aboubakar tracking', NULL, NULL, NULL, NULL, '556677898908', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(29, 'Aboubakar tracking', NULL, NULL, NULL, NULL, '556677898908', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(30, NULL, NULL, NULL, NULL, NULL, '556677898908', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 26, 1, 50, '2022-12-08', '122', '2222', 'roland', 'zrsws4jvsf02qcd6q45s4v05o5hiqw', 'x nxn xc nx', 'Yes'),
(31, NULL, NULL, NULL, NULL, NULL, '556677898908', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 26, 1, 51, '2022-12-01', 'nmnmm', '2222', 'roland', 'oe3kc2his83od6s8w2dh3v0z6um32b', NULL, NULL),
(39, NULL, NULL, NULL, NULL, NULL, '+237680668907', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 26, 1, 50, '2022-12-02', 'nmnmm', '2222', 'kapekem roland', '1bsiwfg3nj4psr90m2iz78zfrv23e5', 'uhykvvvhjhjjbbjbjbkjbjk', 'No'),
(40, NULL, NULL, NULL, NULL, NULL, '+237680668907', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 27, 1, 50, '2022-12-15', 'nmnmm', '2222', 'kapekem roland', '0231a0e9mvrgx4aviiug8v1tk01qvm', NULL, NULL),
(41, NULL, NULL, NULL, NULL, NULL, '+237680668907', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 28, 1, 55, '2022-12-14', '122', '2222', 'kapekem roland', '7t8z8hzz8i1ebomg81ov87y13hsnib', NULL, NULL),
(42, NULL, NULL, NULL, NULL, NULL, '+237680668907', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, 1, 50, '2022-12-08', 'nmnmm', '2222', 'kapekem roland', 'sef4gm53v53x1sc8rcz4q91oscac6p', NULL, NULL),
(43, NULL, NULL, NULL, NULL, NULL, '+237680668907', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, 1, 50, '2022-12-09', 'nmnmm', '2222', 'kapekem roland', '3p25rmc0h346pyewpxntqixvj01yr9', NULL, NULL),
(45, NULL, NULL, NULL, NULL, NULL, '+23768066907', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 27, 1, 50, '2022-12-08', 'nmnmm', '2222', 'kapekem roland', 'nzupy3w29bimqrf7u5d0nhbypzi203', 'mmn', 'Yes');

-- --------------------------------------------------------

--
-- Structure de la table `sys_companies4`
--

DROP TABLE IF EXISTS `sys_companies4`;
CREATE TABLE IF NOT EXISTS `sys_companies4` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `company_name` varchar(200) CHARACTER SET utf8 DEFAULT NULL,
  `url` varchar(200) CHARACTER SET utf8 DEFAULT NULL,
  `logo_url` varchar(200) CHARACTER SET utf8 DEFAULT NULL,
  `logo_path` varchar(200) CHARACTER SET utf8 DEFAULT NULL,
  `email` varchar(200) CHARACTER SET utf8 DEFAULT NULL,
  `phone` varchar(200) CHARACTER SET utf8 DEFAULT NULL,
  `emails` text CHARACTER SET utf8,
  `phones` text CHARACTER SET utf8,
  `tags` text CHARACTER SET utf8,
  `description` text CHARACTER SET utf8,
  `notes` text CHARACTER SET utf8,
  `address1` varchar(200) CHARACTER SET utf8 DEFAULT NULL,
  `address2` varchar(200) CHARACTER SET utf8 DEFAULT NULL,
  `city` varchar(200) CHARACTER SET utf8 DEFAULT NULL,
  `state` varchar(200) CHARACTER SET utf8 DEFAULT NULL,
  `zip` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `country` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `source` varchar(200) CHARACTER SET utf8 DEFAULT NULL,
  `added_from` varchar(200) CHARACTER SET utf8 DEFAULT NULL,
  `o` varchar(200) CHARACTER SET utf8 DEFAULT NULL,
  `cid` int(11) NOT NULL DEFAULT '0',
  `aid` int(11) NOT NULL DEFAULT '0',
  `pid` int(11) NOT NULL DEFAULT '0',
  `oid` int(11) NOT NULL DEFAULT '0',
  `rid` int(11) NOT NULL DEFAULT '0',
  `assigned` int(11) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `created_by` varchar(200) CHARACTER SET utf8 DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `updated_by` varchar(200) CHARACTER SET utf8 DEFAULT NULL,
  `last_contact` datetime DEFAULT NULL,
  `last_contact_by` varchar(200) CHARACTER SET utf8 DEFAULT NULL,
  `ratings` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `trash` int(1) NOT NULL DEFAULT '0',
  `archived` int(1) NOT NULL DEFAULT '0',
  `c1` text CHARACTER SET utf8,
  `c2` text CHARACTER SET utf8,
  `c3` text CHARACTER SET utf8,
  `c4` text CHARACTER SET utf8,
  `c5` text CHARACTER SET utf8,
  `lsr_id` int(11) DEFAULT NULL,
  `type_of_materials` varchar(255) DEFAULT NULL,
  `status` int(11) DEFAULT '1',
  `size` varchar(255) DEFAULT NULL,
  `weight` varchar(255) DEFAULT NULL,
  `estimated_value` varchar(255) DEFAULT NULL,
  `delivery_location` varchar(255) DEFAULT NULL,
  `quantity` varchar(255) DEFAULT NULL,
  `informations` varchar(255) DEFAULT NULL,
  `destination_country` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=40 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `sys_companies4`
--

INSERT INTO `sys_companies4` (`id`, `company_name`, `url`, `logo_url`, `logo_path`, `email`, `phone`, `emails`, `phones`, `tags`, `description`, `notes`, `address1`, `address2`, `city`, `state`, `zip`, `country`, `source`, `added_from`, `o`, `cid`, `aid`, `pid`, `oid`, `rid`, `assigned`, `created_at`, `created_by`, `updated_at`, `updated_by`, `last_contact`, `last_contact_by`, `ratings`, `trash`, `archived`, `c1`, `c2`, `c3`, `c4`, `c5`, `lsr_id`, `type_of_materials`, `status`, `size`, `weight`, `estimated_value`, `delivery_location`, `quantity`, `informations`, `destination_country`) VALUES
(36, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 22, 'Plastic sheets', 2, 'Tenetur facere atque', 'Aut quae soluta et v', 'Culpa sed sit in e', 'Quia incidunt autem', '294', 'Quaerat vero excepte', 'Et dolores et proide'),
(37, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 22, 'Plastic sheets', 2, 'Ipsum ut omnis mini', 'Dolorem quia vel do', 'Dolores neque et ani', 'Expedita deserunt et', '825', 'Facilis suscipit eve', 'Eum accusamus nisi t'),
(38, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 19, 'Barge', 2, 'Aliqua Voluptatum q', 'Occaecat ut quidem o', 'Consequatur Irure a', 'Ex cillum voluptatem', '940', 'Obcaecati qui occaec', 'Ut aliquam consectet');

-- --------------------------------------------------------

--
-- Structure de la table `sys_companies5`
--

DROP TABLE IF EXISTS `sys_companies5`;
CREATE TABLE IF NOT EXISTS `sys_companies5` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `company_name` varchar(200) CHARACTER SET utf8 DEFAULT NULL,
  `url` varchar(200) CHARACTER SET utf8 DEFAULT NULL,
  `logo_url` varchar(200) CHARACTER SET utf8 DEFAULT NULL,
  `logo_path` varchar(200) CHARACTER SET utf8 DEFAULT NULL,
  `email` varchar(200) CHARACTER SET utf8 DEFAULT NULL,
  `phone` varchar(200) CHARACTER SET utf8 DEFAULT NULL,
  `emails` text CHARACTER SET utf8,
  `phones` text CHARACTER SET utf8,
  `tags` text CHARACTER SET utf8,
  `description` text CHARACTER SET utf8,
  `notes` text CHARACTER SET utf8,
  `address1` varchar(200) CHARACTER SET utf8 DEFAULT NULL,
  `address2` varchar(200) CHARACTER SET utf8 DEFAULT NULL,
  `city` varchar(200) CHARACTER SET utf8 DEFAULT NULL,
  `state` varchar(200) CHARACTER SET utf8 DEFAULT NULL,
  `zip` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `country` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `source` varchar(200) CHARACTER SET utf8 DEFAULT NULL,
  `added_from` varchar(200) CHARACTER SET utf8 DEFAULT NULL,
  `o` varchar(200) CHARACTER SET utf8 DEFAULT NULL,
  `cid` int(11) NOT NULL DEFAULT '0',
  `aid` int(11) NOT NULL DEFAULT '0',
  `pid` int(11) NOT NULL DEFAULT '0',
  `oid` int(11) NOT NULL DEFAULT '0',
  `rid` int(11) NOT NULL DEFAULT '0',
  `assigned` int(11) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `created_by` varchar(200) CHARACTER SET utf8 DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `updated_by` varchar(200) CHARACTER SET utf8 DEFAULT NULL,
  `last_contact` datetime DEFAULT NULL,
  `last_contact_by` varchar(200) CHARACTER SET utf8 DEFAULT NULL,
  `ratings` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `trash` int(1) NOT NULL DEFAULT '0',
  `archived` int(1) NOT NULL DEFAULT '0',
  `c1` text CHARACTER SET utf8,
  `c2` text CHARACTER SET utf8,
  `c3` text CHARACTER SET utf8,
  `c4` text CHARACTER SET utf8,
  `c5` text CHARACTER SET utf8,
  `truck_picture_file_token` varchar(255) DEFAULT NULL,
  `lsr_id` int(11) DEFAULT NULL,
  `truck_insurance_file_token` varchar(255) DEFAULT NULL,
  `status` int(11) DEFAULT '1',
  `truck_patent_file_token` varchar(255) DEFAULT NULL,
  `truck_registration_document_file_token` varchar(255) DEFAULT NULL,
  `Road_Worthiness_file_token` varchar(255) DEFAULT NULL,
  `Road_Worthiness` varchar(255) DEFAULT NULL,
  `lsp_id` int(11) DEFAULT NULL,
  `truck_immatriculation` varchar(255) DEFAULT NULL,
  `type_of_truck` varchar(255) DEFAULT NULL,
  `insurance_start_date` varchar(255) DEFAULT NULL,
  `truck_availability` varchar(255) DEFAULT NULL,
  `road` varchar(255) DEFAULT NULL,
  `insurance_expiration_date` varchar(255) DEFAULT NULL,
  `chassis_number` varchar(255) DEFAULT NULL,
  `date_of_entry` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=62 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `sys_companies5`
--

INSERT INTO `sys_companies5` (`id`, `company_name`, `url`, `logo_url`, `logo_path`, `email`, `phone`, `emails`, `phones`, `tags`, `description`, `notes`, `address1`, `address2`, `city`, `state`, `zip`, `country`, `source`, `added_from`, `o`, `cid`, `aid`, `pid`, `oid`, `rid`, `assigned`, `created_at`, `created_by`, `updated_at`, `updated_by`, `last_contact`, `last_contact_by`, `ratings`, `trash`, `archived`, `c1`, `c2`, `c3`, `c4`, `c5`, `truck_picture_file_token`, `lsr_id`, `truck_insurance_file_token`, `status`, `truck_patent_file_token`, `truck_registration_document_file_token`, `Road_Worthiness_file_token`, `Road_Worthiness`, `lsp_id`, `truck_immatriculation`, `type_of_truck`, `insurance_start_date`, `truck_availability`, `road`, `insurance_expiration_date`, `chassis_number`, `date_of_entry`) VALUES
(50, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, '', NULL, '', 1, '', '', NULL, 'Mauritania', 30, 'Odit accusamus recus', 'Et ut provident ist', '2006-09-07', 'No', NULL, '1986-06-08', NULL, NULL),
(51, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, '', NULL, '', 1, '', '', NULL, 'United States', 26, 'Odit accusamus recus', '', '', 'yes', NULL, '', NULL, NULL),
(52, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, '', NULL, '', 1, '', '', NULL, 'United States', 30, 'Odit accusamus recus', 'jknjj', '', 'yes', NULL, '', NULL, NULL),
(53, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, '', NULL, '', 1, '', '', NULL, 'United States', 26, 'Odit accusamus recus', '', '', 'yes', NULL, '', NULL, NULL),
(54, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 'vhub8iznj7lsxo137imnqw2qh4qxng', NULL, '23ca10915uo4eh4v3agkc76p609jef', 1, 'y7yzjltdiohg2i4qfb8u0khbyuqgoc', 'gn9wcfeyg09l2vla96uek7kt5vc637', NULL, 'United States', 27, 'Odit accusamus recus', 'jknjj', '2022-12-08', 'yes', NULL, '2022-12-21', NULL, NULL),
(55, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, '', NULL, '', 1, '', '', NULL, 'United States', 26, '4547jh', 'jknjj', '2022-12-08', 'yes', NULL, '2022-12-09', '', '2025-12-05'),
(58, '', '', '', NULL, NULL, '', '', NULL, '', '', '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', 1, '', '', NULL, NULL, 23, 'Odit  recus', 'jknjj', '2022', '', NULL, '', 'hhghghhhhh', '2022-12-02'),
(61, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 'km5wec94bqmi58pxhy514soobm23ug', NULL, 'w3po8j0w6z7r7lm8mo2dgz9eyc56wz', 1, 'dbvt38suc5tlj1xaszmz1l5xwckx8i', 'nmuudmapfcv80qj4hvzbeulwdf7a1u', NULL, 'Cameroon', 61, '34657858', 'jknjj', '2022-12-16', 'yes', NULL, '2022-12-23', 'mmmm,m,88', '2017-01-30');

-- --------------------------------------------------------

--
-- Structure de la table `sys_companies6`
--

DROP TABLE IF EXISTS `sys_companies6`;
CREATE TABLE IF NOT EXISTS `sys_companies6` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `company_name` varchar(200) CHARACTER SET utf8 DEFAULT NULL,
  `url` varchar(200) CHARACTER SET utf8 DEFAULT NULL,
  `logo_url` varchar(200) CHARACTER SET utf8 DEFAULT NULL,
  `logo_path` varchar(200) CHARACTER SET utf8 DEFAULT NULL,
  `email` varchar(200) CHARACTER SET utf8 DEFAULT NULL,
  `phone` varchar(200) CHARACTER SET utf8 DEFAULT NULL,
  `emails` text CHARACTER SET utf8,
  `phones` text CHARACTER SET utf8,
  `tags` text CHARACTER SET utf8,
  `description` text CHARACTER SET utf8,
  `notes` text CHARACTER SET utf8,
  `address1` varchar(200) CHARACTER SET utf8 DEFAULT NULL,
  `address2` varchar(200) CHARACTER SET utf8 DEFAULT NULL,
  `city` varchar(200) CHARACTER SET utf8 DEFAULT NULL,
  `state` varchar(200) CHARACTER SET utf8 DEFAULT NULL,
  `zip` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `country` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `source` varchar(200) CHARACTER SET utf8 DEFAULT NULL,
  `added_from` varchar(200) CHARACTER SET utf8 DEFAULT NULL,
  `o` varchar(200) CHARACTER SET utf8 DEFAULT NULL,
  `cid` int(11) NOT NULL DEFAULT '0',
  `aid` int(11) NOT NULL DEFAULT '0',
  `pid` int(11) NOT NULL DEFAULT '0',
  `oid` int(11) NOT NULL DEFAULT '0',
  `rid` int(11) NOT NULL DEFAULT '0',
  `assigned` int(11) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `created_by` varchar(200) CHARACTER SET utf8 DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `updated_by` varchar(200) CHARACTER SET utf8 DEFAULT NULL,
  `last_contact` datetime DEFAULT NULL,
  `last_contact_by` varchar(200) CHARACTER SET utf8 DEFAULT NULL,
  `ratings` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `trash` int(1) NOT NULL DEFAULT '0',
  `archived` int(1) NOT NULL DEFAULT '0',
  `c1` text CHARACTER SET utf8,
  `c2` text CHARACTER SET utf8,
  `c3` text CHARACTER SET utf8,
  `c4` text CHARACTER SET utf8,
  `c5` text CHARACTER SET utf8,
  `bill_lading_file_token` varchar(255) DEFAULT NULL,
  `status` int(1) NOT NULL DEFAULT '1' COMMENT 'trade status',
  `lsr_id` int(11) DEFAULT NULL,
  `types_of_goods` varchar(255) DEFAULT NULL,
  `estimated_value` varchar(255) DEFAULT NULL,
  `weight` varchar(255) DEFAULT NULL,
  `origin_country` varchar(255) DEFAULT NULL,
  `destination_country` varchar(255) DEFAULT NULL,
  `delivery_location` varchar(255) DEFAULT NULL,
  `transit` varchar(255) DEFAULT NULL,
  `loading_date` varchar(255) DEFAULT NULL,
  `off_loading_service` varchar(255) DEFAULT NULL,
  `loading_services` varchar(255) DEFAULT NULL,
  `observations` varchar(255) DEFAULT NULL,
  `transport_insurance` varchar(255) DEFAULT NULL,
  `tracking` varchar(255) DEFAULT NULL,
  `pick_uplocation` varchar(255) DEFAULT NULL,
  `recipient_name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=63 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `sys_companies6`
--

INSERT INTO `sys_companies6` (`id`, `company_name`, `url`, `logo_url`, `logo_path`, `email`, `phone`, `emails`, `phones`, `tags`, `description`, `notes`, `address1`, `address2`, `city`, `state`, `zip`, `country`, `source`, `added_from`, `o`, `cid`, `aid`, `pid`, `oid`, `rid`, `assigned`, `created_at`, `created_by`, `updated_at`, `updated_by`, `last_contact`, `last_contact_by`, `ratings`, `trash`, `archived`, `c1`, `c2`, `c3`, `c4`, `c5`, `bill_lading_file_token`, `status`, `lsr_id`, `types_of_goods`, `estimated_value`, `weight`, `origin_country`, `destination_country`, `delivery_location`, `transit`, `loading_date`, `off_loading_service`, `loading_services`, `observations`, `transport_insurance`, `tracking`, `pick_uplocation`, `recipient_name`) VALUES
(58, NULL, NULL, NULL, NULL, NULL, '+1 (255) 115-9223', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, '', 2, 18, 'Perferendis amet di', '7', '86', 'Ad adipisci aut aut', 'Eaque nihil occaecat', 'Iure fugiat est lib', 'No', '1990-10-06', 'yes', 'yes', 'Quia minima nihil se', 'No', 'yes', NULL, 'Ignacia Shields'),
(57, NULL, NULL, NULL, NULL, NULL, '+1 (746) 365-7566', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, '', 2, 23, 'Exercitationem facer', '13', '67', 'Est ea fugiat sed a', 'Iure facilis ipsum s', 'Facilis aliqua Aut', 'yes', '1985-03-21', 'yes', 'yes', 'Illum est sit minu', 'No', 'No', NULL, 'Ruth Hampton'),
(56, NULL, NULL, NULL, NULL, NULL, '+1 (803) 689-8822', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, '', 2, 23, 'Dolores corporis del', '22', '75', 'Provident enim prae', 'Ut fugit sit dolore', 'Molestiae nisi volup', 'yes', '2005-07-23', 'No', 'yes', 'Magnam ex sequi opti', 'Partial', 'No', NULL, 'Jermaine Hawkins'),
(55, NULL, NULL, NULL, NULL, NULL, '+1 (666) 207-9003', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, '', 1, 15, 'Dolor dolor sit et', '30', '4', 'Saepe tempora simili', 'Incidunt quod ex ea', 'Quam porro praesenti', 'yes', '2019-12-09', 'No', 'yes', 'Illum qui sit esse', 'No', 'No', NULL, 'Ferdinand Golden'),
(54, NULL, NULL, NULL, NULL, NULL, '+1 (952) 429-8069', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, '', 2, 22, 'Dolore rem culpa mol', '40', '20', 'Libero ea aut aliqui', 'Voluptatum voluptas', 'Eiusmod hic culpa e', 'No', '2013-08-21', 'yes', 'yes', 'Adipisci impedit no', 'Partial', 'No', NULL, 'Gay Walter'),
(59, NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 'brmxx6czrt29n4ttl8223apxwvoqar', 2, 15, 'ghyjggjgjhgh', '', '', '', '', '', 'yes', '', 'yes', 'yes', '', 'Full', 'yes', 'njnjnn', ''),
(62, NULL, NULL, NULL, NULL, NULL, '+1 (344) 631-1888', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, '', 2, 23, 'Eveniet et laborum', '19', '86', 'Id beatae tenetur cu', 'Hic eligendi quos an', 'Magnam asperiores si', 'No', '1998-02-19', 'yes', 'No', 'At eos eaque ex nul', 'No', 'yes', 'Possimus ut dolorem', 'Tyler Combs');

-- --------------------------------------------------------

--
-- Structure de la table `sys_currencies`
--

DROP TABLE IF EXISTS `sys_currencies`;
CREATE TABLE IF NOT EXISTS `sys_currencies` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cname` varchar(100) DEFAULT NULL,
  `iso_code` varchar(10) DEFAULT NULL,
  `symbol` varchar(20) DEFAULT NULL,
  `rate` decimal(16,8) NOT NULL DEFAULT '1.00000000',
  `prefix` varchar(20) DEFAULT NULL,
  `suffix` varchar(20) DEFAULT NULL,
  `format` varchar(100) DEFAULT NULL,
  `decimal_separator` varchar(10) DEFAULT NULL,
  `thousand_separator` varchar(10) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `created_by` varchar(200) DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `updated_by` varchar(200) DEFAULT NULL,
  `available_in` text,
  `isdefault` int(1) NOT NULL DEFAULT '0',
  `trash` int(1) NOT NULL DEFAULT '0',
  `archived` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `sys_currencies`
--

INSERT INTO `sys_currencies` (`id`, `cname`, `iso_code`, `symbol`, `rate`, `prefix`, `suffix`, `format`, `decimal_separator`, `thousand_separator`, `created_at`, `created_by`, `updated_at`, `updated_by`, `available_in`, `isdefault`, `trash`, `archived`) VALUES
(1, 'FCFA', 'FCFA', 'FCFA', '100.00000000', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0);

-- --------------------------------------------------------

--
-- Structure de la table `sys_documents`
--

DROP TABLE IF EXISTS `sys_documents`;
CREATE TABLE IF NOT EXISTS `sys_documents` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(200) DEFAULT NULL,
  `file_o_name` varchar(200) DEFAULT NULL,
  `file_r_name` varchar(200) DEFAULT NULL,
  `file_mime_type` varchar(200) DEFAULT NULL,
  `file_path` varchar(200) DEFAULT NULL,
  `file_dl_token` varchar(200) DEFAULT NULL,
  `file_owner` int(11) NOT NULL DEFAULT '0',
  `version` varchar(100) DEFAULT NULL,
  `link` varchar(100) DEFAULT NULL,
  `sha1` varchar(40) DEFAULT NULL,
  `md5` varchar(32) DEFAULT NULL,
  `cid` int(11) NOT NULL DEFAULT '0',
  `gid` int(11) NOT NULL DEFAULT '0',
  `company_id` int(11) NOT NULL DEFAULT '0',
  `aid` int(11) NOT NULL DEFAULT '0',
  `contacts` text,
  `deals` text,
  `leads` text,
  `created_at` datetime DEFAULT NULL,
  `created_by` varchar(200) DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `updated_by` varchar(200) DEFAULT NULL,
  `customer_can_download` int(1) NOT NULL DEFAULT '0',
  `trash` int(1) NOT NULL DEFAULT '0',
  `archived` int(1) NOT NULL DEFAULT '0',
  `is_global` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=292 DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `sys_documents`
--

INSERT INTO `sys_documents` (`id`, `title`, `file_o_name`, `file_r_name`, `file_mime_type`, `file_path`, `file_dl_token`, `file_owner`, `version`, `link`, `sha1`, `md5`, `cid`, `gid`, `company_id`, `aid`, `contacts`, `deals`, `leads`, `created_at`, `created_by`, `updated_at`, `updated_by`, `customer_can_download`, `trash`, `archived`, `is_global`) VALUES
(1, 'hgkuhjhjhj', NULL, NULL, 'png', '_1454ca2268468016626273561980.png', 'dyw45bf1vqp6lsg2s6n65dxqy3leqn', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-09-08 04:56:02', NULL, NULL, NULL, 0, 0, 0, 0),
(2, 'ttttt', NULL, NULL, 'pdf', '_f6bc7e9d363856166262790210903786.pdf', '6rtzn4mdb5ooejsr5uli39o913wqa5', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-09-08 05:05:15', NULL, NULL, NULL, 0, 0, 0, 0),
(3, 'test', NULL, NULL, 'png', '_8f91c9c2015309166264535411079287.png', 'e7f7iovxvzu0ha87ca6any1nbdl9fw', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-09-08 09:56:04', NULL, NULL, NULL, 0, 0, 0, 0),
(4, 'css', NULL, NULL, 'png', '_818cdcf0678449166307934610112891.png', '9fhfrndpg4vo7e9ydbrjqmr726te3l', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-09-13 10:29:20', NULL, NULL, NULL, 0, 0, 0, 0),
(5, 'afm', NULL, NULL, 'jpg', '_ab81265d599472166307939110714904.jpg', 'jhu0z3a5bah1w4vhym0ko8xbwzll0n', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-09-13 10:30:03', NULL, NULL, NULL, 0, 0, 0, 0),
(6, 'hgkuhjhjhj', NULL, NULL, 'png', '_331cc28f928053166308413610777996.png', '3bx18enc4dopnwgpkhj3isxw3wis7b', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-09-13 11:49:01', NULL, NULL, NULL, 0, 0, 0, 0),
(8, 'css', NULL, NULL, 'png', '_2e2079d6654157166784358111024100.png', '8nrvoidu5ow2ic83lzza6cs61afawu', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-11-07 12:53:01', NULL, NULL, NULL, 0, 0, 0, 0),
(9, 'js', NULL, NULL, 'png', '_0801a457246065166784358110915753.png', '3aapv0dktzcvg4vk16d3ewugeuw0cn', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-11-07 12:53:01', NULL, NULL, NULL, 0, 0, 0, 0),
(10, 'login', NULL, NULL, 'jpg', '_9308b0d6741710166784385010542047.jpg', 'pbo6eq905a356bwclv614uh2uhfr85', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-11-07 12:57:30', NULL, NULL, NULL, 0, 0, 0, 0),
(12, 'html', NULL, NULL, 'png', '_45c166d6892234166784385010882322.png', 'kr31qgnym541lmd4oyq7g8chyxiv5t', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-11-07 12:57:30', NULL, NULL, NULL, 0, 0, 0, 0),
(13, 'Screenshot (1)', NULL, NULL, 'png', '_437d46a8632019166789724910011641.png', 'fd9wnsu8rgcpm16nko9gi7iqvwkn8d', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-11-08 03:47:29', NULL, NULL, NULL, 0, 0, 0, 0),
(14, 'Screenshot (2)', NULL, NULL, 'png', '_ae353986521922166789724910688151.png', 't7c04pdco7s7brrae3badv5j03bvvg', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-11-08 03:47:29', NULL, NULL, NULL, 0, 0, 0, 0),
(15, 'live', NULL, NULL, 'jpg', '_cb7c403a994490166789724910618781.jpg', 'vevnxgsz7jkgko7x31ocgryht8n2ah', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-11-08 03:47:29', NULL, NULL, NULL, 0, 0, 0, 0),
(16, 'h', NULL, NULL, 'pdf', '_e834cb11342136166789724910962297.pdf', '398emnc0j6z3ontlsc0ga7cmetbei9', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-11-08 03:47:29', NULL, NULL, NULL, 0, 0, 0, 0),
(17, 'bootstrap', NULL, NULL, 'png', '_a0443c8c288874166790409610713808.png', 'uqtlh5ibslayk1xxsh3bih75z0bqwp', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-11-08 05:41:37', NULL, NULL, NULL, 0, 0, 0, 0),
(18, 'Bee', NULL, NULL, 'png', '_2cc73b24745558166790409710898044.png', 'er8qfny4m8tclib3hm9kto2aubieed', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-11-08 05:41:37', NULL, NULL, NULL, 0, 0, 0, 0),
(19, 'css', NULL, NULL, 'png', '_68a97503589148166790409711108829.png', '3fv7sry1rdehpd4slcoyun91jpbvl8', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-11-08 05:41:37', NULL, NULL, NULL, 0, 0, 0, 0),
(20, 'bootstrap', NULL, NULL, 'png', '_3f9e3767291558166790805710478235.png', '1sokavgcep1jsy6ecd3h86uccazyse', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-11-08 06:47:37', NULL, NULL, NULL, 0, 0, 0, 0),
(21, 'bootstrap', NULL, NULL, 'png', '_b85d65c3508569166790812610782006.png', '5dx7qse9u978sf8pxxtrp1snme7fpa', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-11-08 06:48:46', NULL, NULL, NULL, 0, 0, 0, 0),
(22, 'bootstrap', NULL, NULL, 'png', '_4ea83d95811275166790812610529799.png', 'q7qqyrnzc68noojdgqth87cq1qpwrz', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-11-08 06:48:46', NULL, NULL, NULL, 0, 0, 0, 0),
(23, 'bootstrap', NULL, NULL, 'png', '_97ea3cfb81154616679081261104424.png', '68swvs1ebx0hr77pqe6p7wtp8kib9x', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-11-08 06:48:46', NULL, NULL, NULL, 0, 0, 0, 0),
(24, 'html', NULL, NULL, 'png', '_80e888e032875116679081261009279.png', 'ude4bvc2132ta7k3ezfl0f1pb6blgk', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-11-08 06:48:46', NULL, NULL, NULL, 0, 0, 0, 0),
(25, 'bootstrap', NULL, NULL, 'png', '_b166b57d228575166790818310961861.png', 'm8bpcgeujolt3zpcael9u90jv12rzl', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-11-08 06:49:43', NULL, NULL, NULL, 0, 0, 0, 0),
(26, 'css', NULL, NULL, 'png', '_372d3f30860524166790818310295518.png', 'hauad0srngdardnjxj6ny1pc00lu08', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-11-08 06:49:43', NULL, NULL, NULL, 0, 0, 0, 0),
(27, 'css', NULL, NULL, 'png', '_7c9d0b1f239208166790818310962860.png', 'ki5x8thd2buhfasuwq88dof2xfok0l', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-11-08 06:49:43', NULL, NULL, NULL, 0, 0, 0, 0),
(28, 'js', NULL, NULL, 'png', '_ddcb1554956519166790818310676646.png', 'n2a8tn5ft86ylwhbibep3vo0x2u4wo', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-11-08 06:49:43', NULL, NULL, NULL, 0, 0, 0, 0),
(29, 'bootstrap', NULL, NULL, 'png', '_0cd60efb020815166791346510474697.png', 'p3g83b57wtn6qs1pkpey38p8ed287i', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-11-08 08:17:45', NULL, NULL, NULL, 0, 0, 0, 0),
(30, 'html', NULL, NULL, 'png', '_825f9cd5564050166791346510702571.png', 'ur1wbkx9a2fwy09pv8pzipjbd6pd84', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-11-08 08:17:45', NULL, NULL, NULL, 0, 0, 0, 0),
(31, 'css', NULL, NULL, 'png', '_bdad073d514221166792371510834431.png', '89gms36d5v8sgsn7n67utj7w83ekui', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-11-08 11:08:35', NULL, NULL, NULL, 0, 0, 0, 0),
(32, 'html', NULL, NULL, 'png', '_d202ed5b647665166792371510848625.png', 'gr14g8yeje4ujoie7mh2ycy4nbpwfx', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-11-08 11:08:35', NULL, NULL, NULL, 0, 0, 0, 0),
(33, 'js', NULL, NULL, 'png', '_d7657583976114166792371510055810.png', 'phr1zl4bc2lcn1ntggl0n3hbf743ou', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-11-08 11:08:35', NULL, NULL, NULL, 0, 0, 0, 0),
(34, 'Bee', NULL, NULL, 'png', '_751f6b6b893525166792371510424344.png', '51dr4c3mz36jf560f7lo8gmdrcce7t', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-11-08 11:08:35', NULL, NULL, NULL, 0, 0, 0, 0),
(35, 'bootstrap', NULL, NULL, 'png', '_bd9d0310489925166798253210864068.png', 'srdlx7ntktv6461z7x48zrrcrdqmdz', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-11-09 03:28:52', NULL, NULL, NULL, 0, 0, 0, 0),
(36, 'js', NULL, NULL, 'png', '_db182d25221824166798253210477918.png', '7zooq4944uroo2d01nccab8r9yrzk3', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-11-09 03:28:52', NULL, NULL, NULL, 0, 0, 0, 0),
(37, 'Bee', NULL, NULL, 'png', '_5a44a53b915760166798253210157825.png', 'a6tevzdt4p37wjpd9kb9880x9wmh2g', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-11-09 03:28:52', NULL, NULL, NULL, 0, 0, 0, 0),
(38, 'edraw', NULL, NULL, 'png', '_0465a182390132166798253210752593.png', '44z7tdxv7ssnd82oaxyh3wrtojsafk', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-11-09 03:28:52', NULL, NULL, NULL, 0, 0, 0, 0),
(39, 'css', NULL, NULL, 'png', '_4b55df75179303166799111010878612.png', 's2q18gm0gqx36n0y6ovos171zph0fk', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-11-09 05:51:50', NULL, NULL, NULL, 0, 0, 0, 0),
(40, 'bootstrap', NULL, NULL, 'png', '_0b24d84689116016679911101050659.png', '4xvjoy85r5hjyfpre7no5znxm0p0ye', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-11-09 05:51:50', NULL, NULL, NULL, 0, 0, 0, 0),
(41, 'Bee', NULL, NULL, 'png', '_201d5469558130166799111011067564.png', 'hjy3ddtysvsehvy0uyoksfwophuumx', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-11-09 05:51:50', NULL, NULL, NULL, 0, 0, 0, 0),
(42, 'h', NULL, NULL, 'pdf', '_aa0d2a8075866416679911101045690.pdf', 'dyc087fkz13m19luxa5dk1dhmlob8v', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-11-09 05:51:50', NULL, NULL, NULL, 0, 0, 0, 0),
(43, 'html', NULL, NULL, 'png', '_ab73f542884219166799270110962792.png', 'uyehm8m8lrp6mnxxg728mngfkf5f7x', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-11-09 06:18:21', NULL, NULL, NULL, 0, 0, 0, 0),
(44, 'bootstrap', NULL, NULL, 'png', '_d54ce9de135349166799270110451350.png', 'sdmv9oukuqe0ssyovmhg3huof9qmkg', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-11-09 06:18:21', NULL, NULL, NULL, 0, 0, 0, 0),
(45, 'html', NULL, NULL, 'png', '_a425170b158786166799271110822672.png', 'ntnrzmhiol0ed5xjbquohw6asisghu', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-11-09 06:18:31', NULL, NULL, NULL, 0, 0, 0, 0),
(46, 'bootstrap', NULL, NULL, 'png', '_b90ba831911693166799271110257367.png', 'rhaolrn08tqtub7y6ugwjw6bph5xut', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-11-09 06:18:31', NULL, NULL, NULL, 0, 0, 0, 0),
(47, 'bootstrap', NULL, NULL, 'png', '_c09b1ead080278166799388710505803.png', 'fkx8za3chrc5qu4hbptgloa3zg2gkf', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-11-09 06:38:07', NULL, NULL, NULL, 0, 0, 0, 0),
(48, 'css', NULL, NULL, 'png', '_9eb53b50640133166799492410168043.png', '98boj5q8spqm1n7p7mhnu0immjk1zn', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-11-09 06:55:24', NULL, NULL, NULL, 0, 0, 0, 0),
(49, 'bootstrap', NULL, NULL, 'png', '_b571ecea733773166799492410589303.png', 'wyayc21jm4z9kpfdstowh538y3s9vt', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-11-09 06:55:24', NULL, NULL, NULL, 0, 0, 0, 0),
(50, 'Bee', NULL, NULL, 'png', '_da974f5e747569166799492410889098.png', 'ed94eom2j09rczn02xji7p9niypfwr', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-11-09 06:55:24', NULL, NULL, NULL, 0, 0, 0, 0),
(51, 'html', NULL, NULL, 'png', '_13e36f06404223166799492410898447.png', 'y7le8noz0vt03y12nwk3wy2oa2x4uv', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-11-09 06:55:24', NULL, NULL, NULL, 0, 0, 0, 0),
(52, 'css', NULL, NULL, 'png', '_b2945042316992166799536210378688.png', 'nera3xux3g8s29l1ca3ho6fctecl9o', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-11-09 07:02:42', NULL, NULL, NULL, 0, 0, 0, 0),
(53, 'Bee', NULL, NULL, 'png', '_0a30a980674506166799536210453689.png', '6ry7h6cfwtun3mbkcikrmlf5jsvas0', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-11-09 07:02:42', NULL, NULL, NULL, 0, 0, 0, 0),
(54, 'h', NULL, NULL, 'pdf', '_8df6a659146556166799536210137936.pdf', 'u8ykf2i7353d4s74w4ymader5gg7pr', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-11-09 07:02:42', NULL, NULL, NULL, 0, 0, 0, 0),
(55, 'edraw', NULL, NULL, 'png', '_15212f24244247166799536310156861.png', 'vl35uo9rco3eutrmlxoo6ik1l0gd45', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-11-09 07:02:43', NULL, NULL, NULL, 0, 0, 0, 0),
(56, 'css', NULL, NULL, 'png', '_88b05733804303166800441010187842.png', '0cwhcj1jiefh5xh0lalpe49h21q9g5', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-11-09 09:33:30', NULL, NULL, NULL, 0, 0, 0, 0),
(57, 'css', NULL, NULL, 'png', '_3fa14621590670166800651210895564.png', 'x6j1gms61rdy7mowt0srgi0bqmszm0', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-11-09 10:08:32', NULL, NULL, NULL, 0, 0, 0, 0),
(58, 'bootstrap', NULL, NULL, 'png', '_cd4bb35c140716166800651210995645.png', 'mp0ykph00h205woo6nzlrybgt62fmc', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-11-09 10:08:32', NULL, NULL, NULL, 0, 0, 0, 0),
(59, 'bootstrap', NULL, NULL, 'png', '_3df07fda138030166800651210797103.png', 'vwnygey2yfzxvggcduiyjc300suj86', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-11-09 10:08:32', NULL, NULL, NULL, 0, 0, 0, 0),
(60, 'js', NULL, NULL, 'png', '_287e0413046523166800651210069478.png', 'uul7mlxwhii10us6mmv5tpckjdsqj2', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-11-09 10:08:32', NULL, NULL, NULL, 0, 0, 0, 0),
(61, 'bootstrap', NULL, NULL, 'png', '_e8d92f99631714166800693510298427.png', 'jl4el93y5da72swri7hz9q114rtawn', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-11-09 10:15:35', NULL, NULL, NULL, 0, 0, 0, 0),
(62, 'bootstrap', NULL, NULL, 'png', '_ddf90299917804166800693510071522.png', 'kf53w04g4qxe7n2auxpkftp1mqo8r4', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-11-09 10:15:35', NULL, NULL, NULL, 0, 0, 0, 0),
(63, 'css', NULL, NULL, 'png', '_e9470886517578166800693611089339.png', '0b0h4azq7ocqmd7wewjpoehu7kazjb', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-11-09 10:15:36', NULL, NULL, NULL, 0, 0, 0, 0),
(64, 'Bee', NULL, NULL, 'png', '_56468d56002303166800693610227426.png', 'yrmo7mow12nxxthisk3jinigtlkrj1', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-11-09 10:15:36', NULL, NULL, NULL, 0, 0, 0, 0),
(65, 'Bee', NULL, NULL, 'png', '_ee16fa83462659166800724010659391.png', 'i07m2bxqdzfd14o1dab6f4zmt505xf', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-11-09 10:20:40', NULL, NULL, NULL, 0, 0, 0, 0),
(66, 'edraw', NULL, NULL, 'png', '_6236c78e030191166800724010345140.png', 'ynjfx4r6rw936067otyd2yl6xbr008', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-11-09 10:20:40', NULL, NULL, NULL, 0, 0, 0, 0),
(67, 'js', NULL, NULL, 'png', '_564127c0825318166800724011039449.png', 's8sb8qq14dlw5bqmufjbj8185lgqpx', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-11-09 10:20:40', NULL, NULL, NULL, 0, 0, 0, 0),
(68, 'css', NULL, NULL, 'png', '_76444b31547783166800724010934815.png', '1qvmq68by97rpjswho177q2amnjk26', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-11-09 10:20:40', NULL, NULL, NULL, 0, 0, 0, 0),
(69, 'Bee', NULL, NULL, 'png', '_1c280e54385074166800724410828185.png', 'dlns8inhfhzs2ddxv6f5wi5s28wpsi', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-11-09 10:20:44', NULL, NULL, NULL, 0, 0, 0, 0),
(70, 'edraw', NULL, NULL, 'png', '_a376802c220421166800724410873333.png', '2sur24c3dx4cxy7whqxhzb9i1jg70v', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-11-09 10:20:44', NULL, NULL, NULL, 0, 0, 0, 0),
(71, 'js', NULL, NULL, 'png', '_08fc80de99845916680072441094115.png', 'j7yqaoo7m8zzhiyms12k5udxina6kp', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-11-09 10:20:44', NULL, NULL, NULL, 0, 0, 0, 0),
(72, 'css', NULL, NULL, 'png', '_63f44623407396166800724410602505.png', '11umnw4f497pw0j9rfpycabk6g7fb6', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-11-09 10:20:44', NULL, NULL, NULL, 0, 0, 0, 0),
(73, 'Bee', NULL, NULL, 'png', '_9f067d8d068954166800724610649247.png', 'vmnauvext1270xvtnf6vwlynrsbwxk', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-11-09 10:20:46', NULL, NULL, NULL, 0, 0, 0, 0),
(74, 'edraw', NULL, NULL, 'png', '_c900ced7362496166800724610524499.png', 'pu50a855bjadzju61nbzhuq7dy6as0', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-11-09 10:20:46', NULL, NULL, NULL, 0, 0, 0, 0),
(75, 'js', NULL, NULL, 'png', '_fb5c2bc1120543166800724610282147.png', 'q9qd9jmjr8htn39ovnqkqnd8b5n9p6', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-11-09 10:20:46', NULL, NULL, NULL, 0, 0, 0, 0),
(76, 'css', NULL, NULL, 'png', '_819e3d6c274815166800724611038690.png', '5uabotzu0inyof0zcfylglqucty92v', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-11-09 10:20:46', NULL, NULL, NULL, 0, 0, 0, 0),
(77, 'Bee', NULL, NULL, 'png', '_0383314b188927166800724710305763.png', 'yp73dwzremwxrex9rhwnopieo8iek0', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-11-09 10:20:47', NULL, NULL, NULL, 0, 0, 0, 0),
(78, 'edraw', NULL, NULL, 'png', '_f7e2b2b7207776166800724711095435.png', '8fzodsos09akae34c3bryvn91ag0nl', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-11-09 10:20:47', NULL, NULL, NULL, 0, 0, 0, 0),
(79, 'js', NULL, NULL, 'png', '_9fc64354341757166800724711062022.png', '7h089oj2lbotfcdushr9hqxto4x5kc', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-11-09 10:20:47', NULL, NULL, NULL, 0, 0, 0, 0),
(80, 'css', NULL, NULL, 'png', '_af3303f8987682166800724710178970.png', '435yn3avqpvye63gy1i93j184te8i0', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-11-09 10:20:47', NULL, NULL, NULL, 0, 0, 0, 0),
(81, 'Bee', NULL, NULL, 'png', '_90f1f497790993166800724810347485.png', 'qrzxsj9e6o77dnp3bgb9xy0ec8417u', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-11-09 10:20:48', NULL, NULL, NULL, 0, 0, 0, 0),
(82, 'edraw', NULL, NULL, 'png', '_63771e3e120070166800724810369189.png', '4goenul0isb81xxjfr7zijs8t842fc', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-11-09 10:20:48', NULL, NULL, NULL, 0, 0, 0, 0),
(83, 'js', NULL, NULL, 'png', '_4572101f41178416680072481100769.png', '9zz03qw7g7q8hq5qn6smokjcsgtzus', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-11-09 10:20:48', NULL, NULL, NULL, 0, 0, 0, 0),
(84, 'css', NULL, NULL, 'png', '_5ef99d16039533166800724810327464.png', '2xy2bcxrujkpczn4t984foann2xxkv', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-11-09 10:20:48', NULL, NULL, NULL, 0, 0, 0, 0),
(85, 'Bee', NULL, NULL, 'png', '_d1d7015f868009166800724910602089.png', 'k7nb6bw5h06joxblumhurqo8ehgvs1', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-11-09 10:20:49', NULL, NULL, NULL, 0, 0, 0, 0),
(86, 'edraw', NULL, NULL, 'png', '_187acf79296315166800724910826682.png', 'uuwvja44dn5pao58rq00zljcosnpsm', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-11-09 10:20:49', NULL, NULL, NULL, 0, 0, 0, 0),
(87, 'js', NULL, NULL, 'png', '_24510415938888166800724910258238.png', '40eqkmg7zyz4p9b5pz01qytoggd9oc', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-11-09 10:20:49', NULL, NULL, NULL, 0, 0, 0, 0),
(88, 'css', NULL, NULL, 'png', '_69f357fc052129166800724910587621.png', 'l1uxrp886v3rwtvbcsaokxjw7ay5hn', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-11-09 10:20:49', NULL, NULL, NULL, 0, 0, 0, 0),
(89, 'Bee', NULL, NULL, 'png', '_dfa92d8f680906166800725011009596.png', 'alh6nge44f8ywgmhjvuzf9hu7e8c2s', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-11-09 10:20:50', NULL, NULL, NULL, 0, 0, 0, 0),
(90, 'edraw', NULL, NULL, 'png', '_d60678e8105957166800725010807778.png', 'd6fjltkduks5t8o9k1u474od53xmwp', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-11-09 10:20:50', NULL, NULL, NULL, 0, 0, 0, 0),
(91, 'js', NULL, NULL, 'png', '_04f2a414449876166800725111074765.png', 'oafz749y9jzww2c1byyubooqqekteo', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-11-09 10:20:51', NULL, NULL, NULL, 0, 0, 0, 0),
(92, 'css', NULL, NULL, 'png', '_8ba6c657966952166800725110741325.png', '67mzb032xzcy4thhsrulfsrfgdq6ji', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-11-09 10:20:51', NULL, NULL, NULL, 0, 0, 0, 0),
(93, 'Bee', NULL, NULL, 'png', '_85554f20292975166800725210945074.png', 'go8kxpsx4icjat99ip3chex0o52ntk', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-11-09 10:20:52', NULL, NULL, NULL, 0, 0, 0, 0),
(94, 'edraw', NULL, NULL, 'png', '_61995373896474166800725210964187.png', '61pw382tax8o5us06gas048b65jy9l', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-11-09 10:20:52', NULL, NULL, NULL, 0, 0, 0, 0),
(95, 'js', NULL, NULL, 'png', '_f1748d6b480838166800725210389581.png', '6wa9fy8uwwcxdxhyu93sfg268ickkv', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-11-09 10:20:52', NULL, NULL, NULL, 0, 0, 0, 0),
(96, 'css', NULL, NULL, 'png', '_d47bf0af426801166800725211035830.png', 'pc09reffp6ayvj3317k573414v4oeg', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-11-09 10:20:52', NULL, NULL, NULL, 0, 0, 0, 0),
(97, 'Bee', NULL, NULL, 'png', '_db64f68d393165166800734610479382.png', '3ip8qq4qythprorpn1re6n6ua0hjn9', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-11-09 10:22:26', NULL, NULL, NULL, 0, 0, 0, 0),
(98, 'edraw', NULL, NULL, 'png', '_11833d4b853213166800734610258137.png', 'des9ffiu8bz6dl8woy2k32oaovx0kj', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-11-09 10:22:26', NULL, NULL, NULL, 0, 0, 0, 0),
(99, 'js', NULL, NULL, 'png', '_2eacc822095353166800734610227284.png', '3f3elu6asriepa7tu3qfj87snreqoc', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-11-09 10:22:26', NULL, NULL, NULL, 0, 0, 0, 0),
(100, 'css', NULL, NULL, 'png', '_29921001130475166800734610819436.png', '088mj1dm4wsvcillywa5d7ttgmh3n6', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-11-09 10:22:26', NULL, NULL, NULL, 0, 0, 0, 0),
(101, 'Bee', NULL, NULL, 'png', '_563ca5e0227026166800734810895060.png', 'f5y35d52lusw0rixph5epssmmvrf9h', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-11-09 10:22:28', NULL, NULL, NULL, 0, 0, 0, 0),
(102, 'edraw', NULL, NULL, 'png', '_fe5e7cb6175323166800734811091164.png', 'rz3s1qwb9hwl1ts81vvwpze9y4bquw', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-11-09 10:22:28', NULL, NULL, NULL, 0, 0, 0, 0),
(103, 'js', NULL, NULL, 'png', '_d5369744791047166800734810897601.png', '1h0e89fblq9bvpbl99vbmepl7ob2cz', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-11-09 10:22:28', NULL, NULL, NULL, 0, 0, 0, 0),
(104, 'css', NULL, NULL, 'png', '_65d90fc6314495166800734810414942.png', 'j4rbwds6534225tf469st6lpxo5o5q', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-11-09 10:22:28', NULL, NULL, NULL, 0, 0, 0, 0),
(105, 'Bee', NULL, NULL, 'png', '_416ebee8545810166800735410474024.png', 'w0pl7tqpkc89ykfdk3j6jx9hh6pdd3', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-11-09 10:22:34', NULL, NULL, NULL, 0, 0, 0, 0),
(106, 'edraw', NULL, NULL, 'png', '_cfe912f5544092166800735410925183.png', '4ip0e2809s3x98is940iogbd6avnsw', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-11-09 10:22:34', NULL, NULL, NULL, 0, 0, 0, 0),
(107, 'js', NULL, NULL, 'png', '_d51b4167849181166800735410806868.png', 'mwzej8vj4iq6k0trj961ywovslxoai', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-11-09 10:22:34', NULL, NULL, NULL, 0, 0, 0, 0),
(108, 'css', NULL, NULL, 'png', '_4fa177df135514166800735410714380.png', '2vgdm3v65g138lbdj8cot1jng7ksjc', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-11-09 10:22:34', NULL, NULL, NULL, 0, 0, 0, 0),
(109, 'Bee', NULL, NULL, 'png', '_c43aa697310606166800735610669245.png', 'ikd7mkycrj7jvconbx8wky9kuv5dnv', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-11-09 10:22:36', NULL, NULL, NULL, 0, 0, 0, 0),
(110, 'edraw', NULL, NULL, 'png', '_af4f00ca24036816680073561061965.png', '8smnbx6ly335tbovl451gv6j9urdwu', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-11-09 10:22:36', NULL, NULL, NULL, 0, 0, 0, 0),
(111, 'js', NULL, NULL, 'png', '_baed9f5156084516680073561008718.png', 'wjb5ykuuj0g8mvzobcclf41weizg08', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-11-09 10:22:36', NULL, NULL, NULL, 0, 0, 0, 0),
(112, 'css', NULL, NULL, 'png', '_564127c0812338166800735610178418.png', '6l62zs0s4y0lg1r93bch8j0eqfdfuq', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-11-09 10:22:36', NULL, NULL, NULL, 0, 0, 0, 0),
(113, 'Bee', NULL, NULL, 'png', '_4e87337f944402166800742910544434.png', 'bewxr6fq7uofhav6ba0ky6kpszdl5p', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-11-09 10:23:49', NULL, NULL, NULL, 0, 0, 0, 0),
(114, 'edraw', NULL, NULL, 'png', '_bd380c81129254166800742910883003.png', 'pnkjzra23y39xar2ky11ef0tzocyhy', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-11-09 10:23:49', NULL, NULL, NULL, 0, 0, 0, 0),
(115, 'js', NULL, NULL, 'png', '_6f75e9b2101169166800742910934619.png', 'n8j7sg7qf6d2qw9t7akwvupi7b5glo', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-11-09 10:23:49', NULL, NULL, NULL, 0, 0, 0, 0),
(116, 'css', NULL, NULL, 'png', '_023d0a56007362166800742911109610.png', 'cf6dq6awp0yp773oam43hmxhuycld1', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-11-09 10:23:49', NULL, NULL, NULL, 0, 0, 0, 0),
(117, 'css', NULL, NULL, 'png', '_e033fdb1356905166800823311115198.png', 'hg9pvvpbiynvbxym4jrnqpbmzp6ya0', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-11-09 10:37:13', NULL, NULL, NULL, 0, 0, 0, 0),
(118, 'css', NULL, NULL, 'png', '_58785316517909166800823510171308.png', 'rikt6jqxrfeebrbrkll950qsytia6g', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-11-09 10:37:15', NULL, NULL, NULL, 0, 0, 0, 0),
(119, 'css', NULL, NULL, 'png', '_2f4fe03d81326416680082351056384.png', 'p4xv1jl974d1jntanl8uib1uvrw62u', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-11-09 10:37:15', NULL, NULL, NULL, 0, 0, 0, 0),
(120, 'css', NULL, NULL, 'png', '_a2232b5b364154166800823610242297.png', '1w2ot97c442ukuvfxv04mmmakbn2tq', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-11-09 10:37:16', NULL, NULL, NULL, 0, 0, 0, 0),
(121, 'css', NULL, NULL, 'png', '_ce059ef4020625166800956310274604.png', 'xitvtlfpbxbwpv9o8s1o9iqat5bgb0', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-11-09 10:59:23', NULL, NULL, NULL, 0, 0, 0, 0),
(122, 'css', NULL, NULL, 'png', '_cf63547f488775166800956610494912.png', 'lq25p0mi21vyfounuz9jrduwhz2q1n', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-11-09 10:59:26', NULL, NULL, NULL, 0, 0, 0, 0),
(123, 'css', NULL, NULL, 'png', '_1a996ecc539628166807938610468507.png', 'fdsk8nec5ri5npscqgzwhqllb454ui', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-11-10 06:23:06', NULL, NULL, NULL, 0, 0, 0, 0),
(124, 'bootstrap', NULL, NULL, 'png', '_2287c6b8507216166807938710204473.png', 'n94viux7fnpq5p0i95y586n8d0w9q2', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-11-10 06:23:07', NULL, NULL, NULL, 0, 0, 0, 0),
(125, 'js', NULL, NULL, 'png', '_1d7b813d90675716680793871073554.png', 's3ekfa441iv2i1q3mu8whm6oiuipcq', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-11-10 06:23:07', NULL, NULL, NULL, 0, 0, 0, 0),
(126, 'js', NULL, NULL, 'png', '_e702e51d414918166807938710023548.png', 'puj5m5cb6nqx0srgd8hg3gzdo9mt22', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-11-10 06:23:07', NULL, NULL, NULL, 0, 0, 0, 0),
(127, 'css', NULL, NULL, 'png', '_fcd11da0739948166807938910856181.png', 'b821ulgtijn9jc3tgh50y5u5924j9y', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-11-10 06:23:09', NULL, NULL, NULL, 0, 0, 0, 0),
(128, 'bootstrap', NULL, NULL, 'png', '_e0b60d93016038166807938910625331.png', 'm9l439g80nu02jle4sbjmjbahi58ir', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-11-10 06:23:09', NULL, NULL, NULL, 0, 0, 0, 0),
(129, 'js', NULL, NULL, 'png', '_586f9b40115857166807938910572615.png', 'wj23wsg4qvn4hx9p8a2gjap6da78mn', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-11-10 06:23:09', NULL, NULL, NULL, 0, 0, 0, 0),
(130, 'js', NULL, NULL, 'png', '_fdd5b16f123244166807938910498503.png', 'ggb0cwv9wwlqdoedyu3vxi4crfld6a', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-11-10 06:23:09', NULL, NULL, NULL, 0, 0, 0, 0),
(131, 'css', NULL, NULL, 'png', '_f04cd739429246166807939010087819.png', '8zejbai9c3roosfc9zilzf63o92o5i', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-11-10 06:23:10', NULL, NULL, NULL, 0, 0, 0, 0),
(132, 'bootstrap', NULL, NULL, 'png', '_77bdfcff674528166807939010068477.png', '9hl5ivtgvc0v3vsb7470b25kbdedee', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-11-10 06:23:10', NULL, NULL, NULL, 0, 0, 0, 0),
(133, 'js', NULL, NULL, 'png', '_131f383b460678166807939010619947.png', 'x4hgvt0asz33zevk2lc0v4ka1tt2jo', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-11-10 06:23:10', NULL, NULL, NULL, 0, 0, 0, 0),
(134, 'js', NULL, NULL, 'png', '_e9fd7c2c169835166807939010984194.png', '9lvpnhi3m58f7tcfvjj51baaqbszl7', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-11-10 06:23:10', NULL, NULL, NULL, 0, 0, 0, 0),
(135, 'css', NULL, NULL, 'png', '_e254457f508437166807943910076819.png', 'c9j7t775pdz1udhto07j84l0lyeb4i', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-11-10 06:23:59', NULL, NULL, NULL, 0, 0, 0, 0),
(136, 'bootstrap', NULL, NULL, 'png', '_50982fb259672816680794391111472.png', '5ayvg7c8009llr7ndcylcl3hhzzf21', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-11-10 06:23:59', NULL, NULL, NULL, 0, 0, 0, 0),
(137, 'js', NULL, NULL, 'png', '_310b6094149709166807943910927684.png', 'cduuofdov4bgv2hz62kgoox90vk75r', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-11-10 06:23:59', NULL, NULL, NULL, 0, 0, 0, 0),
(138, 'js', NULL, NULL, 'png', '_49e863b1053054166807944010946356.png', 'dv52qtkvo97loyj2k0igya2jujr6xa', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-11-10 06:24:00', NULL, NULL, NULL, 0, 0, 0, 0),
(139, 'css', NULL, NULL, 'png', '_5a7b238b409085166807944110253113.png', 'rpulbj5wu7l0itydqx7rsc9vtbbhrp', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-11-10 06:24:01', NULL, NULL, NULL, 0, 0, 0, 0),
(140, 'bootstrap', NULL, NULL, 'png', '_12b668a1554368166807944110707083.png', '1bfsrqxv9dlxnl0w5slmstt2mhtan5', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-11-10 06:24:01', NULL, NULL, NULL, 0, 0, 0, 0),
(141, 'js', NULL, NULL, 'png', '_d8e1344e837253166807944110155261.png', 'xk12nuopht6obiypfd2qpqc2i7t3it', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-11-10 06:24:01', NULL, NULL, NULL, 0, 0, 0, 0),
(142, 'js', NULL, NULL, 'png', '_efb3d8be216479166807944111073426.png', '76pjwryjk3pikeql3ht9l6h9h29izk', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-11-10 06:24:01', NULL, NULL, NULL, 0, 0, 0, 0),
(143, 'css', NULL, NULL, 'png', '_55a0ce82467708166807947211009153.png', 'x7rtug0ziglnjvofg7740ilvgjklt3', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-11-10 06:24:32', NULL, NULL, NULL, 0, 0, 0, 0),
(144, 'bootstrap', NULL, NULL, 'png', '_2557911c422440166807947210665219.png', '6bqcl1xaseer1zysukn6qgentkbnok', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-11-10 06:24:32', NULL, NULL, NULL, 0, 0, 0, 0),
(145, 'js', NULL, NULL, 'png', '_fccc6497749972166807947211026306.png', 'z4xs1devunmqm9e5sk1a25tsk00jdd', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-11-10 06:24:32', NULL, NULL, NULL, 0, 0, 0, 0),
(146, 'js', NULL, NULL, 'png', '_7a68443f621458166807947210796170.png', 'jgakqd0so1ohyshw28cgbh2jo64w7t', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-11-10 06:24:32', NULL, NULL, NULL, 0, 0, 0, 0),
(147, 'css', NULL, NULL, 'png', '_30aaa42888710616680795061052529.png', 'voox8ra2w0rayvve6ws9dilj58f063', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-11-10 06:25:06', NULL, NULL, NULL, 0, 0, 0, 0),
(148, 'css', NULL, NULL, 'png', '_ed46558a359809166807950610325973.png', 'lj4suac96g44dat2whaccllegllxy9', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-11-10 06:25:06', NULL, NULL, NULL, 0, 0, 0, 0),
(149, 'bootstrap', NULL, NULL, 'png', '_4a06d868842743166807950610951780.png', '027rvcpeeeehewy7u95op3d0nopkpp', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-11-10 06:25:06', NULL, NULL, NULL, 0, 0, 0, 0),
(150, 'css', NULL, NULL, 'png', '_3ba07b63645380166807950610792994.png', 'nohsjq05q2p1wrb3k8q5djr512dnzb', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-11-10 06:25:06', NULL, NULL, NULL, 0, 0, 0, 0),
(151, 'Bee', NULL, NULL, 'png', '_a6db4ed0837678166807996410285232.png', 'rlvpk4fpezfi9frsehlhap84z34h9y', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-11-10 06:32:44', NULL, NULL, NULL, 0, 0, 0, 0),
(152, 'Revenu vs dépenses-23 September 2022', NULL, NULL, 'png', '_2c8ed858865283166817115210248439.png', 'nvsaejf5bx9zie9eklq7wxsig5rbk9', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-11-11 07:52:33', NULL, NULL, NULL, 0, 0, 0, 0),
(153, 'WhatsApp Image 2022-07-02 at 16.15.23 (1)', NULL, NULL, 'jpeg', '_d87aa42c830001166817115310835302.jpeg', 's2dn51ryfd99siw9agzu3sjxghezjs', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-11-11 07:52:33', NULL, NULL, NULL, 0, 0, 0, 0),
(154, 'capture_d’écran_2022-11-09_104852', NULL, NULL, 'png', '_de7f47e0185086166817115310008579.png', '3rertcox8v2rvrncdxr8gz2vgccc0t', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-11-11 07:52:33', NULL, NULL, NULL, 0, 0, 0, 0),
(155, 'WhatsApp Image 2022-07-02 at 16.15.23', NULL, NULL, 'jpeg', '_c37a2122319830166817115310346464.jpeg', 'job7746x1esbr6qlmsu03mzhho129u', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-11-11 07:52:33', NULL, NULL, NULL, 0, 0, 0, 0),
(156, 'capture_d’écran_2022-11-09_104852', NULL, NULL, 'png', '_2812e5cf627306166817231710355141.png', 'xf2c5e0vq7xw8gy7tnfmd9l6rk05b2', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-11-11 08:11:57', NULL, NULL, NULL, 0, 0, 0, 0),
(157, 'h', NULL, NULL, 'pdf', '_6351bf9d316431166818059711087881.pdf', '81ra1qdfhyj14pq1164qdu46hubm8i', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-11-11 10:29:57', NULL, NULL, NULL, 0, 0, 0, 0),
(158, 'js', NULL, NULL, 'png', '_6547884c431817166818059710855700.png', 'zwkypchkbddfq34lwh3xtuc86t8hq8', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-11-11 10:29:57', NULL, NULL, NULL, 0, 0, 0, 0),
(159, 'bootstrap', NULL, NULL, 'png', '_46384036538177166818059710928402.png', 'p41kiqkltznyrr5ojkxukx8jmweje5', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-11-11 10:29:57', NULL, NULL, NULL, 0, 0, 0, 0),
(160, 'Bee', NULL, NULL, 'png', '_0424d201256008166818059710166873.png', 's3t5d0ylhgb7zdme3j4k208yh2d1s6', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-11-11 10:29:57', NULL, NULL, NULL, 0, 0, 0, 0),
(161, 'bootstrap', NULL, NULL, 'png', '_298f587446159016685016021089133.png', 'v2h4cg9ekdvrvf611inao2ktwh01la', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-11-15 03:40:03', NULL, NULL, NULL, 0, 0, 0, 0),
(162, 'Bee', NULL, NULL, 'png', '_f1de5100223042166850160310017205.png', 'gj663wjuynzpcy878i8qg8n5gwdug0', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-11-15 03:40:03', NULL, NULL, NULL, 0, 0, 0, 0),
(163, 'bootstrap', NULL, NULL, 'png', '_81c650ca361897166850309810192252.png', 'miattkwyam14vl3mksk3x2xvc0mz3j', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-11-15 04:04:58', NULL, NULL, NULL, 0, 0, 0, 0),
(164, 'bootstrap', NULL, NULL, 'png', '_4589b8b6871793166850309810194127.png', '4ejiryjtumvs11n85cgbb4yrds1vo2', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-11-15 04:04:58', NULL, NULL, NULL, 0, 0, 0, 0),
(165, 'css', NULL, NULL, 'png', '_7e05d6f8605819166850394710954123.png', 'dv77ai4p2ccd99hwv27muh14ald9mn', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-11-15 04:19:07', NULL, NULL, NULL, 0, 0, 0, 0),
(166, 'bootstrap', NULL, NULL, 'png', '_9c16f660361263166850394710418196.png', 'slbn35crgk9c2tkrprcxnx9wgaftas', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-11-15 04:19:07', NULL, NULL, NULL, 0, 0, 0, 0),
(167, 'css', NULL, NULL, 'png', '_228e338f548636166850441610722867.png', 'kwy5tsz3z3p7nfoqw0g409oq8798wc', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-11-15 04:26:56', NULL, NULL, NULL, 0, 0, 0, 0),
(168, 'edraw', NULL, NULL, 'png', '_15b3342a988745166850441610407565.png', '8zl1m3l1zzdpgyl9rid0l4fhbem0f5', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-11-15 04:26:56', NULL, NULL, NULL, 0, 0, 0, 0),
(169, 'Bee', NULL, NULL, 'png', '_adbe673f72522716685047951088178.png', 'il05uaszc82sxu264tkuqmvugbmqnp', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-11-15 04:33:15', NULL, NULL, NULL, 0, 0, 0, 0),
(170, 'Bee', NULL, NULL, 'png', '_8e621619572963166850479510381459.png', 'iz3aj9by46l8ngvo2d3bdcsaonknlp', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-11-15 04:33:15', NULL, NULL, NULL, 0, 0, 0, 0),
(171, 'css', NULL, NULL, 'png', '_bb6b07f0981404166850516210505273.png', 'osronfuoyn3pw0z5nypflg2xun5eev', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-11-15 04:39:22', NULL, NULL, NULL, 0, 0, 0, 0),
(172, 'html', NULL, NULL, 'png', '_2fd5d41e193070166850516210865382.png', 'n8llicg7xdqasz02ajtcgv5qc4ak7l', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-11-15 04:39:22', NULL, NULL, NULL, 0, 0, 0, 0),
(173, 'css', NULL, NULL, 'png', '_92af93f7496733166850655010742447.png', '32cljzbut12stwx2t8xryfd1tke3gc', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-11-15 05:02:30', NULL, NULL, NULL, 0, 0, 0, 0),
(174, 'bootstrap', NULL, NULL, 'png', '_13168e6a005956166850655010783079.png', '4sxw9c24o8kv5xrhzgx0yibmq16v19', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-11-15 05:02:30', NULL, NULL, NULL, 0, 0, 0, 0),
(175, 'login', NULL, NULL, 'jpg', '_d1ee59e2371302166850655010571961.jpg', 'rc15f2nwmplc6jiftn02ke2wx0unet', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-11-15 05:02:30', NULL, NULL, NULL, 0, 0, 0, 0),
(176, 'live', NULL, NULL, 'jpg', '_d2cd33e9702941166850655010688300.jpg', 'w3g6557hilwv8mej22gx4phtixbdli', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-11-15 05:02:30', NULL, NULL, NULL, 0, 0, 0, 0),
(177, 'edraw', NULL, NULL, 'png', '_d139db6a397176166850655010856730.png', 'zw55vsiryebl8vak2dakv7n3xkwhcz', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-11-15 05:02:30', NULL, NULL, NULL, 0, 0, 0, 0),
(178, 'css', NULL, NULL, 'png', '_e6ed5dac396288166850873310379365.png', '6w9j4794elniab8z6568flpc9pjtxd', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-11-15 05:38:53', NULL, NULL, NULL, 0, 0, 0, 0),
(179, 'bootstrap', NULL, NULL, 'png', '_09fb05dd683109166850873310194089.png', 'feu62d3qtlwbdr6mbkhlmd426nqb90', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-11-15 05:38:53', NULL, NULL, NULL, 0, 0, 0, 0),
(180, 'bootstrap', NULL, NULL, 'png', '_812214fb297185166850873310911326.png', '3k0qj2x7ii13xtj2remmnjo1gjybau', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-11-15 05:38:53', NULL, NULL, NULL, 0, 0, 0, 0),
(181, 'Bee', NULL, NULL, 'png', '_118bd558456178166850873311095484.png', 'hwa4gd1w0m9fetj8rnqcch39j0ycsx', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-11-15 05:38:54', NULL, NULL, NULL, 0, 0, 0, 0),
(182, 'css', NULL, NULL, 'png', '_5df0385c984157166850885010197475.png', 'reukb1xydcfw738safwcpa5ycz0x22', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-11-15 05:40:50', NULL, NULL, NULL, 0, 0, 0, 0),
(183, 'html', NULL, NULL, 'png', '_3d0236a1471680166850885010873507.png', '1z2dpzjj8v924ycz2691w064wtso9n', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-11-15 05:40:50', NULL, NULL, NULL, 0, 0, 0, 0),
(184, 'html', NULL, NULL, 'png', '_22b1cd1683202516685088501048616.png', 'o8a4cxojhm7ockybcpgxbv5dfcs737', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-11-15 05:40:50', NULL, NULL, NULL, 0, 0, 0, 0),
(185, 'html', NULL, NULL, 'png', '_d6cf4da5425168166850885010058211.png', 'qpvoq1iewuay13y5w97y3sny8nhvhv', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-11-15 05:40:50', NULL, NULL, NULL, 0, 0, 0, 0),
(186, 'css', NULL, NULL, 'png', '_1a638db8731060166850974410074496.png', '6qlsgc1yfjer8dhoit0qe5xfcw1c8f', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-11-15 05:55:44', NULL, NULL, NULL, 0, 0, 0, 0),
(187, 'bootstrap', NULL, NULL, 'png', '_b430beda110653166850974410405462.png', 'pupykk5452ovkwzqzogu4zmemo4i2s', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-11-15 05:55:44', NULL, NULL, NULL, 0, 0, 0, 0),
(188, 'Bee', NULL, NULL, 'png', '_e36286b9166538166850974410148595.png', 'c3t038v4px4swxt3lryu9xcll41rbh', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-11-15 05:55:44', NULL, NULL, NULL, 0, 0, 0, 0),
(189, 'html', NULL, NULL, 'png', '_dcda54e2917586166850974411086669.png', 'vob6lb1khoks33dz0bb6vao6z8dtct', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-11-15 05:55:44', NULL, NULL, NULL, 0, 0, 0, 0),
(190, 'Bee', NULL, NULL, 'png', '_565767eb476593166851595811112174.png', '475r2xmpr8z6ag7vg99pqml654j32x', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-11-15 07:39:18', NULL, NULL, NULL, 0, 0, 0, 0),
(191, 'html', NULL, NULL, 'png', '_ad7bdcaf816727166851595810133573.png', 'ty6hdrkljfgyrrmz4nmlbdibw0ndm5', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-11-15 07:39:18', NULL, NULL, NULL, 0, 0, 0, 0),
(192, 'bootstrap', NULL, NULL, 'png', '_754c32eb949038166851595811095045.png', 'jgov2yubnsu5dhkiaezwzg24igyt12', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-11-15 07:39:18', NULL, NULL, NULL, 0, 0, 0, 0),
(193, 'Bee', NULL, NULL, 'png', '_e2f92479839995166851716711007480.png', 'zber5kj8410tybawowiacaveb646nb', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-11-15 07:59:27', NULL, NULL, NULL, 0, 0, 0, 0),
(194, 'html', NULL, NULL, 'png', '_582967e0609164166851716710713872.png', 'b550in9ownytaevpfy709g7uxhkpoo', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-11-15 07:59:27', NULL, NULL, NULL, 0, 0, 0, 0),
(195, 'html', NULL, NULL, 'png', '_060afc8a322029166851718110059588.png', 'fg2om0t6lxpot5xfv5ou592ff40x2m', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-11-15 07:59:41', NULL, NULL, NULL, 0, 0, 0, 0),
(196, 'Bee', NULL, NULL, 'png', '_ad9d4d2b228978166851718110849055.png', 'vazctes79xt91lygftlg44ceeriz5k', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-11-15 07:59:41', NULL, NULL, NULL, 0, 0, 0, 0),
(197, 'html', NULL, NULL, 'png', '_12e1b435579668166851718110424937.png', '20gcrov0pzsjyw57n0tvolm80l8vsk', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-11-15 07:59:41', NULL, NULL, NULL, 0, 0, 0, 0),
(198, 'projet forage', NULL, NULL, 'pdf', '_f708f064297588166952979510369590.pdf', 'kxjhi5vlhel640tnsv0f31m01ns7u4', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-11-27 01:16:35', NULL, NULL, NULL, 0, 0, 0, 0),
(199, 'projet forage', NULL, NULL, 'pdf', '_7cb1f2f2365448166953009811109413.pdf', 'wq9k3459efudmme9rxwfrktrg1r5kf', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-11-27 01:21:38', NULL, NULL, NULL, 0, 0, 0, 0),
(200, 'projet forage', NULL, NULL, 'pdf', '_211c1e0b947471166953030210951886.pdf', 'ex1bcvo2a4qrgurgh5yc8eyw27z6p4', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-11-27 01:25:02', NULL, NULL, NULL, 0, 0, 0, 0),
(201, 'projet forage', NULL, NULL, 'pdf', '_5101a479537628166953113310883310.pdf', 'd6l66xpefqkm1h5a0aewumjn8mpx0f', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-11-27 01:38:53', NULL, NULL, NULL, 0, 0, 0, 0),
(202, 'projet forage', NULL, NULL, 'pdf', '_add5efc3437292166953372810498050.pdf', '78u38sh3t3o804dn0mr1914yyvm6ne', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-11-27 02:22:08', NULL, NULL, NULL, 0, 0, 0, 0),
(203, 'ff', NULL, NULL, 'jpg', '_3df07fda750920166953379710769316.jpg', 'cchf457myau1y4m7zn5pir6wf31r82', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-11-27 02:23:17', NULL, NULL, NULL, 0, 0, 0, 0),
(204, '1j.-models_contrat_cadre_services_110100_fr_clean', NULL, NULL, 'pdf', '_e593c562598241166953543810455958.pdf', '3snxga3p7rcf3dvnlbq7hnsojj1sn0', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-11-27 02:50:38', NULL, NULL, NULL, 0, 0, 0, 0),
(205, 'make-a-trade-01', NULL, NULL, 'png', '_818de4d2067870166953546010348515.png', '5jd0b5lzgpnajwlaqsjoct32b9coyp', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-11-27 02:51:00', NULL, NULL, NULL, 0, 0, 0, 0),
(206, 'Mustervertrag-F', NULL, NULL, 'pdf', '_af1c25e8623016166953550310248219.pdf', 'vgizycp8mc2r8xu4dsfm51b8c198ie', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-11-27 02:51:43', NULL, NULL, NULL, 0, 0, 0, 0),
(207, 'Rédaction-Contrat-de-prestation-de-services-1', NULL, NULL, 'pdf', '_e7e23670079728166953553010374732.pdf', 'ece46pw89jq7vukw1srhyg1g438ppr', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-11-27 02:52:10', NULL, NULL, NULL, 0, 0, 0, 0),
(208, 'contrat_daccompagnement_rh_vs', NULL, NULL, 'pdf', '_05b15a3b179930166953555010412585.pdf', 'nv4bhq0e502mp9ide9qbdr9tq0ybbb', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-11-27 02:52:30', NULL, NULL, NULL, 0, 0, 0, 0),
(209, 'make-a-trade-04', NULL, NULL, 'png', '_c09f9caf508109166953567110602231.png', 'x68xhvyb5g3q1ltcaj56xv481vp8xb', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-11-27 02:54:31', NULL, NULL, NULL, 0, 0, 0, 0),
(210, 'make-a-trade-04', NULL, NULL, 'png', '_621fbd17684219166953965310579398.png', '74l2yng16fvs0wmazl6tyjxxlf46ac', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-11-27 04:00:53', NULL, NULL, NULL, 0, 0, 0, 0),
(211, 'make-a-trade-03', NULL, NULL, 'png', '_3fab5890480092166953965310419670.png', 'p0kjjr871kbglrrf8c1c5prapgb2lv', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-11-27 04:00:53', NULL, NULL, NULL, 0, 0, 0, 0),
(212, 'make-a-trade-03', NULL, NULL, 'png', '_838e8afb570571166953965311082424.png', '1ge9q9vbn5td8zyquely5ekjblc9r8', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-11-27 04:00:53', NULL, NULL, NULL, 0, 0, 0, 0),
(213, 'téléchargement', NULL, NULL, 'png', '_3713bdda952639166954795110795472.png', 'n5redr1o1gqhh9qo76jx4zza0dax76', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-11-27 06:19:11', NULL, NULL, NULL, 0, 0, 0, 0),
(214, '7', NULL, NULL, 'pdf', '_5fd2c06f703488166955299610763032.pdf', 'nqxx2wh0267f1pe7inf01qgt3mp3ya', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-11-27 07:43:16', NULL, NULL, NULL, 0, 0, 0, 0),
(215, 'Bee', NULL, NULL, 'png', '_0cb5ebb1281938166979935111113390.png', 'q5ayhuqgn5mn5d7xfhh4rhvq13mmyy', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-11-30 04:09:11', NULL, NULL, NULL, 0, 0, 0, 0),
(216, 'bootstrap', NULL, NULL, 'png', '_a2a722df917838166979935110945014.png', 'b05vmg4rp6w7daukywewxhc5dm20g5', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-11-30 04:09:11', NULL, NULL, NULL, 0, 0, 0, 0),
(217, 'css', NULL, NULL, 'png', '_c0f52c66713634166979935110958227.png', 'q4fal42y64v6uzewpjy69o9uothv4v', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-11-30 04:09:11', NULL, NULL, NULL, 0, 0, 0, 0),
(218, 'css', NULL, NULL, 'png', '_98afdcc1647913166979935110511743.png', '9hjxbrdfzxt2f4drlcek4umb8r5m5b', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-11-30 04:09:11', NULL, NULL, NULL, 0, 0, 0, 0),
(219, 'css', NULL, NULL, 'png', '_475d6631558319166979945110891544.png', '5nwvu46rylzrvbxsvgf5o999d37apj', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-11-30 04:10:51', NULL, NULL, NULL, 0, 0, 0, 0),
(220, 'bootstrap', NULL, NULL, 'png', '_251e16a2241770166979945110125814.png', '71o4lscdyz6e6iy6kawk1bssro0z4n', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-11-30 04:10:51', NULL, NULL, NULL, 0, 0, 0, 0),
(221, 'bootstrap', NULL, NULL, 'png', '_a41b3bb3980643166979945110067404.png', '7b0guuqr4kwdjyhb58bg6dr3mw7ift', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-11-30 04:10:51', NULL, NULL, NULL, 0, 0, 0, 0),
(222, 'html', NULL, NULL, 'png', '_7aa7b774379552166979945110493894.png', 'vz0wnuybr2je54v5ymmqzee3bkdm0u', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-11-30 04:10:51', NULL, NULL, NULL, 0, 0, 0, 0),
(223, 'css', NULL, NULL, 'png', '_f12a6a74194780166981381710749912.png', 'gl1gy69vnvzcflvf9a7zkoskshidfr', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-11-30 08:10:17', NULL, NULL, NULL, 0, 0, 0, 0),
(224, 'css', NULL, NULL, 'png', '_d58e2f07893724166981381710698965.png', 'pdrii7jq3nay931w4frvp8auchewls', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-11-30 08:10:17', NULL, NULL, NULL, 0, 0, 0, 0),
(225, 'js', NULL, NULL, 'png', '_f0282b5f509455166981381710448571.png', 'qaldl7jshxavomw3pjapoum13iupp9', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-11-30 08:10:17', NULL, NULL, NULL, 0, 0, 0, 0),
(226, 'html', NULL, NULL, 'png', '_43f8e83d606230166981381710623032.png', 'myu8lhjksc5g36pbqlqgva9u9vgba7', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-11-30 08:10:17', NULL, NULL, NULL, 0, 0, 0, 0),
(227, 'bootstrap', NULL, NULL, 'png', '_8c59fd6f902860166981441210874726.png', 'rtjd5jlrg1j8lbxds0cczcyhtjflqc', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-11-30 08:20:12', NULL, NULL, NULL, 0, 0, 0, 0),
(228, 'html', NULL, NULL, 'png', '_88f0bf28937583166981441210179581.png', 'lb2h83fo7thptjr6jfzujy9k6rc74c', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-11-30 08:20:12', NULL, NULL, NULL, 0, 0, 0, 0),
(229, 'js', NULL, NULL, 'png', '_83cdcec0613291166981441210717261.png', 'jv1vq91ylva0x63ndbltmyad1e068f', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-11-30 08:20:12', NULL, NULL, NULL, 0, 0, 0, 0);
INSERT INTO `sys_documents` (`id`, `title`, `file_o_name`, `file_r_name`, `file_mime_type`, `file_path`, `file_dl_token`, `file_owner`, `version`, `link`, `sha1`, `md5`, `cid`, `gid`, `company_id`, `aid`, `contacts`, `deals`, `leads`, `created_at`, `created_by`, `updated_at`, `updated_by`, `customer_can_download`, `trash`, `archived`, `is_global`) VALUES
(230, 'css', NULL, NULL, 'png', '_bd4d08cd909716166981441210264705.png', 'a1ltxjm5azmi05ynmzsgz0a7d9oww2', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-11-30 08:20:12', NULL, NULL, NULL, 0, 0, 0, 0),
(231, 'html', NULL, NULL, 'png', '_854f1fb6674403166981493311116984.png', 'ja9qjyy0y57cm807r4xcxfqlnzy17s', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-11-30 08:28:53', NULL, NULL, NULL, 0, 0, 0, 0),
(232, 'js', NULL, NULL, 'png', '_7ffb4e0e422108166981493410289523.png', 'zvu5k1x5ugpd43a5wo8i55qspjo38v', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-11-30 08:28:54', NULL, NULL, NULL, 0, 0, 0, 0),
(233, 'make-a-trade-03', NULL, NULL, 'png', '_abdeb6f5228411166995046210665002.png', 'iqxpyo8oxycq7t3jww4of6xeevnntn', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-12-01 22:07:42', NULL, NULL, NULL, 0, 0, 0, 0),
(234, 'css', NULL, NULL, 'png', '_36a773b0403714167024618310698164.png', 'vhub8iznj7lsxo137imnqw2qh4qxng', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-12-05 08:16:23', NULL, NULL, NULL, 0, 0, 0, 0),
(235, 'bootstrap', NULL, NULL, 'png', '_24aa17e7820444167024618310796220.png', '23ca10915uo4eh4v3agkc76p609jef', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-12-05 08:16:23', NULL, NULL, NULL, 0, 0, 0, 0),
(236, 'Bee', NULL, NULL, 'png', '_d89a66c7601521167024618411043109.png', 'y7yzjltdiohg2i4qfb8u0khbyuqgoc', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-12-05 08:16:24', NULL, NULL, NULL, 0, 0, 0, 0),
(237, 'bootstrap', NULL, NULL, 'png', '_e2a7555f659902167024618410741324.png', 'gn9wcfeyg09l2vla96uek7kt5vc637', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-12-05 08:16:24', NULL, NULL, NULL, 0, 0, 0, 0),
(238, 'css', NULL, NULL, 'png', '_8612c55d853672167024839410223604.png', '33oo66k2vixvwlyzdn9f8xdzkapmwz', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-12-05 08:53:14', NULL, NULL, NULL, 0, 0, 0, 0),
(239, 'bootstrap', NULL, NULL, 'png', '_275d7fb2416505167024839410809418.png', '8cfqhqh4zn22gl1aiongj3mtouvajn', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-12-05 08:53:14', NULL, NULL, NULL, 0, 0, 0, 0),
(240, 'css', NULL, NULL, 'png', '_ba7e36c4895297167024839410429156.png', 'egqljayvw285mpeil2ym3wie0tx9pv', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-12-05 08:53:14', NULL, NULL, NULL, 0, 0, 0, 0),
(241, 'js', NULL, NULL, 'png', '_25daeb9b896107167024839410308914.png', '4vnppks3wqj7lq44bjeq4h6hnywbtz', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-12-05 08:53:14', NULL, NULL, NULL, 0, 0, 0, 0),
(242, 'css', NULL, NULL, 'png', '_eab0141b278194167024884110017939.png', 'zmzm7tqv6mv0zbjhyrfy6s1qzcjxum', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-12-05 09:00:41', NULL, NULL, NULL, 0, 0, 0, 0),
(243, 'bootstrap', NULL, NULL, 'png', '_94130ea1933042167024884110534853.png', 't8jbvpu1aq1wm7w5tqr303wx4yfsgo', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-12-05 09:00:41', NULL, NULL, NULL, 0, 0, 0, 0),
(244, 'Bee', NULL, NULL, 'png', '_83dc55ae404769167024884110103170.png', '3tk4q1k5lmfeiw5nsqed9lcv7ab5gx', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-12-05 09:00:41', NULL, NULL, NULL, 0, 0, 0, 0),
(245, 'html', NULL, NULL, 'png', '_55a988df408057167024884110349315.png', 'm5o4042j5lkdxk5azdbtu4farduglh', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-12-05 09:00:41', NULL, NULL, NULL, 0, 0, 0, 0),
(246, 'bootstrap', NULL, NULL, 'png', '_24aa17e7972463167024888310501059.png', 'nxe96rf5jlx29d0pzh196txkc8xhsv', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-12-05 09:01:23', NULL, NULL, NULL, 0, 0, 0, 0),
(247, 'html', NULL, NULL, 'png', '_5352696a344056167024888310449102.png', 'ly7vlh041wtiadfhnk95jtfob0g94y', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-12-05 09:01:23', NULL, NULL, NULL, 0, 0, 0, 0),
(248, 'js', NULL, NULL, 'png', '_812649f8226475167024888310375527.png', '1izv72usz1fml654r4ytlivqldaust', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-12-05 09:01:23', NULL, NULL, NULL, 0, 0, 0, 0),
(249, 'html', NULL, NULL, 'png', '_22f7e834301589167024888310935131.png', 'iq3rcv0na8kxvvjq8h4q8peakxsms4', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-12-05 09:01:23', NULL, NULL, NULL, 0, 0, 0, 0),
(250, 'bootstrap', NULL, NULL, 'png', '_91a575b3030325167024889211055775.png', 'mrdi2zw0mflta2mueocb5ut2pkutaa', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-12-05 09:01:32', NULL, NULL, NULL, 0, 0, 0, 0),
(251, 'html', NULL, NULL, 'png', '_37c9216b455069167024889210599874.png', 'y9pii00kaiukn876wd29hmyx6v9p6t', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-12-05 09:01:32', NULL, NULL, NULL, 0, 0, 0, 0),
(252, 'js', NULL, NULL, 'png', '_e2c9cd9310278616702488921076734.png', 'mtljimxc04huok4xs2ef52d9w1nnck', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-12-05 09:01:32', NULL, NULL, NULL, 0, 0, 0, 0),
(253, 'html', NULL, NULL, 'png', '_0141a8ae948988167024889210198830.png', '3pgv2y5k6arbc4ph3nhuaiht0aci4i', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-12-05 09:01:32', NULL, NULL, NULL, 0, 0, 0, 0),
(254, 'js', NULL, NULL, 'png', '_cddaa6e1858343167025389810617785.png', 'dw1wp4oiz199pc5q1sqwm4k7l51jw1', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-12-05 10:24:58', NULL, NULL, NULL, 0, 0, 0, 0),
(255, 'bootstrap', NULL, NULL, 'png', '_7da9fd85560333167025389811046160.png', '55f3sapuog95qu9k8ayadlvb7y0kky', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-12-05 10:24:58', NULL, NULL, NULL, 0, 0, 0, 0),
(256, 'css', NULL, NULL, 'png', '_cd6b73b6860579167032458710382886.png', 'gw5ylzg13gid3lvoqy2a9kw4youp22', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-12-06 06:03:07', NULL, NULL, NULL, 0, 0, 0, 0),
(257, 'js', NULL, NULL, 'png', '_7da18d03107790167033334110927954.png', 'uuyflq7irwg56z1mq968u8s5rt7pew', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-12-06 08:29:01', NULL, NULL, NULL, 0, 0, 0, 0),
(258, 'js', NULL, NULL, 'png', '_74249bfb313053167033334910002126.png', 'oe3kc2his83od6s8w2dh3v0z6um32b', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-12-06 08:29:09', NULL, NULL, NULL, 0, 0, 0, 0),
(259, 'bootstrap', NULL, NULL, 'png', '_0383314b399598167040914210203400.png', '1ba904bnt9frp3bxq6owjfxtd7znfo', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-12-07 05:32:22', NULL, NULL, NULL, 0, 0, 0, 0),
(260, 'css', NULL, NULL, 'png', '_831c2f88659809167040930210189446.png', '1bsiwfg3nj4psr90m2iz78zfrv23e5', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-12-07 05:35:02', NULL, NULL, NULL, 0, 0, 0, 0),
(261, 'bootstrap', NULL, NULL, 'png', '_07ac7cd1801779167041033710298573.png', 'yikctef23t6t0umuqurz05ke34rsw3', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-12-07 05:52:17', NULL, NULL, NULL, 0, 0, 0, 0),
(262, 'bootstrap', NULL, NULL, 'png', '_409bbd0d050306167041034710815194.png', 'b8fmt3nzzrimhy56tdoydqsdyppnhc', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-12-07 05:52:27', NULL, NULL, NULL, 0, 0, 0, 0),
(263, 'css', NULL, NULL, 'png', '_dc20d121811572167041511210335932.png', 'dv0h0ttrfvaea2sgzbnnmubl1xtobu', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-12-07 07:11:52', NULL, NULL, NULL, 0, 0, 0, 0),
(264, 'css', NULL, NULL, 'png', '_5c5bc7df068571167041512610008476.png', 'zrsws4jvsf02qcd6q45s4v05o5hiqw', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-12-07 07:12:06', NULL, NULL, NULL, 0, 0, 0, 0),
(265, 'js', NULL, NULL, 'png', '_7c78335a899170167041522010846368.png', 'zagqn73pmtlxhfkukq25r7a9ed8mpf', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-12-07 07:13:40', NULL, NULL, NULL, 0, 0, 0, 0),
(266, 'bootstrap', NULL, NULL, 'png', '_6c2fdcf8294169167041522011028629.png', 'hkur4y7ygiugktgms32og656gchp3x', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-12-07 07:13:40', NULL, NULL, NULL, 0, 0, 0, 0),
(267, 'bootstrap', NULL, NULL, 'png', '_8a146f1a390424167041621410647609.png', 'brmxx6czrt29n4ttl8223apxwvoqar', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-12-07 07:30:14', NULL, NULL, NULL, 0, 0, 0, 0),
(268, 'html', NULL, NULL, 'png', '_a51fb97597890416704199961033135.png', '0231a0e9mvrgx4aviiug8v1tk01qvm', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-12-07 08:33:16', NULL, NULL, NULL, 0, 0, 0, 0),
(269, 'js', NULL, NULL, 'png', '_c4819d06760021167042005210884687.png', '7t8z8hzz8i1ebomg81ov87y13hsnib', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-12-07 08:34:12', NULL, NULL, NULL, 0, 0, 0, 0),
(270, 'bootstrap', NULL, NULL, 'png', '_9c779f56792858167042208910826458.png', 'sef4gm53v53x1sc8rcz4q91oscac6p', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-12-07 09:08:09', NULL, NULL, NULL, 0, 0, 0, 0),
(271, 'bootstrap', NULL, NULL, 'png', '_df334b22114500167042243810108156.png', '3p25rmc0h346pyewpxntqixvj01yr9', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-12-07 09:13:58', NULL, NULL, NULL, 0, 0, 0, 0),
(272, 'js', NULL, NULL, 'png', '_30f8f6b9092323167042263510029433.png', 'v4kf4idvyandcvykj7klavtoofw2w7', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-12-07 09:17:15', NULL, NULL, NULL, 0, 0, 0, 0),
(273, 'edraw', NULL, NULL, 'png', '_d3630410784841167044191510596578.png', '0x4wf55oq6r5eqvg9l3y4rki44yazf', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-12-07 14:38:35', NULL, NULL, NULL, 0, 0, 0, 0),
(274, 'Bee', NULL, NULL, 'png', '_ee3dd1c2316785167044198010024704.png', 'mjwxriwr50x7wfx2rlaaxhbbkopptp', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-12-07 14:39:40', NULL, NULL, NULL, 0, 0, 0, 0),
(275, 'bootstrap', NULL, NULL, 'png', '_4191ef5f027634167066635110749988.png', 'nzupy3w29bimqrf7u5d0nhbypzi203', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-12-10 04:59:11', NULL, NULL, NULL, 0, 0, 0, 0),
(276, '7', NULL, NULL, 'pdf', '_6948bd4410926216706713971027351.pdf', 'c5e8iq7uzbspep2fafihas2inz9v4v', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-12-10 06:23:17', NULL, NULL, NULL, 0, 0, 0, 0),
(277, '7', NULL, NULL, 'pdf', '_01a06836845440167074240110602919.pdf', 'pat8iu9r10oqqqnnk9w8r0hd7hdvkq', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-12-11 02:06:41', NULL, NULL, NULL, 0, 0, 0, 0),
(278, '7', NULL, NULL, 'pdf', '_4edb2dc8440519167074240110338114.pdf', 'zrj5fmus7zk7k138ww5h0hrtv8mhss', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-12-11 02:06:41', NULL, NULL, NULL, 0, 0, 0, 0),
(279, '7', NULL, NULL, 'pdf', '_a6ea847131501916707424011102742.pdf', 'ihqwt8chsy7ebfvaqonkl3ngwpz7is', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-12-11 02:06:41', NULL, NULL, NULL, 0, 0, 0, 0),
(280, '7', NULL, NULL, 'pdf', '_9dc37271061860167075083410741134.pdf', 'puxil63kq9vg2bkny1jv81hqlf7i21', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-12-11 04:27:14', NULL, NULL, NULL, 0, 0, 0, 0),
(281, '7', NULL, NULL, 'pdf', '_4d42d2f5067959167077189810297408.pdf', 'w2062x8nmfjrpjk6235h87xh80nyzy', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-12-11 10:18:18', NULL, NULL, NULL, 0, 0, 0, 0),
(282, '07. Contrat de prestations', NULL, NULL, 'pdf', '_c2890d44238055167077223911017743.pdf', '9njxsmvhq5g3639f8cny5j19fodvrm', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-12-11 10:23:59', NULL, NULL, NULL, 0, 0, 0, 0),
(283, '07. Contrat de prestations', NULL, NULL, 'pdf', '_ef72d539993569167077230110547788.pdf', '04mtqguusqo6djcl6uae0no5fzri5r', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-12-11 10:25:01', NULL, NULL, NULL, 0, 0, 0, 0),
(284, '7', NULL, NULL, 'pdf', '_2ea279ca357442167077322410788713.pdf', 'rcxmn2mt84b8y0cxij164isyzwl4lz', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-12-11 10:40:24', NULL, NULL, NULL, 0, 0, 0, 0),
(285, '7', NULL, NULL, 'pdf', '_5a38a1eb757267167077329410308201.pdf', 'zt2pabpqyw01acptf4gquz3qrxps55', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-12-11 10:41:34', NULL, NULL, NULL, 0, 0, 0, 0),
(286, '7', NULL, NULL, 'pdf', '_dc0c3980932979167077541810957885.pdf', '9rp3r564qubm5cdg03nkob87xq9pij', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-12-11 11:16:58', NULL, NULL, NULL, 0, 0, 0, 0),
(287, '7', NULL, NULL, 'pdf', '_5a0c8283816135167090281610478382.pdf', 'edtec98cdmsoalv2trif5i3nhcgyfn', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-12-12 22:40:16', NULL, NULL, NULL, 0, 0, 0, 0),
(288, 'Bee', NULL, NULL, 'png', '_1c330c47692049167224871410727929.png', 'km5wec94bqmi58pxhy514soobm23ug', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-12-28 12:31:54', NULL, NULL, NULL, 0, 0, 0, 0),
(289, 'bootstrap', NULL, NULL, 'png', '_05f17e3c529731167224871410214676.png', 'w3po8j0w6z7r7lm8mo2dgz9eyc56wz', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-12-28 12:31:54', NULL, NULL, NULL, 0, 0, 0, 0),
(290, 'html', NULL, NULL, 'png', '_198dd5fb954861167224871411118145.png', 'dbvt38suc5tlj1xaszmz1l5xwckx8i', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-12-28 12:31:54', NULL, NULL, NULL, 0, 0, 0, 0),
(291, 'css', NULL, NULL, 'png', '_6acb0844012380167224871410253840.png', 'nmuudmapfcv80qj4hvzbeulwdf7a1u', 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, NULL, NULL, '2022-12-28 12:31:54', NULL, NULL, NULL, 0, 0, 0, 0);

-- --------------------------------------------------------

--
-- Structure de la table `sys_emailconfig`
--

DROP TABLE IF EXISTS `sys_emailconfig`;
CREATE TABLE IF NOT EXISTS `sys_emailconfig` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `method` varchar(50) NOT NULL,
  `host` varchar(100) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(200) NOT NULL,
  `apikey` varchar(200) NOT NULL,
  `port` varchar(10) NOT NULL,
  `secure` varchar(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `sys_emailconfig`
--

INSERT INTO `sys_emailconfig` (`id`, `method`, `host`, `username`, `password`, `apikey`, `port`, `secure`) VALUES
(1, 'phpmail', 'smtp.gmail.com', 'you@gmail.com', '123456', '', '587', 'tls');

-- --------------------------------------------------------

--
-- Structure de la table `sys_email_logs`
--

DROP TABLE IF EXISTS `sys_email_logs`;
CREATE TABLE IF NOT EXISTS `sys_email_logs` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `userid` int(10) NOT NULL,
  `sender` varchar(200) NOT NULL,
  `email` text NOT NULL,
  `subject` text NOT NULL,
  `message` text NOT NULL,
  `date` datetime DEFAULT NULL,
  `iid` int(11) NOT NULL DEFAULT '0',
  `rel_type` varchar(100) DEFAULT NULL,
  `rel_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `sys_email_logs`
--

INSERT INTO `sys_email_logs` (`id`, `userid`, `sender`, `email`, `subject`, `message`, `date`, `iid`, `rel_type`, `rel_id`) VALUES
(1, 3, '', 'kapekemrol@outlook.com', 'xgnffhh,tg.k//', 'zxmm,.', '2022-09-08 10:00:58', 0, NULL, 0),
(2, 3, '', 'kapekemrol@outlook.com', 'xgnffhh,tg.k//', 'zxmm,.', '2022-09-08 10:01:29', 0, NULL, 0);

-- --------------------------------------------------------

--
-- Structure de la table `sys_email_templates`
--

DROP TABLE IF EXISTS `sys_email_templates`;
CREATE TABLE IF NOT EXISTS `sys_email_templates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tplname` varchar(128) NOT NULL,
  `language_id` int(11) NOT NULL DEFAULT '1',
  `subject` text NOT NULL,
  `message` text NOT NULL,
  `send` varchar(50) DEFAULT 'Active',
  `core` enum('Yes','No') DEFAULT 'Yes',
  `hidden` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`,`language_id`),
  KEY `tplname` (`tplname`(32))
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `sys_email_templates`
--

INSERT INTO `sys_email_templates` (`id`, `tplname`, `language_id`, `subject`, `message`, `send`, `core`, `hidden`) VALUES
(3, 'Invoice:Invoice Created', 1, '{{business_name}} Invoice', '<div style=\"line-height:1.6;color:#222;text-align:left;width:550px;font-size:10pt;margin:0px 10px;font-family:verdana,\'droid sans\',\'lucida sans\',sans-serif;padding:14px;border:3px solid #d8d8d8;border-top:3px solid #007bc3\"><div style=\"padding:5px;font-size:11pt;font-weight:bold\">   Greetings,</div>	<div style=\"padding:5px\">		This email serves as your official invoice from <strong>{{business_name}}. </strong>	</div><div style=\"padding:10px 5px\">    Invoice URL: <a href=\"{{invoice_url}}\" target=\"_blank\">{{invoice_url}}</a><a target=\"_blank\" style=\"color:#1da9c0;font-weight:bold;padding:3px;text-decoration:none\" href=\"{{app_url}}\"></a><br>Invoice ID: {{invoice_id}}<br>Invoice Amount: {{invoice_amount}}<br>Due Date: {{invoice_due_date}}</div><div style=\"padding:5px\"><span style=\"font-size: 13.3333330154419px; line-height: 21.3333320617676px;\">If you have any questions or need assistance, please don\'t hesitate to contact us.</span><br></div><div style=\"padding:0px 5px\">	<div>Best Regards,<br>{{business_name}} Team</div></div></div>', 'Yes', 'Yes', 0),
(7, 'Admin:Password Change Request', 1, '{{business_name}} password change request', '<div style=\"line-height:1.6;color:#222;text-align:left;width:550px;font-size:10pt;margin:0px 10px;font-family:verdana,\'droid sans\',\'lucida sans\',sans-serif;padding:14px;border:3px solid #d8d8d8;border-top:3px solid #007bc3\"><div style=\"padding:5px;font-size:11pt;font-weight:bold\">   Hi {{name}},</div>	<div style=\"padding:5px\">		This is to confirm that we have received a Forgot Password request for your Account Username - {{username}} <br>From the IP Address - {{ip_address}}	</div>	<div style=\"padding:5px\">		Click this linke to reset your password- <br><a target=\"_blank\" style=\"color:#1da9c0;font-weight:bold;padding:3px;text-decoration:none\" href=\"{{password_reset_link}}\">{{password_reset_link}}</a>	</div><div style=\"padding:5px\">Please note: until your password has been changed, your current password will remain valid. The Forgot Password Link will be available for a limited time only.</div><div style=\"padding:0px 5px\">	<div>Best Regards,<br>{{business_name}} Team</div></div></div>', 'Yes', 'Yes', 0),
(10, 'Admin:New Password', 1, '{{business_name}} New Password for Admin', '<div style=\"line-height:1.6;color:#222;text-align:left;width:550px;font-size:10pt;margin:0px 10px;font-family:verdana,\'droid sans\',\'lucida sans\',sans-serif;padding:14px;border:3px solid #d8d8d8;border-top:3px solid #007bc3\">\n\n<div style=\"padding:5px;font-size:11pt;font-weight:bold\">\n   Hello {{name}}\n</div>\n\n\n	<div style=\"padding:5px\">\n		Here is your new password for <strong>{{business_name}}. </strong>\n	</div>\n\n	\n<div style=\"padding:10px 5px\">\n    Log in URL: <a target=\"_blank\" style=\"color:#1da9c0;font-weight:bold;padding:3px;text-decoration:none\" href=\"{{login_url}}\">{{login_url}}</a><br>Username: {{username}}<br>Password: {{password}}</div>\n\n<div style=\"padding:5px\">For security reason, Please change your password after login. </div>\n\n<div style=\"padding:0px 5px\">\n	<div>Best Regards,<br>{{business_name}} Team</div>\n\n</div>\n\n</div>', 'Yes', 'Yes', 0),
(12, 'Invoice:Invoice Payment Reminder', 1, '{{business_name}} Invoice Payment Reminder', '<div style=\"line-height:1.6;color:#222;text-align:left;width:550px;font-size:10pt;margin:0px 10px;font-family:verdana,\'droid sans\',\'lucida sans\',sans-serif;padding:14px;border:3px solid #d8d8d8;border-top:3px solid #007bc3\"><div style=\"padding:5px;font-size:11pt;font-weight:bold\">   Greetings,</div>	<div style=\"padding:5px\">		This is a billing reminder that your invoice no. {{invoice_id}} which was generated on {{invoice_date}} is due on {{invoice_due_date}}. 	</div><div style=\"padding:10px 5px\">    Invoice URL: <a href=\"{{invoice_url}}\" target=\"_blank\">{{invoice_url}}</a><a target=\"_blank\" style=\"color:#1da9c0;font-weight:bold;padding:3px;text-decoration:none\" href=\"{{app_url}}\"></a><br>Invoice ID: {{invoice_id}}<br>Invoice Amount: {{invoice_amount}}<br>Due Date: {{invoice_due_date}}</div><div style=\"padding:5px\"><span style=\"font-size: 13.3333330154419px; line-height: 21.3333320617676px;\">If you have any questions or need assistance, please don\'t hesitate to contact us.</span><br></div><div style=\"padding:0px 5px\">	<div>Best Regards,<br>{{business_name}} Team</div></div></div>', 'Yes', 'Yes', 0),
(13, 'Invoice:Invoice Overdue Notice', 1, '{{business_name}} Invoice Overdue Notice', '<div style=\"line-height:1.6;color:#222;text-align:left;width:550px;font-size:10pt;margin:0px 10px;font-family:verdana,\'droid sans\',\'lucida sans\',sans-serif;padding:14px;border:3px solid #d8d8d8;border-top:3px solid #007bc3\"><div style=\"padding:5px;font-size:11pt;font-weight:bold\">   Greetings,</div>	<div style=\"padding:5px\">		This is the notice that your invoice no. {{invoice_id}} which was generated on {{invoice_date}} is now overdue.	</div>	<div style=\"padding:10px 5px\">    Invoice URL: <a href=\"{{invoice_url}}\" target=\"_blank\">{{invoice_url}}</a><a target=\"_blank\" style=\"color:#1da9c0;font-weight:bold;padding:3px;text-decoration:none\" href=\"{{app_url}}\"></a><br>Invoice ID: {{invoice_id}}<br>Invoice Amount: {{invoice_amount}}<br>Due Date: {{invoice_due_date}}</div><div style=\"padding:5px\"><span style=\"font-size: 13.3333330154419px; line-height: 21.3333320617676px;\">If you have any questions or need assistance, please don\'t hesitate to contact us.</span><br></div><div style=\"padding:0px 5px\">	<div>Best Regards,<br>{{business_name}} Team</div></div></div>', 'Yes', 'Yes', 0),
(14, 'Invoice:Invoice Payment Confirmation', 1, '{{business_name}} Invoice Payment Confirmation', '<div style=\"line-height:1.6;color:#222;text-align:left;width:550px;font-size:10pt;margin:0px 10px;font-family:verdana,\'droid sans\',\'lucida sans\',sans-serif;padding:14px;border:3px solid #d8d8d8;border-top:3px solid #007bc3\">\n\n<div style=\"padding:5px;font-size:11pt;font-weight:bold\">\n   Greetings,\n</div>\n\n\n\n	<div style=\"padding:5px\">\n		This is a payment receipt for Invoice {{invoice_id}} sent on {{invoice_date}}.\n	</div>\n\n\n	<div style=\"padding:5px\">\n		Login to your client Portal to view this invoice.\n	</div>\n\n\n<div style=\"padding:10px 5px\">\n    Invoice URL: <a href=\"{{invoice_url}}\" target=\"_blank\">{{invoice_url}}</a><a target=\"_blank\" style=\"color:#1da9c0;font-weight:bold;padding:3px;text-decoration:none\" href=\"{{app_url}}\"></a><br>Invoice ID: {{invoice_id}}<br>Invoice Amount: {{invoice_amount}}<br>Due Date: {{invoice_due_date}}</div>\n\n\n<div style=\"padding:5px\"><span style=\"font-size: 13.3333330154419px; line-height: 21.3333320617676px;\">If you have any questions or need assistance, please don\'t hesitate to contact us.</span><br></div>\n\n\n<div style=\"padding:0px 5px\">\n	<div>Best Regards,<br>{{business_name}} Team</div>\n\n\n</div>\n\n\n</div>', 'Yes', 'Yes', 0),
(15, 'Invoice:Invoice Refund Confirmation', 1, '{{business_name}} Invoice Refund Confirmation', '<div style=\"line-height:1.6;color:#222;text-align:left;width:550px;font-size:10pt;margin:0px 10px;font-family:verdana,\'droid sans\',\'lucida sans\',sans-serif;padding:14px;border:3px solid #d8d8d8;border-top:3px solid #007bc3\"><div style=\"padding:5px;font-size:11pt;font-weight:bold\">   Greetings,</div>	<div style=\"padding:5px\">		This is confirmation that a refund has been processed for Invoice {{invoice_id}} sent on {{invoice_date}}.	</div><div style=\"padding:10px 5px\">    Invoice URL: <a href=\"{{invoice_url}}\" target=\"_blank\">{{invoice_url}}</a><a target=\"_blank\" style=\"color:#1da9c0;font-weight:bold;padding:3px;text-decoration:none\" href=\"{{app_url}}\"></a><br>Invoice ID: {{invoice_id}}<br>Invoice Amount: {{invoice_amount}}<br>Due Date: {{invoice_due_date}}</div><div style=\"padding:5px\"><span style=\"font-size: 13.3333330154419px; line-height: 21.3333320617676px;\">If you have any questions or need assistance, please don\'t hesitate to contact us.</span><br></div><div style=\"padding:0px 5px\">	<div>Best Regards,<br>{{business_name}} Team</div></div></div>', 'Yes', 'Yes', 0),
(16, 'Quote:Quote Created', 1, '{{quote_subject}}', '<div style=\"line-height:1.6;color:#222;text-align:left;width:550px;font-size:10pt;margin:0px 10px;font-family:verdana,sans-serif;padding:14px;border:3px solid #d8d8d8;border-top:3px solid #007bc3\"><div style=\"padding:5px;font-size:11pt;font-weight:bold\">   Greetings,</div>	<div style=\"padding:5px\">		Dear {{contact_name}},&nbsp;<br> Here is the quote you requested for.  The quote is valid until {{valid_until}}.	</div><div style=\"padding:10px 5px\">    Quote Unique URL: <a href=\"{{quote_url}}\" target=\"_blank\">{{quote_url}}</a><br></div><div style=\"padding:5px\"><span style=\"font-size: 13.3333330154419px; line-height: 21.3333320617676px;\">You may view the quote at any time and simply reply to this email with any further questions or requirement.</span><br></div><div style=\"padding:0px 5px\">	<div>Best Regards,<br>{{business_name}} Team</div></div></div>', 'Yes', 'Yes', 0),
(17, 'Client:Client Signup Email', 1, 'Your {{business_name}} Login Info', '<p>Dear {{client_name}},</p>\n<p>Welcome to {{business_name}}.</p>\n<p>You can track your billing, profile, transactions from this portal.</p>\n<p>Your login information is as follows:</p>\n<p>---------------------------------------------------------------------------------------</p>\n<p>Login URL: {{client_login_url}} <br />Email Address: {{client_email}}<br /> Password: Your chosen password.</p>\n<p>----------------------------------------------------------------------------------------</p>\n<p>We very much appreciate you for choosing us.</p>\n<p>{{business_name}} Team</p>', 'Yes', 'Yes', 0);

-- --------------------------------------------------------

--
-- Structure de la table `sys_events`
--

DROP TABLE IF EXISTS `sys_events`;
CREATE TABLE IF NOT EXISTS `sys_events` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` text,
  `description` text,
  `contacts` text,
  `deals` text,
  `owner` varchar(200) DEFAULT NULL,
  `status` varchar(200) DEFAULT NULL,
  `etype` varchar(200) DEFAULT NULL,
  `priority` varchar(200) DEFAULT NULL,
  `color` varchar(20) DEFAULT NULL,
  `o` varchar(200) DEFAULT NULL,
  `cid` int(11) NOT NULL DEFAULT '0',
  `aid` int(11) NOT NULL DEFAULT '0',
  `iid` int(11) NOT NULL DEFAULT '0',
  `oid` int(11) NOT NULL DEFAULT '0',
  `rid` int(11) NOT NULL DEFAULT '0',
  `company_id` int(11) NOT NULL DEFAULT '0',
  `start` datetime DEFAULT NULL,
  `end` datetime DEFAULT NULL,
  `allday` int(1) NOT NULL DEFAULT '0',
  `notification` int(1) NOT NULL DEFAULT '0',
  `trash` int(1) NOT NULL DEFAULT '0',
  `archived` int(1) NOT NULL DEFAULT '0',
  `picture_file_token` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `sys_events`
--

INSERT INTO `sys_events` (`id`, `title`, `description`, `contacts`, `deals`, `owner`, `status`, `etype`, `priority`, `color`, `o`, `cid`, `aid`, `iid`, `oid`, `rid`, `company_id`, `start`, `end`, `allday`, `notification`, `trash`, `archived`, `picture_file_token`) VALUES
(1, 'abbonement', 're,fwn.sjdmk/,.', NULL, NULL, NULL, NULL, NULL, NULL, '#21f3d9', NULL, 0, 0, 0, 0, 0, 0, '2022-11-18 12:30:00', '2022-11-18 14:30:59', 0, 0, 0, 0, ''),
(2, 'abbonement', 'ggguiiuuihibuhinhnnhjknkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkk', NULL, NULL, NULL, NULL, NULL, NULL, '#2196f3', NULL, 0, 0, 0, 0, 0, 0, '2022-12-07 09:30:00', '2022-12-07 11:30:59', 0, 0, 0, 0, '0x4wf55oq6r5eqvg9l3y4rki44yazf'),
(3, 'school fees', 'bijbjjjnjkj', NULL, NULL, NULL, NULL, NULL, NULL, '#ffeb3b', NULL, 0, 0, 0, 0, 0, 0, '2022-12-07 09:30:00', '2022-12-07 11:30:59', 0, 0, 0, 0, 'mjwxriwr50x7wfx2rlaaxhbbkopptp');

-- --------------------------------------------------------

--
-- Structure de la table `sys_invoiceitems`
--

DROP TABLE IF EXISTS `sys_invoiceitems`;
CREATE TABLE IF NOT EXISTS `sys_invoiceitems` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `invoiceid` int(10) NOT NULL DEFAULT '0',
  `userid` int(10) NOT NULL,
  `type` text NOT NULL,
  `relid` int(10) NOT NULL,
  `itemcode` varchar(100) NOT NULL,
  `description` text NOT NULL,
  `qty` varchar(20) NOT NULL DEFAULT '1',
  `amount` decimal(14,2) NOT NULL DEFAULT '0.00',
  `taxed` int(1) NOT NULL,
  `taxamount` decimal(10,2) NOT NULL DEFAULT '0.00',
  `total` decimal(14,2) NOT NULL DEFAULT '0.00',
  `duedate` date DEFAULT NULL,
  `paymentmethod` text NOT NULL,
  `notes` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `invoiceid` (`invoiceid`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `sys_invoiceitems`
--

INSERT INTO `sys_invoiceitems` (`id`, `invoiceid`, `userid`, `type`, `relid`, `itemcode`, `description`, `qty`, `amount`, `taxed`, `taxamount`, `total`, `duedate`, `paymentmethod`, `notes`) VALUES
(1, 1, 11, '', 0, '', 'douala', '1', '200000.00', 0, '0.00', '200000.00', '2022-09-24', '', ''),
(2, 2, 50, '', 0, '', 'ddihufcegrhigri', '12', '4000.00', 1, '0.00', '48000.00', '2022-11-10', '', ''),
(3, 3, 22, '', 0, '', 'm mm', '4', '4000.00', 0, '0.00', '16000.00', '2022-12-10', '', ''),
(4, 4, 22, '', 0, '', 'yggyuugugguu', '12', '10000000000.00', 0, '0.00', '120000000000.00', '2022-12-10', '', '');

-- --------------------------------------------------------

--
-- Structure de la table `sys_invoices`
--

DROP TABLE IF EXISTS `sys_invoices`;
CREATE TABLE IF NOT EXISTS `sys_invoices` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `userid` int(10) NOT NULL,
  `account` varchar(200) NOT NULL,
  `cn` varchar(100) NOT NULL DEFAULT '',
  `invoicenum` text NOT NULL,
  `date` date DEFAULT NULL,
  `duedate` date DEFAULT NULL,
  `datepaid` datetime DEFAULT NULL,
  `subtotal` decimal(18,2) NOT NULL,
  `discount_type` varchar(1) NOT NULL DEFAULT 'f',
  `discount_value` decimal(14,2) NOT NULL DEFAULT '0.00',
  `discount` decimal(14,2) NOT NULL DEFAULT '0.00',
  `credit` decimal(10,2) NOT NULL DEFAULT '0.00',
  `taxname` varchar(100) NOT NULL,
  `tax` decimal(10,2) NOT NULL,
  `tax2` decimal(10,2) NOT NULL,
  `total` decimal(18,2) NOT NULL DEFAULT '0.00',
  `taxrate` decimal(10,2) NOT NULL,
  `taxrate2` decimal(10,2) NOT NULL,
  `status` text NOT NULL,
  `paymentmethod` text NOT NULL,
  `notes` text NOT NULL,
  `vtoken` varchar(20) NOT NULL,
  `ptoken` varchar(20) NOT NULL,
  `r` varchar(100) NOT NULL DEFAULT '0',
  `nd` date DEFAULT NULL,
  `eid` int(10) NOT NULL DEFAULT '0',
  `ename` varchar(200) NOT NULL DEFAULT '',
  `vid` int(11) NOT NULL DEFAULT '0',
  `currency` int(11) NOT NULL DEFAULT '0',
  `currency_symbol` varchar(10) DEFAULT NULL,
  `currency_prefix` varchar(10) DEFAULT NULL,
  `currency_suffix` varchar(10) DEFAULT NULL,
  `currency_rate` decimal(11,4) NOT NULL DEFAULT '1.0000',
  `recurring` tinyint(1) NOT NULL DEFAULT '0',
  `recurring_ends` date DEFAULT NULL,
  `last_recurring_date` date DEFAULT NULL,
  `source` varchar(200) DEFAULT NULL,
  `sale_agent` int(11) NOT NULL DEFAULT '0',
  `last_overdue_reminder` date DEFAULT NULL,
  `allowed_payment_methods` text,
  `billing_street` varchar(200) DEFAULT NULL,
  `billing_city` varchar(100) DEFAULT NULL,
  `billing_state` varchar(100) DEFAULT NULL,
  `billing_zip` varchar(50) DEFAULT NULL,
  `billing_country` varchar(100) DEFAULT NULL,
  `shipping_street` varchar(200) DEFAULT NULL,
  `shipping_city` varchar(100) DEFAULT NULL,
  `shipping_state` varchar(100) DEFAULT NULL,
  `shipping_zip` varchar(100) DEFAULT NULL,
  `shipping_country` varchar(100) DEFAULT NULL,
  `q_hide` tinyint(1) NOT NULL DEFAULT '0',
  `show_quantity_as` varchar(100) DEFAULT NULL,
  `pid` int(11) NOT NULL DEFAULT '0',
  `is_credit_invoice` int(1) NOT NULL DEFAULT '0',
  `aid` int(11) NOT NULL DEFAULT '0',
  `aname` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `userid` (`userid`),
  KEY `status` (`status`(3))
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `sys_invoices`
--

INSERT INTO `sys_invoices` (`id`, `userid`, `account`, `cn`, `invoicenum`, `date`, `duedate`, `datepaid`, `subtotal`, `discount_type`, `discount_value`, `discount`, `credit`, `taxname`, `tax`, `tax2`, `total`, `taxrate`, `taxrate2`, `status`, `paymentmethod`, `notes`, `vtoken`, `ptoken`, `r`, `nd`, `eid`, `ename`, `vid`, `currency`, `currency_symbol`, `currency_prefix`, `currency_suffix`, `currency_rate`, `recurring`, `recurring_ends`, `last_recurring_date`, `source`, `sale_agent`, `last_overdue_reminder`, `allowed_payment_methods`, `billing_street`, `billing_city`, `billing_state`, `billing_zip`, `billing_country`, `shipping_street`, `shipping_city`, `shipping_state`, `shipping_zip`, `shipping_country`, `q_hide`, `show_quantity_as`, `pid`, `is_credit_invoice`, `aid`, `aname`) VALUES
(2, 50, 'test', 'er', 'c esd', '2022-11-10', '2022-11-15', '2022-11-10 06:50:50', '48000.00', 'p', '0.00', '0.00', '0.00', '', '0.00', '0.00', '48000.00', '0.00', '0.00', 'Unpaid', '', '<p>fmkfgfgmgfmgfmgf</p>', '4871045995', '2278272437', '0', '2022-11-10', 0, '', 0, 1, '-', NULL, NULL, '1.0000', 0, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, 0, 0, 0, NULL),
(3, 22, 'abc', '', '', '2022-12-10', '2022-12-10', '2022-12-10 04:31:16', '16000.00', 'p', '0.00', '0.00', '0.00', '', '0.00', '0.00', '16000.00', '0.00', '0.00', 'Unpaid', '', '', '2348099596', '8121516579', '0', '2022-12-10', 0, '', 0, 1, '-', NULL, NULL, '1.0000', 0, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, 0, 0, 0, NULL),
(4, 22, 'abc', '', '', '2022-12-10', '2022-12-10', '2022-12-10 04:35:46', '120000000000.00', 'p', '0.00', '0.00', '0.00', '', '0.00', '0.00', '120000000000.00', '0.00', '0.00', 'Unpaid', '', '', '6702206069', '2167555771', '0', '2022-12-10', 0, '', 0, 1, 'FCFA', NULL, NULL, '100.0000', 0, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, 0, 0, 0, NULL);

-- --------------------------------------------------------

--
-- Structure de la table `sys_items`
--

DROP TABLE IF EXISTS `sys_items`;
CREATE TABLE IF NOT EXISTS `sys_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` mediumtext NOT NULL,
  `unit` varchar(100) NOT NULL DEFAULT '',
  `sales_price` decimal(16,2) NOT NULL DEFAULT '0.00',
  `inventory` decimal(16,4) NOT NULL DEFAULT '0.0000',
  `weight` decimal(16,4) NOT NULL DEFAULT '0.0000',
  `width` decimal(12,4) NOT NULL DEFAULT '0.0000',
  `length` decimal(12,4) NOT NULL DEFAULT '0.0000',
  `height` decimal(12,4) NOT NULL DEFAULT '0.0000',
  `sku` varchar(50) DEFAULT NULL,
  `upc` varchar(50) DEFAULT NULL,
  `ean` varchar(50) DEFAULT NULL,
  `mpn` varchar(50) DEFAULT NULL,
  `isbn` varchar(50) DEFAULT NULL,
  `sid` int(11) NOT NULL DEFAULT '0',
  `supplier` varchar(200) DEFAULT NULL,
  `bid` int(11) NOT NULL DEFAULT '0',
  `brand` varchar(200) DEFAULT NULL,
  `sell_account` int(11) NOT NULL DEFAULT '0',
  `purchase_account` int(11) NOT NULL DEFAULT '0',
  `inventory_account` int(11) NOT NULL DEFAULT '0',
  `taxable` int(1) NOT NULL DEFAULT '0',
  `location` varchar(200) DEFAULT NULL,
  `item_number` varchar(100) NOT NULL DEFAULT '',
  `description` mediumtext NOT NULL,
  `type` enum('Service','Product') NOT NULL,
  `track_inventroy` enum('Yes','No') NOT NULL DEFAULT 'No',
  `negative_stock` enum('Yes','No') NOT NULL DEFAULT 'No',
  `available` int(11) NOT NULL DEFAULT '0',
  `status` enum('Active','Inactive') NOT NULL DEFAULT 'Active',
  `added` date DEFAULT NULL,
  `last_sold` date DEFAULT NULL,
  `e` mediumtext NOT NULL,
  `sorder` int(11) NOT NULL DEFAULT '0',
  `gid` int(11) NOT NULL DEFAULT '0',
  `category_id` int(11) NOT NULL DEFAULT '0',
  `supplier_id` int(11) NOT NULL DEFAULT '0',
  `gname` varchar(100) DEFAULT NULL,
  `product_id` varchar(100) DEFAULT NULL,
  `size` varchar(100) DEFAULT NULL,
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `expire_date` date DEFAULT NULL,
  `expire_days` int(11) NOT NULL DEFAULT '0',
  `image` text,
  `flag` int(1) NOT NULL DEFAULT '0',
  `is_service` int(1) NOT NULL DEFAULT '0',
  `commission_percent` decimal(16,2) NOT NULL DEFAULT '0.00',
  `commission_percent_type` varchar(100) DEFAULT NULL,
  `commission_fixed` decimal(16,2) NOT NULL DEFAULT '0.00',
  `trash` int(1) NOT NULL DEFAULT '0',
  `payterm` varchar(200) DEFAULT NULL,
  `cost_price` decimal(16,2) NOT NULL DEFAULT '0.00',
  `unit_price` decimal(16,2) NOT NULL DEFAULT '0.00',
  `promo_price` decimal(16,2) NOT NULL DEFAULT '0.00',
  `setup` decimal(16,2) NOT NULL DEFAULT '0.00',
  `onetime` decimal(16,2) NOT NULL DEFAULT '0.00',
  `monthly` decimal(16,2) NOT NULL DEFAULT '0.00',
  `monthlysetup` decimal(16,2) NOT NULL DEFAULT '0.00',
  `quarterly` decimal(16,2) NOT NULL DEFAULT '0.00',
  `quarterlysetup` decimal(16,2) NOT NULL DEFAULT '0.00',
  `halfyearly` decimal(16,2) NOT NULL DEFAULT '0.00',
  `halfyearlysetup` decimal(16,2) NOT NULL DEFAULT '0.00',
  `annually` decimal(16,2) NOT NULL DEFAULT '0.00',
  `annuallysetup` decimal(16,2) NOT NULL DEFAULT '0.00',
  `biennially` decimal(16,2) NOT NULL DEFAULT '0.00',
  `bienniallysetup` decimal(16,2) NOT NULL DEFAULT '0.00',
  `triennially` decimal(16,2) NOT NULL DEFAULT '0.00',
  `trienniallysetup` decimal(16,2) NOT NULL DEFAULT '0.00',
  `has_domain` varchar(100) DEFAULT NULL,
  `free_domain` varchar(100) DEFAULT NULL,
  `email_rel` int(11) NOT NULL DEFAULT '0',
  `tags` text,
  `c1` text,
  `c2` text,
  `c3` text,
  `c4` text,
  `c5` text,
  `c6` text,
  `c7` text,
  `c8` text,
  `c9` text,
  `c10` text,
  `c11` text,
  `c12` text,
  `c13` text,
  `c14` text,
  `c15` text,
  `c16` text,
  `c17` text,
  `c18` text,
  `c19` text,
  `c20` text,
  `c21` text,
  `c22` text,
  `c23` text,
  `c24` text,
  `c25` text,
  `c26` text,
  `c27` text,
  `c28` text,
  `c29` text,
  `c30` text,
  `sold_count` decimal(16,4) DEFAULT '0.0000',
  `total_amount` decimal(16,4) DEFAULT '0.0000',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `sys_items`
--

INSERT INTO `sys_items` (`id`, `name`, `unit`, `sales_price`, `inventory`, `weight`, `width`, `length`, `height`, `sku`, `upc`, `ean`, `mpn`, `isbn`, `sid`, `supplier`, `bid`, `brand`, `sell_account`, `purchase_account`, `inventory_account`, `taxable`, `location`, `item_number`, `description`, `type`, `track_inventroy`, `negative_stock`, `available`, `status`, `added`, `last_sold`, `e`, `sorder`, `gid`, `category_id`, `supplier_id`, `gname`, `product_id`, `size`, `start_date`, `end_date`, `expire_date`, `expire_days`, `image`, `flag`, `is_service`, `commission_percent`, `commission_percent_type`, `commission_fixed`, `trash`, `payterm`, `cost_price`, `unit_price`, `promo_price`, `setup`, `onetime`, `monthly`, `monthlysetup`, `quarterly`, `quarterlysetup`, `halfyearly`, `halfyearlysetup`, `annually`, `annuallysetup`, `biennially`, `bienniallysetup`, `triennially`, `trienniallysetup`, `has_domain`, `free_domain`, `email_rel`, `tags`, `c1`, `c2`, `c3`, `c4`, `c5`, `c6`, `c7`, `c8`, `c9`, `c10`, `c11`, `c12`, `c13`, `c14`, `c15`, `c16`, `c17`, `c18`, `c19`, `c20`, `c21`, `c22`, `c23`, `c24`, `c25`, `c26`, `c27`, `c28`, `c29`, `c30`, `sold_count`, `total_amount`, `created_at`, `updated_at`) VALUES
(1, 'douala', '', '200000.00', '0.0000', '0.0000', '0.0000', '0.0000', '0.0000', NULL, NULL, NULL, NULL, NULL, 0, NULL, 0, NULL, 0, 0, 0, 0, NULL, '1', '', 'Product', 'No', 'No', 0, 'Active', NULL, NULL, '', 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, 0, 0, '0.00', NULL, '0.00', 0, NULL, '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0.0000', '0.0000', NULL, NULL);

-- --------------------------------------------------------

--
-- Structure de la table `sys_item_cats`
--

DROP TABLE IF EXISTS `sys_item_cats`;
CREATE TABLE IF NOT EXISTS `sys_item_cats` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pid` int(11) NOT NULL DEFAULT '0',
  `name` varchar(200) DEFAULT NULL,
  `type` varchar(200) DEFAULT NULL,
  `img` varchar(200) DEFAULT NULL,
  `status` varchar(200) DEFAULT NULL,
  `description` text,
  `sorder` int(11) NOT NULL DEFAULT '0',
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `sys_leads`
--

DROP TABLE IF EXISTS `sys_leads`;
CREATE TABLE IF NOT EXISTS `sys_leads` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fullname` varchar(200) DEFAULT NULL,
  `company` varchar(200) DEFAULT NULL,
  `email` varchar(200) DEFAULT NULL,
  `phone` varchar(50) DEFAULT NULL,
  `color` varchar(20) DEFAULT NULL,
  `status` varchar(200) DEFAULT NULL,
  `source` varchar(200) DEFAULT NULL,
  `added_from` varchar(200) DEFAULT NULL,
  `o` varchar(200) DEFAULT NULL,
  `cid` int(11) NOT NULL DEFAULT '0',
  `aid` int(11) NOT NULL DEFAULT '0',
  `iid` int(11) NOT NULL DEFAULT '0',
  `oid` int(11) NOT NULL DEFAULT '0',
  `rid` int(11) NOT NULL DEFAULT '0',
  `sorder` int(11) NOT NULL DEFAULT '0',
  `assigned` int(11) NOT NULL DEFAULT '0',
  `created_at` datetime DEFAULT NULL,
  `created_by` varchar(200) DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `updated_by` varchar(200) DEFAULT NULL,
  `last_contact` datetime DEFAULT NULL,
  `last_contact_by` varchar(200) DEFAULT NULL,
  `date_converted` datetime DEFAULT NULL,
  `public` int(1) NOT NULL DEFAULT '0',
  `ratings` varchar(50) DEFAULT NULL,
  `flag` int(1) NOT NULL DEFAULT '0',
  `lost` int(1) NOT NULL DEFAULT '0',
  `junk` int(1) NOT NULL DEFAULT '0',
  `trash` int(1) NOT NULL DEFAULT '0',
  `archived` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `sys_logs`
--

DROP TABLE IF EXISTS `sys_logs`;
CREATE TABLE IF NOT EXISTS `sys_logs` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `type` varchar(50) NOT NULL,
  `description` text NOT NULL,
  `userid` int(10) NOT NULL,
  `ip` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=439 DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `sys_logs`
--

INSERT INTO `sys_logs` (`id`, `date`, `type`, `description`, `userid`, `ip`) VALUES
(1, '2016-11-15 11:30:45', 'System', 'Build Updated to: 4600\r\nDocuments Table Created\r\nOrders Table Created\r\nsys_items table altered\r\nUpdate Completed!\r\n', 0, '::1'),
(2, '2017-04-18 08:37:23', 'System', 'Build Updated to: 4620\r\nUpdate Completed!\r\n', 0, '::1'),
(3, '2017-09-17 15:08:39', 'System', 'Build Updated to: 4671\r\nUpdate Completed!\r\n', 0, '127.0.0.1'),
(4, '2017-09-21 05:34:13', 'Admin', 'Login Successful demo@example.com', 1, '127.0.0.1'),
(5, '2017-09-28 05:07:55', 'Admin', 'Login Successful demo@example.com', 1, '127.0.0.1'),
(6, '2017-09-29 19:12:19', 'Admin', 'Login Successful demo@example.com', 1, '127.0.0.1'),
(7, '2017-11-13 04:44:33', 'Admin', 'Login Successful demo@example.com', 1, '127.0.0.1'),
(8, '2017-11-13 05:12:33', 'Admin', 'New Contact Added test [CID: 1]', 1, '127.0.0.1'),
(9, '2017-11-13 05:12:40', 'Admin', 'New Contact Added test 2 [CID: 2]', 1, '127.0.0.1'),
(10, '2017-11-18 11:52:45', 'Admin', 'Login Successful demo@example.com', 1, '127.0.0.1'),
(11, '2021-07-02 06:26:35', 'Admin', 'Failed Login demo@example.com', 0, '127.0.0.1'),
(12, '2021-07-02 06:27:26', 'Admin', 'Login Successful demo@example.com', 1, '127.0.0.1'),
(13, '2021-07-02 06:27:26', 'System', 'Build updated: 4900\r\nUpdate Completed!\n', 0, '127.0.0.1'),
(14, '2022-08-31 12:54:09', 'Admin', 'Failed Login demo@example.com', 0, '::1'),
(15, '2022-08-31 12:54:24', 'Admin', 'Failed Login demo@example.com', 0, '::1'),
(16, '2022-08-31 12:58:02', 'Admin', 'Login Successful demo@example.com', 1, '::1'),
(17, '2022-08-31 14:32:29', 'Admin', 'Failed Login demo@example.com', 0, '::1'),
(18, '2022-08-31 14:32:46', 'Admin', 'Login Successful demo@example.com', 1, '::1'),
(19, '2022-09-02 01:28:59', 'Admin', 'Login Successful demo@example.com', 1, '::1'),
(20, '2022-09-02 01:49:57', 'Admin', 'Login Successful demo@example.com', 1, '::1'),
(21, '2022-09-02 05:43:49', 'Admin', 'Login Successful demo@example.com', 1, '::1'),
(22, '2022-09-02 05:48:24', 'Admin', 'New Contact Added kapekem  Mboudjeu roland [CID: 3]', 1, '::1'),
(23, '2022-09-02 06:05:22', 'Admin', 'New Contact Added kapekem  Mboudjeu roland [CID: 4]', 1, '::1'),
(24, '2022-09-02 06:07:17', 'Admin', 'New Contact Added kapekem roland [CID: 5]', 1, '::1'),
(25, '2022-09-02 06:52:40', 'Admin', 'New Contact Added kapekem  Mboudjeu roland [CID: 6]', 1, '::1'),
(26, '2022-09-02 07:25:57', 'Admin', 'New Contact Added kapekem  Mboudjeu roland [CID: 7]', 1, '::1'),
(27, '2022-09-03 08:01:42', 'Admin', 'Login Successful demo@example.com', 1, '::1'),
(28, '2022-09-03 08:04:04', 'Admin', 'New Contact Added kapekem  Mboudjeu roland [CID: 8]', 1, '::1'),
(29, '2022-09-03 08:18:55', 'Admin', 'New Contact Added kapekem roland [CID: 9]', 1, '::1'),
(30, '2022-09-03 08:38:49', 'Admin', 'New Contact Added kapekem  Mboudjeu roland [CID: 10]', 1, '::1'),
(31, '2022-09-03 08:45:17', 'Admin', 'New Contact Added kapekem  Mboudjeu roland [CID: 11]', 1, '::1'),
(32, '2022-09-03 09:38:39', 'Admin', 'New Contact Added kapekem  Mboudjeu roland [CID: 0]', 1, '::1'),
(33, '2022-09-03 09:41:12', 'Admin', 'New Contact Added rigrfsskngt [CID: 0]', 1, '::1'),
(34, '2022-09-05 05:16:42', 'Admin', 'Login Successful demo@example.com', 1, '::1'),
(35, '2022-09-06 00:39:53', 'Admin', 'Login Successful demo@example.com', 1, '::1'),
(36, '2022-09-06 05:41:49', 'Admin', 'Login Successful demo@example.com', 1, '::1'),
(37, '2022-09-06 06:12:32', 'Admin', 'Login Successful demo@example.com', 1, '::1'),
(38, '2022-09-06 07:14:24', 'Admin', 'Login Successful demo@example.com', 1, '::1'),
(39, '2022-09-06 07:24:05', 'Admin', 'Login Successful demo@example.com', 1, '::1'),
(40, '2022-09-06 10:23:45', 'Admin', 'Login Successful demo@example.com', 1, '::1'),
(41, '2022-09-07 04:19:36', 'Admin', 'Login Successful demo@example.com', 1, '::1'),
(42, '2022-09-07 04:24:08', 'Admin', 'Login Successful demo@example.com', 1, '::1'),
(43, '2022-09-07 04:24:34', 'Admin', 'Login Successful demo@example.com', 1, '::1'),
(44, '2022-09-07 04:26:39', 'Admin', 'New Contact Added roland [CID: 5]', 1, '::1'),
(45, '2022-09-07 05:09:46', 'Admin', 'New Contact Added roland [CID: 12]', 1, '::1'),
(46, '2022-09-07 05:32:50', 'Admin', 'New Contact Added roland [CID: 13]', 1, '::1'),
(47, '2022-09-07 05:57:40', 'Admin', 'New Contact Added roland [CID: 14]', 1, '::1'),
(48, '2022-09-07 06:09:17', 'Admin', 'New Contact Added roland [CID: 15]', 1, '::1'),
(49, '2022-09-07 06:11:34', 'Admin', 'New Contact Added roland [CID: 16]', 1, '::1'),
(50, '2022-09-07 06:18:59', 'Admin', 'New Contact Added roland [CID: 17]', 1, '::1'),
(51, '2022-09-07 06:24:54', 'Admin', 'New Contact Added roland [CID: 18]', 1, '::1'),
(52, '2022-09-07 07:17:50', 'Admin', 'New Contact Added roland [CID: 19]', 1, '::1'),
(53, '2022-09-07 07:33:40', 'Admin', 'New Contact Added roland [CID: 20]', 1, '::1'),
(54, '2022-09-07 07:36:11', 'Admin', 'New Contact Added roland [CID: 21]', 1, '::1'),
(55, '2022-09-07 07:39:53', 'Admin', 'New Contact Added kaps design [CID: 22]', 1, '::1'),
(56, '2022-09-07 07:55:22', 'Admin', 'New Contact Added kaps design [CID: 23]', 1, '::1'),
(57, '2022-09-07 12:38:25', 'Admin', 'Login Successful demo@example.com', 1, '::1'),
(58, '2022-09-08 03:50:39', 'Admin', 'Login Successful demo@example.com', 1, '::1'),
(59, '2022-09-08 07:00:57', 'Admin', 'New Contact Added roland [CID: 24]', 1, '::1'),
(60, '2022-09-08 07:47:52', 'Admin', 'New Contact Added kaps design [CID: 25]', 1, '::1'),
(61, '2022-09-12 16:58:41', 'Admin', 'Login Successful demo@example.com', 1, '::1'),
(62, '2022-09-13 10:48:44', 'Admin', 'Login Successful demo@example.com', 1, '::1'),
(63, '2022-09-13 11:00:07', 'Admin', 'New Deposit: gflkmlgd [TrID: 2 | Amount: 777]', 1, '::1'),
(64, '2022-09-13 11:15:45', 'Admin', 'New Deposit: hhjili [TrID: 3 | Amount: 777]', 1, '::1'),
(65, '2022-09-13 13:40:31', 'Admin', 'Login Successful demo@example.com', 1, '::1'),
(66, '2022-09-13 13:42:14', 'Admin', 'Login Successful demo@example.com', 1, '::1'),
(67, '2022-09-13 14:53:15', 'Admin', 'Contact Deleted: test', 1, '::1'),
(68, '2022-09-14 04:27:23', 'Admin', 'Login Successful demo@example.com', 1, '::1'),
(69, '2022-09-14 04:31:22', 'Admin', 'Contact Deleted: roland', 1, '::1'),
(70, '2022-09-14 07:47:28', 'Admin', 'Login Successful demo@example.com', 1, '::1'),
(71, '2022-09-14 09:15:27', 'Admin', 'Login Successful demo@example.com', 1, '::1'),
(72, '2022-09-14 09:44:46', 'Admin', 'Login Successful demo@example.com', 1, '::1'),
(73, '2022-09-14 12:06:39', 'Admin', 'Login Successful demo@example.com', 1, '::1'),
(74, '2022-09-15 05:38:47', 'Admin', 'Login Successful demo@example.com', 1, '::1'),
(75, '2022-09-15 05:39:42', 'Admin', 'Login Successful demo@example.com', 1, '::1'),
(76, '2022-09-15 05:48:00', 'Admin', 'Login Successful demo@example.com', 1, '::1'),
(77, '2022-09-15 06:06:01', 'Admin', 'Login Successful demo@example.com', 1, '::1'),
(78, '2022-09-15 09:39:22', 'Admin', 'Login Successful demo@example.com', 1, '::1'),
(79, '2022-09-15 13:47:32', 'Admin', 'New Contact Added roland [CID: 6]', 1, '::1'),
(80, '2022-09-16 07:08:27', 'Admin', 'Login Successful demo@example.com', 1, '::1'),
(81, '2022-09-16 07:25:54', 'Admin', 'Login Successful demo@example.com', 1, '::1'),
(82, '2022-09-16 07:31:44', 'Admin', 'Login Successful demo@example.com', 1, '::1'),
(83, '2022-09-16 07:32:49', 'Admin', 'Login Successful demo@example.com', 1, '::1'),
(84, '2022-09-16 07:33:08', 'Admin', 'Login Successful demo@example.com', 1, '::1'),
(85, '2022-09-16 07:39:39', 'Admin', 'Login Successful demo@example.com', 1, '::1'),
(86, '2022-09-16 07:42:25', 'Admin', 'Login Successful demo@example.com', 1, '::1'),
(87, '2022-09-16 07:46:32', 'Admin', 'Login Successful demo@example.com', 1, '::1'),
(88, '2022-09-16 07:50:53', 'Admin', 'Login Successful demo@example.com', 1, '::1'),
(89, '2022-09-16 08:02:03', 'Admin', 'Login Successful demo@example.com', 1, '::1'),
(90, '2022-09-16 08:02:51', 'Admin', 'Login Successful demo@example.com', 1, '::1'),
(91, '2022-09-16 08:12:41', 'Admin', 'Login Successful demo@example.com', 1, '::1'),
(92, '2022-09-16 13:08:51', 'Admin', 'Login Successful demo@example.com', 1, '::1'),
(93, '2022-09-17 05:33:46', 'Admin', 'Login Successful demo@example.com', 1, '::1'),
(94, '2022-09-17 06:21:31', 'Admin', 'New Contact Added rolandcompany [CID: 7]', 1, '::1'),
(95, '2022-09-17 06:22:33', 'Admin', 'New Contact Added kingue [CID: 8]', 1, '::1'),
(96, '2022-09-17 06:24:36', 'Admin', 'Contact Deleted: kaps design', 1, '::1'),
(97, '2022-09-17 06:52:54', 'Admin', 'New Contact Added steve company [CID: 9]', 1, '::1'),
(98, '2022-09-17 07:25:12', 'Admin', 'Contact Deleted: kapekem roland', 1, '::1'),
(99, '2022-09-17 07:25:31', 'Admin', 'Contact Deleted: kapekem  Mboudjeu roland', 1, '::1'),
(100, '2022-09-17 07:36:57', 'Admin', 'Contact Deleted: steve company', 1, '::1'),
(101, '2022-09-17 07:38:55', 'Admin', 'Contact Deleted: kapekem  Mboudjeu roland', 1, '::1'),
(102, '2022-09-17 07:39:49', 'Admin', 'Contact Deleted: kingue', 1, '::1'),
(103, '2022-09-17 08:25:44', 'Admin', 'Contact Deleted: rolandcompany', 1, '::1'),
(104, '2022-09-17 08:39:12', 'Admin', 'Contact Deleted: kapekem  Mboudjeu roland', 1, '::1'),
(105, '2022-09-17 08:39:59', 'Admin', 'New Contact Added bm tracking [CID: 10]', 1, '::1'),
(106, '2022-09-17 08:40:33', 'Admin', 'Contact Deleted: kapekem  Mboudjeu roland', 1, '::1'),
(107, '2022-09-17 08:46:44', 'Admin', 'Contact1 Deleted: test', 1, '::1'),
(108, '2022-09-17 08:47:25', 'Admin', 'Contact Deleted: test 2', 1, '::1'),
(109, '2022-09-17 09:47:17', 'Admin', 'Login Successful demo@example.com', 1, '::1'),
(110, '2022-09-17 09:57:24', 'Portal Registration', 'New Contact Added kingue [CID: 26]', 0, '::1'),
(111, '2022-09-17 10:00:48', 'Admin', 'Login Successful demo@example.com', 1, '::1'),
(112, '2022-09-17 10:39:46', 'Portal Registration', 'New Contact Added maurice [CID: 27]', 0, '::1'),
(113, '2022-09-17 10:51:56', 'Admin', 'Login Successful kingue@lol.vf', 2, '::1'),
(114, '2022-09-17 10:52:54', 'Admin', 'Failed Login demo@example.com', 0, '::1'),
(115, '2022-09-17 10:53:14', 'Admin', 'Failed Login demo@example.com', 0, '::1'),
(116, '2022-09-17 10:53:23', 'Admin', 'Failed Login demo@example.com', 0, '::1'),
(117, '2022-09-17 10:53:43', 'Admin', 'Login Successful demo@example.com', 1, '::1'),
(118, '2022-09-17 10:57:42', 'Admin', 'Failed Login kingue@lol.vf', 0, '::1'),
(119, '2022-09-17 10:58:05', 'Admin', 'Failed Login kingue@lol.vf', 0, '::1'),
(120, '2022-09-17 10:58:19', 'Admin', 'Failed Login kingue@lol.vf', 0, '::1'),
(121, '2022-09-17 10:58:40', 'Admin', 'Login Successful kingue@lol.vf', 2, '::1'),
(122, '2022-09-17 11:12:46', 'Admin', 'Failed Login demo@example.com', 0, '::1'),
(123, '2022-09-17 11:13:01', 'Admin', 'Login Successful demo@example.com', 1, '::1'),
(124, '2022-09-17 11:14:36', 'Admin', 'Failed Login demo@example.com', 0, '::1'),
(125, '2022-09-17 11:14:48', 'Admin', 'Login Successful demo@example.com', 1, '::1'),
(126, '2022-09-17 11:15:09', 'Admin', 'Failed Login kingue@lol.vf', 0, '::1'),
(127, '2022-09-17 11:15:24', 'Admin', 'Login Successful kingue@lol.vf', 2, '::1'),
(128, '2022-09-19 06:33:06', 'Admin', 'Login Successful kingue@lol.vf', 2, '::1'),
(129, '2022-09-19 07:05:42', 'Portal Registration', 'New Contact Added kapscampany [CID: 28]', 0, '::1'),
(130, '2022-09-19 07:07:29', 'Portal Registration', 'New Contact Added kp campany [CID: 29]', 0, '::1'),
(131, '2022-09-19 07:20:34', 'Portal Registration', 'New Contact Added afm [CID: 30]', 0, '::1'),
(132, '2022-09-19 07:22:03', 'Admin', 'Login Successful kingue@lol.vf', 2, '::1'),
(133, '2022-09-19 07:41:08', 'Admin', 'Failed Login demo@example.com', 0, '::1'),
(134, '2022-09-19 07:41:33', 'Admin', 'Failed Login demo@example.com', 0, '::1'),
(135, '2022-09-19 07:41:53', 'Admin', 'Failed Login demo@example.com', 0, '::1'),
(136, '2022-09-19 07:42:18', 'Admin', 'Login Successful demo@example.com', 1, '::1'),
(137, '2022-09-19 07:44:52', 'Admin', 'Login Successful demo@example.com', 1, '::1'),
(138, '2022-09-19 09:40:58', 'Admin', 'Contact Deleted: kapekem  Mboudjeu roland', 1, '::1'),
(139, '2022-09-19 12:29:45', 'Admin', 'Login Successful demo@example.com', 1, '::1'),
(140, '2022-09-19 12:44:31', 'Portal Registration', 'New Contact Added kp campany [CID: 31]', 0, '::1'),
(141, '2022-09-19 12:51:27', 'Admin', 'Failed Login demo@example.com', 0, '::1'),
(142, '2022-09-19 12:51:50', 'Admin', 'Login Successful demo@example.com', 1, '::1'),
(143, '2022-09-19 13:31:50', 'Admin', 'Login Successful demo@example.com', 1, '::1'),
(144, '2022-09-20 06:19:34', 'Admin', 'Login Successful demo@example.com', 1, '::1'),
(145, '2022-09-20 08:08:21', 'Admin', 'Login Successful demo@example.com', 1, '::1'),
(146, '2022-09-20 08:09:47', 'Admin', 'Login Successful demo@example.com', 1, '::1'),
(147, '2022-09-20 08:10:26', 'Admin', 'Login Successful demo@example.com', 1, '::1'),
(148, '2022-09-22 05:36:29', 'Admin', 'Login Successful demo@example.com', 1, '::1'),
(149, '2022-09-24 08:54:53', 'Admin', 'Login Successful demo@example.com', 1, '::1'),
(150, '2022-09-24 09:04:55', 'Admin', 'Contact1 Deleted: test 2', 1, '::1'),
(151, '2022-09-24 09:15:30', 'Admin', 'New Contact Added kp campany [CID: 11]', 1, '::1'),
(152, '2022-09-24 10:06:53', 'Admin', 'New Contact Added afriquemedia [CID: 12]', 1, '::1'),
(153, '2022-09-24 12:36:12', 'Admin', 'Contact1 Deleted: kapekem  Mboudjeu roland', 1, '::1'),
(154, '2022-09-29 18:19:51', 'Admin', 'Login Successful demo@example.com', 1, '::1'),
(155, '2022-10-26 11:06:40', 'Admin', 'Login Successful demo@example.com', 1, '::1'),
(156, '2022-10-27 04:51:35', 'Admin', 'Login Successful demo@example.com', 1, '::1'),
(157, '2022-10-27 07:33:24', 'Admin', 'Login Successful demo@example.com', 1, '::1'),
(158, '2022-10-27 08:29:59', 'Admin', 'Login Successful demo@example.com', 1, '::1'),
(159, '2022-10-29 06:54:52', 'Admin', 'Login Successful demo@example.com', 1, '::1'),
(160, '2022-10-29 06:55:17', 'Admin', 'Login Successful demo@example.com', 1, '::1'),
(161, '2022-10-29 06:56:53', 'Admin', 'Login Successful demo@example.com', 1, '::1'),
(162, '2022-10-29 07:03:16', 'Admin', 'Login Successful demo@example.com', 1, '::1'),
(163, '2022-10-30 10:43:53', 'Admin', 'Login Successful demo@example.com', 1, '::1'),
(164, '2022-10-30 18:21:25', 'Admin', 'Login Successful demo@example.com', 1, '::1'),
(165, '2022-10-31 05:48:28', 'Admin', 'Login Successful demo@example.com', 1, '::1'),
(166, '2022-10-31 06:36:41', 'Admin', 'Login Successful demo@example.com', 1, '::1'),
(167, '2022-10-31 09:27:46', 'Admin', 'Login Successful demo@example.com', 1, '::1'),
(168, '2022-10-31 11:07:54', 'Admin', 'Login Successful demo@example.com', 1, '::1'),
(169, '2022-10-31 11:11:50', 'Admin', 'Login Successful demo@example.com', 1, '::1'),
(170, '2022-10-31 11:18:31', 'Admin', 'New Contact Added kp campany [CID: 13]', 1, '::1'),
(171, '2022-10-31 11:59:49', 'Admin', 'New Contact Added kacampany [CID: 13]', 1, '::1'),
(172, '2022-10-31 12:01:35', 'Admin', 'Contact1 Deleted: afriquemedia', 1, '::1'),
(173, '2022-10-31 12:24:41', 'Admin', 'Login Successful demo@example.com', 1, '::1'),
(174, '2022-11-01 00:44:22', 'Admin', 'Login Successful demo@example.com', 1, '::1'),
(175, '2022-11-01 00:45:35', 'Admin', 'Login Successful demo@example.com', 1, '::1'),
(176, '2022-11-01 01:06:52', 'Admin', 'Login Successful demo@example.com', 1, '::1'),
(177, '2022-11-01 01:08:02', 'Admin', 'Login Successful demo@example.com', 1, '::1'),
(178, '2022-11-01 03:53:55', 'Admin', 'Login Successful demo@example.com', 1, '::1'),
(179, '2022-11-01 03:58:11', 'Admin', 'Login Successful demo@example.com', 1, '::1'),
(180, '2022-11-01 04:29:54', 'Admin', 'Login Successful demo@example.com', 1, '::1'),
(181, '2022-11-01 04:32:22', 'Admin', 'New Contact Added deposit account [CID: 32]', 1, '::1'),
(182, '2022-11-01 04:50:26', 'Admin', 'Login Successful demo@example.com', 1, '::1'),
(183, '2022-11-01 04:59:16', 'Admin', 'Login Successful demo@example.com', 1, '::1'),
(184, '2022-11-01 05:06:53', 'Admin', 'Login Successful demo@example.com', 1, '::1'),
(185, '2022-11-01 05:17:42', 'Admin', 'Login Successful demo@example.com', 1, '::1'),
(186, '2022-11-01 05:17:50', 'Admin', 'Login Successful demo@example.com', 1, '::1'),
(187, '2022-11-01 05:43:13', 'Admin', 'Login Successful demo@example.com', 1, '::1'),
(188, '2022-11-01 05:44:25', 'Admin', 'New Contact Added test [CID: 14]', 1, '::1'),
(189, '2022-11-01 05:45:22', 'Admin', 'Login Successful demo@example.com', 1, '::1'),
(190, '2022-11-01 05:49:20', 'Admin', 'Login Successful demo@example.com', 1, '::1'),
(191, '2022-11-01 05:58:21', 'Admin', 'Login Successful demo@example.com', 1, '::1'),
(192, '2022-11-01 06:18:03', 'Admin', 'Login Successful demo@example.com', 1, '::1'),
(193, '2022-11-01 06:45:07', 'Admin', 'Login Successful demo@example.com', 1, '::1'),
(194, '2022-11-01 06:45:17', 'Admin', 'Login Successful demo@example.com', 1, '::1'),
(195, '2022-11-01 07:13:24', 'Admin', 'New Contact Added test [CID: 14]', 1, '::1'),
(196, '2022-11-01 07:20:29', 'Admin', 'New Contact Added deposit account [CID: 15]', 1, '::1'),
(197, '2022-11-01 07:31:17', 'Admin', 'New Contact Added deposit account [CID: 16]', 1, '::1'),
(198, '2022-11-01 09:15:53', 'Admin', 'Contact1 Deleted: rigrfsskngt', 1, '::1'),
(199, '2022-11-01 09:16:17', 'Admin', 'Contact1 Deleted: roland', 1, '::1'),
(200, '2022-11-01 09:21:17', 'Admin', 'Contact1 Deleted: roland', 1, '::1'),
(201, '2022-11-01 09:22:09', 'Admin', 'Contact1 Deleted: kp campany', 1, '::1'),
(202, '2022-11-01 09:25:27', 'Admin', 'Contact2 Deleted: rigrfsskngt', 1, '::1'),
(203, '2022-11-01 09:31:23', 'Admin', 'Contact2 Deleted: roland', 1, '::1'),
(204, '2022-11-01 09:34:42', 'Admin', 'Contact2 Deleted: roland', 1, '::1'),
(205, '2022-11-01 09:35:22', 'Admin', 'Contact1 Deleted: bm tracking', 1, '::1'),
(206, '2022-11-01 09:44:07', 'Admin', 'Contact2 Deleted: bm tracking', 1, '::1'),
(207, '2022-11-01 09:49:13', 'Admin', 'Contact1 Deleted: test', 1, '::1'),
(208, '2022-11-01 10:58:41', 'Admin', 'Contact Deleted: deposit account', 1, '::1'),
(209, '2022-11-01 10:59:21', 'Admin', 'Contact Deleted: roland', 1, '::1'),
(210, '2022-11-01 11:14:37', 'Admin', 'Contact Deleted: kp campany', 1, '::1'),
(211, '2022-11-01 11:29:06', 'Admin', 'New Contact Added le pacha [CID: 17]', 1, '::1'),
(212, '2022-11-01 11:42:56', 'Admin', 'Contact Deleted: afriquemedia', 1, '::1'),
(213, '2022-11-01 11:59:52', 'Admin', 'Contact1 Deleted: kp campany', 1, '::1'),
(214, '2022-11-01 12:00:20', 'Admin', 'Contact Deleted: test', 1, '::1'),
(215, '2022-11-01 12:20:18', 'Admin', 'New Contact Added deposit account [CID: 15]', 1, '::1'),
(216, '2022-11-02 03:42:15', 'Admin', 'Login Successful demo@example.com', 1, '::1'),
(217, '2022-11-02 04:15:37', 'Admin', 'Contact Deleted: kacampany', 1, '::1'),
(218, '2022-11-02 04:16:08', 'Admin', 'Contact Deleted: deposit account', 1, '::1'),
(219, '2022-11-02 06:55:26', 'Admin', 'Login Successful demo@example.com', 1, '::1'),
(220, '2022-11-02 07:37:57', 'Admin', 'New Contact Added bm tracking [CID: 18]', 1, '::1'),
(221, '2022-11-02 07:54:06', 'Admin', 'Contact Deleted: kapekem roland', 1, '::1'),
(222, '2022-11-02 07:54:12', 'Admin', 'Contact Deleted: kapekem  Mboudjeu roland', 1, '::1'),
(223, '2022-11-02 07:55:09', 'Admin', 'Contact Deleted: roland', 1, '::1'),
(224, '2022-11-02 07:55:14', 'Admin', 'Contact Deleted: roland', 1, '::1'),
(225, '2022-11-02 07:55:21', 'Admin', 'Contact Deleted: roland', 1, '::1'),
(226, '2022-11-02 07:55:27', 'Admin', 'Contact Deleted: roland', 1, '::1'),
(227, '2022-11-02 07:55:34', 'Admin', 'Contact Deleted: roland', 1, '::1'),
(228, '2022-11-02 07:55:44', 'Admin', 'Contact Deleted: roland', 1, '::1'),
(229, '2022-11-02 07:55:51', 'Admin', 'Contact Deleted: roland', 1, '::1'),
(230, '2022-11-02 07:55:59', 'Admin', 'Contact Deleted: roland', 1, '::1'),
(231, '2022-11-02 07:56:07', 'Admin', 'Contact Deleted: kaps design', 1, '::1'),
(232, '2022-11-02 07:56:13', 'Admin', 'Contact Deleted: kaps design', 1, '::1'),
(233, '2022-11-02 07:59:25', 'Admin', 'New Contact Added kingue [CID: 16]', 1, '::1'),
(234, '2022-11-02 08:00:20', 'Admin', 'Contact Deleted: roland', 1, '::1'),
(235, '2022-11-02 08:11:15', 'Admin', 'Login Successful demo@example.com', 1, '::1'),
(236, '2022-11-02 08:59:11', 'Admin', 'New Contact Added kp campany [CID: 33]', 1, '::1'),
(237, '2022-11-02 08:59:52', 'Admin', 'Contact Deleted: deposit account', 1, '::1'),
(238, '2022-11-02 09:33:06', 'Admin', 'New Contact Added kingue [CID: 34]', 1, '::1'),
(239, '2022-11-02 09:48:17', 'Admin', 'New Contact Added fullstack .net [CID: 35]', 1, '::1'),
(240, '2022-11-02 09:57:35', 'Admin', 'New Contact Added fulllstack.com [CID: 36]', 1, '::1'),
(241, '2022-11-02 12:45:08', 'Admin', 'Login Successful demo@example.com', 1, '::1'),
(242, '2022-11-03 05:39:43', 'Admin', 'Login Successful demo@example.com', 1, '::1'),
(243, '2022-11-03 09:16:38', 'Admin', 'New Contact Added Aimetracking [CID: 17]', 1, '::1'),
(244, '2022-11-03 09:19:35', 'Admin', 'Failed Login demo@example.com', 0, '::1'),
(245, '2022-11-03 09:19:47', 'Admin', 'Login Successful demo@example.com', 1, '::1'),
(246, '2022-11-03 09:22:21', 'Portal Registration', 'New Contact Added rolandtracking [CID: 37]', 0, '::1'),
(247, '2022-11-03 09:27:29', 'Admin', 'Login Successful demo@example.com', 1, '::1'),
(248, '2022-11-03 09:43:01', 'Portal Registration', 'New Contact Added rolandtracking [CID: 38]', 0, '::1'),
(249, '2022-11-03 10:36:54', 'Admin', 'Login Successful demo@example.com', 1, '::1'),
(250, '2022-11-03 11:06:21', 'Admin', 'Login Successful demo@example.com', 1, '::1'),
(251, '2022-11-04 03:54:33', 'Admin', 'Login Successful demo@example.com', 1, '::1'),
(252, '2022-11-04 04:46:43', 'Admin', 'Login Successful demo@example.com', 1, '::1'),
(253, '2022-11-04 04:59:05', 'Admin', 'Login Successful demo@example.com', 1, '::1'),
(254, '2022-11-04 05:04:50', 'Portal Registration', 'New Contact Added abc [CID: 39]', 0, '::1'),
(255, '2022-11-04 05:05:38', 'Admin', 'Login Successful demo@example.com', 1, '::1'),
(256, '2022-11-04 05:19:18', 'Admin', 'Login Successful demo@example.com', 1, '::1'),
(257, '2022-11-04 06:00:49', 'Admin', 'Login Successful demo@example.com', 1, '::1'),
(258, '2022-11-04 08:06:41', 'Portal Registration', 'New Contact Added kingsleylogistics [CID: 40]', 0, '::1'),
(259, '2022-11-04 08:11:31', 'Admin', 'Login Successful demo@example.com', 1, '::1'),
(260, '2022-11-04 08:24:09', 'Portal Registration', 'New Contact Added raoultrading [CID: 41]', 0, '::1'),
(261, '2022-11-04 08:24:36', 'Admin', 'Login Successful demo@example.com', 1, '::1'),
(262, '2022-11-04 08:29:56', 'Admin', 'New Contact Added raoultrading [CID: 18]', 1, '::1'),
(263, '2022-11-04 09:47:45', 'Portal Registration', 'New Contact Added kp [CID: 42]', 0, '::1'),
(264, '2022-11-04 10:05:34', 'Portal Registration', 'New Contact Added kp [CID: 43]', 0, '::1'),
(265, '2022-11-04 10:17:21', 'Portal Registration', 'New Contact Added rolandtracking [CID: 19]', 0, '::1'),
(266, '2022-11-04 10:22:34', 'Portal Registration', 'New Contact Added kp [CID: 44]', 0, '::1'),
(267, '2022-11-04 11:28:35', 'Portal Registration', 'New Contact Added kpk [CID: 20]', 0, '::1'),
(268, '2022-11-05 01:57:12', 'Admin', 'Login Successful demo@example.com', 1, '::1'),
(269, '2022-11-05 02:00:34', 'Portal Registration', 'New Contact Added kp campany [CID: 19]', 0, '::1'),
(270, '2022-11-05 02:06:12', 'Admin', 'Login Successful demo@example.com', 1, '::1'),
(271, '2022-11-05 02:08:30', 'Admin', 'Login Successful demo@example.com', 1, '::1'),
(272, '2022-11-05 02:10:14', 'Admin', 'Login Successful demo@example.com', 1, '::1'),
(273, '2022-11-05 05:25:54', 'Admin', 'Login Successful demo@example.com', 1, '::1'),
(274, '2022-11-05 05:37:40', 'Portal Registration', 'New Contact Added abc [CID: 21]', 0, '::1'),
(275, '2022-11-05 05:39:01', 'Portal Registration', 'New Contact Added abc [CID: 20]', 0, '::1'),
(276, '2022-11-05 05:42:13', 'Admin', 'Login Successful demo@example.com', 1, '::1'),
(277, '2022-11-05 05:42:36', 'Admin', 'Login Successful demo@example.com', 1, '::1'),
(278, '2022-11-05 05:42:50', 'Admin', 'Login Successful demo@example.com', 1, '::1'),
(279, '2022-11-05 06:56:35', 'Portal Registration', 'New Contact Added kapstracking [CID: 45]', 0, '::1'),
(280, '2022-11-05 06:57:35', 'Portal Registration', 'New Contact Added afm [CID: 21]', 0, '::1'),
(281, '2022-11-05 06:59:44', 'Portal Registration', 'New Contact Added agr [CID: 22]', 0, '::1'),
(282, '2022-11-05 07:09:34', 'Admin', 'Login Successful demo@example.com', 1, '::1'),
(283, '2022-11-05 10:28:58', 'Admin', 'Login Successful demo@example.com', 1, '::1'),
(284, '2022-11-05 11:05:10', 'Admin', 'Login Successful demo@example.com', 1, '::1'),
(285, '2022-11-06 15:40:37', 'Admin', 'Login Successful demo@example.com', 1, '::1'),
(286, '2022-11-07 05:24:57', 'Admin', 'Login Successful demo@example.com', 1, '::1'),
(287, '2022-11-07 06:54:55', 'Admin', 'Login Successful demo@example.com', 1, '::1'),
(288, '2022-11-07 06:55:15', 'Admin', 'Login Successful demo@example.com', 1, '::1'),
(289, '2022-11-07 11:03:46', 'Portal Registration', 'New Contact Added rolandtracking [CID: 46]', 0, '::1'),
(290, '2022-11-07 11:07:59', 'Admin', 'Login Successful demo@example.com', 1, '::1'),
(291, '2022-11-07 11:52:15', 'Admin', 'Login Successful demo@example.com', 1, '::1'),
(292, '2022-11-07 12:08:14', 'Admin', 'Login Successful demo@example.com', 1, '::1'),
(293, '2022-11-08 03:07:08', 'Admin', 'Login Successful demo@example.com', 1, '::1'),
(294, '2022-11-08 03:54:41', 'Admin', 'New Contact Added deposit account [CID: 47]', 1, '::1'),
(295, '2022-11-08 04:04:09', 'Admin', 'New Contact Added uhhhh [CID: 48]', 1, '::1'),
(296, '2022-11-08 04:10:12', 'Admin', 'New Contact Added the [CID: 49]', 1, '::1'),
(297, '2022-11-08 04:14:15', 'Admin', 'Contact Deleted: kp campany', 1, '::1'),
(298, '2022-11-08 04:14:23', 'Admin', 'Contact Deleted: deposit account', 1, '::1'),
(299, '2022-11-08 04:14:31', 'Admin', 'Contact Deleted: rolandtracking', 1, '::1'),
(300, '2022-11-08 04:14:38', 'Admin', 'Contact Deleted: kapstracking', 1, '::1'),
(301, '2022-11-08 04:15:51', 'Admin', 'New Contact Added test [CID: 50]', 1, '::1'),
(302, '2022-11-08 04:58:57', 'Admin', 'Login Successful demo@example.com', 1, '::1'),
(303, '2022-11-08 05:16:14', 'Admin', 'Login Successful demo@example.com', 1, '::1'),
(304, '2022-11-08 05:41:37', 'Admin', 'New Contact Added rol [CID: 51]', 1, '::1'),
(305, '2022-11-08 06:46:40', 'Admin', 'Login Successful demo@example.com', 1, '::1'),
(306, '2022-11-08 07:50:30', 'Admin', 'New Contact Added Aboubakar [CID: 23]', 1, '::1'),
(307, '2022-11-08 08:02:41', 'Admin', 'Contact Deleted: abc', 1, '::1'),
(308, '2022-11-08 08:03:48', 'Admin', 'New Contact Added Aimetracking [CID: 24]', 1, '::1'),
(309, '2022-11-08 08:09:15', 'Admin', 'New Contact Added kapekem roland [CID: 25]', 1, '::1'),
(310, '2022-11-08 08:11:07', 'Admin', 'New Contact Added admin [CID: 26]', 1, '::1'),
(311, '2022-11-08 08:15:54', 'Admin', 'Failed Login demo@example.com', 0, '::1'),
(312, '2022-11-08 08:16:08', 'Admin', 'Login Successful demo@example.com', 1, '::1'),
(313, '2022-11-08 08:16:51', 'Admin', 'Contact Deleted: kapekem roland', 1, '::1'),
(314, '2022-11-08 08:16:57', 'Admin', 'Contact Deleted: Aimetracking', 1, '::1'),
(315, '2022-11-08 08:17:01', 'Admin', 'Contact Deleted: agr', 1, '::1'),
(316, '2022-11-08 08:17:05', 'Admin', 'Contact Deleted: admin', 1, '::1'),
(317, '2022-11-08 08:17:45', 'Admin', 'New Contact Added admin [CID: 27]', 1, '::1'),
(318, '2022-11-08 08:54:48', 'Admin', 'Login Successful demo@example.com', 1, '::1'),
(319, '2022-11-08 09:11:27', 'Portal Registration', 'New Contact Added abc [CID: 22]', 0, '::1'),
(320, '2022-11-09 04:05:55', 'Admin', 'Login Successful demo@example.com', 1, '::1'),
(321, '2022-11-09 06:01:00', 'Admin', 'New Contact Added roland [CID: 52]', 1, '::1'),
(322, '2022-11-09 06:11:00', 'Admin', 'New Contact Added roland [CID: 53]', 1, '::1'),
(323, '2022-11-09 06:13:44', 'Admin', 'New Contact Added deposit account [CID: 54]', 1, '::1'),
(324, '2022-11-09 06:18:31', 'Admin', 'New Contact Added fulllstack.com [CID: 28]', 1, '::1'),
(325, '2022-11-09 06:24:32', 'Admin', 'Login Successful demo@example.com', 1, '::1'),
(326, '2022-11-09 10:06:24', 'Admin', 'Login Successful demo@example.com', 1, '::1'),
(327, '2022-11-09 11:05:18', 'Admin', 'Contact Deleted: roland', 1, '::1'),
(328, '2022-11-09 11:05:22', 'Admin', 'Contact Deleted: roland', 1, '::1'),
(329, '2022-11-09 11:05:27', 'Admin', 'Contact Deleted: deposit account', 1, '::1'),
(330, '2022-11-11 04:01:55', 'Admin', 'Login Successful demo@example.com', 1, '::1'),
(331, '2022-11-11 04:02:05', 'Admin', 'Login Successful demo@example.com', 1, '::1'),
(332, '2022-11-11 04:19:48', 'Admin', 'Login Successful demo@example.com', 1, '::1'),
(333, '2022-11-11 07:13:47', 'Admin', 'Login Successful demo@example.com', 1, '::1'),
(334, '2022-11-12 04:28:40', 'Admin', 'Login Successful demo@example.com', 1, '::1'),
(335, '2022-11-14 05:47:46', 'Admin', 'Login Successful demo@example.com', 1, '::1'),
(336, '2022-11-14 06:46:09', 'Portal Registration', 'New Contact Added afm [CID: 52]', 0, '::1'),
(337, '2022-11-15 04:34:34', 'Admin', 'Login Successful demo@example.com', 1, '::1'),
(338, '2022-11-15 07:22:23', 'Portal Registration', 'New Contact Added kingue [CID: 53]', 0, '::1'),
(339, '2022-11-15 07:39:18', 'Admin', 'New Contact Added kaps design [CID: 54]', 1, '::1'),
(340, '2022-11-15 07:59:41', 'Admin', 'New Contact Added abakartruking [CID: 55]', 1, '::1'),
(341, '2022-11-15 09:48:38', 'Portal Registration', 'New Contact Added rolandtracking [CID: 29]', 0, '::1'),
(342, '2022-11-15 09:49:22', 'Admin', 'Login Successful demo@example.com', 1, '::1'),
(343, '2022-11-15 09:50:50', 'Portal Registration', 'New Contact Added raoultrading [CID: 30]', 0, '::1'),
(344, '2022-11-15 10:17:51', 'Admin', 'Login Successful demo@example.com', 1, '::1'),
(345, '2022-11-15 10:31:16', 'Admin', 'Login Successful demo@example.com', 1, '::1'),
(346, '2022-11-15 14:33:49', 'Admin', 'Login Successful demo@example.com', 1, '127.0.0.1'),
(347, '2022-11-18 09:09:14', 'Admin', 'Login Successful demo@example.com', 1, '::1'),
(348, '2022-11-21 13:02:34', 'Admin', 'Login Successful demo@example.com', 1, '127.0.0.1'),
(349, '2022-11-21 13:02:35', 'Admin', 'Login Successful demo@example.com', 1, '127.0.0.1'),
(350, '2022-11-23 10:49:14', 'Admin', 'Login Successful demo@example.com', 1, '127.0.0.1'),
(351, '2022-11-23 10:51:10', 'Admin', 'Login Successful demo@example.com', 1, '127.0.0.1'),
(352, '2022-11-23 10:53:13', 'Admin', 'Login Successful demo@example.com', 1, '127.0.0.1'),
(353, '2022-11-23 11:09:15', 'Admin', 'Login Successful demo@example.com', 1, '127.0.0.1'),
(354, '2022-11-23 11:12:24', 'Admin', 'Login Successful demo@example.com', 1, '127.0.0.1'),
(355, '2022-11-23 11:16:44', 'Admin', 'Login Successful demo@example.com', 1, '127.0.0.1'),
(356, '2022-11-23 11:21:37', 'Admin', 'Login Successful demo@example.com', 1, '127.0.0.1'),
(357, '2022-11-23 11:22:11', 'Admin', 'Login Successful demo@example.com', 1, '127.0.0.1'),
(358, '2022-11-23 11:24:04', 'Admin', 'Login Successful demo@example.com', 1, '127.0.0.1'),
(359, '2022-11-23 11:24:49', 'Admin', 'Login Successful demo@example.com', 1, '127.0.0.1'),
(360, '2022-11-26 06:08:43', 'Admin', 'Login Successful demo@example.com', 1, '127.0.0.1'),
(361, '2022-11-26 06:17:35', 'Admin', 'Login Successful demo@example.com', 1, '127.0.0.1'),
(362, '2022-11-26 06:20:21', 'Admin', 'Login Successful demo@example.com', 1, '127.0.0.1'),
(363, '2022-11-26 20:33:05', 'Admin', 'Login Successful demo@example.com', 1, '127.0.0.1'),
(364, '2022-11-27 03:48:16', 'Admin', 'New Contact Added Clarke Rosales LLC [CID: 23]', 1, '127.0.0.1'),
(365, '2022-11-27 03:53:31', 'Admin', 'Login Successful demo@example.com', 1, '127.0.0.1'),
(366, '2022-11-27 04:00:15', 'Admin', 'Login Successful demo@example.com', 1, '127.0.0.1'),
(367, '2022-11-27 04:00:53', 'Admin', 'New Contact Added Barker Rojas Plc [CID: 56]', 1, '127.0.0.1'),
(368, '2022-11-27 07:00:51', 'Admin', 'Login Successful demo@example.com', 1, '127.0.0.1'),
(369, '2022-11-27 07:07:13', 'Admin', 'Failed Login demo@example.com', 0, '127.0.0.1'),
(370, '2022-11-27 07:07:36', 'Admin', 'Login Successful demo@example.com', 1, '127.0.0.1'),
(371, '2022-11-27 07:13:38', 'Admin', 'Failed Login demo@example.com', 0, '127.0.0.1'),
(372, '2022-11-27 07:13:48', 'Admin', 'Login Successful demo@example.com', 1, '127.0.0.1'),
(373, '2022-11-27 09:02:11', 'Admin', 'Login Successful demo@example.com', 1, '127.0.0.1'),
(374, '2022-11-27 11:32:26', 'Admin', 'Login Successful demo@example.com', 1, '127.0.0.1'),
(375, '2022-11-29 15:00:05', 'Admin', 'Login Successful demo@example.com', 1, '127.0.0.1'),
(376, '2022-11-30 03:54:07', 'Admin', 'Login Successful demo@example.com', 1, '::1'),
(377, '2022-11-30 05:54:55', 'Admin', 'Login Successful demo@example.com', 1, '::1'),
(378, '2022-11-30 09:47:50', 'LSP', 'Failed Login root', 0, '::1'),
(379, '2022-11-30 09:48:57', 'Admin', 'Failed Login root', 0, '::1'),
(380, '2022-11-30 09:49:27', 'Admin', 'Failed Login root', 0, '::1'),
(381, '2022-11-30 09:49:50', 'LSR', 'Failed Login root', 0, '::1'),
(382, '2022-11-30 09:52:13', 'LSR', 'Failed Login root', 0, '::1'),
(383, '2022-11-30 09:52:18', 'LSR', 'Failed Login root', 0, '::1'),
(384, '2022-11-30 09:52:21', 'LSR', 'Failed Login root', 0, '::1'),
(385, '2022-11-30 09:53:01', 'Admin', 'Login Successful demo@example.com', 1, '::1'),
(386, '2022-11-30 09:54:31', 'LSR', 'Failed Login nywu@mailinator.com', 0, '::1'),
(387, '2022-11-30 09:55:37', 'Admin', 'Login Successful demo@example.com', 1, '::1'),
(388, '2022-11-30 09:56:43', 'LSR', 'Failed Login afm@gmail.com', 0, '::1'),
(389, '2022-11-30 09:58:31', 'LSR', 'Failed Login aime@gmai.com', 0, '::1'),
(390, '2022-11-30 10:56:33', 'Admin', 'Login Successful demo@example.com', 1, '::1'),
(391, '2022-12-05 04:50:29', 'Admin', 'Login Successful demo@example.com', 1, '::1'),
(392, '2022-12-05 21:52:38', 'Admin', 'Login Successful demo@example.com', 1, '::1'),
(393, '2022-12-06 05:23:05', 'Admin', 'New Contact Added admin [CID: 57]', 0, '::1'),
(394, '2022-12-06 06:40:14', 'Admin', 'Login Successful demo@example.com', 1, '::1'),
(395, '2022-12-07 03:35:13', 'Admin', 'Login Successful demo@example.com', 1, '::1'),
(396, '2022-12-07 04:01:17', 'Admin', 'Login Successful demo@example.com', 1, '::1'),
(397, '2022-12-07 04:01:39', 'Admin', 'Login Successful demo@example.com', 1, '::1'),
(398, '2022-12-07 04:02:29', 'Admin', 'Login Successful demo@example.com', 1, '::1'),
(399, '2022-12-07 04:08:57', 'Admin', 'Login Successful demo@example.com', 1, '::1'),
(400, '2022-12-07 04:12:47', 'Admin', 'Login Successful demo@example.com', 1, '::1'),
(401, '2022-12-07 04:14:22', 'Admin', 'Login Successful demo@example.com', 1, '::1'),
(402, '2022-12-07 09:01:46', 'Portal Registration', 'New Contact Added kp campany [CID: 61]', 0, '::1'),
(403, '2022-12-07 09:20:40', 'Admin', 'Login Successful demo@example.com', 1, '::1'),
(404, '2022-12-07 09:21:47', 'Admin', 'Contact Deleted: admin', 1, '::1'),
(405, '2022-12-07 09:21:53', 'Admin', 'Contact Deleted: admin', 1, '::1'),
(406, '2022-12-07 09:22:11', 'Admin', 'Contact Deleted: admin', 1, '::1'),
(407, '2022-12-07 09:22:18', 'Admin', 'Contact Deleted: admin', 1, '::1'),
(408, '2022-12-07 14:34:03', 'Admin', 'Login Successful demo@example.com', 1, '::1'),
(409, '2022-12-07 14:38:36', 'Admin', 'Login Successful demo@example.com', 1, '::1'),
(410, '2022-12-09 11:17:08', 'Admin', 'Login Successful demo@example.com', 1, '::1'),
(411, '2022-12-10 04:28:20', 'Admin', 'Failed Login demo@example.com', 0, '::1'),
(412, '2022-12-10 04:28:20', 'Admin', 'Login Successful demo@example.com', 1, '::1'),
(413, '2022-12-10 04:44:28', 'Admin', 'New Deposit: mlklkm [TrID: 4 | Amount: 379090]', 1, '::1'),
(414, '2022-12-10 04:45:28', 'Admin', 'New Expense: ll l, ,l, [TrID: 5 | Amount: 40000]', 1, '::1'),
(415, '2022-12-11 02:06:41', 'Admin', 'New Contact Added Huber and Potter LLC [CID: 62]', 1, '127.0.0.1'),
(416, '2022-12-12 22:39:17', 'Admin', 'Login Successful demo@example.com', 1, '127.0.0.1'),
(417, '2022-12-13 14:27:21', 'Admin', 'Login Successful demo@example.com', 1, '127.0.0.1'),
(418, '2022-12-13 15:53:57', 'Admin', 'Login Successful demo@example.com', 1, '127.0.0.1'),
(419, '2022-12-22 03:32:15', 'Admin', 'Login Successful demo@example.com', 1, '::1'),
(420, '2022-12-22 06:00:44', 'Admin', 'Login Successful demo@example.com', 1, '::1'),
(421, '2022-12-23 04:15:30', 'Admin', 'Login Successful demo@example.com', 1, '::1'),
(422, '2022-12-24 04:50:29', 'Admin', 'Login Successful demo@example.com', 1, '::1'),
(423, '2022-12-24 06:59:22', 'Admin', 'Login Successful demo@example.com', 1, '127.0.0.1'),
(424, '2022-12-27 13:41:20', 'Admin', 'Login Successful demo@example.com', 1, '127.0.0.1'),
(425, '2022-12-27 13:56:22', 'Admin', 'Login Successful demo@example.com', 1, '127.0.0.1'),
(426, '2022-12-28 10:47:49', 'Admin', 'Login Successful demo@example.com', 1, '::1'),
(427, '2022-12-28 11:06:32', 'Admin', 'Login Successful kingue@lol.vf', 2, '::1'),
(428, '2022-12-28 11:12:31', 'Admin', 'Login Successful kingue@lol.vf', 2, '::1'),
(429, '2022-12-28 11:51:46', 'Admin', 'Login Successful kingue@lol.vf', 2, '::1'),
(430, '2022-12-28 12:26:55', 'Admin', 'Login Successful demo@example.com', 1, '::1'),
(431, '2022-12-29 02:33:44', 'Admin', 'Login Successful kingue@lol.vf', 2, '::1'),
(432, '2022-12-29 02:34:20', 'Admin', 'Login Successful demo@example.com', 1, '::1'),
(433, '2022-12-29 02:51:10', 'Admin', 'Login Successful kingue@lol.vf', 2, '::1'),
(434, '2022-12-29 03:00:50', 'Admin', 'Login Successful demo@example.com', 1, '::1'),
(435, '2022-12-29 03:02:42', 'Admin', 'Login Successful kingue@lol.vf', 2, '::1'),
(436, '2022-12-29 03:09:46', 'Admin', 'Login Successful demo@example.com', 1, '::1'),
(437, '2022-12-29 03:10:49', 'Admin', 'Login Successful kingue@lol.vf', 2, '::1'),
(438, '2022-12-29 04:21:13', 'Admin', 'Login Successful kingue@lol.vf', 2, '::1');

-- --------------------------------------------------------

--
-- Structure de la table `sys_orders`
--

DROP TABLE IF EXISTS `sys_orders`;
CREATE TABLE IF NOT EXISTS `sys_orders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ordernum` varchar(50) DEFAULT NULL,
  `source` varchar(100) DEFAULT NULL,
  `status` varchar(100) DEFAULT NULL,
  `sales_person` varchar(100) DEFAULT NULL,
  `branch_name` varchar(100) DEFAULT NULL,
  `cname` varchar(100) DEFAULT NULL,
  `cid` int(11) DEFAULT NULL,
  `contract_id` int(11) DEFAULT NULL,
  `bid` int(11) DEFAULT NULL,
  `date_added` date DEFAULT NULL,
  `date_expiry` date DEFAULT NULL,
  `pid` int(11) DEFAULT NULL,
  `stitle` varchar(200) DEFAULT NULL,
  `sid` int(11) DEFAULT NULL,
  `iid` int(11) DEFAULT NULL,
  `aid` int(11) DEFAULT NULL,
  `amount` decimal(16,2) NOT NULL DEFAULT '0.00',
  `recurring` decimal(16,2) NOT NULL DEFAULT '0.00',
  `setup_fee` decimal(16,2) NOT NULL DEFAULT '0.00',
  `billing_cycle` text,
  `addon_ids` text,
  `related_orders` text,
  `description` text,
  `upgrade_ids` text,
  `xdata` text,
  `xsecret` varchar(100) DEFAULT NULL,
  `promo_code` text,
  `promo_type` text,
  `promo_value` text,
  `payment_method` text,
  `ipaddress` text,
  `fraud_module` text,
  `fraud_output` text,
  `activation_subject` text,
  `activation_message` text,
  `trash` int(1) NOT NULL DEFAULT '0',
  `archived` int(1) NOT NULL DEFAULT '0',
  `c1` text,
  `c2` text,
  `c3` text,
  `c4` text,
  `c5` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `sys_permissions`
--

DROP TABLE IF EXISTS `sys_permissions`;
CREATE TABLE IF NOT EXISTS `sys_permissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pname` varchar(200) DEFAULT NULL,
  `shortname` varchar(200) DEFAULT NULL,
  `available` int(1) NOT NULL DEFAULT '0',
  `core` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `sys_permissions`
--

INSERT INTO `sys_permissions` (`id`, `pname`, `shortname`, `available`, `core`) VALUES
(1, 'LSP', 'customers', 0, 1),
(2, 'Purchase Construction Material', 'companies', 0, 1),
(3, 'Transactions', 'transactions', 0, 1),
(4, 'Sales', 'sales', 0, 1),
(5, 'Bank & Cash', 'bank_n_cash', 0, 1),
(6, 'Products & Services', 'products_n_services', 0, 1),
(7, 'Reports', 'reports', 0, 1),
(8, 'Utilities', 'utilities', 0, 1),
(9, 'Appearance', 'appearance', 0, 1),
(10, 'Plugins', 'plugins', 0, 1),
(11, 'Calendar', 'calendar', 0, 1),
(12, 'Leads', 'leads', 0, 1),
(13, 'Tasks', 'tasks', 0, 1),
(14, 'Contracts', 'contracts', 0, 1),
(15, 'Trade', 'orders', 0, 1),
(16, 'Settings', 'settings', 0, 1),
(17, 'Documents', 'documents', 0, 1),
(18, 'Providers', 'providers', 0, 1),
(19, 'Requestors', 'requestors', 0, 1),
(20, 'Truck Registration', 'companies5', 0, 1),
(21, 'Submit Transport Request', 'companies6', 0, 1),
(22, 'Rental Heavy Machine', 'companies2', 0, 1),
(23, 'Rental of Agricultural Equipment', 'companies1', 0, 1),
(24, 'Purchase Parkaging Material', 'companies4', 0, 1),
(25, 'LSP Driver', 'companies3', 0, 1),
(26, 'LSR', 'lsr', 0, 1),
(27, 'Driver', 'driver', 0, 1),
(28, 'Dashboard', 'dashboard', 0, 1);

-- --------------------------------------------------------

--
-- Structure de la table `sys_pg`
--

DROP TABLE IF EXISTS `sys_pg`;
CREATE TABLE IF NOT EXISTS `sys_pg` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,
  `settings` text NOT NULL,
  `value` text NOT NULL,
  `processor` text NOT NULL,
  `ins` text NOT NULL,
  `c1` text NOT NULL,
  `c2` text NOT NULL,
  `c3` text NOT NULL,
  `c4` text NOT NULL,
  `c5` text NOT NULL,
  `status` enum('Active','Inactive') NOT NULL,
  `sorder` int(2) NOT NULL,
  `logo` varchar(200) DEFAULT NULL,
  `mode` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `gateway_setting` (`name`(32),`processor`(32)),
  KEY `setting_value` (`processor`(32),`ins`(32))
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `sys_pg`
--

INSERT INTO `sys_pg` (`id`, `name`, `settings`, `value`, `processor`, `ins`, `c1`, `c2`, `c3`, `c4`, `c5`, `status`, `sorder`, `logo`, `mode`) VALUES
(1, 'Paypal', 'Paypal Email', 'demo@example.com', 'paypal', 'Invoices', 'USD', '1', '', '', '', 'Active', 1, NULL, NULL),
(2, 'Stripe', 'API Key', 'sk_test_ARblMczqDw61NusMMs7o1RVK', 'stripe', '', 'USD', '', '', '', '', 'Active', 2, NULL, NULL),
(3, 'Bank / Cash', 'Instructions', 'Make a Payment to Our Bank Account <br>Bank Name: City Bank <br>Account Name: Sadia Sharmin <br>Account Number: 1505XXXXXXXX <br>', 'manualpayment', '', '', '', '', '', '', 'Active', 3, NULL, NULL),
(4, 'Authorize.net', 'API_LOGIN_ID', 'Insert API Login ID here', 'authorize_net', '', 'Insert Transaction Key Here', '', '', '', '', 'Active', 4, NULL, NULL),
(5, 'Braintree', 'Merchant ID', 'your merchant id', 'braintree', '', 'your public key', 'your private key', 'bank account', 'sandbox', '', 'Inactive', 5, NULL, NULL);

-- --------------------------------------------------------

--
-- Structure de la table `sys_pl`
--

DROP TABLE IF EXISTS `sys_pl`;
CREATE TABLE IF NOT EXISTS `sys_pl` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `c` varchar(50) NOT NULL,
  `status` int(11) NOT NULL DEFAULT '1',
  `sorder` int(11) NOT NULL DEFAULT '0',
  `build` int(10) DEFAULT '1',
  `c1` text,
  `c2` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `sys_pmethods`
--

DROP TABLE IF EXISTS `sys_pmethods`;
CREATE TABLE IF NOT EXISTS `sys_pmethods` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `sorder` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `sys_pmethods`
--

INSERT INTO `sys_pmethods` (`id`, `name`, `sorder`) VALUES
(1, 'Cash', 1),
(2, 'Check', 4),
(3, 'Credit Card', 5),
(4, 'Debit', 6),
(5, 'Electronic Transfer', 7),
(9, 'Paypal', 2),
(10, 'ATM Withdrawals', 3);

-- --------------------------------------------------------

--
-- Structure de la table `sys_quoteitems`
--

DROP TABLE IF EXISTS `sys_quoteitems`;
CREATE TABLE IF NOT EXISTS `sys_quoteitems` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `qid` int(10) NOT NULL,
  `itemcode` text NOT NULL,
  `description` text NOT NULL,
  `qty` text NOT NULL,
  `amount` decimal(18,2) NOT NULL,
  `discount` decimal(10,2) NOT NULL,
  `total` decimal(18,2) NOT NULL,
  `taxable` int(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `sys_quotes`
--

DROP TABLE IF EXISTS `sys_quotes`;
CREATE TABLE IF NOT EXISTS `sys_quotes` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `subject` text NOT NULL,
  `stage` enum('Draft','Delivered','On Hold','Accepted','Lost','Dead') NOT NULL,
  `validuntil` date NOT NULL,
  `userid` int(10) NOT NULL,
  `invoicenum` text NOT NULL,
  `cn` text NOT NULL,
  `account` text NOT NULL,
  `firstname` text NOT NULL,
  `lastname` text NOT NULL,
  `companyname` text NOT NULL,
  `email` text NOT NULL,
  `address1` text NOT NULL,
  `address2` text NOT NULL,
  `city` text NOT NULL,
  `state` text NOT NULL,
  `postcode` text NOT NULL,
  `country` text NOT NULL,
  `phonenumber` text NOT NULL,
  `currency` int(10) NOT NULL,
  `subtotal` decimal(18,2) NOT NULL,
  `discount_type` text NOT NULL,
  `discount_value` decimal(10,2) NOT NULL,
  `discount` decimal(10,2) NOT NULL,
  `taxname` text NOT NULL,
  `taxrate` decimal(10,2) NOT NULL,
  `tax1` decimal(10,2) NOT NULL,
  `tax2` decimal(10,2) NOT NULL,
  `total` decimal(18,2) NOT NULL,
  `proposal` text NOT NULL,
  `customernotes` text NOT NULL,
  `adminnotes` text NOT NULL,
  `datecreated` date NOT NULL,
  `lastmodified` date NOT NULL,
  `datesent` date NOT NULL,
  `dateaccepted` date NOT NULL,
  `vtoken` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `sys_roles`
--

DROP TABLE IF EXISTS `sys_roles`;
CREATE TABLE IF NOT EXISTS `sys_roles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rname` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `sys_roles`
--

INSERT INTO `sys_roles` (`id`, `rname`) VALUES
(1, 'Employee'),
(2, 'LSR'),
(3, 'LSP');

-- --------------------------------------------------------

--
-- Structure de la table `sys_sales`
--

DROP TABLE IF EXISTS `sys_sales`;
CREATE TABLE IF NOT EXISTS `sys_sales` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cid` int(11) NOT NULL DEFAULT '0',
  `oid` int(11) NOT NULL DEFAULT '0',
  `oname` varchar(200) NOT NULL,
  `description` mediumtext NOT NULL,
  `amount` decimal(14,2) NOT NULL,
  `term` varchar(100) NOT NULL,
  `milestone` varchar(100) NOT NULL,
  `p` int(11) NOT NULL,
  `o` int(11) NOT NULL,
  `open` date NOT NULL,
  `close` date NOT NULL,
  `status` enum('New','In Progress','Won','Lost') NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `sys_schedule`
--

DROP TABLE IF EXISTS `sys_schedule`;
CREATE TABLE IF NOT EXISTS `sys_schedule` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cname` mediumtext NOT NULL,
  `val` mediumtext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `sys_schedule`
--

INSERT INTO `sys_schedule` (`id`, `cname`, `val`) VALUES
(1, 'accounting_snapshot', 'Active'),
(2, 'recurring_invoice', 'Active'),
(3, 'notify', 'Active'),
(4, 'notifyemail', 'demo@example.com');

-- --------------------------------------------------------

--
-- Structure de la table `sys_schedulelogs`
--

DROP TABLE IF EXISTS `sys_schedulelogs`;
CREATE TABLE IF NOT EXISTS `sys_schedulelogs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `logs` mediumtext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `sys_schedulelogs`
--

INSERT INTO `sys_schedulelogs` (`id`, `date`, `logs`) VALUES
(4, '2015-03-14', '2015-03-14 20:17:15 : Schedule Jobs Started....... <br>2015-03-14 20:17:15 : Creating Accounting Snapshot <br>2015-03-14 20:17:15 : Accounting Snapshot created! <br>=============== Accounting Snaphsot ==================== <br>Accounting Snaphsot - Date: 2015-03-13<br>Total Income: Tk. 0.00<br>Total Expense: Tk. 0.00<br>================================================== <br>2015-03-14 20:17:15 : Creating Recurring Invoice <br>2015-03-14 20:17:15 : 1 Invoice created! <br>================================================== <br>');

-- --------------------------------------------------------

--
-- Structure de la table `sys_staffpermissions`
--

DROP TABLE IF EXISTS `sys_staffpermissions`;
CREATE TABLE IF NOT EXISTS `sys_staffpermissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rid` int(11) DEFAULT NULL,
  `pid` int(11) DEFAULT NULL,
  `shortname` varchar(50) DEFAULT NULL,
  `can_view` int(1) NOT NULL DEFAULT '0',
  `can_edit` int(1) NOT NULL DEFAULT '0',
  `can_create` int(1) NOT NULL DEFAULT '0',
  `can_delete` int(1) NOT NULL DEFAULT '0',
  `all_data` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=318 DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `sys_staffpermissions`
--

INSERT INTO `sys_staffpermissions` (`id`, `rid`, `pid`, `shortname`, `can_view`, `can_edit`, `can_create`, `can_delete`, `all_data`) VALUES
(1, 3, 1, 'customers', 0, 0, 0, 0, 0),
(2, 3, 2, 'companies', 0, 0, 0, 0, 0),
(3, 3, 3, 'transactions', 0, 0, 0, 0, 0),
(4, 3, 4, 'sales', 0, 0, 0, 0, 0),
(5, 3, 5, 'bank_n_cash', 0, 0, 0, 0, 0),
(6, 3, 6, 'products_n_services', 0, 0, 0, 0, 0),
(7, 3, 7, 'reports', 0, 0, 0, 0, 0),
(8, 3, 8, 'utilities', 0, 0, 0, 0, 0),
(9, 3, 9, 'appearance', 0, 0, 0, 0, 0),
(10, 3, 10, 'plugins', 0, 0, 0, 0, 0),
(11, 3, 11, 'calendar', 0, 0, 0, 0, 0),
(12, 3, 12, 'leads', 0, 0, 0, 0, 0),
(13, 3, 13, 'tasks', 0, 0, 0, 0, 0),
(14, 3, 14, 'contracts', 0, 0, 0, 0, 0),
(15, 3, 15, 'orders', 0, 0, 0, 0, 0),
(16, 3, 16, 'settings', 0, 0, 0, 0, 0),
(17, 3, 17, 'documents', 0, 0, 0, 0, 0),
(18, 3, 18, 'providers', 0, 0, 0, 0, 0),
(19, 3, 19, 'requestors', 0, 0, 0, 0, 0),
(20, 3, 20, 'companies5', 0, 0, 0, 0, 0),
(21, 3, 21, 'companies6', 1, 0, 0, 0, 0),
(290, 1, 1, 'customers', 1, 1, 1, 0, 0),
(291, 1, 2, 'companies', 1, 1, 1, 0, 0),
(292, 1, 3, 'transactions', 0, 0, 0, 0, 0),
(293, 1, 4, 'sales', 0, 0, 0, 0, 0),
(294, 1, 5, 'bank_n_cash', 0, 0, 0, 0, 0),
(295, 1, 6, 'products_n_services', 0, 0, 0, 0, 0),
(296, 1, 7, 'reports', 1, 0, 0, 0, 0),
(297, 1, 8, 'utilities', 0, 0, 0, 0, 0),
(298, 1, 9, 'appearance', 0, 0, 0, 0, 0),
(299, 1, 10, 'plugins', 0, 0, 0, 0, 0),
(300, 1, 11, 'calendar', 0, 0, 0, 0, 0),
(301, 1, 12, 'leads', 0, 0, 0, 0, 0),
(302, 1, 13, 'tasks', 0, 0, 0, 0, 0),
(303, 1, 14, 'contracts', 0, 0, 0, 0, 0),
(304, 1, 15, 'orders', 1, 0, 0, 0, 0),
(305, 1, 16, 'settings', 0, 0, 0, 0, 0),
(306, 1, 17, 'documents', 0, 0, 0, 0, 0),
(307, 1, 18, 'providers', 1, 0, 0, 0, 0),
(308, 1, 19, 'requestors', 1, 0, 0, 0, 0),
(309, 1, 20, 'companies5', 1, 1, 1, 0, 0),
(310, 1, 21, 'companies6', 1, 1, 1, 0, 0),
(311, 1, 22, 'companies2', 1, 0, 0, 0, 0),
(312, 1, 23, 'companies1', 1, 0, 0, 0, 0),
(313, 1, 24, 'companies4', 1, 0, 0, 0, 0),
(314, 1, 25, 'companies3', 1, 0, 0, 0, 0),
(315, 1, 26, 'lsr', 1, 0, 0, 0, 0),
(316, 1, 27, 'driver', 1, 0, 0, 0, 0),
(317, 1, 28, 'dashboard', 1, 0, 0, 0, 0);

-- --------------------------------------------------------

--
-- Structure de la table `sys_tags`
--

DROP TABLE IF EXISTS `sys_tags`;
CREATE TABLE IF NOT EXISTS `sys_tags` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `text` varchar(100) NOT NULL,
  `type` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `sys_tasks`
--

DROP TABLE IF EXISTS `sys_tasks`;
CREATE TABLE IF NOT EXISTS `sys_tasks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` text,
  `description` text,
  `status` varchar(200) DEFAULT NULL,
  `cid` int(11) NOT NULL DEFAULT '0',
  `oid` int(11) NOT NULL DEFAULT '0',
  `iid` int(11) NOT NULL DEFAULT '0',
  `aid` int(11) NOT NULL DEFAULT '0',
  `tid` int(11) NOT NULL DEFAULT '0',
  `eid` int(11) NOT NULL DEFAULT '0',
  `pid` int(11) NOT NULL DEFAULT '0',
  `did` int(11) NOT NULL DEFAULT '0',
  `company_id` int(11) NOT NULL DEFAULT '0',
  `subscribers` text,
  `assigned_to` text,
  `priority` varchar(200) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `created_by` varchar(200) DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `updated_by` varchar(200) DEFAULT NULL,
  `vtoken` varchar(50) DEFAULT NULL,
  `ptoken` varchar(50) DEFAULT NULL,
  `started` date DEFAULT NULL,
  `due_date` date DEFAULT NULL,
  `stime` varchar(50) DEFAULT NULL,
  `dtime` varchar(50) DEFAULT NULL,
  `time_spent` varchar(50) DEFAULT NULL,
  `date_finished` date DEFAULT NULL,
  `source` varchar(100) DEFAULT NULL,
  `flag` int(1) NOT NULL DEFAULT '0',
  `finished` int(1) NOT NULL DEFAULT '0',
  `ratings` varchar(50) DEFAULT NULL,
  `rel_type` varchar(50) DEFAULT NULL,
  `rel_id` int(11) DEFAULT NULL,
  `parent` int(11) NOT NULL DEFAULT '0',
  `is_public` int(1) NOT NULL DEFAULT '0',
  `billable` int(1) NOT NULL DEFAULT '0',
  `billed` int(1) NOT NULL DEFAULT '0',
  `hourly_rate` decimal(14,2) NOT NULL DEFAULT '0.00',
  `milestone` int(11) DEFAULT NULL,
  `progress` int(3) DEFAULT NULL,
  `visible_to_client` int(1) NOT NULL DEFAULT '0',
  `notification` int(1) NOT NULL DEFAULT '0',
  `trash` int(1) NOT NULL DEFAULT '0',
  `archived` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `sys_tax`
--

DROP TABLE IF EXISTS `sys_tax`;
CREATE TABLE IF NOT EXISTS `sys_tax` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,
  `state` text NOT NULL,
  `country` text NOT NULL,
  `rate` decimal(10,2) NOT NULL,
  `aid` int(11) NOT NULL,
  `bal` decimal(10,2) NOT NULL DEFAULT '0.00',
  PRIMARY KEY (`id`),
  KEY `state_country` (`state`(32),`country`(2))
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `sys_tax`
--

INSERT INTO `sys_tax` (`id`, `name`, `state`, `country`, `rate`, `aid`, `bal`) VALUES
(1, 'Sales Tax', '', '', '1.50', 0, '0.00');

-- --------------------------------------------------------

--
-- Structure de la table `sys_transactions`
--

DROP TABLE IF EXISTS `sys_transactions`;
CREATE TABLE IF NOT EXISTS `sys_transactions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `account` varchar(200) NOT NULL,
  `type` enum('Income','Expense','Transfer') NOT NULL,
  `category` varchar(200) DEFAULT NULL,
  `amount` decimal(18,2) NOT NULL,
  `payer` varchar(200) DEFAULT NULL,
  `payee` varchar(200) DEFAULT NULL,
  `payerid` int(11) NOT NULL DEFAULT '0',
  `payeeid` int(11) NOT NULL DEFAULT '0',
  `method` varchar(200) DEFAULT NULL,
  `ref` varchar(200) DEFAULT NULL,
  `status` enum('Cleared','Uncleared','Reconciled','Void') NOT NULL DEFAULT 'Cleared',
  `description` text,
  `tags` text,
  `tax` decimal(18,2) NOT NULL DEFAULT '0.00',
  `date` date NOT NULL,
  `dr` decimal(18,2) NOT NULL DEFAULT '0.00',
  `cr` decimal(18,2) NOT NULL DEFAULT '0.00',
  `bal` decimal(18,2) NOT NULL DEFAULT '0.00',
  `iid` int(11) NOT NULL DEFAULT '0',
  `currency` int(11) NOT NULL DEFAULT '0',
  `currency_symbol` varchar(10) DEFAULT NULL,
  `currency_prefix` varchar(10) DEFAULT NULL,
  `currency_suffix` varchar(10) DEFAULT NULL,
  `currency_rate` decimal(11,4) NOT NULL DEFAULT '1.0000',
  `base_amount` decimal(16,4) NOT NULL DEFAULT '0.0000',
  `company_id` int(11) NOT NULL DEFAULT '0',
  `vid` int(11) NOT NULL DEFAULT '0',
  `aid` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `updated_by` int(11) NOT NULL DEFAULT '0',
  `attachments` text,
  `source` varchar(200) DEFAULT NULL,
  `rid` int(11) NOT NULL DEFAULT '0',
  `pid` int(11) NOT NULL DEFAULT '0',
  `archived` int(1) NOT NULL DEFAULT '0',
  `trash` int(1) NOT NULL DEFAULT '0',
  `flag` int(1) NOT NULL DEFAULT '0',
  `c1` text,
  `c2` text,
  `c3` text,
  `c4` text,
  `c5` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `sys_transactions`
--

INSERT INTO `sys_transactions` (`id`, `account`, `type`, `category`, `amount`, `payer`, `payee`, `payerid`, `payeeid`, `method`, `ref`, `status`, `description`, `tags`, `tax`, `date`, `dr`, `cr`, `bal`, `iid`, `currency`, `currency_symbol`, `currency_prefix`, `currency_suffix`, `currency_rate`, `base_amount`, `company_id`, `vid`, `aid`, `created_at`, `updated_at`, `updated_by`, `attachments`, `source`, `rid`, `pid`, `archived`, `trash`, `flag`, `c1`, `c2`, `c3`, `c4`, `c5`) VALUES
(1, 'deposit account', 'Income', '', '3400000.00', '', '', 0, 0, '', '', 'Cleared', 'Initial Balance', '', '0.00', '2022-09-13', '0.00', '3400000.00', '3400000.00', 0, 0, NULL, NULL, NULL, '1.0000', '0.0000', 0, 0, 0, NULL, '2022-09-13 09:58:39', 0, NULL, NULL, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL),
(2, 'deposit account', 'Income', 'Uncategorized', '777.00', '', '', 0, 0, '', '', 'Cleared', 'gflkmlgd', '', '0.00', '2022-09-13', '0.00', '777.00', '3400777.00', 0, 0, NULL, NULL, NULL, '1.0000', '0.0000', 0, 0, 0, NULL, '2022-09-13 10:00:07', 0, '_e2c61965779006166308119410441795.jpg', NULL, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL),
(3, 'deposit account', 'Income', 'Uncategorized', '777.00', '', '', 0, 0, '', '', 'Cleared', 'hhjili', '', '0.00', '2022-09-13', '0.00', '777.00', '3401554.00', 0, 0, NULL, NULL, NULL, '1.0000', '0.0000', 0, 0, 0, NULL, '2022-09-13 10:15:45', 0, '_fd8c07a3864731166308183310821451.png', NULL, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL),
(4, 'deposit account', 'Income', 'Uncategorized', '379090.00', '', '', 0, 0, '', '', 'Cleared', 'mlklkm', '', '0.00', '2022-12-10', '0.00', '379090.00', '3780644.00', 0, 0, NULL, NULL, NULL, '1.0000', '0.0000', 0, 0, 0, NULL, '2022-12-10 03:44:28', 0, '', NULL, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL),
(5, 'deposit account', 'Expense', 'Uncategorized', '40000.00', '', '', 0, 0, '', '', 'Cleared', 'll l, ,l,', '', '0.00', '2022-12-10', '40000.00', '0.00', '3740644.00', 0, 0, NULL, NULL, NULL, '1.0000', '0.0000', 0, 0, 0, NULL, '2022-12-10 03:45:28', 0, '_ae3f58a1075593167066551810447160.png', NULL, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Structure de la table `sys_units`
--

DROP TABLE IF EXISTS `sys_units`;
CREATE TABLE IF NOT EXISTS `sys_units` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(200) DEFAULT NULL,
  `name` varchar(200) DEFAULT NULL,
  `reference` varchar(200) DEFAULT NULL,
  `conversion_factor` decimal(16,2) NOT NULL DEFAULT '0.00',
  `sorder` int(11) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `sys_users`
--

DROP TABLE IF EXISTS `sys_users`;
CREATE TABLE IF NOT EXISTS `sys_users` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `username` varchar(100) NOT NULL DEFAULT '',
  `fullname` varchar(45) NOT NULL DEFAULT '',
  `phonenumber` varchar(20) DEFAULT NULL,
  `password` mediumtext NOT NULL,
  `user_type` varchar(50) NOT NULL DEFAULT 'Full Access',
  `status` enum('Active','Inactive') NOT NULL DEFAULT 'Active',
  `last_login` datetime DEFAULT NULL,
  `email` varchar(200) DEFAULT NULL,
  `creationdate` datetime NOT NULL,
  `otp` enum('Yes','No') NOT NULL DEFAULT 'No',
  `pin_enabled` enum('Yes','No') NOT NULL DEFAULT 'No',
  `pin` mediumtext NOT NULL,
  `img` text NOT NULL,
  `api` enum('Yes','No') DEFAULT 'No',
  `pwresetkey` varchar(100) NOT NULL,
  `keyexpire` varchar(100) NOT NULL,
  `roleid` int(11) NOT NULL DEFAULT '0',
  `role` varchar(200) DEFAULT NULL,
  `last_activity` datetime DEFAULT NULL,
  `autologin` varchar(200) DEFAULT NULL,
  `at` varchar(200) DEFAULT NULL,
  `landing_page` varchar(200) DEFAULT NULL,
  `language` varchar(100) DEFAULT NULL,
  `notes` text,
  `c1` text,
  `c2` text,
  `c3` text,
  `c4` text,
  `c5` text,
  `user_lang` varchar(50) NOT NULL DEFAULT 'en',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `sys_users`
--

INSERT INTO `sys_users` (`id`, `username`, `fullname`, `phonenumber`, `password`, `user_type`, `status`, `last_login`, `email`, `creationdate`, `otp`, `pin_enabled`, `pin`, `img`, `api`, `pwresetkey`, `keyexpire`, `roleid`, `role`, `last_activity`, `autologin`, `at`, `landing_page`, `language`, `notes`, `c1`, `c2`, `c3`, `c4`, `c5`, `user_lang`) VALUES
(1, 'demo@example.com', 'Administrator', '', '$2b$10$.vWJz4hX0TW5Z7hK.hYkB.JdXXiz7zceyJbPo3hm.jxtbTNp05oQi', 'Admin', 'Active', '2022-12-29 03:09:46', '', '2014-10-20 01:43:07', 'No', 'No', '$1$ZW/.uF5.$.rwCeLiguoBzYzf3waOnY1', '', 'No', '', '0', 0, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'en'),
(2, 'kingue@lol.vf', 'moi', '', 'ibLJRKHoI8Qfk', 'Employee', 'Active', '2022-12-29 04:21:13', '', '2022-09-17 10:51:41', 'No', 'No', '', '', 'No', '', '', 1, 'Employee', NULL, 'woybsvswibrdf69orb4q2', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'fr');

-- --------------------------------------------------------

--
-- Structure de la table `trades`
--

DROP TABLE IF EXISTS `trades`;
CREATE TABLE IF NOT EXISTS `trades` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `lsr_id` int(10) UNSIGNED DEFAULT '0',
  `item_id` int(10) UNSIGNED ZEROFILL DEFAULT '0000000000',
  `item_table` varchar(50) DEFAULT NULL,
  `status` int(11) NOT NULL DEFAULT '1',
  `contacted_lsr` int(2) NOT NULL DEFAULT '0',
  `contacted_lsp` int(2) NOT NULL DEFAULT '0',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=56 DEFAULT CHARSET=latin1 COMMENT='list all trades';

--
-- Déchargement des données de la table `trades`
--

INSERT INTO `trades` (`id`, `lsr_id`, `item_id`, `item_table`, `status`, `contacted_lsr`, `contacted_lsp`, `created_at`, `updated_at`) VALUES
(44, 23, 0000000062, 'sys_companies6', 1, 1, 1, '2022-12-11 09:43:18', '2022-12-13 04:40:16'),
(45, 23, 0000000057, 'sys_companies6', 1, 1, 0, '2022-12-11 10:42:29', '2022-12-11 10:42:29'),
(46, 15, 0000000059, 'sys_companies6', 1, 1, 0, '2022-12-11 16:18:18', '2022-12-11 16:18:18'),
(47, 23, 0000000056, 'sys_companies6', 1, 1, 0, '2022-12-11 16:23:59', '2022-12-11 16:23:59'),
(48, 22, 0000000054, 'sys_companies6', 1, 1, 0, '2022-12-11 16:25:01', '2022-12-11 16:25:01'),
(49, 22, 0000000036, 'sys_companies4', 1, 1, 0, '2022-12-11 16:40:24', '2022-12-11 16:40:24'),
(50, 18, 0000000058, 'sys_companies6', 1, 1, 0, '2022-12-11 16:41:34', '2022-12-11 16:41:34'),
(51, 15, 0000000003, 'sys_companies', 1, 1, 0, '2022-12-11 16:42:44', '2022-12-11 16:42:44'),
(52, 19, 0000000038, 'sys_companies4', 1, 1, 1, '2022-12-11 16:46:33', '2022-12-23 09:08:16'),
(53, 23, 0000000035, 'sys_companies1', 1, 1, 0, '2022-12-11 16:54:36', '2022-12-11 16:54:36'),
(54, 22, 0000000037, 'sys_companies4', 1, 1, 0, '2022-12-11 17:04:37', '2022-12-11 17:04:37'),
(55, 21, 0000000002, 'sys_companies', 1, 1, 0, '2022-12-11 17:16:58', '2022-12-11 17:16:58');

-- --------------------------------------------------------

--
-- Structure de la table `trade_conversations`
--

DROP TABLE IF EXISTS `trade_conversations`;
CREATE TABLE IF NOT EXISTS `trade_conversations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `trade_id` int(11) NOT NULL DEFAULT '0',
  `subject` varchar(255) NOT NULL DEFAULT '0',
  `content` text NOT NULL,
  `recipient_type` varchar(50) NOT NULL,
  `recipient_id` int(11) NOT NULL DEFAULT '0',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `sender_id` int(11) DEFAULT NULL,
  `sender_type` varchar(50) DEFAULT NULL,
  `send_by_sms` varchar(50) DEFAULT NULL,
  `send_by_email` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=126 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `trade_conversations`
--

INSERT INTO `trade_conversations` (`id`, `trade_id`, `subject`, `content`, `recipient_type`, `recipient_id`, `created_at`, `updated_at`, `sender_id`, `sender_type`, `send_by_sms`, `send_by_email`) VALUES
(72, 44, 'dfhgfgh fdjhjhdf dfjjhdf', 'gfghfhffg', 'lsr', 23, '2022-12-11 09:43:18', '2022-12-11 09:43:18', 1, 'admin', 'No', ''),
(73, 45, 'dfhgfgh fdjhjhdf dfjjhdf', 'ghffgfhg ffhfh', 'lsr', 23, '2022-12-11 10:42:29', '2022-12-11 10:42:29', 1, 'admin', 'No', ''),
(74, 46, 'Demande cotation fdfdfef', 'cxxcxcx', 'lsr', 15, '2022-12-11 16:18:18', '2022-12-11 16:18:18', 1, 'admin', 'No', ''),
(75, 47, 'dfhgfgh fdjhjhdf dfjjhdf', 'cxcxc', 'lsr', 23, '2022-12-11 16:24:00', '2022-12-11 16:24:00', 1, 'admin', 'No', 'Yes'),
(76, 48, 'dfhgfgh fdjhjhdf dfjjhdf', 'bvbvbvb', 'lsr', 22, '2022-12-11 16:25:01', '2022-12-11 16:25:01', 1, 'admin', 'No', 'Yes'),
(77, 49, 'dfhgfgh fdjhjhdf dfjjhdf', 'bvbvvbbvvb', 'lsr', 22, '2022-12-11 16:40:24', '2022-12-11 16:40:24', 1, 'admin', 'No', 'Yes'),
(78, 50, 'Demande cotation fdfdfef', 'cbvcvvv', 'lsr', 18, '2022-12-11 16:41:34', '2022-12-11 16:41:34', 1, 'admin', 'No', 'Yes'),
(79, 51, 'dfhgfgh fdjhjhdf dfjjhdf', 'bbvbvbvbvbv', 'lsr', 15, '2022-12-11 16:42:44', '2022-12-11 16:42:44', 1, 'admin', 'No', 'Yes'),
(80, 52, 'Demande cotation', 'ghcbvcbvcbv', 'lsr', 19, '2022-12-11 16:46:33', '2022-12-11 16:46:33', 1, 'admin', 'No', 'Yes'),
(83, 54, 'Demande cotation fdfdfef', 'gffgfgfg', 'lsr', 22, '2022-12-11 17:04:37', '2022-12-11 17:04:37', 1, 'admin', 'No', 'Yes'),
(84, 55, 'dfhgfgh fdjhjhdf dfjjhdf', 'gffgfg', 'lsr', 21, '2022-12-11 17:16:58', '2022-12-11 17:16:58', 1, 'admin', 'No', 'Yes'),
(85, 44, 'Demande cotation', '<p>ghfgfhf</p>', 'lsp', 56, '2022-12-13 04:40:22', '2022-12-13 04:40:22', 1, 'admin', 'No', 'Yes'),
(86, 44, 'Demande cotation', '<p>ghfgfhf</p>', 'lsp', 62, '2022-12-13 04:40:23', '2022-12-13 04:40:23', 1, 'admin', 'No', 'Yes'),
(87, 52, 'fgccgfcvvvg', 't4jhtkjtg', 'lsp', 56, '2022-12-23 09:29:42', '2022-12-23 09:29:42', NULL, 'admin', 'mknhymh', ''),
(88, 52, 'fgccgfcvvvg', 't4jhtkjtg', 'lsp', 56, '2022-12-23 09:30:02', '2022-12-23 09:30:02', NULL, 'admin', 'mknhymh', ''),
(89, 52, 'fgccgfcvvvg', 't4jhtkjtg', 'lsp', 56, '2022-12-23 09:30:30', '2022-12-23 09:30:30', NULL, 'admin', 'mknhymh', ''),
(90, 52, 'fgccgfcvvvg', 't4jhtkjtg', 'lsp', 56, '2022-12-23 09:30:39', '2022-12-23 09:30:39', NULL, 'admin', 'mknhymh', ''),
(91, 52, 'fgccgfcvvvg', 't4jhtkjtg', 'lsp', 56, '2022-12-23 09:32:35', '2022-12-23 09:32:35', NULL, 'admin', 'mknhymh', ''),
(92, 52, 'fgccgfcvvvg', 't4jhtkjtg', 'lsp', 56, '2022-12-23 09:33:26', '2022-12-23 09:33:26', NULL, 'admin', 'mknhymh', ''),
(93, 52, 'fgccgfcvvvg', 't4jhtkjtg', 'lsp', 56, '2022-12-23 09:33:27', '2022-12-23 09:33:27', NULL, 'admin', 'mknhymh', ''),
(94, 52, 'fgccgfcvvvg', 't4jhtkjtg', 'lsp', 56, '2022-12-23 09:34:14', '2022-12-23 09:34:14', NULL, 'admin', 'mknhymh', ''),
(95, 52, 'fgccgfcvvvg', 't4jhtkjtg', 'lsp', 56, '2022-12-23 09:34:16', '2022-12-23 09:34:16', NULL, 'admin', 'mknhymh', ''),
(96, 52, 'fgccgfcvvvg', 't4jhtkjtg', 'lsp', 56, '2022-12-23 09:34:17', '2022-12-23 09:34:17', NULL, 'admin', 'mknhymh', ''),
(97, 52, 'fgccgfcvvvg', 't4jhtkjtg', 'lsp', 56, '2022-12-23 09:34:19', '2022-12-23 09:34:19', NULL, 'admin', 'mknhymh', ''),
(98, 52, 'fgccgfcvvvg', 't4jhtkjtg', 'lsp', 56, '2022-12-23 09:34:34', '2022-12-23 09:34:34', NULL, 'admin', 'mknhymh', 'yes'),
(99, 52, 'fgccgfcvvvg', 't4jhtkjtg', 'lsp', 56, '2022-12-23 09:35:27', '2022-12-23 09:35:27', NULL, 'admin', 'mknhymh', 'yes'),
(100, 52, 'fgccgfcvvvg', 't4jhtkjtg', 'lsp', 56, '2022-12-23 09:35:37', '2022-12-23 09:35:37', NULL, 'admin', 'mknhymh', 'yes'),
(101, 52, 'fgccgfcvvvg', 't4jhtkjtg', 'lsp', 56, '2022-12-23 09:36:10', '2022-12-23 09:36:10', NULL, 'admin', 'mknhymh', 'yes'),
(102, 52, 'fgccgfcvvvg', 't4jhtkjtg', 'lsp', 56, '2022-12-23 09:36:41', '2022-12-23 09:36:41', NULL, 'admin', 'mknhymh', 'yes'),
(103, 52, 'fgccgfcvvvg', 't4jhtkjtg', 'lsp', 56, '2022-12-23 09:36:43', '2022-12-23 09:36:43', NULL, 'admin', 'mknhymh', 'yes'),
(104, 52, 'fgccgfcvvvg', 't4jhtkjtg', 'lsp', 56, '2022-12-23 09:36:59', '2022-12-23 09:36:59', NULL, 'admin', 'mknhymh', 'yes'),
(105, 52, 'fgccgfcvvvg', 't4jhtkjtg', 'lsp', 56, '2022-12-23 09:48:28', '2022-12-23 09:48:28', NULL, 'admin', 'mknhymh', 'yes'),
(106, 52, 'fgccgfcvvvg', 't4jhtkjtg', 'lsp', 56, '2022-12-23 09:48:37', '2022-12-23 09:48:37', NULL, 'admin', 'mknhymh', 'yes'),
(107, 52, 'fgccgfcvvvg', 't4jhtkjtg', 'lsp', 56, '2022-12-23 09:48:39', '2022-12-23 09:48:39', NULL, 'admin', 'mknhymh', 'yes'),
(108, 52, 'fgccgfcvvvg', 't4jhtkjtg', 'lsp', 56, '2022-12-23 09:49:11', '2022-12-23 09:49:11', NULL, 'admin', 'mknhymh', 'yes'),
(109, 52, 'fgccgfcvvvg', 't4jhtkjtg', 'lsp', 56, '2022-12-23 09:49:40', '2022-12-23 09:49:40', NULL, 'admin', 'mknhymh', 'yes'),
(110, 52, 'fgccgfcvvvg', 't4jhtkjtg', 'lsp', 56, '2022-12-23 09:50:04', '2022-12-23 09:50:04', NULL, 'admin', 'mknhymh', 'yes'),
(111, 52, 'fgccgfcvvvg', 't4jhtkjtg', 'lsp', 56, '2022-12-23 09:50:21', '2022-12-23 09:50:21', NULL, 'admin', 'mknhymh', 'yes'),
(112, 52, 'fgccgfcvvvg', 't4jhtkjtg', 'lsp', 56, '2022-12-23 09:50:51', '2022-12-23 09:50:51', NULL, 'admin', 'mknhymh', 'yes'),
(113, 52, 'fgccgfcvvvg', 't4jhtkjtg', 'lsp', 56, '2022-12-23 09:51:24', '2022-12-23 09:51:24', NULL, 'admin', 'mknhymh', 'yes'),
(114, 52, 'fgccgfcvvvg', 't4jhtkjtg', 'lsp', 56, '2022-12-23 09:52:14', '2022-12-23 09:52:14', NULL, 'admin', 'mknhymh', 'yes'),
(115, 52, 'fgccgfcvvvg', 't4jhtkjtg', 'lsp', 56, '2022-12-23 09:52:30', '2022-12-23 09:52:30', NULL, 'admin', 'mknhymh', 'yes'),
(116, 52, 'fgccgfcvvvg', 't4jhtkjtg', 'lsp', 56, '2022-12-23 09:53:09', '2022-12-23 09:53:09', NULL, 'admin', 'mknhymh', 'yes'),
(117, 52, 'fgccgfcvvvg', 't4jhtkjtg', 'lsp', 56, '2022-12-23 09:53:10', '2022-12-23 09:53:10', NULL, 'admin', 'mknhymh', 'yes'),
(118, 52, 'fgccgfcvvvg', 't4jhtkjtg', 'lsr', 25, '2022-12-23 10:01:22', '2022-12-23 10:01:22', NULL, 'admin', 'mknhymh', ''),
(119, 52, 'fgccgfcvvvg', 't4jhtkjtg', 'lsr', 25, '2022-12-23 10:01:25', '2022-12-23 10:01:25', NULL, 'admin', 'mknhymh', ''),
(120, 52, 'fgccgfcvvvg', 't4jhtkjtg', 'lsr', 25, '2022-12-23 10:02:56', '2022-12-23 10:02:56', NULL, 'admin', 'mknhymh', ''),
(121, 52, 'fgccgfcvvvg', 't4jhtkjtg', 'lsr', 25, '2022-12-23 10:03:05', '2022-12-23 10:03:05', NULL, 'admin', 'mknhymh', ''),
(122, 52, 'fgccgfcvvvg', 't4jhtkjtg', 'lsr', 25, '2022-12-23 10:05:11', '2022-12-23 10:05:11', NULL, 'admin', 'mknhymh', ''),
(123, 52, 'fgccgfcvvvg', 't4jhtkjtg', 'lsr', 25, '2022-12-23 10:05:21', '2022-12-23 10:05:21', NULL, 'admin', 'mknhymh', ''),
(124, 52, 'fgccgfcvvvg', 't4jhtkjtg', 'lsr', 25, '2022-12-23 10:06:47', '2022-12-23 10:06:47', NULL, 'admin', 'mknhymh', ''),
(125, 52, 'fgccgfcvvvg', 't4jhtkjtg', 'lsr', 25, '2022-12-23 10:06:58', '2022-12-23 10:06:58', NULL, 'admin', 'mknhymh', '');

-- --------------------------------------------------------

--
-- Doublure de structure pour la vue `users`
-- (Voir ci-dessous la vue réelle)
--
DROP VIEW IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
`id` int(11)
,`account` varchar(200)
,`fname` varchar(100)
,`lname` varchar(100)
,`company` varchar(200)
,`phone` varchar(100)
,`email` varchar(100)
,`user_type` varchar(3)
);

-- --------------------------------------------------------

--
-- Structure de la vue `users`
--
DROP TABLE IF EXISTS `users`;

DROP VIEW IF EXISTS `users`;
CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `users`  AS  select `crm_accounts`.`id` AS `id`,`crm_accounts`.`account` AS `account`,`crm_accounts`.`fname` AS `fname`,`crm_accounts`.`lname` AS `lname`,`crm_accounts`.`company` AS `company`,`crm_accounts`.`phone` AS `phone`,`crm_accounts`.`email` AS `email`,'lsp' AS `user_type` from `crm_accounts` union all select `crm_accounts_1`.`id` AS `id`,`crm_accounts_1`.`account` AS `account`,`crm_accounts_1`.`fname` AS `fname`,`crm_accounts_1`.`lname` AS `lname`,`crm_accounts_1`.`company` AS `company`,`crm_accounts_1`.`phone` AS `phone`,`crm_accounts_1`.`email` AS `email`,'lsr' AS `user_type` from `crm_accounts_1` ;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
