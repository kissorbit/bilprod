$(document).ready(function () {
  $("#get_notifications").click(function (e) {
    var _url = $("#_url").val();
    $.post(_url + "util/notifications-ajax/", {}).done(function (data) {
      setTimeout(function () {
        $("#notifications_loaded").html(data);
      }, 2000);
    });
  });

  $("#get_languages").click(function (e) {
    var _url = $("#_url").val();
    $.post(_url + "util/ajax-languages/", {}).done(function (data) {
      setTimeout(function () {
        $("#languages_loaded").html(data);
      }, 2000);
    });
  });
});
