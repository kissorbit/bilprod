<?php
use Illuminate\Database\Eloquent\Model;

class Company4 extends Model
{
    protected $table = 'sys_companies4';
}