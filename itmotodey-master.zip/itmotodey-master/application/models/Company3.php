<?php
use Illuminate\Database\Eloquent\Model;

class Company3 extends Model
{
    protected $table = 'sys_companies3';
}