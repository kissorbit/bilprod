<?php
use Illuminate\Database\Eloquent\Model;

class ContactGroup2 extends Model
{
    protected $table = 'crm_groups2';
    public $timestamps = false;
}