<?php
use Illuminate\Database\Eloquent\Model;

class Trades extends Model
{
    protected $table = 'trades';

}