<?php
use Illuminate\Database\Eloquent\Model;

class Company1 extends Model
{
    protected $table = 'sys_companies1';
}