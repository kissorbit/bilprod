<?php
use Illuminate\Database\Eloquent\Model;

class Company2 extends Model
{
    protected $table = 'sys_companies2';
}