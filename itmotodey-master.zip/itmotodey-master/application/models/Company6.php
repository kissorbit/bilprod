<?php
use Illuminate\Database\Eloquent\Model;

class Company6 extends Model
{
    protected $table = 'sys_companies6';
}