<?php
class Models_Company1 extends Model
{
    public static $_table = 'sys_companies1';
}
