<?php
class Models_Contact extends Model
{
    public static $_table = 'crm_accounts';
}
