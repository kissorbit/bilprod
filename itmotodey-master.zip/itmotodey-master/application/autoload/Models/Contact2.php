<?php
class Models_Contact2 extends Model
{
    public static $_table = 'crm_accounts2';
}
