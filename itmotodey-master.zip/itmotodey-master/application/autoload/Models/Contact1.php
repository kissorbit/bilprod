<?php
class Models_Contact1 extends Model
{
    public static $_table = 'crm_accounts_1';
}
