<?php
class Models_Company3 extends Model
{
    public static $_table = 'sys_companies3';
}
