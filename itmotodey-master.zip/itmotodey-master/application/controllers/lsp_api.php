<?php

$version = route(1);


switch ($version) {
    case 'v2':
    
        if (isset($_GET['_METHOD'])) {
            $method = $_GET['_METHOD'];
        } else {
            $method = $_SERVER['REQUEST_METHOD'];
        }
        

        header('Access-Control-Allow-Origin: *');

        apiAuth();

        $object = route(2);

        switch ($object) {
            case 'auth':
            switch ($method) {
              
               case 'POST':
                           $email = _post('username');
                           $password = _post('password');
                   
                           $remember_me = _post('remember_me');
                   
                           $auth = Contacts::login($email, $password);
                           if($auth){
                                
                            jsonResponse(['tokent'=>$auth,
                           'user'=>ORM::for_table('crm_accounts')
                           ->where('token', $auth)
                           ->find_array(),
                            ]
                       );
                        echo 'login succesful';
                        
                        }
                        else{
                        echo 'error';
                        }
                   break;
           
                   default:
                   jsonResponse([
                       'error' => true,
                       'message' => 'Unknown Method!',
                   ]);

                   break;
           }
            break;
            case 'lsps':
                switch ($method) {
                    case 'GET':
                        jsonResponse(
                            Contact::orderBy('id', 'desc')
                                ->get()
                                ->toArray()
                        );

                        break;

                    case 'POST':
                        break;

                    case 'PUT':
                        break;

                    case 'DELETE':
                        break;

                    default:
                        jsonResponse([
                            'error' => true,
                            'message' => 'Unknown Method!',
                        ]);

                        break;
                }

                break;
                case 'lsp_drivers':
                switch ($method) {
                    case 'GET':
                        jsonResponse(
                            Company3::orderBy('id', 'desc')
                                ->get()
                                ->toArray()
                        );

                        break;

                    case 'POST':
                        break;

                    case 'PUT':
                        break;

                    case 'DELETE':
                        break;

                    default:
                        jsonResponse([
                            'error' => true,
                            'message' => 'Unknown Method!',
                        ]);

                        break;
                }

                case 'Trucks_Registrations':
                switch ($method) {
                    case 'GET':
                        jsonResponse(
                            Company5::orderBy('id', 'desc')
                                ->get()
                                ->toArray()
                        );

                        break;

                    case 'POST':
                        break;

                    case 'PUT':
                        break;

                    case 'DELETE':
                        break;

                    default:
                        jsonResponse([
                            'error' => true,
                            'message' => 'Unknown Method!',
                        ]);

                        break;
                }

                break;

            case 'lsp':
                switch ($method) {
                    case 'GET':
                   
                        $id = route(3);

                        $contact = Contact::find($id)->toArray();

                        if ($contact) {
                           
                            jsonResponse($contact);
                        } else {
                            jsonResponse([
                                'error' => true,
                                'message' => 'Contact not found!',
                            ]);
                        }

                        break;

                    case 'POST':
                        $errors = [];

                        $account = _post('account');

                        $type_customer = _post('customer');
                        $type_supplier = _post('supplier');

                        $type = $type_customer . ',' . $type_supplier;
                        $type = trim($type, ',');

                        if ($type == '') {
                            $type = 'Customer';
                        }

                         $company = _post('company');

                        $company_id = _post('company_id');

                        $company = '';
                        $cid = 0;

                        $email = _post('email');
                        $username = _post('username');
                        $phone = _post('phone');
                        $currency = _post('currency');

                        $address = _post('address');
                        $city = _post('city');
                        $state = _post('state');
                        $zip = _post('zip');
                        $country = _post('country');
                        $trucks = _post('trucks');
                        $fname = _post('fname');
                        $lname = _post('fname');

                        // $owner_id = _post('owner_id');

                        // if ($owner_id == '') {
                        //     $owner_id = 0;
                        // }

                        // if ($company_id != '') {
                        //     if ($company_id != '0') {
                        //         $company_db = db_find_one(
                        //             'sys_companies',
                        //             $company_id
                        //         );

                        //         if ($company_db) {
                        //             $company = $company_db->company_name;
                        //             $cid = $company_id;
                        //         }
                        //     }
                        // } elseif (_post('company') != '') {
                        //     // create compnay
                        //     $company = _post('company');
                        //     $c = new Company();

                        //     $c->company_name = $company;
                        //     $c->email = $email;
                        //     $c->phone = $phone;
                                                                                
                        //     $c->address1 = $address;
                        //     $c->city = $city;
                        //     $c->state = $state;
                        //     $c->zip = $zip;
                        //     $c->country = $country;

                        //     $c->save();

                        //     $cid = $c->id;
                        // }

                        // if ($currency == '') {
                        //     $currency = '0';
                        // }

                        // if (isset($_POST['tags']) and $_POST['tags'] != '') {
                        //     $tags = $_POST['tags'];
                        // } else {
                        //     $tags = '';
                        // }

                        if ($account == '') {
                            $errors[] = $_L['Account Name is required'];
                        }

                        if ($email != '') {
                            if (Validator::Email($email) == false) {
                                $errors[] = $_L['Invalid Email'];
                            }
                            $f = ORM::for_table('crm_accounts')
                                ->where('email', $email)
                                ->find_one();

                            if ($f) {
                                $errors[] = $_L['Email already exist'];
                            }
                        }

                        if ($phone != '') {
                            $f = ORM::for_table('crm_accounts')
                                ->where('phone', $phone)
                                ->find_one();

                            if ($f) {
                                $errors[] = $_L['Phone number already exist'];
                            }
                        }

                        // $gid = _post('group');

                        // if ($gid != '') {
                        //     $g = db_find_one('crm_groups', $gid);
                        //     $gname = $g['gname'];
                        // } else {
                        //     $gid = 0;
                        //     $gname = '';
                        // }

                        $password = _post('password');

                        $u_password = '';

                        if ($password != '') {
                            if (!Validator::Length($password, 15, 5)) {
                                $errors[] =
                                    'Password should be between 6 to 15 characters';
                            }

                            $u_password = $password;
                            $password = Password::_crypt($password);
                            $admin_file_token = '';
                            $trucks_files_token = '';
                            $transport_license_file_token = '';
                    
                            if (array_key_exists('adminfile', $_FILES)) {
                                $uploadResult = uploadFile('adminfile');
                    
                                if (!$uploadResult['success']) {
                                    $msg .= 'Administrative file: ' . $uploadResult['msg'] . '<br>';
                                } else {
                                    $admin_file_token = $uploadResult['token'];
                                }
                            }
                    
                            if (array_key_exists('trucksfiles', $_FILES)) {
                                $uploadResult = uploadFile('trucksfiles');
                    
                                if (!$uploadResult['success']) {
                                    $msg .= 'Trucks files: ' . $uploadResult['msg'] . '<br>';
                                } else {
                                    $trucks_files_token = $uploadResult['token'];
                                }
                            }
                    
                            if (array_key_exists('transport_license', $_FILES)) {
                                $uploadResult = uploadFile('transport_license');
                    
                                if (!$uploadResult['success']) {
                                    $msg .= 'Transport License: ' . $uploadResult['msg'] . '<br>';
                                } else {
                                    $transport_license_file_token = $uploadResult['token'];
                                }
                            }
                        }
                       
                        if (empty($errors)) {
                            // Tags::save($tags, 'Contacts');

                            $data = [];

                            $data['created_at'] = date('Y-m-d H:i:s');
                            $data['updated_at'] = date('Y-m-d H:i:s');

                            //  $type = _post('type');

                            $d = ORM::for_table('crm_accounts')->create();

                            $d->account = $account;
                            $d->email = $email;
                            $d->phone = $phone;
                            $d->address = $address;
                            $d->city = $city;
                            $d->zip = $zip;
                            $d->admin_file_token             = $admin_file_token;
                            $d->trucks_files_token           = $trucks_files_token;
                            $d->transport_license_file_token = $transport_license_file_token;
            
                            $d->state = $state;
                            $d->country = $country;
                           // $d->tags = Arr::arr_to_str($tags);

                            //others
                            $d->trucks = $trucks;
                            $d->fname =  $fname;
                            $d->lname =  $lname;
                            $d->company = $company;
                            // $d->jobtitle = '';
                            $d->cid = $cid;
                            // $d->o = $owner_id;
                            $d->balance = '0.00';
                            $d->status = 'Active';
                            $d->notes = '';
                            $d->password = $password;
                            $d->token = '';
                            $d->tags = '';
                            $d->ts = '';
                            $d->img = '';
                            $d->web = '';
                            $d->facebook = '';
                            $d->google = '';
                            $d->linkedin = '';

                            // v 4.2

                           // $d->gname = $gname;
                           // $d->gid = $gid;

                            // build 4550

                         //   $d->currency = $currency;

                            //

                            $d->created_at = $data['created_at'];

                            //$d->type = $type;

                            //

                            // $d->business_number = _post('business_number');

                            // $d->fax = _post('fax');

                            //

                            //

                            // $drive = time() . Ib_Str::random_string(12);

                            // $d->drive = $drive;

                            //
                            try {
                                $d->save();
                                jsonResponse([
                                    'error' => false,
                                    'contact_id' => $cid,
                                    'message' =>
                                        $_L['account_created_successfully'],
                                ]);
                            } catch (Exception $error) {
                            
                                jsonResponse($error);
                                exit();
                            
                            }
                            $cid = $d->id();
                           
                            _log(
                                $_L['New Contact Added'] .
                                    ' ' .
                                    $account .
                                    ' [CID: ' .
                                    $cid .
                                    ']',
                                'Admin',
                                $owner_id
                            );

                            Event::trigger('contacts/add-post/_on_finished');

                            // send welcome email if needed

                            $send_client_signup_email = _post(
                                'send_client_signup_email'
                            );

                            if (
                                $email != '' &&
                                $send_client_signup_email == 'Yes' &&
                                $u_password != ''
                            ) {
                                $email_data = [];
                                $email_data['account'] = $account;
                                $email_data['company'] = $company;
                                $email_data['password'] = $u_password;
                                $email_data['email'] = $email;

                                $send_email = Ib_Email::send_client_welcome_email(
                                    $email_data
                                );
                            }

                            // Create Drive if this feature is enabled

                            if ($config['client_drive'] == '1') {
                                if (
                                    !file_exists(
                                        'storage/drive/customers/' .
                                            $drive .
                                            '/storage'
                                    )
                                ) {
                                    mkdir(
                                        'storage/drive/customers/' .
                                            $drive .
                                            '/storage',
                                        0777,
                                        true
                                    );
                                }
                            }

                            //

                            jsonResponse([
                                'error' => false,
                                'contact_id' => $cid,
                                'message' =>
                                    $_L['account_created_successfully'],
                            ]);
                        } else {
                            jsonResponse([
                                'error' => true,
                                'message' => $errors,
                            ]);
                        }

                        break;

                    case 'PUT':
                   
                    
                        break;

                    case 'DELETE':
                     $id = route(3);
                         $lsp = Model::factory('Models_Contact');

                          $c = $lsp->find_one($id);

                                if ($c) {
                                    $c->delete();
                                    if($c){
                                        echo 'Account deleted successfully';
                                    }

                                  //  r2(U . 'contacts1', 's', $_L['Deleted Successzfully']); 
                                }
                        break;

                    default:
                        jsonResponse([
                            'error' => true,
                            'message' => 'Unknown Method!',
                        ]);

                        break;
                }

                break;
            
                case 'lsp_driver':
                switch ($method) {
                    case 'GET':
                   
                        $id = route(3);

                        $contact = Company3  ::find($id)->toArray();

                        if ($contact) {
                          
                            jsonResponse($contact);
                        } else {
                            jsonResponse([
                                'error' => true,
                                'message' => 'Contact not found!',
                            ]);
                        }

                        break;

                    case 'POST':
                    $errors = [];

                    $name = _post('name');

                    $permit_number = _post('permit_number');
                    $lsp_id = _post('lsp_id');

                  

                     $truck_id = _post('truck_id');

                    $expiry_date = _post('expiry_date');

                    $logo_url = _post('logo_url');
                    $logo_path = _post('logo_path');
                    $phone = _post('phone');
                    $description = _post('description');

                    $suspend = _post('suspend');
                    $comment = _post('comment');
                    $permit_category = _post('permit_category');
                    $picture_permit_file_token = '';

        if (array_key_exists('picture_permit', $_FILES) && !empty($_FILES['picture_permit'])) {
            $uploadResult = uploadFile('picture_permit');

            if (!$uploadResult['success']) {
                $msg .= $_L['picture of permit'] . ': ' . $uploadResult['msg'] . '<br>';
            } else {
                $picture_permit_file_token = $uploadResult['token'];
            }
        }

                    if ($phone != '') {
                        $f = ORM::for_table('crm_accounts2')
                            ->where('phone', $phone)
                            ->find_one();

                        if ($f) {
                            $errors[] = $_L['Phone number already exist'];
                        }
                    }
                    if ($name== '') {
                        i_close($_L['the driver name is required']);
                    }
                    if ($permit_number == '') {
                        i_close($_L['permit number is required']);
                    }
                    if ($phone == '') {
                        i_close($_L['phone number is required']);
                    }
                  
                   
                    if (empty($errors)) {
                        // Tags::save($tags, 'Contacts');

                        $data = [];

                        $data['created_at'] = date('Y-m-d H:i:s');
                        $data['updated_at'] = date('Y-m-d H:i:s');

                        //  $type = _post('type');

                        $company3 = ORM::for_table('sys_companies3')->create();
                        $company3->name = $name;
                        $company3->permit_number = $permit_number;
                        $company3->lsp_id = $lsp_id;
                        $company3->expiry_date = $expiry_date;
                        $company3->picture_permit_file_token  = $picture_permit_file_token;
                        $company3->permit_category = $permit_category;
                        $company3->truck_id = $truck_id;
                        $company3->phone = $phone;
                        $company3->logo_url = $logo_url;
                        $company3->logo_path = $logo_path;
                        $company3->description = $description;
                        $company3->suspend = $suspend;
                        $company3->comment = $comment;
                

                        $d->created_at = $data['created_at'];
                        $d->updated_at = $data['updated_at'];

                      
                        try {
                            $company3->save();
                            echo $company3->id();
                            jsonResponse([
                                'error' => false,
                                'contact_id' => $cid,
                                'message' =>
                                    $_L['account_created_successfully'],
                            ]);
                        } catch (Exception $error) {
                        
                            jsonResponse($error);
                            exit();
                        
                        }
                        $cid = $d->id();
                       
                        _log(
                            $_L['New Contact Added'] .
                                ' ' .
                                $account .
                                ' [CID: ' .
                                $cid .
                                ']',
                            'Admin',
                            $owner_id
                        );

                       
                        jsonResponse([
                            'error' => false,
                            'contact_id' => $cid,
                            'message' =>
                                $_L['account_created_successfully'],
                        ]);
                    } else {
                        jsonResponse([
                            'error' => true,
                            'message' => $errors,
                        ]);
                    }

                        break;

                    case 'PUT':
                  
                        break;

                    case 'DELETE':
                    $id = route(3);
                         $lsr = Model::factory('Models_Company3');

                          $c = $lsr->find_one($id);

                                if ($c) {
                                    $c->delete();
                                    if($c){
                                        echo 'Delete successful';
                                    }

                                  //  r2(U . 'contacts1', 's', $_L['Deleted Successzfully']); 
                                }
                        break;

                    default:
                        jsonResponse([
                            'error' => true,
                            'message' => 'Unknown Method!',
                        ]);

                        break;
                }

               

                case 'Trucks_Registration':
                switch ($method) {
                    case 'GET':
                   
                        $id = route(3);

                        $contact = Company5::find($id)->toArray();

                        if ($contact) {
                          
                            jsonResponse($contact);
                        } else {
                            jsonResponse([
                                'error' => true,
                                'message' => 'Contact not found!',
                            ]);
                        }

                        break;

                    case 'POST':
                    $errors = [];

                    $company_name = _post('company_name');

                    $url = _post('url');
                    $phone = _post('phone');

                    
                     $lsp_id = _post('lsp_id');

                    $emails = _post('emails');



                    $tags = _post('tags');
                    $logo_url = _post('logo_url');
                    $date_of_entry = _post('date_of_entry');
                    $chassis_number = _post('chassis_number');

                    $truck_immatriculation = _post('truck_immatriculation');
                    $type_of_truck = _post('type_of_truck');
                    $insurance_start_date = _post('insurance_start_date');
                    $truck_availability = _post('truck_availability');
                    $insurance_expiration_date = _post('insurance_expiration_date');
                    $Road_Worthiness = _post('Road_Worthiness');
                    $notes = _post('notes');
                    $description = _post('description');
                    $address2 = _post('address2');
                    $address1 = _post('address1');
                   

                  
                    if ($truck_immatriculation == '') {
                        i_close($_L['truck immatriculation  is required']);
                    }
                    $truck_picture_file_token = '';

                    if (array_key_exists('truck_picture', $_FILES) && !empty($_FILES['truck_picture'])) {
                        $uploadResult = uploadFile('truck_picture');
            
                        if (!$uploadResult['success']) {
                            $msg .= 'Truck picture: ' . $uploadResult['msg'] . '<br>';
                        } else {
                            $truck_picture_file_token = $uploadResult['token'];
                        }
                    }
            
                    $truck_insurance_file_token = '';
            
                    if (array_key_exists('truck_insurance', $_FILES) && !empty($_FILES['truck_insurance'])) {
                        $uploadResult = uploadFile('truck_insurance');
            
                        if (!$uploadResult['success']) {
                            $msg .= 'Truck insurance: ' . $uploadResult['msg'] . '<br>';
                        } else {
                            $truck_insurance_file_token = $uploadResult['token'];
                        }
                    }
            
            
                    $truck_patent_file_token = '';
            
                    if (array_key_exists('truck_patent', $_FILES) && !empty($_FILES['truck_patent'])) {
                        $uploadResult = uploadFile('truck_patent');
            
                        if (!$uploadResult['success']) {
                            $msg .= 'Truck patent: ' . $uploadResult['msg'] . '<br>';
                        } else {
                            $truck_patent_file_token = $uploadResult['token'];
                        }
                    }
                    $truck_registration_document_file_token = '';
            
                    if (array_key_exists('truck_registration_document', $_FILES) && !empty($_FILES['truck_registration_document'])) {
                        $uploadResult = uploadFile('truck_registration_document');
            
                        if (!$uploadResult['success']) {
                            $msg .= 'Truck registration document: ' . $uploadResult['msg'] . '<br>';
                        } else {
                            $truck_registration_document_file_token = $uploadResult['token'];
                        }
                    }
                   
                   
                    if (empty($errors)) {
                        // Tags::save($tags, 'Contacts');

                        $data = [];

                        $data['created_at'] = date('Y-m-d H:i:s');
                        $data['updated_at'] = date('Y-m-d H:i:s');

                        //  $type = _post('type');

                        $company5 = ORM::for_table('sys_companies5')->create();

                        $company5->company_name = $company_name;
                        $company5->url = $url;
                        // $company5->email = $data['email'];
                        //$company5->phone = $data['phone'];
                        
                        $company5->lsp_id = $lsp_id;
                        $company5->emails = $emails;
                        $company5->tags = $tags;
                        $company5->phone = $phone;
                        $company5->logo_url = $logo_url;
                        $company5->date_of_entry = $date_of_entry;
                        $company5->chassis_number = $chassis_number;
                        $company5->truck_immatriculation = $truck_immatriculation;
                        $company5->type_of_truck = $type_of_truck;
                        $company5->insurance_start_date = $insurance_start_date;
                        $company5->truck_availability = $truck_availability;
                        $company5->insurance_expiration_date = $insurance_expiration_date;
                        $company5->Road_Worthiness = $Road_Worthines;

                        $company5->notes = $notes;
                        $company5->description = $description;
                        $company5->address2 = $address2;
                        $company5->address1 = $address1;
                    
                        $company5->truck_picture_file_token               = $truck_picture_file_token;

                        $company5->truck_insurance_file_token             = $truck_insurance_file_token;
                        $company5->truck_patent_file_token                = $truck_patent_file_token;
                        $company5->truck_registration_document_file_token = $truck_registration_document_file_token;
       

                     

                        $d->created_at = $data['created_at'];

                      
                        try {
                            $company5->save();
                            echo $company5->id();
                            jsonResponse([
                                'error' => false,
                                'contact_id' => $cid,
                                'message' =>
                                    $_L['account_created_successfully'],
                            ]);
                        } catch (Exception $error) {
                        
                            jsonResponse($error);
                            exit();
                        
                        }
                        $cid = $d->id();
                       
                        _log(
                            $_L['New Contact Added'] .
                                ' ' .
                                $account .
                                ' [CID: ' .
                                $cid .
                                ']',
                            'Admin',
                            $owner_id
                        );

                      
                        //

                        jsonResponse([
                            'error' => false,
                            'contact_id' => $cid,
                            'message' =>
                                $_L['account_created_successfully'],
                        ]);
                    } else {
                        jsonResponse([
                            'error' => true,
                            'message' => $errors,
                        ]);
                    }

                        break;

                        case 'PUT':
                        $id = route(3);

                        $Company5 = Company5::find($id);
                       
                        if ($Company5) {
                            parse_str(
                                file_get_contents("php://input"),
                                $params
                            );

                            // if (isset($params['status'])) {
                            //    // $lsp_id = _post('lsp_id');
                            //     $Company5->status = $params['status'];
                            //     // $Company5->lsp_id = $lsp_id;
                            // }
                            
                                $lsp_id = _post('lsp_id');
                                $truck_immatriculation = _post('truck_immatriculation');
                                $Company5->lsp_id = $lsp_id;
                               
                               $Company5->truck_immatriculation = $truck_immatriculation;
                               var_dump($truck_immatriculation);
                            
                          
                            $Company5->save();

                            jsonResponse([
                                'truck_id' => $Company5,
                                'message' => 'truck updated!',
                            ]);
                        } else {
                            jsonResponse([
                                'error' => true,
                                'message' => 'Invoice not found!',
                            ]);
                        }
                        break;

                        case 'DELETE':
                        $id = route(3);
                             $lsr = Model::factory('Models_Company5');
    
                              $c = $lsr->find_one($id);
    
                                    if ($c) {
                                        $c->delete();
                                        if($c){
                                            echo 'Delete successful';
                                        }
    
                                      //  r2(U . 'contacts1', 's', $_L['Deleted Successzfully']); 
                                    }
                            break;


                    default:
                        jsonResponse([
                            'error' => true,
                            'message' => 'Unknown Method!',
                        ]);

                        break;
                }

                break;

                
            
            case 'lsp-trade':
            $action = route(3);
            switch($action){
             case 'auth-lsp':
                switch ($method) {
                    case 'GET':
                    $user = Contacts::details();
                    echo json_encode([
                        "id"      => $user->id,
                        "account" => $user->account,
                        "email"   => $user->email
                    ]);

                     break;

                    case 'POST':
                        break;

                    case 'PUT':
                        break;

                    case 'DELETE':
                        break;

                    default:
                        jsonResponse([
                            'error' => true,
                            'message' => 'Unknown Method!',
                        ]);

                        break;
                }
                case 'current-trade':
                switch ($method) {
                    case 'GET':
                    $tradeId = _get('tradeId');
                    $itemTable = _get('itemTable');
                    $trade = ORM::for_table($itemTable)->find_one($tradeId);
            
                    echo json_encode([
                        "id"           => $trade->id,
                        "company_name" => $trade->company_name,
                        "status"       => $trade->status,
                    ]);
                        break;

                    case 'POST':
                        break;

                    case 'PUT':
                        break;

                    case 'DELETE':
                        break;

                    default:
                        jsonResponse([
                            'error' => true,
                            'message' => 'Unknown Method!',
                        ]);

                        break;
                }
              
                break;
            

             
                case 'lsp-trade-conversation':
                switch ($method) {
                    case 'GET':
                    $user = Contacts::details();
                    $tradeId = _get("ID");
                    $tradeConversation = ORM::for_table("trade_conversations")
                        ->where([
                            "trade_id"       => $tradeId,
                            "recipient_type" => "lsr",
                            "recipient_id" => $user->id,
                        ])->find_array();

                    header('Content-Type: application/json; charset=utf-8');
                    echo json_encode($tradeConversation);
                        break;

                    case 'POST':
                        break;

                    case 'PUT':
                        break;

                    case 'DELETE':
                        break;

                    default:
                        jsonResponse([
                            'error' => true,
                            'message' => 'Unknown Method!',
                        ]);

                        break;
                }
              
                break;
               
                case 'trade-lsp-messages':
                switch ($method) {
                    case 'GET':
                    $conversationId = _get("ID");
                    $messages = ORM::for_table('conversation_message')
                        ->table_alias('c')
                        ->select('c.*')
                        ->select('doc.id', 'file_id')
                        ->select('doc.title', 'file_name')
                        ->select('doc.file_mime_type', 'file_ext')
                        ->select('doc.file_dl_token', 'file_dl_token')
                        ->select('doc.file_path', 'file_path')
                        ->left_outer_join("sys_documents", ['c.file_token', '=', 'doc.file_dl_token'], 'doc')
                        ->where([
                            'c.trade_conversation_id' => $conversationId
                        ])
                        ->order_by_asc('c.created_at')
                        ->find_array();

                    jsonResponse($messages);
                        break;

                    case 'POST':
                    $user = Contacts::details();
                        $conversationId = _post('tradeConversationId');
                        $userId         = $user->id;
                        $content        = _post('content');
                        $recipientId    = _post('recipientId');
                        $file = $_FILES['file'];

                        $file_token = '';
                        if (array_key_exists('file', $_FILES) && !empty($_FILES['file'])) {
                            $uploadResult        = uploadFile('file');
                            $file_token          = $uploadResult['token'];
                        }
                        /** Saving message */
                        $message = ORM::for_table('conversation_message')->create();

                        $message->trade_conversation_id = $conversationId;
                        $message->sender_id             = $userId;
                        $message->sender_table          = 'crm_accounts';
                        $message->recipient_id          = $recipientId;
                        $message->recipient_table       = 'sys_users';
                        $message->content               = $content;
                        $message->file_token            = $file_token;

                        $message->save();

                        $conversation = ORM::for_table('trade_conversations')->find_one($conversationId);

                        // notifications
                        $event = ORM::for_table('events')->create();
                        $event->type = $user->account;
                        $event->text = mb_strimwidth($content, 0, 20, "...");

                        // making the link to the conversation
                        $event->link = "trades/list/";
                        $trade = ORM::for_table('trades')->find_one($conversation->trade_id);
                        switch ($trade->item_table) {
                            case 'sys_companies':
                                $event->link .= "purchase-construction-material/show/";
                                break;
                            case 'sys_companies4':
                                $event->link .= "purchase-packaging-material/show/";
                                break;
                            case 'sys_companies1':
                                $event->link .= "rental-of-agricultural-equipment/show/";
                                break;
                            case 'sys_companies2':
                                $event->link .= "rental-heavy-machine/show/";
                                break;
                            case 'sys_companies6':
                                $event->link .= "submit-lsr/show/";
                                break;

                            default:
                                # code...
                                break;
                        }

                        // remove extra '0' at the beginning
                        $trdId = ltrim($trade->item_id, '0');

                        $event->link .= $trdId;
                        $event->save();

                        $notif                             = ORM::for_table('notifications')->create();
                        $notif->user_to_notify             = $recipientId;
                        $notif->user_to_notify_table       = 'sys_users';
                        $notif->user_who_fired_event       = $userId;
                        $notif->user_who_fired_event_table = "crm_accounts_1";
                        $notif->event_id                   = $event->id();
                        $notif->save();

                        header('Content-Type: application/json; charset=utf-8');
                        echo "ok";
                        break;

                    case 'PUT':
                        break;

                    case 'DELETE':
                        break;

                    default:
                        jsonResponse([
                            'error' => true,
                            'message' => 'Unknown Method!',
                        ]);

                        break;
                }
              
                break;
                case 'list':
                $action2 = route(4);
                $user = Contacts::details();
                switch($action2){
                 case '':
                 switch ($method) {
                     case 'GET': 
                     $lspTrades = ORM::for_table('trade_conversations')
                     ->table_alias('conv')
                     ->select('conv.*')
                     ->select('trd.*')
                     ->left_outer_join('trades', ['conv.trade_id', '=', 'trd.id'], 'trd')
                     ->where([
                         'recipient_type' => 'lsp',
                         'recipient_id' => $user->id,
                     ])
                     ->find_array();
                     
                     $submitLsr = array_filter($lspTrades, function ($trade) {
                        return $trade['item_table'] == 'sys_companies6';
                    });
                    $rentalAgricultalEquipments = array_filter($lspTrades, function ($trade) {
                        return $trade['item_table'] == 'sys_companies1';
                    });
                    $rentalHeavyMachine = array_filter($lspTrades, function ($trade) {
                        return $trade['item_table'] == 'sys_companies2';
                    });
                    $purchaseMaterialConstruction = array_filter($lspTrades, function ($trade) {
                        return $trade['item_table'] == 'sys_companies';
                    });
                    $purchasePackagingMaterial = array_filter($lspTrades, function ($trade) {
                        return $trade['item_table'] == 'sys_companies4';
                    });
 
                         jsonResponse([
                             'Submited Transport Request' =>   count($submitLsr),
                             'Submited Rental of Agricultural Equipment' => count($rentalAgricultalEquipments),
                             'Submited Rental Heavy Machine' =>  count($rentalHeavyMachine),
                             'Submited Purchase construction material' =>  count($purchaseMaterialConstruction),
                             'Submited Purchase packaging material' =>  count($purchasePackagingMaterial),
                            
 
                                
                         ]);
 
                         break;
 
                     case 'POST':
                         break;
 
                     case 'PUT':
                         break;
 
                     case 'DELETE':
                         break;
 
                     default:
                         jsonResponse([
                             'error' => true,
                             'message' => 'Unknown Method!',
                         ]);
 
                         break;
                 }
                 break;
                 case 'submit-lsr':
                 switch ($method) {
                                    case 'GET':
                                    
                        $lspTrades = ORM::for_table('trade_conversations')
                          ->table_alias('conv')
                          ->select('conv.*')
                          ->select('trd.*')
                          ->left_outer_join('trades', ['conv.trade_id', '=', 'trd.id'], 'trd')
                          ->where([
                              'recipient_type' => 'lsp',
                              'recipient_id' => $user->id,
                          ])
                          ->find_array();
                          
                          $submitLsrConv = array_filter($lspTrades, function ($trade) {
                            return $trade['item_table'] == 'sys_companies6';
                        });
                        

                        $trdIds = [];
                        foreach ($submitLsrConv as $trd) {
                            $trdIds[] = $trd['item_id'];
                        }

                        $trades = ORM::for_table('sys_companies6')
                            ->table_alias('c')
                            ->select('c.*')
                            ->select_expr('(SELECT account FROM crm_accounts_1 WHERE  id = c.lsr_id)', 'comp')
                            ->where_id_in($trdIds)
                            ->order_by_desc('c.id')
                            ->find_array();
                                      
                                     
                         jsonResponse($trades );
 
                         break;
 
                     case 'POST':
                         break;
 
                     case 'PUT':
                         break;
 
                     case 'DELETE':
                         break;
 
                     default:
                         jsonResponse([
                             'error' => true,
                             'message' => 'Unknown Method!',
                         ]);
 
                         break;
                 }
                 case 'rental-of-agricultural-equipment':
                 switch ($method) {
                     case 'GET': 
                    
                     $lspTrades = ORM::for_table('trade_conversations')
                            ->table_alias('conv')
                            ->select('conv.*')
                            ->select('trd.*')
                            ->left_outer_join('trades', ['conv.trade_id', '=', 'trd.id'], 'trd')
                            ->where([
                                'recipient_type' => 'lsp',
                                'recipient_id' => $user->id,
                            ])
                            ->find_array();

                        $submitLsrConv = array_filter($lspTrades, function ($trade) {
                            return $trade['item_table'] == 'sys_companies1';
                        });

                        $trdIds = [];
                        foreach ($submitLsrConv as $trd) {
                            $trdIds[] = $trd['item_id'];
                        }
                        $trades = [];

                        $trades = ORM::for_table('sys_companies1')
                            ->table_alias('c')
                            ->select('c.*')
                            ->select_expr('(SELECT account FROM crm_accounts_1 WHERE  id = c.lsr_id)', 'comp')
                            ->where_id_in($trdIds)
                            ->order_by_desc('c.id')
                            ->find_array();
                         jsonResponse($trades);
 
                         break;
 
                     case 'POST':
                         break;
 
                     case 'PUT':
                         break;
 
                     case 'DELETE':
                         break;
 
                     default:
                         jsonResponse([
                             'error' => true,
                             'message' => 'Unknown Method!',
                         ]);
 
                         break;
                 }
                 case 'rental-heavy-machine':
                 switch ($method) {
                         case 'GET':
 
                                     $lspTrades = ORM::for_table('trade_conversations')
                                     ->table_alias('conv')
                                     ->select('conv.*')
                                     ->select('trd.*')
                                     ->left_outer_join('trades', ['conv.trade_id', '=', 'trd.id'], 'trd')
                                     ->where([
                                         'recipient_type' => 'lsp',
                                         'recipient_id' => $user->id,
                                     ])
                                     ->find_array();
         
                                 $submitLsrConv = array_filter($lspTrades, function ($trade) {
                                     return $trade['item_table'] == 'sys_companies2';
                                 });
         
                                 $trdIds = [];
                                 foreach ($submitLsrConv as $trd) {
                                     $trdIds[] = $trd['item_id'];
                                 }
                                 $trades = [];
         
                                 $trades = ORM::for_table('sys_companies2')
                                     ->table_alias('c')
                                     ->select('c.*')
                                     ->select_expr('(SELECT account FROM crm_accounts_1 WHERE  id = c.lsr_id)', 'comp')
                                     ->where_id_in($trdIds)
                                     ->order_by_desc('c.id')
                                     ->find_array();
         
                         jsonResponse($trades );
 
                         break;
 
                     case 'POST':
                         break;
 
                     case 'PUT':
                         break;
 
                     case 'DELETE':
                         break;
 
                     default:
                         jsonResponse([
                             'error' => true,
                             'message' => 'Unknown Method!',
                         ]);
 
                         break;
                 }
                 case 'purchase-construction-material':
                 switch ($method) {
                                     case 'GET':
                                     $lspTrades = ORM::for_table('trade_conversations')
                                     ->table_alias('conv')
                                     ->select('conv.*')
                                     ->select('trd.*')
                                     ->left_outer_join('trades', ['conv.trade_id', '=', 'trd.id'], 'trd')
                                     ->where([
                                         'recipient_type' => 'lsp',
                                         'recipient_id' => $user->id,
                                     ])
                                     ->find_array();
         
                                 $submitLsrConv = array_filter($lspTrades, function ($trade) {
                                     return $trade['item_table'] == 'sys_companies';
                                 });
         
                                 $trdIds = [];
                                 foreach ($submitLsrConv as $trd) {
                                     $trdIds[] = $trd['item_id'];
                                 }
                                 $trades = [];
         
                                 $trades = ORM::for_table('sys_companies')
                                     ->table_alias('c')
                                     ->select('c.*')
                                     ->select_expr('(SELECT account FROM crm_accounts_1 WHERE  id = c.lsr_id)', 'comp')
                                     ->where_id_in($trdIds)
                                     ->order_by_desc('c.id')
                                     ->find_array();
 
                         jsonResponse($trades );
 
                         break;
 
                     case 'POST':
                         break;
 
                     case 'PUT':
                         break;
 
                     case 'DELETE':
                         break;
 
                     default:
                         jsonResponse([
                             'error' => true,
                             'message' => 'Unknown Method!',
                         ]);
 
                         break;
                 }
                 case 'purchase-packaging-material':
                 switch ($method) {
                     case 'GET': 
                    
                     $lspTrades = ORM::for_table('trade_conversations')
                     ->table_alias('conv')
                     ->select('conv.*')
                     ->select('trd.*')
                     ->left_outer_join('trades', ['conv.trade_id', '=', 'trd.id'], 'trd')
                     ->where([
                         'recipient_type' => 'lsp',
                         'recipient_id' => $user->id,
                     ])
                     ->find_array();

                 $submitLsrConv = array_filter($lspTrades, function ($trade) {
                     return $trade['item_table'] == 'sys_companies4';
                 });

                 $trdIds = [];
                 foreach ($submitLsrConv as $trd) {
                     $trdIds[] = $trd['item_id'];
                 }
                 $trades = [];

                 $trades = ORM::for_table('sys_companies4')
                     ->table_alias('c')
                     ->select('c.*')
                     ->select_expr('(SELECT account FROM crm_accounts_1 WHERE  id = c.lsr_id)', 'comp')
                     ->where_id_in($trdIds)
                     ->order_by_desc('c.id')
                     ->find_array();

                         jsonResponse($trades );
 
                         break;
 
                     case 'POST':
                         break;
 
                     case 'PUT':
                         break;
 
                     case 'DELETE':
                         break;
 
                     default:
                         jsonResponse([
                             'error' => true,
                             'message' => 'Unknown Method!',
                         ]);
 
                         break;
                 }
 
                 default:
                 # code...
                 break;
                }
                break;
                case 'submit-lsr':
                switch ($method) {
                 case 'GET': 
                 $tradeId = route(3);
                 $hasConversations = false;
                 
                 $trade = ORM::for_table('sys_companies6')
                     ->table_alias('c')
                     ->select('c.*')
                     ->select_expr('(SELECT account FROM crm_accounts_1 WHERE  id = c.lsr_id)', 'comp')
                     ->select_expr('(SELECT email FROM crm_accounts_1 WHERE  id = c.lsr_id)', 'lsr_email')
                     ->where('id', $tradeId)
                     ->find_array();
 
                 // the 'trades table' content
                 $tradeContent = ORM::for_table('trades')->where(array(
                     'item_id' => $tradeId,
                     'item_table' => 'sys_companies6',
                 ))->find_array();
                 if ($tradeContent) {
                     $hasConversations = true;
                 }
                 
                
 
                     jsonResponse([
                          $tradeContent,
                         'trade' =>  Company6::orderBy('id', 'desc') ->find($tradeId),
                         'hasConversations' =>  $hasConversations,
                         
                         
 
                            
                     ]);
 
                     break;
 
                 case 'POST':
                     break;
 
                 case 'PUT':
                     break;
 
                 case 'DELETE':
                     break;
 
                 default:
                     jsonResponse([
                         'error' => true,
                         'message' => 'Unknown Method!',
                     ]);
 
                     break;
             }
                break;
                case 'rental-of-agricultural-equipment':
                switch ($method) {
                 case 'GET': 
                 $tradeId = route(3);
                 $hasConversations = false;
                 
                 $trade = ORM::for_table('sys_companies1')
                     ->table_alias('c')
                     ->select('c.*')
                     ->select_expr('(SELECT account FROM crm_accounts_1 WHERE  id = c.lsr_id)', 'comp')
                     ->select_expr('(SELECT email FROM crm_accounts_1 WHERE  id = c.lsr_id)', 'lsr_email')
                     ->where('id', $tradeId)
                     ->find_array();
 
                 // the 'trades table' content
                 $tradeContent = ORM::for_table('trades')->where(array(
                     'item_id' => $tradeId,
                     'item_table' => 'sys_companies1',
                 ))->find_array();
                 if ($tradeContent) {
                     $hasConversations = true;
                 }
                 
                
 
                     jsonResponse([
                          $tradeContent,
                         'trade' =>  Company1::orderBy('id', 'desc') ->find($tradeId),
                         'hasConversations' =>  $hasConversations,
                         
                        
 
                            
                     ]);
 
                     break;
 
                 case 'POST':
                     break;
 
                 case 'PUT':
                     break;
 
                 case 'DELETE':
                     break;
 
                 default:
                     jsonResponse([
                         'error' => true,
                         'message' => 'Unknown Method!',
                     ]);
 
                     break;
             }
                break;
                case 'rental-heavy-machine':
                switch ($method) {
                 case 'GET': 
                 $tradeId = route(3);
                 $hasConversations = false;
                 
                 $trade = ORM::for_table('sys_companies2')
                     ->table_alias('c')
                     ->select('c.*')
                     ->select_expr('(SELECT account FROM crm_accounts_1 WHERE  id = c.lsr_id)', 'comp')
                     ->select_expr('(SELECT email FROM crm_accounts_1 WHERE  id = c.lsr_id)', 'lsr_email')
                     ->where('id', $tradeId)
                     ->find_array();
 
                 // the 'trades table' content
                 $tradeContent = ORM::for_table('trades')->where(array(
                     'item_id' => $tradeId,
                     'item_table' => 'sys_companies2',
                 ))->find_array();
                 if ($tradeContent) {
                     $hasConversations = true;
                 }
                 
               
 
                     jsonResponse([
                          $tradeContent,
                         'trade' =>  Company2::orderBy('id', 'desc') ->find($tradeId),
                         'hasConversations' =>  $hasConversations,
                         
                      
 
                            
                     ]);
 
                     break;
 
                 case 'POST':
                     break;
 
                 case 'PUT':
                     break;
 
                 case 'DELETE':
                     break;
 
                 default:
                     jsonResponse([
                         'error' => true,
                         'message' => 'Unknown Method!',
                     ]);
 
                     break;
             }
                break;
                case 'purchase-construction-material':
                switch ($method) {
                 case 'GET': 
                 $tradeId = route(3);
                 $hasConversations = false;
                 
                 $trade = ORM::for_table('sys_companies')
                     ->table_alias('c')
                     ->select('c.*')
                     ->select_expr('(SELECT account FROM crm_accounts_1 WHERE  id = c.lsr_id)', 'comp')
                     ->select_expr('(SELECT email FROM crm_accounts_1 WHERE  id = c.lsr_id)', 'lsr_email')
                     ->where('id', $tradeId)
                     ->find_array();
 
                 // the 'trades table' content
                 $tradeContent = ORM::for_table('trades')->where(array(
                     'item_id' => $tradeId,
                     'item_table' => 'sys_companies',
                 ))->find_array();
                 if ($tradeContent) {
                     $hasConversations = true;
                 }
 
                     jsonResponse([
                          $tradeContent,
                         'trade' =>  Company::orderBy('id', 'desc') ->find($tradeId),
                         'hasConversations' =>  $hasConversations,
                         
                         'lsps' =>$lsps 
 
                            
                     ]);
 
                     break;
 
                 case 'POST':
                     break;
 
                 case 'PUT':
                     break;
 
                 case 'DELETE':
                     break;
 
                 default:
                     jsonResponse([
                         'error' => true,
                         'message' => 'Unknown Method!',
                     ]);
 
                     break;
             }
                break;
                case 'purchase-packaging-material':
                switch ($method) {
                 case 'GET': 
                 $tradeId = route(3);
                 $hasConversations = false;
                 
                 $trade = ORM::for_table('sys_companies4')
                     ->table_alias('c')
                     ->select('c.*')
                     ->select_expr('(SELECT account FROM crm_accounts_1 WHERE  id = c.lsr_id)', 'comp')
                     ->select_expr('(SELECT email FROM crm_accounts_1 WHERE  id = c.lsr_id)', 'lsr_email')
                     ->where('id', $tradeId)
                     ->find_array();
 
                 // the 'trades table' content
                 $tradeContent = ORM::for_table('trades')->where(array(
                     'item_id' => $tradeId,
                     'item_table' => 'sys_companies4',
                 ))->find_array();
                 if ($tradeContent) {
                     $hasConversations = true;
                 }
                 
              
 
                     jsonResponse([
                          $tradeContent,
                         'trade' =>  Company4::orderBy('id', 'desc') ->find($tradeId),
                         'hasConversations' =>  $hasConversations,
                         
                       
 
                            
                     ]);
 
                     break;
 
                 case 'POST':
                     break;
 
                 case 'PUT':
                     break;
 
                 case 'DELETE':
                     break;
 
                 default:
                     jsonResponse([
                         'error' => true,
                         'message' => 'Unknown Method!',
                     ]);
 
                     break;
             }
                break;
               
                default:
                # code...
                break;

             }
            

          

         

            default:
                jsonResponse([
                    'error' => true,
                    'message' => 'Unknown resources requested!',
                ]);

                break;
        }

        break;

    default:
        jsonResponse([
            'error' => true,
            'message' => 'Unknown API version!',
        ]);

        break;
}
