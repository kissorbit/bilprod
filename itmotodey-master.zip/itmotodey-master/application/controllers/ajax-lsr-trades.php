<?php
$action = $routes['1'];
Event::trigger('ajax-lsp-trades');

switch ($action) {

    case 'auth-lsr':
        $user = Contacts1::details();
        echo json_encode([
            "id"      => $user->id,
            "account" => $user->account,
            "email"   => $user->email
        ]);
        break;
    case 'current-trade':
        $tradeId = _get('tradeId');
        $itemTable = _get('itemTable');
        $trade = ORM::for_table($itemTable)->find_one($tradeId);

        echo json_encode([
            "id"           => $trade->id,
            "company_name" => $trade->company_name,
            "status"       => $trade->status,
        ]);
        break;
    case 'trade-lsr-conversation':
        $user = Contacts1::details();
        $tradeId = _get("ID");
        $tradeConversation = ORM::for_table("trade_conversations")
            ->where([
                "trade_id"       => $tradeId,
                "recipient_type" => "lsr",
                "recipient_id" => $user->id,
            ])->find_array();

        header('Content-Type: application/json; charset=utf-8');
        echo json_encode($tradeConversation);

        break;
    case 'trade-lsr-messages':
        $conversationId = _get("ID");
        $messages = ORM::for_table('conversation_message')
            ->table_alias('c')
            ->select('c.*')
            ->select('doc.id', 'file_id')
            ->select('doc.title', 'file_name')
            ->select('doc.file_mime_type', 'file_ext')
            ->select('doc.file_dl_token', 'file_dl_token')
            ->select('doc.file_path', 'file_path')
            ->left_outer_join("sys_documents", ['c.file_token', '=', 'doc.file_dl_token'], 'doc')
            ->where([
                'c.trade_conversation_id' => $conversationId
            ])
            ->order_by_asc('c.created_at')
            ->find_array();

        jsonResponse($messages);
        break;
    case 'save-message':
        $user = Contacts1::details();
        $conversationId = _post('tradeConversationId');
        $userId         = $user->id;
        $content        = _post('content');
        $recipientId    = _post('recipientId');
        $file = $_FILES['file'];

        $file_token = '';
        if (array_key_exists('file', $_FILES) && !empty($_FILES['file'])) {
            $uploadResult        = uploadFile('file');
            $file_token          = $uploadResult['token'];
        }
        /** Saving message */
        $message = ORM::for_table('conversation_message')->create();

        $message->trade_conversation_id = $conversationId;
        $message->sender_id             = $userId;
        $message->sender_table          = 'crm_accounts_1';
        $message->recipient_id          = $recipientId;
        $message->recipient_table       = 'sys_users';
        $message->content               = $content;
        $message->file_token            = $file_token;

        $message->save();

        $conversation = ORM::for_table('trade_conversations')->find_one($conversationId);

        // notifications
        $event = ORM::for_table('events')->create();
        $event->type = $user->account;
        $event->text = mb_strimwidth($content, 0, 20, "...");

        // making the link to the conversation
        $event->link = "trades/list/";
        $trade = ORM::for_table('trades')->find_one($conversation->trade_id);
        switch ($trade->item_table) {
            case 'sys_companies':
                $event->link .= "purchase-construction-material/show/";
                break;
            case 'sys_companies4':
                $event->link .= "purchase-packaging-material/show/";
                break;
            case 'sys_companies1':
                $event->link .= "rental-of-agricultural-equipment/show/";
                break;
            case 'sys_companies2':
                $event->link .= "rental-heavy-machine/show/";
                break;
            case 'sys_companies6':
                $event->link .= "submit-lsr/show/";
                break;

            default:
                # code...
                break;
        }

        // remove extra '0' at the beginning
        $trdId = ltrim($trade->item_id, '0');

        $event->link .= $trdId;
        $event->save();

        $notif                             = ORM::for_table('notifications')->create();
        $notif->user_to_notify             = $recipientId;
        $notif->user_to_notify_table       = 'sys_users';
        $notif->user_who_fired_event       = $userId;
        $notif->user_who_fired_event_table = "crm_accounts_1";
        $notif->event_id                   = $event->id();
        $notif->save();

        header('Content-Type: application/json; charset=utf-8');
        echo "ok";

        break;
    default:
        echo 'action not defined';
}
