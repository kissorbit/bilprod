<?php

_auth();
$ui->assign('_application_menu', 'trades');
$ui->assign('_title', $_L['Trades'] . '- ' . $config['CompanyName']);
$ui->assign('_st', $_L['Trades']);
$action = $routes['1'];
$action2 = $routes['2'];
$user = User::_info();

function loadUserLang($user)
{
    unset($_L);

    $config['language'] = $user['user_lang'];

    $ib_language_file_path = 'application/i18n/' . $config['language'] . '.php';

    if (file_exists($ib_language_file_path)) {
        require $ib_language_file_path;
    } else {
        require 'application/i18n/en.php';
    }

    return $_L;
}
$_L = loadUserLang($user);
$ui->assign('_L', $_L);

$ui->assign('user', $user);
$messagesCount = msgCount($user->id, 'sys_users');
$ui->assign('messagesCount', $messagesCount);
Event::trigger('trades');

switch ($action) {
    case 'new-lsps-offer':

        Event::trigger('trades/new-lsps-offer');

        $msg = '';

        /** getting hidden fields */
        $lsrId = _post('lsr_id');
        $itemId = _post('item_id');
        $itemTable = _post('item_table');
        $recipientTable = "crm_accounts";
        $item = ORM::for_table($itemTable)->find_one($itemId);

        $subject = _post('subject');
        $recipientsIds = $_POST['recipients'];
        $content = _post('content');
        $notifyBySms = _post('sms');
        $send_lsp_email = _post('send_lsp_email');
        $file = $_FILES['file'];


        $allowedExtensions = [
            "pdf",
            "jpg",
            "jpeg",
            "png",
            "PNG",
            "doc"
        ];

        $fileExtension = pathinfo($file['name'], PATHINFO_EXTENSION);

        if (!empty($fileExtension) && !in_array($fileExtension, $allowedExtensions)) {
            $msg .= 'This file is not allowed<br>';
        } else if ($file['size'] > 10000000) { // the file is > 10MB
            $msg .= 'Your file is too big<br>';
        }
        if ($subject == '') {
            $msg .= 'The subject cannot be empty<br>';
        }
        if ($content == '') {
            $msg .= 'The message cannot be empty<br>';
        }
        if (empty($recipientsIds)) {
            $msg .= 'Please select at least one recipient<br>';
        }

        if ($msg != '') {
            echo $msg;
        } else {
            $item = ORM::for_table($itemTable)->find_one($itemId);

            if ($item->status == 1) {
                $item->set('status', 2); // In progress
                $item->save();
            }

            /** Retrieve lsps infos */
            $lsps = ORM::for_table($recipientTable)->where_in('id', $recipientsIds)->find_array();

            $trade = ORM::for_table('trades')->where([
                'item_id' => $itemId,
                'item_table' => $itemTable,
            ])->find_one();

            if ($trade) {
                $trade->set('contacted_lsp', 1);
            } else {

                $trade = ORM::for_table('trades')->create();
                $trade->lsr_id = $item->lsr_id;
                $trade->item_id = $itemId;
                $trade->item_table = $itemTable;
                $trade->contacted_lsp = 1;
            }


            /** Saving the trade */
            $trade->save();
            $file_token = '';
            if (array_key_exists('file', $_FILES) && !empty($_FILES['file'])) {
                $uploadResult        = uploadFile('file');
                $file_token          = $uploadResult['token'];
            }

            /** send email to lsps */
            foreach ($lsps as $lsp) {
                if ($send_lsp_email == 'Yes') {
                    $send_email = Ib_Email::sendEmail($lsp['email'], $subject, $content);
                }
                if ($notifyBySms == 'Yes') {
                    notifyBySMS($lsp['phone']);
                }

                /** Creating a new trade conversation */
                $conversation                 = ORM::for_table('trade_conversations')->create();
                $conversation->trade_id       = $trade->id();
                $conversation->subject        = $subject;
                $conversation->recipient_type = 'lsp';
                $conversation->recipient_id   = $lsp['id'];
                $conversation->content        = $content;
                $conversation->sender_id      = $user->id;
                $conversation->sender_type    = "admin";
                $conversation->send_by_email  = $send_lsp_email;
                $conversation->send_by_sms    = $notifyBySms;

                $conversation->save();

                /** Saving message */
                $message = ORM::for_table('conversation_message')->create();

                $message->trade_conversation_id = $conversation->id();
                $message->sender_id             = $user->id;
                $message->sender_table          = 'sys_users';
                $message->recipient_id          = $lsp['id'];
                $message->recipient_table       = $recipientTable;
                $message->content               = $content;
                $message->file_token            = $file_token;


                $message->save();

                // notifications
                $event = ORM::for_table('events')->create();
                $event->type = "Motodey";
                $event->text = mb_strimwidth($content, 0, 20, "...");

                // making the link to the conversation
                $event->link = "trades/";
                $trade = ORM::for_table('trades')->find_one($conversation->trade_id);

                // making the link to the conversation
                $event->link = "trades/";
                $trade = ORM::for_table('trades')->find_one($conversation->trade_id);
                switch ($trade->item_table) {
                    case 'sys_companies':
                        $event->link .= "purchase-construction-material/";
                        break;
                    case 'sys_companies4':
                        $event->link .= "purchase-packaging-material/";
                        break;
                    case 'sys_companies1':
                        $event->link .= "rental-of-agricultural-equipment/";
                        break;
                    case 'sys_companies2':
                        $event->link .= "rental-heavy-machine/";
                        break;
                    case 'sys_companies6':
                        $event->link .= "submit-lsr/";
                        break;

                    default:
                        # code...
                        break;
                }

                // remove extra '0' at the beginning
                $trdId = ltrim($trade->item_id, '0');

                $event->link .= $trdId;
                $event->save();

                $notif                             = ORM::for_table('notifications')->create();
                $notif->user_to_notify             = $lsp['id'];
                $notif->user_to_notify_table       = $recipientTable;
                $notif->user_who_fired_event       = $user->id;
                $notif->user_who_fired_event_table = "sys_users";
                $notif->event_id                   = $event->id();
                $notif->save();
            }

            echo '1';
        }

        break;
    case 'new-lsr-message':
        Event::trigger('trades/new-lsr-message');

        $msg = '';

        /** getting hidden fields */
        $lsrId = _post('lsr_id');
        $itemId = _post('item_id');
        $itemTable = _post('item_table');
        $recipientTable = "crm_accounts_1";

        $subject = _post('subject');
        $content = _post('content');
        $notifyBySms = _post('sms');
        $file = $_FILES['file'];
        $send_lsr_email = _post('send_lsr_email');

        $allowedExtensions = [
            "pdf",
            "jpg",
            "jpeg",
            "doc",
            "png"
        ];

        $fileExtension = pathinfo($file['name'], PATHINFO_EXTENSION);

        if (!empty($fileExtension) && !in_array($fileExtension, $allowedExtensions)) {
            $msg .= 'This file is not allowed<br>';
        } else if ($file['size'] > 10000000) { // the file is > 10MB
            $msg .= 'Your file is too big<br>';
        }
        if ($subject == '') {
            $msg .= 'The subject cannot be empty<br>';
        }
        if ($content == '') {
            $msg .= 'The message cannot be empty<br>';
        }

        if ($msg != '') {
            echo $msg;
        } else {

            $item = ORM::for_table($itemTable)->find_one($itemId);

            if ($item->status == 1) {
                $item->set('status', 2); // In progress
                $item->save();
            }

            $trade = ORM::for_table('trades')->where([
                'item_id' => $itemId,
                'item_table' => $itemTable,
            ])->find_one();

            if ($trade) {
                $trade->set('contacted_lsr', 1);
            } else {
                $trade = ORM::for_table('trades')->create();
                $trade->lsr_id = $lsrId;
                $trade->item_id = $itemId;
                $trade->item_table = $itemTable;
                $trade->contacted_lsr = 1;
            }

            /** Saving the trade */
            $trade->save();
            $file_token = '';
            if (array_key_exists('file', $_FILES) && !empty($_FILES['file'])) {
                $uploadResult        = uploadFile('file');
                $file_token          = $uploadResult['token'];
            }

            /** Creating a new trade conversation */
            $conversation                 = ORM::for_table('trade_conversations')->create();
            $conversation->trade_id       = $trade->id();
            $conversation->subject        = $subject;
            $conversation->recipient_type = 'lsr';
            $conversation->recipient_id   = $lsrId;
            $conversation->content        = $content;
            $conversation->sender_id      = $user->id;
            $conversation->sender_type    = "admin";
            $conversation->send_by_email  = $send_lsr_email;
            $conversation->send_by_sms    = $notifyBySms;

            $conversation->save();

            /** Saving message */
            $message = ORM::for_table('conversation_message')->create();

            $message->trade_conversation_id = $conversation->id();
            $message->sender_id             = $user->id;
            $message->sender_table          = 'sys_users';
            $message->recipient_id          = $lsrId;
            $message->recipient_table       = $recipientTable;
            $message->content               = $content;
            $message->file_token            = $file_token;

            $message->save();

            if ($send_lsr_email == 'Yes') {
                $lsr = ORM::for_table($recipientTable)->find_one($lsrId);
                $send_email = Ib_Email::sendEmail($lsr['email'], $subject, $content);
            }

            if ($notifyBySms == 'Yes') {
                $lsr = ORM::for_table($recipientTable)->find_one($lsrId);
                notifyBySMS($lsr['phone']);
            }

            // notifications
            $event = ORM::for_table('events')->create();
            $event->type = "Motodey";
            $event->text = mb_strimwidth($content, 0, 20, "...");

            // making the link to the conversation
            $event->link = "trades/";
            $trade = ORM::for_table('trades')->find_one($conversation->trade_id);

            // making the link to the conversation
            $event->link = "trades/";
            $trade = ORM::for_table('trades')->find_one($conversation->trade_id);
            switch ($trade->item_table) {
                case 'sys_companies':
                    $event->link .= "purchase-construction-material/";
                    break;
                case 'sys_companies4':
                    $event->link .= "purchase-packaging-material/";
                    break;
                case 'sys_companies1':
                    $event->link .= "rental-of-agricultural-equipment/";
                    break;
                case 'sys_companies2':
                    $event->link .= "rental-heavy-machine/";
                    break;
                case 'sys_companies6':
                    $event->link .= "submit-lsr/";
                    break;

                default:
                    # code...
                    break;
            }

            // remove extra '0' at the beginning
            $trdId = ltrim($trade->item_id, '0');

            $event->link .= $trdId;
            $event->save();

            $notif                             = ORM::for_table('notifications')->create();
            $notif->user_to_notify             = $lsr['id'];
            $notif->user_to_notify_table       = $recipientTable;
            $notif->user_who_fired_event       = $user->id;
            $notif->user_who_fired_event_table = "sys_users";
            $notif->event_id                   = $event->id();
            $notif->save();

            echo '1';
        }

        break;
    case 'list':
        $action2 = $routes['2'];
        switch ($action2) {
            case '':
                $mode_js = Asset::js([
                    'footable/js/footable.all.min'
                ]);

                $submitLsrCount                    = ORM::for_table('sys_companies6')->count();
                $rentalAgricultalEquipmentCount    = ORM::for_table('sys_companies1')->count();
                $rentalHeavyMachineCount           = ORM::for_table('sys_companies2')->count();
                $purchaseMaterialConstructionCount = ORM::for_table('sys_companies')->count();
                $purchasePackagingMaterialCount    = ORM::for_table('sys_companies4')->count();

                $ui->assign('submitLsrCount', $submitLsrCount);
                $ui->assign('rentalAgricultalEquipmentCount', $rentalAgricultalEquipmentCount);
                $ui->assign('rentalHeavyMachineCount', $rentalHeavyMachineCount);
                $ui->assign('purchaseMaterialConstructionCount', $purchaseMaterialConstructionCount);
                $ui->assign('purchasePackagingMaterialCount', $purchasePackagingMaterialCount);
                $ui->assign('xheader', $mode_css);
                $ui->assign('xfooter', $mode_js);

                $ui->display('motodey/trades_overview.tpl');
                break;
            case 'submit-lsr':
                $action3 = route(3);

                switch ($action3) {
                    case 'show':
                        $tradeId = route(4);
                        $hasConversations = false;
                        $itemTable = 'sys_companies6';
                        $trade = ORM::for_table($itemTable)
                            ->table_alias('c')
                            ->select('c.*')
                            ->select_expr('(SELECT account FROM crm_accounts_1 WHERE  id = c.lsr_id)', 'comp')
                            ->select_expr('(SELECT email FROM crm_accounts_1 WHERE  id = c.lsr_id)', 'lsr_email')
                            ->find_one($tradeId);

                        // the 'trades table' content
                        $tradeContent = ORM::for_table('trades')->where([
                            'item_id' => $tradeId,
                            'item_table' => $itemTable,
                        ])->find_one();

                        if ($tradeContent) {
                            $hasConversations = true;
                        }

                        $lsps = ORM::for_table('crm_accounts')->find_array();

                        $ui->assign('tradeContent', $tradeContent);
                        $ui->assign('submitLsr', $trade);
                        $ui->assign('lsps', $lsps);
                        $ui->assign('hasConversations', $hasConversations);

                        $ui->assign('xheader', Asset::css([
                            'modal',
                            'trades/custom',
                            's2/css/select2.min',
                            'redactor/redactor',
                        ]));
                        $ui->assign(
                            'xfooter',
                            Asset::js([
                                'vue/vue.global',
                                'axios/axios.min',
                                'redactor/redactor.min',
                                's2/js/select2.min',
                                'trades/components/message',
                                'trades/motodey/trade',
                                'trades/motodey/main',
                                'trades/motodey/script',
                            ])
                        );

                        $ui->assign(
                            'xjq',
                            '$(\'#message\').redactor({minHeight: 200});'
                        );

                        $ui->assign('submitLsrTrades', $trade);

                        $ui->display('motodey/trades/submit_lsr/show.tpl');
                        break;

                    default:

                        $submitLsrTrades = ORM::for_table('sys_companies6')
                            ->table_alias('c')
                            ->select('c.*')
                            ->select_expr('(SELECT id FROM sys_documents WHERE  file_dl_token = c.bill_lading_file_token)', 'bill_lading_file_id')
                            ->select_expr('(SELECT account FROM crm_accounts_1 WHERE  id = c.lsr_id)', 'comp')
                            ->order_by_desc('c.id')
                            ->find_many();

                        $ui->assign(
                            'xfooter',
                            Asset::js([
                                'modal',
                                'tinymce/tinymce.min',
                                'js/editor',
                                'numeric'
                            ])
                        );

                        $ui->assign('submitLsrTrades', $submitLsrTrades);

                        $ui->display('motodey/trades/submit_lsr/list.tpl');
                        break;
                }
                break;

            case 'rental-of-agricultural-equipment':
                $action3 = route(3);
                switch ($action3) {
                    case '':
                        $trades = ORM::for_table('sys_companies1')
                            ->table_alias('c')
                            ->select('c.*')
                            ->select_expr('(SELECT id FROM sys_documents WHERE  file_dl_token = c.picture1_file_token)', 'picture1_file_id')

                            ->select_expr('(SELECT id FROM sys_documents WHERE  file_dl_token = c.picture2_file_token)', 'picture2_file_id')
                            ->select_expr('(SELECT account FROM crm_accounts_1 WHERE  id = c.lsr_id)', 'comp')
                            ->select_expr('(SELECT email FROM crm_accounts_1 WHERE  id = c.lsr_id)', 'c_email')
                            ->order_by_desc('c.id')
                            ->find_many();

                        $ui->assign(
                            'xfooter',
                            Asset::js([
                                'tinymce/tinymce.min',
                                'js/editor',
                                'numeric',
                            ])
                        );
                        $ui->assign('trades', $trades);
                        $ui->display('motodey/trades/rental_agricultural_equipment/list.tpl');
                        break;
                    case 'show':
                        $tradeId = route(4);
                        $hasConversations = false;
                        $itemTable = 'sys_companies1';
                        $trade = ORM::for_table($itemTable)
                            ->table_alias('c')
                            ->select('c.*')
                            ->select_expr('(SELECT account FROM crm_accounts_1 WHERE  id = c.lsr_id)', 'comp')
                            ->select_expr('(SELECT email FROM crm_accounts_1 WHERE  id = c.lsr_id)', 'lsr_email')
                            ->find_one($tradeId);

                        // the 'trades table' content
                        $tradeContent = ORM::for_table('trades')->where([
                            'item_id' => $tradeId,
                            'item_table' => $itemTable,
                        ])->find_one();

                        if ($tradeContent) {
                            $hasConversations = true;
                        }

                        $lsps = ORM::for_table('crm_accounts')->find_array();

                        $ui->assign('tradeContent', $tradeContent);
                        $ui->assign('transportRequest', $trade);
                        $ui->assign('lsps', $lsps);
                        $ui->assign('hasConversations', $hasConversations);
                        $ui->assign('xheader', Asset::css([
                            'modal',
                            'trades/custom',
                            's2/css/select2.min',
                            'redactor/redactor',
                        ]));
                        $ui->assign(
                            'xfooter',
                            Asset::js([
                                'vue/vue.global',
                                'axios/axios.min',
                                'redactor/redactor.min',
                                's2/js/select2.min',
                                'trades/components/message',
                                'trades/motodey/trade',
                                'trades/motodey/main',
                                'trades/motodey/script',
                            ])
                        );

                        $ui->assign(
                            'xjq',
                            '$(\'#message\').redactor({minHeight: 200});'
                        );

                        $ui->display('motodey/trades/rental_agricultural_equipment/show.tpl');
                        break;

                    default:
                        echo 'action not defined';
                        break;
                }
                break;
            case 'rental-heavy-machine':
                $action3 = route(3);
                switch ($action3) {
                    case 'show':
                        $tradeId = route(4);
                        $hasConversations = false;
                        $itemTable = 'sys_companies2';
                        $trade = ORM::for_table($itemTable)
                            ->table_alias('c')
                            ->select('c.*')
                            ->select_expr('(SELECT account FROM crm_accounts_1 WHERE  id = c.lsr_id)', 'comp')
                            ->select_expr('(SELECT email FROM crm_accounts_1 WHERE  id = c.lsr_id)', 'lsr_email')
                            ->find_one($tradeId);

                        // the 'trades table' content
                        $tradeContent = ORM::for_table('trades')->where([
                            'item_id' => $tradeId,
                            'item_table' => $itemTable,
                        ])->find_one();

                        if ($tradeContent) {
                            $hasConversations = true;
                        }

                        $lsps = ORM::for_table('crm_accounts')->find_array();

                        $ui->assign('tradeContent', $tradeContent);
                        $ui->assign('trade', $trade);
                        $ui->assign('lsps', $lsps);
                        $ui->assign('hasConversations', $hasConversations);
                        $ui->assign('xheader', Asset::css([
                            'trades/custom',
                            's2/css/select2.min',
                            'redactor/redactor',
                        ]));
                        $ui->assign(
                            'xfooter',
                            Asset::js([
                                'vue/vue.global',
                                'axios/axios.min',
                                'redactor/redactor.min',
                                's2/js/select2.min',
                                'trades/motodey/trade',
                                'trades/motodey/main',
                                'trades/motodey/script',
                            ])
                        );

                        $ui->assign(
                            'xjq',
                            '$(\'#message\').redactor({minHeight: 200});'
                        );

                        $ui->display('motodey/trades/rental_heavy_machine/show.tpl');
                        break;

                    default:
                        $trades = ORM::for_table('sys_companies2')
                            ->table_alias('c')
                            ->select('c.*')
                            ->select_expr('(SELECT account FROM crm_accounts_1 WHERE  id = c.lsr_id)', 'comp')
                            ->select_expr('(SELECT email FROM crm_accounts_1 WHERE  id = c.lsr_id)', 'c_email')
                            ->order_by_desc('c.id')
                            ->find_many();

                        $ui->assign('trades', $trades);
                        $ui->display('motodey/trades/rental_heavy_machine/list.tpl');
                        break;
                }
                break;
            case 'purchase-construction-material':
                $action3 = route(3);
                switch ($action3) {
                    case 'show':
                        $tradeId = route(4);
                        $hasConversations = false;
                        $itemTable = 'sys_companies';
                        $trade = ORM::for_table($itemTable)
                            ->table_alias('c')
                            ->select('c.*')
                            ->select_expr('(SELECT account FROM crm_accounts_1 WHERE  id = c.lsr_id)', 'comp')
                            ->select_expr('(SELECT email FROM crm_accounts_1 WHERE  id = c.lsr_id)', 'lsr_email')
                            ->find_one($tradeId);

                        // the 'trades table' content
                        $tradeContent = ORM::for_table('trades')->where([
                            'item_id' => $tradeId,
                            'item_table' => $itemTable,
                        ])->find_one();

                        if ($tradeContent) {
                            $hasConversations = true;
                        }

                        $lsps = ORM::for_table('crm_accounts')->find_array();

                        $ui->assign('tradeContent', $tradeContent);
                        $ui->assign('trade', $trade);
                        $ui->assign('lsps', $lsps);
                        $ui->assign('hasConversations', $hasConversations);
                        $ui->assign('xheader', Asset::css([
                            'trades/custom',
                            's2/css/select2.min',
                            'redactor/redactor',
                        ]));
                        $ui->assign(
                            'xfooter',
                            Asset::js([
                                'vue/vue.global',
                                'axios/axios.min',
                                'redactor/redactor.min',
                                's2/js/select2.min',
                                'trades/motodey/trade',
                                'trades/motodey/main',
                                'trades/motodey/script',
                            ])
                        );

                        $ui->assign(
                            'xjq',
                            '$(\'#message\').redactor({minHeight: 200});'
                        );

                        $ui->display('motodey/trades/purchase_construction_material/show.tpl');
                        break;

                    default:
                        $trades = ORM::for_table('sys_companies')
                            ->table_alias('c')
                            ->select('c.*')
                            ->select_expr('(SELECT account FROM crm_accounts_1 WHERE  id = c.lsr_id)', 'comp')
                            ->select_expr('(SELECT email FROM crm_accounts_1 WHERE  id = c.lsr_id)', 'c_email')
                            ->order_by_desc('c.id')
                            ->find_many();

                        $ui->assign('trades', $trades);
                        $ui->display('motodey/trades/purchase_construction_material/list.tpl');
                        break;
                }
                break;
            case 'purchase-packaging-material':
                $action3 = route(3);
                switch ($action3) {
                    case 'show':
                        $tradeId = route(4);
                        $hasConversations = false;
                        $itemTable = 'sys_companies4';
                        $trade = ORM::for_table($itemTable)
                            ->table_alias('c')
                            ->select('c.*')
                            ->select_expr('(SELECT account FROM crm_accounts_1 WHERE  id = c.lsr_id)', 'comp')
                            ->select_expr('(SELECT email FROM crm_accounts_1 WHERE  id = c.lsr_id)', 'lsr_email')
                            ->find_one($tradeId);

                        // the 'trades table' content
                        $tradeContent = ORM::for_table('trades')->where([
                            'item_id' => $tradeId,
                            'item_table' => $itemTable,
                        ])->find_one();

                        if ($tradeContent) {
                            $hasConversations = true;
                        }
                        $lsps = ORM::for_table('crm_accounts')->find_array();

                        $ui->assign('tradeContent', $tradeContent);
                        $ui->assign('trade', $trade);
                        $ui->assign('lsps', $lsps);
                        $ui->assign('hasConversations', $hasConversations);
                        $ui->assign('xheader', Asset::css([
                            'trades/custom',
                            's2/css/select2.min',
                            'redactor/redactor',
                        ]));
                        $ui->assign(
                            'xfooter',
                            Asset::js([
                                'vue/vue.global',
                                'axios/axios.min',
                                'redactor/redactor.min',
                                's2/js/select2.min',
                                'trades/motodey/trade',
                                'trades/motodey/main',
                                'trades/motodey/script',
                            ])
                        );

                        $ui->assign(
                            'xjq',
                            '$(\'#message\').redactor({minHeight: 200});'
                        );

                        $ui->display('motodey/trades/purchase_packaging_material/show.tpl');
                        break;

                    default:
                        $trades = ORM::for_table('sys_companies4')
                            ->table_alias('c')
                            ->select('c.*')
                            ->select_expr('(SELECT account FROM crm_accounts_1 WHERE  id = c.lsr_id)', 'comp')
                            ->select_expr('(SELECT email FROM crm_accounts_1 WHERE  id = c.lsr_id)', 'c_email')
                            ->order_by_desc('c.id')
                            ->find_many();

                        $ui->assign('trades', $trades);
                        $ui->display('motodey/trades/purchase_packaging_material/list.tpl');
                        break;
                }
                break;

            default:
                echo 'action not defined';
                break;
        }


        break;
    default:
        echo 'action not defined';
}
