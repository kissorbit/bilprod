
<?php
$errors = [];

$account = _post('account');
 $company = _post('company');
$email = _post('email');
$username = _post('username');
$phone = _post('phone');
$address = _post('address');
$city = _post('city');
$state = _post('state');
$zip = _post('zip');
$trucks = _post('trucks');
$fname = _post('fname');
$lname = _post('fname');
$country = _post('country');
if ($account == '') {
    $errors[] = $_L['Account Name is required'];
}

if ($email != '') {
    if (Validator::Email($email) == false) {
        $errors[] = $_L['Invalid Email'];
    }
    $f = ORM::for_table('crm_accounts')
        ->where('email', $email)
        ->find_one();

    if ($f) {
        $errors[] = $_L['Email already exist'];
    }
}
if ($phone != '') {
    $f = ORM::for_table('crm_accounts')
        ->where('phone', $phone)
        ->find_one();

    if ($f) {
        $errors[] = $_L['Phone number already exist'];
    }
}

$password = _post('password');

$u_password = '';

if ($password != '') {
    if (!Validator::Length($password, 15, 5)) {
        $errors[] =
            'Password should be between 6 to 15 characters';
    }
    $u_password = $password;
    $password = Password::_crypt($password);
    $admin_file_token = '';
    $trucks_files_token = '';
    $transport_license_file_token = '';

    if (array_key_exists('adminfile', $_FILES)) {
        $uploadResult = uploadFile('adminfile');

        if (!$uploadResult['success']) {
            $msg .= 'Administrative file: ' . $uploadResult['msg'] . '<br>';
        } else {
            $admin_file_token = $uploadResult['token'];
        }
    }

    if (array_key_exists('trucksfiles', $_FILES)) {
        $uploadResult = uploadFile('trucksfiles');

        if (!$uploadResult['success']) {
            $msg .= 'Trucks files: ' . $uploadResult['msg'] . '<br>';
        } else {
            $trucks_files_token = $uploadResult['token'];
        }
    }
    if (array_key_exists('transport_license', $_FILES)) {
        $uploadResult = uploadFile('transport_license');

        if (!$uploadResult['success']) {
            $msg .= 'Transport License: ' . $uploadResult['msg'] . '<br>';
        } else {
            $transport_license_file_token = $uploadResult['token'];
        }
    }
}

if (empty($errors)) {
  
    $data = [];
    $data['created_at'] = date('Y-m-d H:i:s');
    $data['updated_at'] = date('Y-m-d H:i:s');
    $d = ORM::for_table('crm_accounts')->create();
    $d->account = $account;
    $d->email = $email;
    $d->phone = $phone;
    $d->address = $address;
    $d->city = $city;
    $d->zip = $zip;
    $d->admin_file_token             = $admin_file_token;
    $d->trucks_files_token           = $trucks_files_token;
    $d->transport_license_file_token = $transport_license_file_token;
    $d->state = $state;
    $d->country = $country;
    $d->trucks = $trucks;
    $d->fname =  $fname;
    $d->lname =  $lname;
    $d->company = $company;
    $d->balance = '0.00';
    $d->status = 'Active';
    $d->notes = '';
    $d->password = $password;
    $d->token = '';
    try {
        $d->save();
    } catch (Exception $error) {
    
        jsonResponse($error);
        exit();
    }
    $cid = $d->id();

    _log(
        $_L['New Contact Added'] .
            ' ' .
            $account .
            ' [CID: ' .
            $cid .
            ']',
        'Admin',
        $owner_id
    );

    Event::trigger('contacts/add-post/_on_finished');

    // send welcome email if needed

    $send_client_signup_email = _post(
        'send_client_signup_email'
    );

    if (
        $email != '' &&
        $send_client_signup_email == 'Yes' &&
        $u_password != ''
    ) {
        $email_data = [];
        $email_data['account'] = $account;
        $email_data['company'] = $company;
        $email_data['password'] = $u_password;
        $email_data['email'] = $email;

        $send_email = Ib_Email::send_client_welcome_email(
            $email_data
        );
    }

    jsonResponse([
        'error' => false,
        'contact_id' => $cid,
        'message' =>
            $_L['account_created_successfully'],
    ]);
} else {
    jsonResponse([
        'error' => true,
        'message' => $errors,
    ]);
}

