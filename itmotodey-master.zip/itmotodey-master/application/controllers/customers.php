<?php
//alias Contacts
$myCtrl = 'customers';
require('application/controllers/contacts.php');
require('application/controllers/contacts1.php');
require('application/controllers/contacts2.php');

