<?php

_auth();
$action = $routes['1'];
$user = User::_info();
Event::trigger('ajax-trades');

switch ($action) {

    case 'auth-user':
        echo json_encode([
            "id"        => $user->id,
            "username"  => $user->username,
            "fullname"  => $user->fullname,
            "user_type" => $user->user_type,
        ]);
        break;
    case 'current-trade':
        $tradeId = _get('tradeId');
        $itemTable = _get('itemTable');
        $trade = ORM::for_table($itemTable)->find_one($tradeId);

        echo json_encode([
            "id"           => $trade->id,
            "status"       => $trade->status,
        ]);
        break;
    case 'update-trade-status':
        $tradeId = _get('tradeId');
        $status = _get('status');
        $itemTable = _get('itemTable');

        $trade = ORM::for_table($itemTable)->find_one($tradeId);
        $trade->status = $status;
        $trade->save();

        echo json_encode([
            "id"           => $trade->id,
            "company_name" => $trade->company_name,
            "status"       => $trade->status,
        ]);
        break;
    case 'lsps-trade-conversations':

        $tradeId = _get("ID");

        $tradeConversations = ORM::for_table("trade_conversations")
            ->table_alias('conv')
            ->select('conv.*')
            ->select('lsp.id', 'lsp_id')
            ->select('lsp.account', 'lsp_account')
            ->select('lsp.email', 'lsp_email')
            ->where([
                "trade_id"       => $tradeId,
                "recipient_type" => "lsp",
            ])->join('crm_accounts', [
                'conv.recipient_id', '=', 'lsp.id'
            ], 'lsp')->find_array();

        echo json_encode($tradeConversations);

        break;
    case 'lsr-trade-conversation':

        $tradeId = _get("ID");

        $tradeConversation = ORM::for_table("trade_conversations")
            ->table_alias('conv')
            ->select('conv.*')
            ->select('lsr.id', 'lsr_id')
            ->select('lsr.account', 'lsr_account')
            ->select('lsr.email', 'lsr_email')
            ->where([
                "trade_id"       => $tradeId,
                "recipient_type" => "lsr",
            ])->join('crm_accounts_1', [
                'conv.recipient_id', '=', 'lsr.id'
            ], 'lsr')->find_array();

        echo json_encode($tradeConversation);

        break;
    case 'trade-messages':
        $conversationId = _get("ID");
        $messages = ORM::for_table('conversation_message')
            ->table_alias('c')
            ->select('c.*')
            ->select('doc.id', 'file_id')
            ->select('doc.title', 'file_name')
            ->select('doc.file_mime_type', 'file_ext')
            ->select('doc.file_dl_token', 'file_dl_token')
            ->select('doc.file_path', 'file_path')
            ->left_outer_join("sys_documents", ['c.file_token', '=', 'doc.file_dl_token'], 'doc')
            ->where([
                'c.trade_conversation_id' => $conversationId
            ])
            ->order_by_asc('c.created_at')
            ->find_array();

        jsonResponse($messages);

        break;
    case 'trade-lsr-messages':
        $conversationId = _get("ID");
        $messages = ORM::for_table('conversation_message')->where([
            'trade_conversation_id' => $conversationId
        ])->find_array();

        echo json_encode($messages);
        break;
    case 'save-lsr-message':

        $conversationId = _post('tradeConversationId');
        $userId         = _post('senderId');
        $content        = _post('content');
        $recipientId    = _post('recipientId');
        $file = $_FILES['file'];
        $recipientTable = "crm_accounts_1";

        $file_token = '';
        if (array_key_exists('file', $_FILES) && !empty($_FILES['file'])) {
            $uploadResult        = uploadFile('file');
            $file_token          = $uploadResult['token'];
        }

        /** Saving message */
        $message = ORM::for_table('conversation_message')->create();

        $message->trade_conversation_id = $conversationId;
        $message->sender_id             = $userId;
        $message->sender_table          = 'sys_users';
        $message->recipient_id          = $recipientId;
        $message->recipient_table       = $recipientTable;
        $message->content               = $content;
        $message->file_token            = $file_token;

        $message->save();

        $conversation = ORM::for_table('trade_conversations')->find_one($conversationId);

        // notifications
        $event = ORM::for_table('events')->create();

        $event->type = "Motodey";
        $event->text = mb_strimwidth($content, 0, 20, "...");

        // making the link to the conversation
        $event->link = "trades/";
        $trade = ORM::for_table('trades')->find_one($conversation->trade_id);
        switch ($trade->item_table) {
            case 'sys_companies':
                $event->link .= "purchase-construction-material/";
                break;
            case 'sys_companies4':
                $event->link .= "purchase-packaging-material/";
                break;
            case 'sys_companies1':
                $event->link .= "rental-of-agricultural-equipment/";
                break;
            case 'sys_companies2':
                $event->link .= "rental-heavy-machine/";
                break;
            case 'sys_companies6':
                $event->link .= "submit-lsr/";
                break;

            default:
                # code...
                break;
        }

        // remove extra '0' at the beginning
        $trdId = ltrim($trade->item_id, '0');

        $event->link .= $trdId;
        $event->save();

        $notif                             = ORM::for_table('notifications')->create();
        $notif->user_to_notify             = $recipientId;
        $notif->user_to_notify_table       = $recipientTable;
        $notif->user_who_fired_event       = $userId;
        $notif->user_who_fired_event_table = "sys_users";
        $notif->event_id                   = $event->id();
        $notif->save();


        if ($conversation->send_by_sms == "Yes") {
            // notify by sms
            $lsr = ORM::for_table($recipientTable)->find_one($recipientId);
            notifyBySMS($lsr['phone']);
        }
        if ($conversation->send_by_email == "Yes") {
            // notify by email
            $lsr = ORM::for_table($recipientTable)->find_one($recipientId);
            notifyByEmail($lsr['email']);
        }

        header('Content-Type: application/json');
        echo "ok";
        break;
    case 'save-message':
        $conversationId = _post('tradeConversationId');
        $userId         = _post('senderId');
        $content        = _post('content');
        $recipientId    = _post('recipientId');
        $file = $_FILES['file'];

        $file_token = '';
        if (array_key_exists('file', $_FILES) && !empty($_FILES['file'])) {
            $uploadResult        = uploadFile('file');
            $file_token          = $uploadResult['token'];
        }

        /** Saving message */
        $message = ORM::for_table('conversation_message')->create();

        $message->trade_conversation_id = $conversationId;
        $message->sender_id             = $userId;
        $message->sender_table          = 'sys_users';
        $message->recipient_id          = $recipientId;
        $message->recipient_table       = 'crm_accounts';
        $message->content               = $content;
        $message->file_token            = $file_token;

        $message->save();

        $conversation = ORM::for_table('trade_conversations')->find_one($conversationId);

        // notifications
        $event = ORM::for_table('events')->create();
        $event->type = "Motodey";
        $event->text = mb_strimwidth($content, 0, 20, "...");

        // making the link to the conversation
        $event->link = "trades/";
        $trade = ORM::for_table('trades')->find_one($conversation->trade_id);
        switch ($trade->item_table) {
            case 'sys_companies':
                $event->link .= "purchase-construction-material/";
                break;
            case 'sys_companies4':
                $event->link .= "purchase-packaging-material/";
                break;
            case 'sys_companies1':
                $event->link .= "rental-of-agricultural-equipment/";
                break;
            case 'sys_companies2':
                $event->link .= "rental-heavy-machine/";
                break;
            case 'sys_companies6':
                $event->link .= "submit-lsr/";
                break;

            default:
                # code...
                break;
        }

        // remove extra '0' at the beginning
        $trdId = ltrim($trade->item_id, '0');

        $event->link .= $trdId;
        $event->save();

        $notif                             = ORM::for_table('notifications')->create();
        $notif->user_to_notify             = $recipientId;
        $notif->user_to_notify_table       = 'crm_accounts';
        $notif->user_who_fired_event       = $userId;
        $notif->user_who_fired_event_table = "sys_users";
        $notif->event_id                   = $event->id();
        $notif->save();


        if ($conversation->send_by_sms == "Yes") {
            // notify by sms
            $lsp = ORM::for_table('crm_accounts')->find_one($recipientId);
            notifyBySMS($lsp['phone']);
        }
        if ($conversation->send_by_email == "Yes") {
            // notify by email
            $lsp = ORM::for_table('crm_accounts')->find_one($recipientId);
            notifyByEmail($lsp['email']);
        }

        header('Content-Type: application/json');
        echo "ok";

        break;
    default:
        echo 'action not defined';
}
