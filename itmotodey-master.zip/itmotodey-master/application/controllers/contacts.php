<?php
if (!isset($myCtrl)) {
    $myCtrl = 'contacts';
}
_auth();
$ui->assign('_application_menu', 'contacts');
$ui->assign('_title', $_L['Contacts'] . ' - ' . $config['CompanyName']);
$ui->assign('_st', $_L['Contacts']);
$ui->assign('content_inner', inner_contents($config['c_cache']));
$action = $routes['1'];
$user = User::_info();
$ui->assign('user', $user);

function loadUserLang($user)
{
    unset($_L);

    $config['language'] = $user['user_lang'];

    $ib_language_file_path = 'application/i18n/' . $config['language'] . '.php';

    if (file_exists($ib_language_file_path)) {
        require $ib_language_file_path;
    } else {
        require 'application/i18n/en.php';
    }

    return $_L;
}
$_L = loadUserLang($user);
$ui->assign('_L', $_L);
$messagesCount = msgCount($user->id, 'sys_users');
$ui->assign('messagesCount', $messagesCount);

$ui->assign(
    'jsvar',
    '
_L[\'Working\'] = \'' .
        $_L['Working'] .
        '\';
_L[\'Submit\'] = \'' .
        $_L['Submit'] .
        '\';
 '
);

switch ($action) {
    case 'add':
        Event::trigger('contacts/add/');
        $_L = loadUserLang($user);
        $ui->assign('_L', $_L);

        if (!has_access($user->roleid, 'customers', 'create')) {
            permissionDenied();
        }

        $ui->assign('countries', Countries::all($config['country'])); // may add this $config['country_code']

        $fs = ORM::for_table('crm_customfields')
            ->where('ctype', 'crm')
            ->order_by_asc('id')
            ->find_many();
        $ui->assign('fs', $fs);

        // find all companies

        $companies = ORM::for_table('sys_companies')
            ->select('id')
            ->select('company_name')
            ->order_by_desc('id')
            ->find_array();

        $ui->assign('companies', $companies);

        // find all companies1

        $companies1 = ORM::for_table('sys_companies1')
            ->select('id')
            ->select('company_name')
            ->order_by_desc('id')
            ->find_array();

        $ui->assign('companies1', $companies1);

        // find all companies2

        $companies2 = ORM::for_table('sys_companies2')
            ->select('id')
            ->select('company_name')
            ->order_by_desc('id')
            ->find_array();

        $ui->assign('companies2', $companies2);
        // find all companies1

        $companies3 = ORM::for_table('sys_companies3')
            ->select('id')
            ->select('company_name')
            ->order_by_desc('id')
            ->find_array();

        $ui->assign('companies3', $companies3);


        // find all groups

        // find all companies4

        $companies4 = ORM::for_table('sys_companies4')
            ->select('id')
            ->select('company_name')
            ->order_by_desc('id')
            ->find_array();

        $ui->assign('companies4', $companies4);


        // find all companies5

        $companies5 = ORM::for_table('crm_accounts')
            ->select('id')
            ->select('company')
            ->order_by_desc('id')
            ->find_array();

        $ui->assign('companies5', $companies5);

        $companies6 = ORM::for_table('sys_companies6')
            ->select('id')
            ->select('company_name')
            ->order_by_desc('id')
            ->find_array();

        $ui->assign('companies6', $companies6);

        $gs = ORM::for_table('crm_groups')
            ->order_by_asc('sorder')
            ->find_array();

        $ui->assign('gs', $gs);

        $g_selected_id = route(2);
        $c_selected_id = route(3);

        if ($g_selected_id) {
            $ui->assign('g_selected_id', $g_selected_id);
        } else {
            $ui->assign('g_selected_id', '');
        }

        if ($c_selected_id) {
            $ui->assign('c_selected_id', $c_selected_id);
        } else {
            $ui->assign('c_selected_id', '');
        }

        $ui->assign('xheader', Asset::css(['modal', 's2/css/select2.min']));
        $ui->assign(
            'xfooter',
            Asset::js([
                'modal',
                's2/js/select2.min',
                's2/js/i18n/' . lan(),
                'add-contact',
            ])
        );
        $tags = Tags::get_all('Contacts');
        $ui->assign('tags', $tags);
        $ui->assign(
            'xjq',
            '
 $("#country").select2({
 theme: "bootstrap"
 });
 '
        );

        $ui->assign(
            'jsvar',
            '
_L[\'Working\'] = \'' .
                $_L['Working'] .
                '\';
_L[\'Company Name\'] = \'' .
                $_L['Company Name'] .
                '\';
_L[\'New Company\'] = \'' .
                $_L['New Company'] .
                '\';
 '
        );

        $currencies = Model::factory('Models_Currency')->find_array();

        $ui->assign('currencies', $currencies);

        $ui->display('add-contact.tpl');

        break;

    case 'summary':
        Event::trigger('contacts/summary/');

        $cid = _post('cid');
        $d = ORM::for_table('crm_accounts')->find_one($cid);
        if ($d) {
            $ti = ORM::for_table('sys_transactions')
                ->where('payerid', $cid)
                ->sum('cr');
            if ($ti == '') {
                $ti = '0';
            }
            $ui->assign('ti', $ti);
            $te = ORM::for_table('sys_transactions')
                ->where('payeeid', $cid)
                ->sum('dr');
            if ($te == '') {
                $te = '0';
            }

            $ui->assign('te', $te);
            $ui->assign('d', $d);

            $cf = ORM::for_table('crm_customfields')
                ->where('ctype', 'crm')
                ->order_by_asc('id')
                ->find_many();
            $ui->assign('cf', $cf);

            // Find Profit

            if ($ti > $te) {
                $happened = $_L['Profit'];
                $css_class = 'green';

                $d_amount = $ti - $te;
            } else {
                $happened = $_L['Loss'];
                $css_class = 'danger';
                $d_amount = $te - $ti;
            }

            $ui->assign('happened', $happened);
            $ui->assign('css_class', $css_class);
            $ui->assign('d_amount', $d_amount);

            $ui->display('ajax.contact-summary.tpl');
        } else {
        }

        break;

    case 'activity':
        Event::trigger('contacts/activity/');

        $cid = _post('cid');
        $d = ORM::for_table('crm_accounts')->find_one($cid);
        if ($d) {
            $ac = ORM::for_table('sys_activity')
                ->where('cid', $cid)
                ->limit(20)
                ->order_by_desc('id')
                ->find_many();
            $ui->assign('ac', $ac);
            $ui->display('ajax.contact-activity.tpl');
        } else {
        }

        break;

    case 'invoices':
        Event::trigger('contacts/invoices/');

        $cid = _post('cid');
        $ui->assign('cid', $cid);
        $d = ORM::for_table('crm_accounts')->find_one($cid);
        if ($d) {
            $i = ORM::for_table('sys_invoices')
                ->where('userid', $cid)
                ->find_many();
            $ui->assign('i', $i);
            $ui->display('ajax.contact-invoices.tpl');
        } else {
        }

        break;

    case 'quotes':
        Event::trigger('contacts/quotes/');

        $cid = _post('cid');
        $ui->assign('cid', $cid);
        $d = ORM::for_table('crm_accounts')->find_one($cid);
        if ($d) {
            $i = ORM::for_table('sys_quotes')
                ->where('userid', $cid)
                ->find_many();
            $ui->assign('i', $i);
            $ui->display('ajax.contact-quotes.tpl');
        } else {
        }

        break;

    case 'transactions':
        Event::trigger('contacts/transactions/');

        $cid = _post('cid');
        $d = ORM::for_table('crm_accounts')->find_one($cid);
        if ($d) {
            $tr = ORM::for_table('sys_transactions')
                ->where_raw('(`payerid` = ? OR `payeeid` = ?)', [$cid, $cid])
                ->order_by_desc('id')
                ->find_many();
            $ui->assign('tr', $tr);
            $ui->display('ajax.contact-transactions.tpl');
        } else {
        }

        break;

    case 'email':
        Event::trigger('contacts/email/');

        $cid = _post('cid');
        $d = ORM::for_table('crm_accounts')->find_one($cid);
        if ($d) {
            $e = ORM::for_table('sys_email_logs')
                ->where('userid', $cid)
                ->order_by_desc('id')
                ->find_many();
            $ui->assign('d', $d);
            $ui->assign('e', $e);
            $ui->display('ajax.contact-emails.tpl');
        } else {
        }

        break;

    case 'edit':
        if (!has_access($user->roleid, 'customers', 'edit')) {
            permissionDenied();
        }

        Event::trigger('contacts/edit/');

        $cid = _post('cid');
        $d = ORM::for_table('crm_accounts')->find_one($cid);
        if ($d) {
            $fs = ORM::for_table('crm_customfields')
                ->where('ctype', 'crm')
                ->order_by_asc('id')
                ->find_many();
            $ui->assign('fs', $fs);
            $ui->assign('countries', Countries::all($d['country']));
            $ui->assign('d', $d);
            $tags = Tags::get_all('Contacts');
            $ui->assign('tags', $tags);
            $dtags = explode(',', $d['tags']);
            $ui->assign('dtags', $dtags);

            // find all groups

            // $gs = ORM::for_table('crm_groups')
            //     ->order_by_asc('sorder')
            //     ->find_array();

            //     $ui->assign('gs', $gs);
            //     $gs = ORM::for_table('crm_groups1')
            //         ->order_by_asc('sorder')
            //         ->find_array();

            //     $ui->assign('gs', $gs);

            //     $companies = ORM::for_table('sys_companies')
            //         ->select('id')
            //         ->select('company_name')
            //         ->order_by_desc('id')
            //         ->find_array();

            //     $ui->assign('companies', $companies);

            //     //company1
            //     $companies1 = ORM::for_table('sys_companies1')
            //     ->select('id')
            //     ->select('company_name')
            //     ->order_by_desc('id')
            //     ->find_array();

            // $ui->assign('companies1', $companies1);

            //          //company2
            //          $companies2 = ORM::for_table('sys_companies2')
            //          ->select('id')
            //          ->select('company_name')
            //          ->order_by_desc('id')
            //          ->find_array();

            //      $ui->assign('companies2', $companies2);

            //        //company3
            //        $companies3 = ORM::for_table('sys_companies3')
            //        ->select('id')
            //        ->select('company_name')
            //        ->order_by_desc('id')
            //        ->find_array();

            //    $ui->assign('companies3', $companies3);


            //company4
            //        $companies4 = ORM::for_table('sys_companies4')
            //        ->select('id')
            //        ->select('company_name')
            //        ->order_by_desc('id')
            //        ->find_array();

            //    $ui->assign('companies4', $companies4);

            //    //company5
            //         $companies5 = ORM::for_table('crm_accounts')
            //         ->select('id')
            //         ->select('company')
            //         ->order_by_desc('id')
            //         ->find_array();

            //         $ui->assign('companies5', $companies5);

            //   //company6
            //   $companies6 = ORM::for_table('sys_companies6')
            //   ->select('id')
            //   ->select('company_name')
            //   ->order_by_desc('id')
            //   ->find_array();

            //   $ui->assign('companies6', $companies6);


            $g_selected_id = route(4);

            if ($g_selected_id) {
                $ui->assign('g_selected_id', $g_selected_id);
            } else {
                $ui->assign('g_selected_id', '');
            }

            $c_selected_id = route(5);

            if ($c_selected_id) {
                $ui->assign('c_selected_id', $c_selected_id);
            } else {
                $ui->assign('c_selected_id', '');
            }

            $currencies = Model::factory('Models_Currency')->find_array();

            $ui->assign('currencies', $currencies);

            $ui->display('ajax.contact-edit.tpl');
        } else {
        }

        break;

    case 'add-activity-post':
        Event::trigger('contacts/add-activity-post/');

        $cid = _post('cid');
        $msg = $_POST['msg'];
        $icon = $_POST['icon'];
        $icon = trim($icon);

        $icon = str_replace('<a href="#"><i class="', '', $icon);
        $icon = str_replace('"></i></a>', '', $icon);
        if ($icon == '') {
            $icon = 'fa fa-check';
        }

        if (Validator::Length($msg, 1000, 5) == false) {
            echo $_L['Message Should be between 5 to 1000 characters'];
        } else {
            $d = ORM::for_table('sys_activity')->create();
            $d->cid = $cid;
            $d->msg = $msg;
            $d->icon = $icon;
            $d->stime = time();
            $d->sdate = date('Y-m-d');
            $d->o = $user['id'];
            $d->oname = $user['fullname'];
            $d->save();

            echo $cid;
        }

        break;

    case 'activity-delete':
        Event::trigger('contacts/activity-delete/');

        $id = $routes['3'];
        $d = ORM::for_table('sys_activity')->find_one($id);
        $d->delete();
        $cid = $routes['2'];
        r2(
            U . $myCtrl . '/view/' . $cid . '/',
            's',
            $_L['Deleted Successfully']
        );
        break;

    case 'view':
        Event::trigger('contacts/view/');

        $id = $routes['2'];
        $d = ORM::for_table('crm_accounts')->find_one($id);
        if ($d) {
            $extra_tab = '';
            $extra_jq = '';

            $tab = route(3);

            if (!$tab) {
                $tab = 'summary';
            }

            $ui->assign('tab', $tab);

            Event::trigger('contacts/view/_on_start');

            $ui->assign('extra_tab', $extra_tab);

            // invoice count

            $inv_count = ORM::for_table('sys_invoices')
                ->where('userid', $id)
                ->count();

            if ($inv_count == '') {
                $inv_count = 0;
            }

            $ui->assign('inv_count', $inv_count);

            $quote_count = ORM::for_table('sys_quotes')
                ->where('userid', $id)
                ->count();

            if ($quote_count == '') {
                $quote_count = 0;
            }

            $ui->assign('quote_count', $quote_count);

            $ui->assign(
                'xheader',
                Asset::css([
                    'modal',
                    'redactor/redactor',
                    's2/css/select2.min',
                    'imgcrop/assets/css/croppic',
                ]) .
                    '
            
            <style>
            .redactor-box {

     margin-bottom: 0;
}
            </style>
            '
            );

            $ui->assign(
                'xfooter',
                Asset::js(
                    [
                        'modal',
                        'redactor/redactor.min',
                        's2/js/select2.min',
                        's2/js/i18n/' . lan(),
                        'imgcrop/croppic',
                        'numeric',
                        'profile',
                    ],
                    $file_build
                )
            );

            $ui->assign(
                'xjq',
                '
 var cid = $(\'#cid\').val();
    var _url = $("#_url").val();
    var cb = function cb (){



            };




 ' . $extra_jq
            );

            $ui->assign('d', $d);

            Event::trigger('contacts/view/_on_display');

            $ui->display('account-profile-alt.tpl');
        } else {
            r2(U . 'customers/list/', 'e', $_L['Account_Not_Found']);
        }

        break;

    case 'add-post':
        Event::trigger('contacts/add-post/');

        Event::trigger('contacts/add-post/_on_start');

        $account = _post('account');

        //  $company = _post('company');

        $company_id = _post('cid');

        $company = '';
        $cid = 0;

        if ($company_id != '' || $company_id != '0') {
            $company_db = db_find_one('sys_companies', $company_id);

            if ($company_db) {
                $company = $company_db->company_name;
                $cid = $company_id;
            }
        }

        //company1

        $company_id = _post('cid');

        $company1 = '';
        $cid = 0;

        if ($company_id != '' || $company_id != '0') {
            $company1_db = db_find_one('sys_companies1', $company_id);

            if ($company1_db) {
                $company1 = $company1_db->company_name;
                $cid = $company_id;
            }
        }

        $company_id = _post('cid');

        $company2 = '';
        $cid = 0;

        if ($company_id != '' || $company_id != '0') {
            $company2_db = db_find_one('sys_companies2', $company_id);

            if ($company2_db) {
                $company2 = $company2_db->company_name;
                $cid = $company_id;
            }
        }


        $company_id = _post('cid');

        $company3 = '';
        $cid = 0;

        if ($company_id != '' || $company_id != '0') {
            $company3_db = db_find_one('sys_companies3', $company_id);

            if ($company3_db) {
                $company3 = $company3_db->company_name;
                $cid = $company_id;
            }
        }


        $company_id = _post('cid');

        $company4 = '';
        $cid = 0;

        if ($company_id != '' || $company_id != '0') {
            $company4_db = db_find_one('sys_companies4', $company_id);

            if ($company4_db) {
                $company4 = $company4_db->company_name;
                $cid = $company_id;
            }
        }
        $company_id = _post('cid');

        $company5 = '';
        $cid = 0;

        if ($company_id != '' || $company_id != '0') {
            $company5_db = db_find_one('sys_companies5', $company_id);

            if ($company5_db) {
                $company5 = $company5_db->company_name;
                $cid = $company_id;
            }
        }
        $company_id = _post('cid');

        $company6 = '';
        $cid = 0;

        if ($company_id != '' || $company_id != '0') {
            $company6_db = db_find_one('sys_companies6', $company_id);

            if ($company6_db) {
                $company6 = $company6_db->company_name;
                $cid = $company_id;
            }
        }

        $company = _post('account');
        $lname = _post('lname');
        $fname = _post('fname');
        $email = _post('email');
        $trucks = _post('trucks');
        $phone = _post('phone');

        $currency = _post('currency');

        if ($currency == '') {
            $currency = '0';
        }

        if (isset($_POST['tags']) and $_POST['tags'] != '') {
            $tags = $_POST['tags'];
        } else {
            $tags = '';
        }

        $address = _post('address');
        $city = _post('city');
        $state = _post('state');
        $zip = _post('zip');
        $country = _post('country');

        $msg = '';

        if ($account == '') {
            $msg .= $_L['Account Name is required'] . ' <br>';
        }

        if ($email != '') {
            if (Validator::Email($email) == false) {
                $msg .= $_L['Invalid Email'] . ' <br>';
            }
            $f = ORM::for_table('crm_accounts')
                ->where('email', $email)
                ->find_one();

            if ($f) {
                $msg .= $_L['Email already exist'] . ' <br>';
            }
        }

        if ($phone != '') {
            $f = ORM::for_table('crm_accounts')
                ->where('phone', $phone)
                ->find_one();

            if ($f) {
                $msg .= $_L['Phone number already exist'] . ' <br>';
            }
        }

        $gid = _post('group');
        $gname = '';
        if ($gid != '') {
            $g = db_find_one('crm_groups', $gid);
            if ($g) {
                $gname = $g['gname'];
            }
        } else {
            $gid = 0;
        }

        $password = _post('password');
        $cpassword = _post('cpassword');

        $u_password = '';

        if ($password != '') {
            if (!Validator::Length($password, 15, 5)) {
                $msg .=
                    'Password should be between 6 to 15 characters' . '<br>';
            }

            if ($password != $cpassword) {
                $msg .= 'Passwords does not match' . '<br>';
            }

            $u_password = $password;
            $password = Password::_crypt($password);
        }

        $admin_file_token = '';
        $trucks_files_token = '';
        $transport_license_file_token = '';

        if (array_key_exists('adminfile', $_FILES)) {
            $uploadResult = uploadFile('adminfile');

            if (!$uploadResult['success']) {
                $msg .= 'Administrative file: ' . $uploadResult['msg'] . '<br>';
            } else {
                $admin_file_token = $uploadResult['token'];
            }
        }

        if (array_key_exists('trucksfiles', $_FILES)) {
            $uploadResult = uploadFile('trucksfiles');

            if (!$uploadResult['success']) {
                $msg .= 'Trucks files: ' . $uploadResult['msg'] . '<br>';
            } else {
                $trucks_files_token = $uploadResult['token'];
            }
        }

        if (array_key_exists('transport_license', $_FILES)) {
            $uploadResult = uploadFile('transport_license');

            if (!$uploadResult['success']) {
                $msg .= 'Transport License: ' . $uploadResult['msg'] . '<br>';
            } else {
                $transport_license_file_token = $uploadResult['token'];
            }
        }

        if ($msg == '') {
            Tags::save($tags, 'Contacts');

            $data = [];

            $data['created_at'] = date('Y-m-d H:i:s');
            $data['updated_at'] = date('Y-m-d H:i:s');

            $d = ORM::for_table('crm_accounts')->create();

            $d->account = $account;
            $d->email = $email;
            $d->phone = $phone;
            $d->address = $address;
            $d->city = $city;
            $d->zip = $zip;
            $d->state = $state;
            $d->country = $country;
            $d->tags = Arr::arr_to_str($tags);

            //others
            $d->fname = $fname;
            $d->lname = $lname;
            $d->trucks = $trucks;
            $d->company = $company;
            $d->jobtitle = '';
            $d->cid = $cid;
            $d->o = $user->id;
            $d->balance = '0.00';
            $d->status = 'Active';
            $d->notes = '';
            $d->password = $password;
            $d->token = '';
            $d->ts = '';
            $d->img = '';
            $d->web = '';
            $d->facebook = '';
            $d->google = '';
            $d->linkedin = '';

            // v 4.2

            $d->gname = $gname;
            $d->gid = $gid;

            // build 4550

            $d->currency = $currency;

            // files
            $d->admin_file_token             = $admin_file_token;
            $d->trucks_files_token           = $trucks_files_token;
            $d->transport_license_file_token = $transport_license_file_token;

            $d->created_at = $data['created_at'];

            $d->save();
            $cid = $d->id();
            _log(
                $_L['New Contact Added'] .
                    ' ' .
                    $account .
                    ' [CID: ' .
                    $cid .
                    ']',
                'Admin',
                $user['id']
            );

            //now add custom fields
            $fs = ORM::for_table('crm_customfields')
                ->where('ctype', 'crm')
                ->order_by_asc('id')
                ->find_many();
            foreach ($fs as $f) {
                $fvalue = _post('cf' . $f['id']);
                $fc = ORM::for_table('crm_customfieldsvalues')->create();
                $fc->fieldid = $f['id'];
                $fc->relid = $cid;
                $fc->fvalue = $fvalue;
                $fc->save();
            }
            //

            Event::trigger('contacts/add-post/_on_finished');

            // send welcome email if needed

            $send_client_signup_email = _post('send_client_signup_email');

            if (
                $email != '' &&
                $send_client_signup_email == 'Yes' &&
                $u_password != ''
            ) {
                $email_data = [];
                $email_data['account'] = $account;
                $email_data['company'] = $company;
                $email_data['password'] = $u_password;
                $email_data['email'] = $email;

                $send_email = Ib_Email::send_client_welcome_email($email_data);
            }

            echo $cid;
        } else {
            echo $msg;
        }
        break;

    case 'list':
        Event::trigger('contacts/list/');
        $_L = loadUserLang($user);
        $ui->assign('_L', $_L);

        $name = _post('name');
        //find all tags
        $t = ORM::for_table('sys_tags')
            ->where('type', 'contacts')
            ->find_many();
        $ui->assign('t', $t);

        $mode_css = '';
        $mode_js = '';

        if ($config['contact_set_view_mode'] == 'search') {
            // Foo Table

            $mode_css = Asset::css('footable/css/footable.core.min');

            $mode_js = Asset::js([
                'footable/js/footable.all.min',
                'contacts/mode_search',
            ]);

            $d = ORM::for_table('crm_accounts')
                ->table_alias('c')
                ->select('c.*')
                ->select_expr('(SELECT id FROM sys_documents WHERE  file_dl_token = c.admin_file_token)', 'admin_file_id')
                ->select_expr('(SELECT id FROM sys_documents WHERE  file_dl_token = c.trucks_files_token)', 'trucks_files_id')
                ->select_expr('(SELECT id FROM sys_documents WHERE  file_dl_token = c.transport_license_file_token)', 'transport_license_file_id')
                ->order_by_desc('c.id')
                ->find_many();

            $paginator['contents'] = '';
        } elseif ($name != '') {
            $paginator = Paginator::bootstrap(
                'crm_accounts',
                'account',
                '%' . $name . '%'
            );
            $d = ORM::for_table('crm_accounts')
                ->table_alias('c')
                ->select('c.*')
                ->select_expr('(SELECT id FROM sys_documents WHERE  file_dl_token = c.admin_file_token)', 'admin_file_id')
                ->select_expr('(SELECT id FROM sys_documents WHERE  file_dl_token = c.trucks_files_token)', 'trucks_files_id')
                ->select_expr('(SELECT id FROM sys_documents WHERE  file_dl_token = c.transport_license_file_token)', 'transport_license_file_id')
                ->where_like('c.account', '%' . $name . '%')
                ->offset($paginator['startpoint'])
                ->limit($paginator['limit'])
                ->order_by_desc('c.id')
                ->find_many();
        } elseif (
            isset($routes[2]) and
            $routes[2] != '' and
            !is_numeric($routes[2])
        ) {
            $tags = $routes[2];
            $paginator['contents'] = '';
            $d = ORM::for_table('crm_accounts')
                ->table_alias('c')
                ->select('c.*')
                ->select_expr('(SELECT id FROM sys_documents WHERE  file_dl_token = c.admin_file_token)', 'admin_file_id')
                ->select_expr('(SELECT id FROM sys_documents WHERE  file_dl_token = c.trucks_files_token)', 'trucks_files_id')
                ->select_expr('(SELECT id FROM sys_documents WHERE  file_dl_token = c.transport_license_file_token)', 'transport_license_file_id')
                ->where_like('c.tags', '%' . $tags . '%')
                ->order_by_desc('c.id')
                ->find_many();
        } else {
            $paginator = Paginator::bootstrap('crm_accounts');
            $d = ORM::for_table('crm_accounts')
                ->table_alias('c')
                ->select('c.*')
                ->select_expr('(SELECT id FROM sys_documents WHERE  file_dl_token = c.admin_file_token)', 'admin_file_id')
                ->select_expr('(SELECT id FROM sys_documents WHERE  file_dl_token = c.trucks_files_token)', 'trucks_files_id')
                ->select_expr('(SELECT id FROM sys_documents WHERE  file_dl_token = c.transport_license_file_token)', 'transport_license_file_id')
                ->offset($paginator['startpoint'])
                ->limit($paginator['limit'])
                ->order_by_desc('c.id')
                ->find_many();
        }

        $ui->assign('d', $d);
        $ui->assign('paginator', $paginator);

        $ui->assign('xheader', $mode_css);

        $ui->assign(
            'xfooter',
            $mode_js .
                '
<script type="text/javascript" src="' .
                $_theme .
                '/lib/list-contacts.js"></script>

'
        );
        $ui->assign(
            'jsvar',
            '
_L[\'are_you_sure\'] = \'' .
                $_L['are_you_sure'] .
                '\';
 '
        );
        $ui->display('list-contacts.tpl');

        break;

    case 'edit-post':
        Event::trigger('contacts/edit-post/');

        $id = _post('fcid');
        $d = ORM::for_table('crm_accounts')->find_one($id);
        if ($d) {
            $old_account = $d->account;

            $account = _post('account');
            // $company = _post('company');

            $company_id = _post('company_id');

            $company = '';
            $cid = 0;

            if ($company_id != '' || $company_id != '0') {
                $company_db = db_find_one('sys_companies', $company_id);

                if ($company_db) {
                    $company = $company_db->company_name;
                    $cid = $company_id;
                }
            }

            $email = _post('edit_email');

            if (isset($_POST['tags'])) {
                $tags = $_POST['tags'];
            } else {
                $tags = '';
            }

            $currency = _post('currency', '0');

            if ($currency == '') {
                $currency = '0';
            }

            $phone = _post('phone');
            $address = _post('address');
            $city = _post('city');
            $fname = _post('fname');
            $lname = _post('lname');
            $notes = _post('notes');

            $state = _post('state');
            $zip = _post('zip');
            $country = _post('country');
            $msg = '';
            $admin_file_token = '';
            $trucks_files_token = '';
            $transport_license_file_token = '';

            if (array_key_exists('adminfile', $_FILES)) {
                $uploadResult = uploadFile('adminfile');

                if (!$uploadResult['success']) {
                    $msg .= 'Administrative file: ' . $uploadResult['msg'] . '<br>';
                } else {
                    $admin_file_token = $uploadResult['token'];
                }
            }

            if (array_key_exists('trucksfiles', $_FILES)) {
                $uploadResult = uploadFile('trucksfiles');

                if (!$uploadResult['success']) {
                    $msg .= 'Trucks files: ' . $uploadResult['msg'] . '<br>';
                } else {
                    $trucks_files_token = $uploadResult['token'];
                }
            }

            if (array_key_exists('transport_license', $_FILES)) {
                $uploadResult = uploadFile('transport_license');

                if (!$uploadResult['success']) {
                    $msg .= 'Transport License: ' . $uploadResult['msg'] . '<br>';
                } else {
                    $transport_license_file_token = $uploadResult['token'];
                }
            }

            if ($account == '') {
                $msg .= $_L['Account Name is required'] . ' <br>';
            }

            Tags::save($tags, 'Contacts');

            if ($email != '') {
                if ($email != $d['email']) {
                    $f = ORM::for_table('crm_accounts')
                        ->where('email', $email)
                        ->find_one();

                    if ($f) {
                        $msg .= $_L['Email already exist'] . ' <br>';
                    }
                }
                if (Validator::Email($email) == false) {
                    $msg .= $_L['Invalid Email'] . ' <br>';
                }
            }

            $gid = _post('group');

            if ($gid != '') {
                $g = db_find_one('crm_groups', $gid);
                $gname = $g['gname'];
            } else {
                $gid = 0;
                $gname = '';
            }

            $password = _post('password');

            if ($msg == '') {
                $d = ORM::for_table('crm_accounts')->find_one($id);
                $d->account = $account;
                $d->company = $company;
                $d->cid = $company_id;

                $d->email = $email;
                $d->tags = Arr::arr_to_str($tags);
                $d->phone = $phone;
                $d->address = $address;
                $d->fname = $fname;
                $d->lname = $lname;
                $d->city = $city;
                $d->notes = $notes;
                $d->zip = $zip;
                $d->state = $state;
                $d->country = $country;
                $d->admin_file_token             = $admin_file_token;
                $d->trucks_files_token           = $trucks_files_token;
                $d->transport_license_file_token = $transport_license_file_token;

                $d->gname = $gname;
                $d->gid = $gid;

                $d->currency = $currency;

                if ($password != '') {
                    $d->password = Password::_crypt($password);
                }

                $d->save();

                $exf = ORM::for_table('crm_customfieldsvalues')
                    ->where('relid', $id)
                    ->delete_many();
                $fs = ORM::for_table('crm_customfields')
                    ->order_by_asc('id')
                    ->find_many();
                foreach ($fs as $f) {
                    $fvalue = _post('cf' . $f['id']);
                    $fc = ORM::for_table('crm_customfieldsvalues')->create();
                    $fc->fieldid = $f['id'];
                    $fc->relid = $id;
                    $fc->fvalue = $fvalue;
                    $fc->save();
                }

                if ($account != $old_account) {
                    $sql = "update sys_invoices set account='$account' where account='$old_account'";

                    ORM::execute($sql);
                }

                _msglog('s', $_L['account_updated_successfully']);

                echo $id;
            } else {
                echo $msg;
            }
        } else {
            r2(U . $myCtrl . '/list', 'e', $_L['Account_Not_Found']);
        }

        break;
    case 'delete':
        Event::trigger('contacts/delete/');

        $id = $routes['2'];
        if ($_app_stage == 'Demo') {
            r2(
                U . $myCtrl . '/list/',
                'e',
                'Sorry! Deleting Account is disabled in the demo mode.'
            );
        }
        $d = ORM::for_table('crm_accounts')->find_one($id);
        if ($d) {
            $d->delete();
            r2(U . $myCtrl . '/list/', 's', $_L['account_delete_successful']);
        }

        break;

    case 'more':
        Event::trigger('contacts/more/');

        $cid = _post('cid');
        $d = ORM::for_table('crm_accounts')->find_one($cid);
        if ($d) {
            $ui->assign('countries', Countries::all($d['country']));
            $ui->assign('d', $d);
            $ui->display('ajax.contact-more.tpl');
        } else {
        }

        break;

    case 'edit-more':
        Event::trigger('contacts/edit-more/');

        $id = _post('cid');
        $d = ORM::for_table('crm_accounts')->find_one($id);
        if ($d) {
            $img = _post('picture');
            $facebook = _post('facebook');
            $google = _post('google');
            $linkedin = _post('linkedin');

            $msg = '';

            //check email already exist

            if ($msg == '') {
                $d = ORM::for_table('crm_accounts')->find_one($id);

                $d->img = $img;
                $d->facebook = $facebook;
                $d->google = $google;
                $d->linkedin = $linkedin;
                $d->save();
                echo $d->id();
            } else {
                echo $msg;
            }
        } else {
            r2(U . $myCtrl . '/list/', 'e', $_L['Account_Not_Found']);
        }

        break;

    case 'edit-notes':
        Event::trigger('contacts/edit-notes/');

        $id = _post('cid');
        $d = ORM::for_table('crm_accounts')->find_one($id);
        if ($d) {
            $notes = _post('notes');

            $msg = '';

            //check email already exist

            if ($msg == '') {
                $d = ORM::for_table('crm_accounts')->find_one($id);

                $d->notes = $notes;
                $d->save();
                echo $d->id();
            } else {
                echo $msg;
            }
        } else {
            r2(U . $myCtrl . '/list/', 'e', $_L['Account_Not_Found']);
        }

        break;

    case 'render-address':
        Event::trigger('contacts/render-address/');

        $cid = _post('cid');
        $d = ORM::for_table('crm_accounts')->find_one($cid);
        $address = $d['address'];
        $city = $d['city'];
        $state = $d['state'];
        $zip = $d['zip'];
        $country = $d['country'];
        echo "$address
$city
$state $zip
$country
";
        break;

    case 'send_email':
        Event::trigger('contacts/send_email/');

        $msg = '';
        $cid = _post('cid');
        $d = ORM::for_table('crm_accounts')->find_one($cid);
        $email = $d['email'];
        $toname = $d['account'];
        $subject = _post('subject');
        if ($subject == '') {
            $msg .= $_L['Subject is Empty'] . ' <br>';
        }
        $message = $_POST['message'];
        if ($message == '') {
            $msg .= $_L['Message is Empty'] . ' <br>';
        }
        if ($msg == '') {
            //send email
            Notify_Email::_send($toname, $email, $subject, $message, $cid);
            echo $cid;
        } else {
            echo $msg;
        }
        break;

    case 'modal_add':
        Event::trigger('contacts/modal_add/');

        $ui->assign('countries', Countries::all($config['country'])); // may add this $config['country_code']
        $ui->display('modal_add_contact.tpl');

        break;

    case 'set_view_mode':
        Event::trigger('contacts/set_view_mode/');

        if (isset($routes[2]) and $routes[2] != '') {
            $mode = $routes['2'];
        } else {
            $mode = 'tbl';
        }

        $available_mode = ["tbl", "card", "search"];
        if (in_array($mode, $available_mode)) {
            update_option('contact_set_view_mode', $mode);
        }

        r2(U . 'contacts/list/');

        break;

    case 'export_csv':
        $fileName = 'contacts_' . time() . '.csv';

        header("Cache-Control: must-revalidate, post-check=0, pre-check=0");
        header('Content-Description: File Transfer');
        header("Content-type: text/csv");
        header("Content-Disposition: attachment; filename={$fileName}");
        header("Expires: 0");
        header("Pragma: public");

        $fh = @fopen('php://output', 'w');

        $headerDisplayed = false;

        $results = db_find_array('crm_accounts', [
            'id',
            'account',
            'company',
            'phone',
            'email',
            'address',
            'city',
            'state',
            'zip',
            'country',
            'balance',
            'tags',
        ]);

        foreach ($results as $data) {
            if (!$headerDisplayed) {
                fputcsv($fh, array_keys($data));
                $headerDisplayed = true;
            }

            fputcsv($fh, $data);
        }
        // Close the file
        fclose($fh);

        break;

    case 'dev_demo_data':
        // this only work with dev mode
        is_dev();

        break;

    case 'import_csv':
        $ui->assign('xheader', Asset::css(['dropzone/dropzone']));

        $ui->assign(
            'xfooter',
            Asset::js(['dropzone/dropzone', 'contacts/import'])
        );

        $ui->display('contacts_import.tpl');

        break;

    case 'csv_upload':
        $uploader = new Uploader();
        $uploader->setDir('application/storage/temp/');
        // $uploader->sameName(true);
        $uploader->setExtensions(['csv']); //allowed extensions list//
        if ($uploader->uploadFile('file')) {
            //txtFile is the filebrowse element name //
            $uploaded = $uploader->getUploadName(); //get uploaded file name, renames on upload//

            $_SESSION['uploaded'] = $uploaded;
        } else {
            //upload failed
            _msglog('e', $uploader->getMessage()); //get upload error message
        }

        break;

    case 'csv_uploaded':
        if (isset($_SESSION['uploaded'])) {
            $uploaded = $_SESSION['uploaded'];

            $csv = new parseCSV();
            $csv->auto('application/storage/temp/' . $uploaded);

            $contacts = $csv->data;

            $cn = 0;

            foreach ($contacts as $contact) {
                $data = [];
                $data['account'] = $contact['Full Name'];
                $data['email'] = $contact['Email'];
                $data['phone'] = $contact['Phone'];
                $data['address'] = $contact['Address'];
                $data['city'] = $contact['City'];
                $data['zip'] = $contact['Zip'];
                $data['state'] = $contact['State'];
                $data['country'] = $contact['Country'];
                $data['company'] = $contact['Company'];

                $save = Contacts::add($data);

                if (is_numeric($save)) {
                    $cn++;
                }
            }

            _msglog('s', $cn . ' Contacts Imported');
        } else {
            _msglog('e', 'An Error Occurred while uploading the files');
        }

        break;

    case 'groups':
        $_L = loadUserLang($user);
        $ui->assign('_L', $_L);
        $gs = ORM::for_table('crm_groups')
            ->order_by_asc('sorder')
            ->find_array();

        $ui->assign('gs', $gs);

        $ui->assign('xfooter', Asset::js(['contacts/groups']));

        $ui->assign(
            'jsvar',
            '
_L[\'are_you_sure\'] = \'' .
                $_L['are_you_sure'] .
                '\';
 '
        );

        $ui->display('crm_groups.tpl');

        break;
        //group1
    case 'groups1':
        $gs = ORM::for_table('crm_groups1')
            ->order_by_asc('sorder')
            ->find_array();

        $ui->assign('gs', $gs);

        $ui->assign('xfooter', Asset::js(['contacts/groups1']));

        $ui->assign(
            'jsvar',
            '
_L[\'are_you_sure\'] = \'' .
                $_L['are_you_sure'] .
                '\';
 '
        );

        $ui->display('crm_groups1.tpl');

        break;

    case 'groups2':
        $gs = ORM::for_table('crm_groups2')
            ->order_by_asc('sorder')
            ->find_array();

        $ui->assign('gs', $gs);

        $ui->assign('xfooter', Asset::js(['contacts/groups2']));

        $ui->assign(
            'jsvar',
            '
_L[\'are_you_sure\'] = \'' .
                $_L['are_you_sure'] .
                '\';
 '
        );

        $ui->display('crm_groups2.tpl');

        break;

    case 'add_group':
        $group_name = _post('group_name');

        if ($group_name != '') {
            $c = ORM::for_table('crm_groups')
                ->where('gname', $group_name)
                ->find_one();

            if ($c) {
                ib_die('A Group with same name already exist');
            }

            $d = ORM::for_table('crm_groups')->create();
            $d->gname = $group_name;
            $d->color = '';
            $d->discount = '';
            $d->parent = '';
            $d->pid = 0;
            $d->exempt = '';
            $d->description = '';
            $d->separateinvoices = '';
            $d->sorder = 0;
            $d->c1 = '';
            $d->c2 = '';
            $d->c3 = '';
            $d->c4 = '';
            $d->c5 = '';
            $d->save();

            echo $d->id();
        } else {
            echo 'Group Name is required';
        }

        break;

    case 'add_group1':
        $group1_name = _post('group1_name');

        if ($group1_name != '') {
            $c = ORM::for_table('crm_groups1')
                ->where('gname', $group1_name)
                ->find_one();

            if ($c) {
                ib_die('A Group with same name already exist');
            }

            $d = ORM::for_table('crm_groups1')->create();
            $d->gname = $group1_name;
            $d->color = '';
            $d->discount = '';
            $d->parent = '';
            $d->pid = 0;
            $d->exempt = '';
            $d->description = '';
            $d->separateinvoices = '';
            $d->sorder = 0;
            $d->c1 = '';
            $d->c2 = '';
            $d->c3 = '';
            $d->c4 = '';
            $d->c5 = '';
            $d->save();

            echo $d->id();
        } else {
            echo 'Group Name is required';
        }

        break;
    case 'add_group2':
        $group2_name = _post('group2_name');

        if ($group_name != '') {
            $c = ORM::for_table('crm_groups2')
                ->where('gname', $group2_name)
                ->find_one();

            if ($c) {
                ib_die('A Group with same name already exist');
            }

            $d = ORM::for_table('crm_groups2')->create();
            $d->gname = $group2_name;
            $d->color = '';
            $d->discount = '';
            $d->parent = '';
            $d->pid = 0;
            $d->exempt = '';
            $d->description = '';
            $d->separateinvoices = '';
            $d->sorder = 0;
            $d->c1 = '';
            $d->c2 = '';
            $d->c3 = '';
            $d->c4 = '';
            $d->c5 = '';
            $d->save();

            echo $d->id();
        } else {
            echo 'Group Name is required';
        }

        break;


    case 'find_by_group':
        $gid = route(2);

        if ($gid) {
            $g = ORM::for_table('crm_groups')->find_one($gid);

            if ($g) {
                $d = ORM::for_table('crm_accounts')
                    ->where('gid', $gid)
                    ->order_by_desc('id')
                    ->find_array();

                $ui->assign('d', $d);
                $ui->assign('gid', $gid);

                $ui->assign(
                    'xjq',
                    ' $(".cdelete").click(function (e) {
        e.preventDefault();
        var id = this.id;
        bootbox.confirm("' .
                        $_L['are_you_sure'] .
                        '", function(result) {
           if(result){
               var _url = $("#_url").val();
               window.location.href = _url + "delete/crm-user/" + id + "/' .
                        $gid .
                        '/";
           }
        });
    });
'
                );

                $ui->display('contacts_find_by_group.tpl');
            }
        }

        break;
    case 'find_by_group1':
        $gid = route(2);

        if ($gid) {
            $g = ORM::for_table('crm_groups1')->find_one($gid);

            if ($g) {
                $d = ORM::for_table('crm_accounts')
                    ->where('gid', $gid)
                    ->order_by_desc('id')
                    ->find_array();

                $ui->assign('d', $d);
                $ui->assign('gid', $gid);

                $ui->assign(
                    'xjq',
                    ' $(".cdelete").click(function (e) {
        e.preventDefault();
        var id = this.id;
        bootbox.confirm("' .
                        $_L['are_you_sure'] .
                        '", function(result) {
           if(result){
               var _url = $("#_url").val();
               window.location.href = _url + "delete/crm-user/" + id + "/' .
                        $gid .
                        '/";
           }
        });
    });
'
                );

                $ui->display('contacts_find_by_group1.tpl');
            }
        }

        break;

    case 'find_by_group2':
        $gid = route(2);

        if ($gid) {
            $g = ORM::for_table('crm_groups2')->find_one($gid);

            if ($g) {
                $d = ORM::for_table('crm_accounts')
                    ->where('gid', $gid)
                    ->order_by_desc('id')
                    ->find_array();

                $ui->assign('d', $d);
                $ui->assign('gid', $gid);

                $ui->assign(
                    'xjq',
                    ' $(".cdelete").click(function (e) {
        e.preventDefault();
        var id = this.id;
        bootbox.confirm("' .
                        $_L['are_you_sure'] .
                        '", function(result) {
           if(result){
               var _url = $("#_url").val();
               window.location.href = _url + "delete/crm-user/" + id + "/' .
                        $gid .
                        '/";
           }
        });
    });
'
                );

                $ui->display('contacts_find_by_group2.tpl');
            }
        }

        break;

    case 'group_edit':
        $id = _post('id');
        $id = str_replace('e', '', $id);
        $gname = _post('gname');

        $d = ORM::for_table('crm_groups')->find_one($id);

        if ($d) {
            $o_gname = $d->gname;

            ORM::execute(
                "update crm_accounts set gname='$gname' where gname='$o_gname'"
            );

            $d->gname = $gname;

            $d->save();

            echo $d->id;
        }

        break;
    case 'group1_edit':
        $id = _post('id');
        $id = str_replace('e', '', $id);
        $gname = _post('gname');

        $d = ORM::for_table('crm_groups1')->find_one($id);

        if ($d) {
            $o_gname = $d->gname;

            ORM::execute(
                "update crm_accounts set gname='$gname' where gname='$o_gname'"
            );

            $d->gname = $gname;

            $d->save();

            echo $d->id;
        }

        break;
    case 'group2_edit':
        $id = _post('id');
        $id = str_replace('e', '', $id);
        $gname = _post('gname');

        $d = ORM::for_table('crm_groups2')->find_one($id);

        if ($d) {
            $o_gname = $d->gname;

            ORM::execute(
                "update crm_accounts set gname='$gname' where gname='$o_gname'"
            );

            $d->gname = $gname;

            $d->save();

            echo $d->id;
        }

        break;

    case 'group_email':
        $gid = route(2);

        if ($gid) {
            $ds = ORM::for_table('crm_accounts')
                ->where('gid', $gid)
                ->where_not_equal('email', '')
                ->select('account')
                ->select('email')
                ->order_by_desc('id')
                ->find_array();

            $ui->assign('ds', $ds);

            $ui->assign(
                'xheader',
                Asset::css([
                    's2/css/select2.min',
                    'sn/summernote',
                    'sn/summernote-bs3',
                    'sn/summernote-application',
                ])
            );

            $ui->assign(
                'xfooter',
                Asset::js([
                    's2/js/select2.min',
                    's2/js/i18n/' . lan(),
                    'sn/summernote.min',
                    'contacts/group_email',
                ])
            );
            $ui->display('contacts_group_email.tpl');
        }

        break;
    case 'group1_email':
        $gid = route(2);

        if ($gid) {
            $ds = ORM::for_table('crm_accounts')
                ->where('gid', $gid)
                ->where_not_equal('email', '')
                ->select('account')
                ->select('email')
                ->order_by_desc('id')
                ->find_array();

            $ui->assign('ds', $ds);

            $ui->assign(
                'xheader',
                Asset::css([
                    's2/css/select2.min',
                    'sn/summernote',
                    'sn/summernote-bs3',
                    'sn/summernote-application',
                ])
            );

            $ui->assign(
                'xfooter',
                Asset::js([
                    's2/js/select2.min',
                    's2/js/i18n/' . lan(),
                    'sn/summernote.min',
                    'contacts/group1_email',
                ])
            );
            $ui->display('contacts_group1_email.tpl');
        }

        break;

    case 'group2_email':
        $gid = route(2);

        if ($gid) {
            $ds = ORM::for_table('crm_accounts')
                ->where('gid', $gid)
                ->where_not_equal('email', '')
                ->select('account')
                ->select('email')
                ->order_by_desc('id')
                ->find_array();

            $ui->assign('ds', $ds);

            $ui->assign(
                'xheader',
                Asset::css([
                    's2/css/select2.min',
                    'sn/summernote',
                    'sn/summernote-bs3',
                    'sn/summernote-application',
                ])
            );

            $ui->assign(
                'xfooter',
                Asset::js([
                    's2/js/select2.min',
                    's2/js/i18n/' . lan(),
                    'sn/summernote.min',
                    'contacts/group2_email',
                ])
            );
            $ui->display('contacts_group2_email.tpl');
        }

        break;

    case 'group_email_post':
        $emails = $_POST['emails'];
        $subject = $_POST['subject'];
        $msg = $_POST['msg'];

        Ib_Email::bulk_email($emails, $subject, $msg, $user->username);

        echo 'Mail Sent!';

        break;

    case 'companies':
        $_L = loadUserLang($user);
        $ui->assign('_L', $_L);
        $ui->assign(
            'jsvar',
            '
_L[\'are_you_sure\'] = \'' .
                $_L['are_you_sure'] .
                '\';
 '
        );

        $ui->assign('_application_menu', 'Purchase_Construction_Material');
        $ui->assign('_st', $_L['Purchase Construction Material']);

        // find all companies

        $companies = ORM::for_table('sys_companies')
            ->table_alias('c')
            ->select('c.*')
            ->select_expr('(SELECT id FROM sys_documents WHERE  file_dl_token = c.picture1_file_token)', 'picture1_file_id')
            ->select_expr('(SELECT id FROM sys_documents WHERE  file_dl_token = c.picture2_file_token)', 'picture2_file_id')
            ->select_expr('(SELECT id FROM sys_documents WHERE  file_dl_token = c.picture3_file_token)', 'picture3_file_id')
            ->select_expr('(SELECT id FROM sys_documents WHERE  file_dl_token = c.picture4_file_token)', 'picture4_file_id')
            ->select_expr('(SELECT account FROM crm_accounts_1 WHERE  id = c.lsr_id)', 'comp')
            ->select_expr('(SELECT email FROM crm_accounts_1 WHERE  id = c.lsr_id)', 'c_email')
            ->order_by_desc('c.id')
            ->find_many();

        $ui->assign('xheader', Asset::css(['modal']));
        $ui->assign(
            'xfooter',
            Asset::js([
                'modal',
                'tinymce/tinymce.min',
                'js/editor',
                'numeric',
                'contacts/companies',
            ])
        );

        $ui->assign('companies', $companies);

        $ui->display('companies.tpl');

        break;

        // company1
    case 'companies1':
        $_L = loadUserLang($user);
        $ui->assign('_L', $_L);
        $ui->assign(
            'jsvar',
            '
_L[\'are_you_sure\'] = \'' .
                $_L['are_you_sure'] .
                '\';
 '
        );

        $ui->assign('_application_menu', 'companies1');
        $ui->assign('_st', $_L['Rental of Agricultural Equipment']);

        // find all companies1

        $companies1 = ORM::for_table('sys_companies1')
            ->table_alias('c')
            ->select('c.*')
            ->select_expr('(SELECT id FROM sys_documents WHERE  file_dl_token = c.picture1_file_token)', 'picture1_file_id')

            ->select_expr('(SELECT id FROM sys_documents WHERE  file_dl_token = c.picture2_file_token)', 'picture2_file_id')
            ->select_expr('(SELECT account FROM crm_accounts_1 WHERE  id = c.lsr_id)', 'comp')
            ->select_expr('(SELECT email FROM crm_accounts_1 WHERE  id = c.lsr_id)', 'c_email')
            ->order_by_desc('c.id')
            ->find_many();

        $ui->assign('xheader', Asset::css(['modal']));
        $ui->assign(
            'xfooter',
            Asset::js([
                'modal',
                'tinymce/tinymce.min',
                'js/editor',
                'numeric',
                'contacts/companies1',
            ])
        );

        $ui->assign('companies1', $companies1);

        $ui->display('companies1.tpl');

        break;

        // company2

    case 'companies2':
        $_L = loadUserLang($user);
        $ui->assign('_L', $_L);
        $ui->assign(
            'jsvar',
            '
 _L[\'are_you_sure\'] = \'' .
                $_L['are_you_sure'] .
                '\';
  '
        );

        $ui->assign('_application_menu', 'companies2');
        $ui->assign('_st', $_L['Companies2']);

        // find all companies2

        //$companies2 = Model::factory('Models_Company2')->find_array();

        $companies2 = ORM::for_table('sys_companies2')
            ->table_alias('c')
            ->select('c.*')
            ->select_expr('(SELECT id FROM sys_documents WHERE  file_dl_token = c.picture1_file_token)', 'picture1_file_id')

            ->select_expr('(SELECT id FROM sys_documents WHERE  file_dl_token = c.picture2_file_token)', 'picture2_file_id')
            ->select_expr('(SELECT id FROM sys_documents WHERE  file_dl_token = c.picture3_file_token)', 'picture3_file_id')

            ->select_expr('(SELECT id FROM sys_documents WHERE  file_dl_token = c.picture4_file_token)', 'picture4_file_id')
            ->select_expr('(SELECT account FROM crm_accounts_1 WHERE  id = c.lsr_id)', 'comp')
            ->select_expr('(SELECT email FROM crm_accounts_1 WHERE  id = c.lsr_id)', 'c_email')
            ->order_by_desc('c.id')
            ->find_many();

        $ui->assign('xheader', Asset::css(['modal']));
        $ui->assign(
            'xfooter',
            Asset::js([
                'modal',
                'tinymce/tinymce.min',
                'js/editor',
                'numeric',
                'contacts/companies2',
            ])
        );


        $ui->assign('companies2', $companies2);

        $ui->display('companies2.tpl');

        break;



        // company3

    case 'companies3':
        $_L = loadUserLang($user);
        $ui->assign('_L', $_L);
        $ui->assign(
            'jsvar',
            '
   _L[\'are_you_sure\'] = \'' .
                $_L['are_you_sure'] .
                '\';
    '
        );

        $ui->assign('_application_menu', 'companies3');
        $ui->assign('_st', $_L['Companies3']);

        // find all companies3

        $companies3 = ORM::for_table('sys_companies3')
            ->table_alias('c')
            ->select('c.*')
            ->select_expr('(SELECT id FROM sys_documents WHERE  file_dl_token = c.picture_permit_file_token	)', 'picture_permit_file_id')
            ->select_expr('(SELECT account FROM crm_accounts WHERE  id = c.lsp_id)', 'comp')
            ->select_expr('(SELECT truck_immatriculation FROM sys_companies5 WHERE  id = c.truck_id	)', 'truck')
            ->order_by_desc('c.id')
            ->find_many();

        $ui->assign('xheader', Asset::css(['modal']));
        $ui->assign(
            'xfooter',
            Asset::js([
                'modal',
                'tinymce/tinymce.min',
                'js/editor',
                'numeric',
                'contacts/companies3',

            ])
        );

        $ui->assign('companies3', $companies3);

        $ui->display('companies3.tpl');

        break;



        // company4

    case 'companies4':
        $_L = loadUserLang($user);
        $ui->assign('_L', $_L);
        $ui->assign(
            'jsvar',
            '
 _L[\'are_you_sure\'] = \'' .
                $_L['are_you_sure'] .
                '\';
  '
        );

        $ui->assign('_application_menu', 'companies4');
        $ui->assign('_st', $_L['Purchase Parkaging Material']);

        // find all companies4

        $companies4 = ORM::for_table('sys_companies4')
            ->table_alias('c')
            ->select('c.*')
            ->select_expr('(SELECT account FROM crm_accounts_1 WHERE  id = c.lsr_id)', 'comp')
            ->select_expr('(SELECT email FROM crm_accounts_1 WHERE  id = c.lsr_id)', 'c_email')
            ->order_by_desc('c.id')
            ->find_many();

        $ui->assign('xheader', Asset::css(['modal']));
        $ui->assign(
            'xfooter',
            Asset::js([
                'modal',
                'tinymce/tinymce.min',
                'js/editor',
                'numeric',
                'contacts/companies4',
            ])
        );

        $ui->assign('companies4', $companies4);

        $ui->display('companies4.tpl');

        break;


        // company5

    case 'companies5':
        $_L = loadUserLang($user);
        $ui->assign('_L', $_L);
        $ui->assign(
            'jsvar',
            '
   _L[\'are_you_sure\'] = \'' .
                $_L['are_you_sure'] .
                '\';
    '
        );

        $ui->assign('_application_menu', 'companies5');
        $ui->assign('_st', $_L['Trucks Registration']);

        // find all companies5

        $companies5 = ORM::for_table('sys_companies5')
            ->table_alias('c')
            ->select('c.*')
            ->select_expr('(SELECT id FROM sys_documents WHERE  file_dl_token = c.truck_picture_file_token)', 'truck_picture_file_id')
            ->select_expr('(SELECT id FROM sys_documents WHERE  file_dl_token = c.truck_insurance_file_token)', 'truck_insurance_file_id')
            ->select_expr('(SELECT id FROM sys_documents WHERE  file_dl_token = c.truck_patent_file_token)', 'truck_patent_file_id')
            ->select_expr('(SELECT id FROM sys_documents WHERE  file_dl_token = c.truck_registration_document_file_token)', 'truck_registration_document_file_id')
            ->select_expr('( SELECT DATE_FORMAT(FROM_DAYS(DATEDIFF(now(),date_of_entry)),"%Y")+0  from sys_companies5 WHERE  id = c.id)', 'age')
            ->select_expr('(SELECT account FROM crm_accounts WHERE  id = c.lsp_id)', 'comp')
            ->select_expr('(SELECT email FROM crm_accounts WHERE  id = c.lsp_id)', 'c_email')
            ->order_by_desc('c.id')
            ->find_many();

        $ui->assign('xheader', Asset::css(['modal']));
        $ui->assign(
            'xfooter',
            Asset::js([
                'modal',
                'tinymce/tinymce.min',
                'js/editor',
                'numeric',
                'contacts/companies5',
            ])
        );

        $ui->assign('companies5', $companies5);

        $ui->display('companies5.tpl');

        break;

        // company6

    case 'companies6':

        $_L = loadUserLang($user);
        $ui->assign('_L', $_L);

        $ui->assign(
            'jsvar',
            '
   _L[\'are_you_sure\'] = \'' .
                $_L['are_you_sure'] .
                '\';
    '
        );

        $ui->assign('_application_menu', 'companies6');
        $ui->assign('_st', $_L['Submitlsr']);

        // find all companies6

        //$companies6 = Model::factory('Models_Company6')->find_array();

        $companies6 = ORM::for_table('sys_companies6')
            ->table_alias('c')
            ->select('c.*')
            ->select_expr('(SELECT id FROM sys_documents WHERE  file_dl_token = c.bill_lading_file_token)', 'bill_lading_file_id')
            ->select_expr('(SELECT account FROM crm_accounts_1 WHERE  id = c.lsr_id)', 'comp')
            ->order_by_desc('c.id')
            ->find_many();

        $ui->assign('xheader', Asset::css(['modal']));
        $ui->assign(
            'xfooter',
            Asset::js([
                'modal',
                'tinymce/tinymce.min',
                'js/editor',
                'numeric',
                'contacts/companies6',
            ])
        );

        $ui->assign('companies6', $companies6);

        $ui->display('companies6.tpl');

        break;

    case 'modal_add_company':
        $id = route(2);
        $lsrs = ORM::for_table('crm_accounts_1')->find_many();
        $ui->assign('lsrs', $lsrs);
        $company = false;

        if ($id != '') {
            $id = str_replace('ae', '', $id);
            $id = str_replace('be', '', $id);

            $company = Model::factory('Models_Company')->find_one($id);
        }

        $val = [];
        if ($company) {
            $f_type = 'edit';
            $val['company_name'] = $company->company_name;
            $val['url'] = $company->url;
            $val['c2'] = $company->c2;
            $val['c1'] = $company->c1;
            $val['tags'] = $company->phone;
            $val['c3'] = $company->c3;
            $val['c4'] = $company->c4;
            $val['c5'] = $company->c5;
            $val['picture1'] = $company->picture1_file_token;
            $val['picture2'] = $company->picture2_file_token;
            $val['picture3'] = $company->picture3_file_token;
            $val['picture4'] = $company->picture4_file_token;

            $val['delivery_time'] = $company->delivery_time;
            $val['type_of_materials'] = $company->type_of_materials;
            $val['quantity'] = $company->quantity;
            $val['weight'] = $company->weight;
            $val['observations'] = $company->observations;
            $val['delivery_location'] = $company->delivery_location;


            $val['notes'] = $company->notes;
            $val['description'] = $company->description;
            $val['cid'] = $id;
            $val['id'] = $id;

            $val['lsr_id'] = $company->lsr_id;
        } else {
            $f_type = 'create';
            $val['company_name'] = '';
            $val['url'] = '';
            $val['email'] = '';
            $val['phone'] = '';
            $val['c2'] = '';
            $val['c1'] = '';
            $val['c3'] = '';
            $val['c4'] = '';
            $val['tags'] = '';
            $val['notes'] = '';
            $val['description'] = '';
            $val['cid'] = $id;
            $val['lsr_id'] = '';
        }

        $ui->assign('f_type', $f_type);
        $ui->assign('val', $val);

        $ui->display('modal_add_company.tpl');
        break;



    case 'modal_add_company1':
        $id = route(2);
        $lsrs = ORM::for_table('crm_accounts_1')->find_many();
        $ui->assign('lsrs', $lsrs);
        $company1 = false;

        if ($id != '') {
            $id = str_replace('ae', '', $id);
            $id = str_replace('be', '', $id);

            $company1 = Model::factory('Models_Company1')->find_one($id);
        }

        $val = [];

        if ($company1) {
            $f_type = 'edit';


            $val['company_name'] = $company1->company_name;
            $val['url'] = $company1->url;
            //  $val['email'] = $company1->email;
            $val['lsr_id'] = $company1->lsr_id;
            $val['c2'] = $company1->c2;
            $val['types_of_equipment'] = $company1->types_of_equipment;
            $val['phone'] = $company1->phone;
            $val['c3'] = $company1->c3;
            $val['c4'] = $company1->c4;
            $val['pprice_per_hour'] = $company1->pprice_per_hour;
            $val['notes'] = $company1->notes;
            $val['other_type'] = $company1->other_type;
            $val['start_date'] = $company1->start_date;
            $val['number_of_rental_day'] = $company1->number_of_rental_day;
            $val['end_date'] = $company1->end_date;
            $val['delivery_location'] = $company1->delivery_location;
            $val['observations'] = $company1->observations;
            $val['pprice_per_hour'] = $company1->pprice_per_hour;
            $val['notes'] = $company1->notes;
            $val['description'] = $company1->description;
            $val['cid'] = $id;
            $val['id'] = $id;

            //            $val[''] = $company->;
        } else {
            $f_type = 'create';
            $val['company_name'] = '';
            $val['url'] = '';
            $val['emails'] = '';
            $val['phone'] = '';
            $val['logo_url'] = '';
            $val['cid'] = $id;
            $val['types_of_equipment'] = '';
            $val['c1'] = '';
            $val['c3'] = '';
            $val['c4'] = '';
            $val['pprice_per_hour'] = '';
            $val['notes'] = '';
            $val['description'] = '';
            $val['other_type'] = '';
            $val['start_date'] = '';
            $val['number_of_rental_day'] = '';
            $val['end_date'] = '';
            $val['delivery_location'] = '';
            $val['observations'] = '';
            $val['lsr_id'] = '';
        }

        $ui->assign('f_type', $f_type);
        $ui->assign('val', $val);

        $ui->display('modal_add_company1.tpl');

        break;


        //add company2 modal


        //     case 'logo-post':
        //     if ($_app_stage == 'Demo') {
        //         r2(U . 'contacts/companies/', 'e', $_L['disabled_in_demo']);
        //     }
        //     $validextentions = ["jpeg", "jpg", "png"];
        //     $temporary = explode(".", $_FILES["file"]["name"]);
        //     $file_extension = end($temporary);
        //     $target_dir = "application/storage/uploads/";
        //     $target_file = $target_dir . basename($_FILES["file"]["name"]);
        //     $fileName = basename($_FILES["file"]["name"]);
        //     if ($_FILES["file"]["type"] == "image/png") {
        //         $file_name = 'logo-tmp.png';
        //     } elseif ($_FILES["file"]["type"] == "image/jpg") {
        //         $file_name = 'logo-tmp.jpg';
        //     } elseif ($_FILES["file"]["type"] == "image/jpeg") {
        //         $file_name = 'logo-tmp.jpeg';
        //     } elseif ($_FILES["file"]["type"] == "image/gif") {
        //         $file_name = 'logo-tmp.gif';
        //     }
        //    elseif ($_FILES["file"]["type"] == "image/gif") {
        //     $file_name = 'logo-tmp.gif';
        // }
        //     else {
        //     }
        //     if (
        //         ($_FILES["file"]["type"] == "image/png" ||
        //             $_FILES["file"]["type"] == "image/jpg" ||
        //             $_FILES["file"]["type"] == "image/jpeg") &&
        //         $_FILES["file"]["size"] < 1000000 && //approx. 100kb files can be uploaded
        //         in_array($file_extension, $validextentions)
        //     ) {
        //         move_uploaded_file(
        //             $_FILES["file"]["tmp_name"],
        //             $target_file
        //         );
        //         $image = new Image();
        //         $image->source_path = 'application/storage/uploads/' . $file_name;
        //         $image->target_path = 'application/storage/uploads/logo2.png';
        //         // $image->resize('0','40',ZEBRA_IMAGE_BOXED,'-1');
        //         $image->resize(0, 0, ZEBRA_IMAGE_BOXED, '-1');

        //         //now delete the tmp image

        //         unlink('application/storage/system/' . $file_name);

        //         //            r2(U.'settings/app','s',$_L['Settings Saved Successfully']);

        //         r2(
        //             U . 'contacts/companies/',
        //             's',
        //             $_L['Settings Saved Successfully']
        //         );
        //     } else {
        //         r2(U . 'contacts/companies/', 'e', $_L['Invalid Logo File']);
        //     }

        //     break;


    case 'modal_add_company2':
        $id = route(2);
        $lsrs = ORM::for_table('crm_accounts_1')->find_many();
        $ui->assign('lsrs', $lsrs);
        $company2 = false;

        if ($id != '') {
            $id = str_replace('ae', '', $id);
            $id = str_replace('be', '', $id);

            $company2 = Model::factory('Models_Company2')->find_one($id);
        }

        $val = [];

        if ($company2) {
            $f_type = 'edit';

            $val['company_name'] = $company2->company_name;
            $val['url'] = $company2->url;
            $val['types_of_machine'] = $company2->types_of_machine;
            $val['lsr_id'] = $company2->lsr_id;

            $val['c2'] = $company2->c2;
            $val['c1'] = $company2->c1;
            $val['phone'] = $company2->phone;
            $val['c3'] = $company2->c3;
            $val['c4'] = $company2->c4;
            $val['c5'] = $company2->c5;
            $val['notes'] = $company2->notes;
            $val['description'] = $company2->description;
            $val['other_type'] = $company2->other_type;
            $val['start_date'] = $company2->start_date;
            $val['number_of_working_hours'] = $company2->number_of_working_hours;
            $val['number_of_rental_day'] = $company2->number_of_rental_day;
            $val['end_date'] = $company2->end_date;
            $val['delivery_location'] = $company2->delivery_location;
            $val['observations'] = $company2->observations;
            $val['proposed_price_per_hours'] = $company2->proposed_price_per_hours;
            $val['cid'] = $id;
            $val['id'] = $id;

            //            $val[''] = $company->;
        } else {
            $f_type = 'create';
            $val['company_name'] = '';
            $val['url'] = '';
            $val['emails'] = '';
            $val['phone'] = '';
            $val['logo_url'] = '';
            $val['cid'] = $cid;
            $val['c2'] = '';
            $val['c1'] = '';
            $val['c3'] = '';
            $val['c4'] = '';
            $val['c5'] = '';
            $val['types_of_machine'] = '';
            $val['notes'] = '';
            $val['description'] = '';
            $val['other_type'] = '';
            $val['start_date'] = '';
            $val['number_of_working_hours'] = '';
            $val['number_of_rental_day'] = '';
            $val['end_date'] = '';
            $val['delivery_location'] = '';
            $val['observations'] = '';
            $val['proposed_price_per_hours'] = '';
            $val['lsr_id'] = '';
        }

        $ui->assign('f_type', $f_type);
        $ui->assign('val', $val);

        $ui->display('modal_add_company2.tpl');

        break;

    case 'modal_add_company3':
        $id = route(2);
        $lsps = ORM::for_table('crm_accounts')->find_many();
        $ui->assign('lsps', $lsps);
        $trucks = ORM::for_table('sys_companies5')->find_many();
        $ui->assign('trucks', $trucks);
        $company3 = false;

        if ($id != '') {
            $id = str_replace('ae', '', $id);
            $id = str_replace('be', '', $id);

            $company3 = ORM::for_table('sys_companies3')
                ->table_alias('c')
                ->select('c.*')
                ->select_expr('(SELECT id FROM sys_documents WHERE  file_dl_token = c.picture_permit_file_token	)', 'picture_permit_file_id')
                ->find_one($id);
        }

        $val = [];

        if ($company3) {
            $f_type = 'edit';
            //$vals = ORM::for_table('crm_accounts_1')->find_one();
            // $ui->assign('company3', $lsp);

            $val['company_name'] = $company3->company_name;
            $val['url'] = $company3->url;
            // $val['picture_permit'] = $company3->picture_permit_file_token;
            $val['emails'] = $company3->emails;
            $val['tags'] = $company3->tags;


            $val['permit_category'] = $company3->permit_category;
            $val['expiry_date'] = $company3->expiry_date;
            //  $val['email'] = $company3->email;
            $val['permit_number'] = $company3->permit_number;
            $val['name'] = $company3->name;
            $val['phone'] = $company3->phone;
            $val['logo_url'] = $company3->logo_url;
            $val['logo_path'] = $company3->logo_path;
            $val['description'] = $company3->description;
            $val['suspend'] = $company3->suspend;
            $val['comment'] = $company3->comment;
            $val['lsp_id'] = $company3->lsp_id;
            $val['truck_id'] = $company3->truck_id;
            $val['cid'] = $id;
            $val['id'] = $id;

            //            $val[''] = $company->;
        } else {
            $f_type = 'create';
            $val['name'] = '';
            $val['permit_number'] = '';
            $val['expiry_date'] = '';
            $val['permit_category'] = '';
            $val['truck_id'] = '';
            $val['lsp_id'] = '';
            $val['email'] = '';
            $val['phone'] = '';
            $val['logo_url'] = '';
            $val['suspend'] = '';
            $val['comment'] = '';
            $val['cid'] = $id;
            //            $val[''] = '';
        }

        $ui->assign('f_type', $f_type);
        $ui->assign('val', $val);

        $ui->display('modal_add_company3.tpl');

        break;
    case 'modal_suspend_driver':
        $id = route(2);
        $vals = ORM::for_table('crm_accounts')->find_many();
        $ui->assign('vals', $vals);
        $trucks = ORM::for_table('sys_companies5')->find_many();
        $ui->assign('trucks', $trucks);
        $id = str_replace('ae', '', $id);
        $id = str_replace('be', '', $id);

        $company3 = Model::factory('Models_Company3')->find_one($id);

        $val['company_name'] = $company3->company_name;
        $val['url'] = $company3->url;
        $val['emails'] = $company3->emails;
        $val['tags'] = $company3->tags;
        $val['permit_category'] = $company3->permit_category;
        $val['expiry_date'] = $company3->expiry_date;
        $val['email'] = $company3->email;
        $val['permit_number'] = $company3->permit_number;
        $val['name']          = $company3->name;
        $val['phone']         = $company3->phone;
        $val['logo_url']      = $company3->logo_url;
        $val['logo_path']     = $company3->logo_path;
        $val['description']   = $company3->description;
        $val['suspend']       = $company3->suspend;
        $val['comment']       = $company3->comment;
        $val['lsp_id']        = $company3->lsp_id;
        $val['truck_id']      = $company3->truck_id;
        $val['cid']           = $id;
        $val['id']            = $id;

        $val = [];
        $val['cid'] = $id;
        $ui->display('modal_suspend_driver.tpl');
        break;
    case 'modal_add_company4':
        $id = route(2);
        $lsrs = ORM::for_table('crm_accounts_1')->find_many();
        $ui->assign('lsrs', $lsrs);
        $company4 = false;

        if ($id != '') {
            $id = str_replace('ae', '', $id);
            $id = str_replace('be', '', $id);

            $company4 = Model::factory('Models_Company4')->find_one($id);
        }

        $val = [];

        if ($company4) {
            $f_type = 'edit';


            $val['company_name'] = $company4->company_name;
            $val['url'] = $company4->url;
            $val['lsr_id'] = $company4->lsr_id;
            $val['address1'] = $company4->address1;
            $val['notes'] = $company4->notes;
            $val['phone'] = $company4->phone;
            $val['logo_url'] = $company4->logo_url;
            $val['logo_path'] = $company4->logo_path;
            $val['description'] = $company4->description;
            $val['destination_country'] = $company4->destination_country;
            $val['type_of_materials'] = $company4->type_of_materials;
            $val['size'] = $company4->size;
            $val['weight'] = $company4->weight;
            $val['estimated_value'] = $company4->estimated_value;
            $val['delivery_location'] = $company4->delivery_location;
            $val['quantity'] = $company4->quantity;
            $val['informations'] = $company4->informations;
            $val['cid'] = $id;
            $val['id'] = $id;

            //            $val[''] = $company->;
        } else {
            $f_type = 'create';
            $val['company_name'] = '';
            $val['url'] = '';
            $val['email'] = '';
            $val['phone'] = '';
            $val['logo_url'] = '';
            $val['company_name'] = '';
            $val['url'] = '';
            $val['type_of_materials'] = '';
            $val['size'] = '';
            $val['weight'] = '';
            $val['estimated_value'] = '';
            $val['delivery_location'] = '';
            $val['quantity'] = '';
            $val['informations'] = '';
            $val['destination_country'] = '';
            $val['cid'] = $id;

            $val['lsr_id'] = '';
        }

        $ui->assign('f_type', $f_type);
        $ui->assign('val', $val);

        $ui->display('modal_add_company4.tpl');
        break;

    case 'modal_add_company5':
        $id = route(2);

        $ui->assign('countries', Countries::all($config['country'])); // may add this $config['country_code']
        $lsps = ORM::for_table('crm_accounts')->find_many();
        $ui->assign('lsps', $lsps);
        $conpany5 = false;

        if ($id != '') {
            $id = str_replace('ae', '', $id);
            $id = str_replace('be', '', $id);

            $conpany5 = Model::factory('Models_Company5')->find_one($id);
        }

        $val = [];

        if ($conpany5) {
            $f_type = 'edit';

            $ui->assign('countries', Countries::all($conpany5->Road_Worthiness));
            $val['company_name'] = $conpany5->company_name;
            $val['url'] = $company5->url;
            $val['Road_Worthiness'] = $conpany5->Road_Worthiness;
            $val['emails'] = $conpany5->emails;
            $val['tags'] = $conpany5->tags;
            $val['phone'] = $conpany5->phone;
            $val['logo_url'] = $conpany5->logo_url;
            $val['notes'] = $conpany5->notes;
            $val['description'] = $conpany5->description;
            $val['address2'] = $conpany5->address2;
            $val['address1'] = $conpany5->address1;
            $val['lsp_id'] = $conpany5->lsp_id;
            $val['date_of_entry'] = $conpany5->date_of_entry;
            $val['chassis_number'] = $conpany5->chassis_number;
            $val['truck_immatriculation'] = $conpany5->truck_immatriculation;
            $val['type_of_truck'] = $conpany5->type_of_truck;
            $val['insurance_start_date'] = $conpany5->insurance_start_date;
            $val['truck_availability'] = $conpany5->truck_availability;
            $val['insurance_expiration_date'] = $conpany5->insurance_expiration_date;
            $val['cid'] = $id;
            $val['id'] = $id;
        } else {
            $f_type = 'create';
            $val['company_name'] = '';
            $val['url'] = '';
            $val['email'] = '';
            $val['notes'] = '';
            $val['tags'] = '';
            $val['phone'] = '';
            $val['date_of_entry'] = '';
            $val['chassis_number'] = '';
            $val['logo_url'] = '';

            $val['emails'] = '';
            $val['description'] = '';
            $val['address2'] = '';
            $val['address1'] = '';
            $val['lsp_id'] = '';
            $val['Road_Worthiness'] = '';

            $val['truck_immatriculation'] = '';
            $val['type_of_truck'] = '';
            $val['insurance_start_date'] = '';
            $val['truck_availabili ty'] = '';
            $val['insurance_expiration_date'] = '';
        }

        $ui->assign('f_type', $f_type);
        $ui->assign('val', $val);

        $ui->display('modal_add_company5.tpl');


        break;



    case 'modal_add_company6':
        $id = route(2);
        $lsrs = ORM::for_table('crm_accounts_1')->find_many();
        $ui->assign('lsrs', $lsrs);
        $conpany6 = false;

        if ($id != '') {
            $id = str_replace('ae', '', $id);
            $id = str_replace('be', '', $id);

            $conpany6 = Model::factory('Models_Company6')->find_one($id);
        }

        $val = [];

        if ($conpany6) {
            $f_type = 'edit';


            $val['company_name'] = $conpany6->company_name;
            $val['country'] = $company6->country;
            $val['weight'] = $conpany6->weight;
            $val['emails'] = $conpany6->emails;
            $val['tags'] = $conpany6->tags;
            $val['phone'] = $conpany6->phone;
            $val['logo_url'] = $conpany6->logo_url;
            $val['notes'] = $conpany6->notes;
            $val['description'] = $conpany6->description;
            $val['loading_date'] = $conpany6->loading_date;
            $val['lsr_id'] = $conpany6->lsr_id;
            $val['c1'] = $conpany6->c1;
            $val['c2'] = $conpany6->c2;
            $val['c3'] = $conpany6->c3;
            $val['recipient_name'] = $conpany6->recipient_name;
            $val['pick_uplocation'] = $conpany6->pick_uplocation;
            $val['estimated_value'] = $conpany6->estimated_value;
            $val['types_of_goods'] = $conpany6->types_of_goods;
            $val['origin_country'] = $conpany6->origin_country;
            $val['destination_country'] = $conpany6->destination_country;
            $val['delivery_location'] = $conpany6->delivery_location;
            $val['transit'] = $conpany6->transit;
            // $val['loading_date'] = $conpany6->c2;
            $val['off_loading_service'] = $conpany6->off_loading_service;
            $val['loading_services'] = $conpany6->loading_services;
            $val['observations'] = $conpany6->observations;
            $val['transport_insurance'] = $conpany6->transport_insurance;
            $val['tracking'] = $conpany6->tracking;
            $val['cid'] = $id;
            $val['id'] = $id;

            //            $val[''] = $company->;
        } else {
            $f_type = 'create';
            $val['company_name'] = '';
            $val['url'] = 'http://';
            $val['email'] = '';
            $val['phone'] = '';
            $val['logo_url'] = '';
            $val['country'] = '';
            $val['notes'] = '';
            $val['description'] = '';

            $val['types_of_goods'] = '';
            $val['estimated_value'] = '';
            $val['origin_country'] = '';
            $val['destination_country'] = '';
            $val['delivery_location'] = '';
            $val['transit'] = '';
            $val['loading_services'] = '';
            $val['off_loading_service'] = '';
            $val['loading_date'] = '';
            $val['observations'] = '';
            $val['transport_insurance'] = '';
            $val['tracking'] = '';
            $val['pick_uplocation'] = '';
            $val['recipient_name'] = '';
            $val['address1'] = '';

            $val['lsr_id'] = '';

            $val['weight'] = '';
            $val['c3'] = '';
            $val['c4'] = '';
            $val['c5'] = '';
            $val['source'] = '';
            $val['city'] = '';
            $val['cid'] = $cid;
            //            $val[''] = '';
        }

        $ui->assign('f_type', $f_type);
        $ui->assign('val', $val);

        $ui->display('modal_add_company6.tpl');
        break;

    case 'add_company_post':
        $data = ib_posted_data();


        if ($data['f_type'] == 'edit') {
            $company = Model::factory('Models_Company')->find_one($data['cid']);

            if (!$company) {
                i_close('Company Not Found');
            }
        } else {
            $company = Model::factory('Models_Company')->create();
        }

        if ($data['type_of_materials'] == '') {
            i_close($_L['Types of materials is required']);
        }

        if ($data['email'] != '' && !Validator::Email($data['email'])) {
            i_close($_L['Invalid Email']);
        }

        if ($data['url'] == 'http') {
            $data['url'] = '';
        }
        $picture1_file_token = '';
        $picture2_file_token = '';
        $picture3_file_token = '';
        $picture4_file_token = '';
        $company->company_name = $data['company_name'];
        $company->url = $data['url'];
        $company->tags = $data['tags'];
        $company->quantity = $data['quantity'];
        $company->description = $data['description'];
        $company->delivery_time = $data['delivery_time'];
        $company->type_of_materials = $data['type_of_materials'];
        $company->weight = $data['weight'];
        $company->observations = $data['observations'];
        $company->delivery_location = $data['delivery_location'];

        $company->c1 = $data['c1'];
        $company->c2 = $data['c2'];
        $company->c3 = $data['c3'];
        $company->c4 = $data['c4'];
        $company->lsr_id = $data['lsr_id'];
        $company->logo_url = $data['logo_url'];

        if (array_key_exists('picture1', $_FILES) && !empty($_FILES['picture1'])) {
            $uploadResult = uploadFile('picture1');

            if (!$uploadResult['success']) {
                $msg .= 'Picture1: ' . $uploadResult['msg'] . '<br>';
            } else {
                $picture1_file_token = $uploadResult['token'];
            }
        }
        if (array_key_exists('picture2', $_FILES) && !empty($_FILES['picture2'])) {
            $uploadResult = uploadFile('picture2');

            if (!$uploadResult['success']) {
                $msg .= 'Picture2: ' . $uploadResult['msg'] . '<br>';
            } else {
                $picture2_file_token = $uploadResult['token'];
            }
        }
        if (array_key_exists('picture3', $_FILES) && !empty($_FILES['picture3'])) {
            $uploadResult = uploadFile('picture3');

            if (!$uploadResult['success']) {
                $msg .= 'Picture3: ' . $uploadResult['msg'] . '<br>';
            } else {
                $picture3_file_token = $uploadResult['token'];
            }
        }
        if (array_key_exists('picture4', $_FILES) && !empty($_FILES['picture4'])) {
            $uploadResult = uploadFile('picture4');

            if (!$uploadResult['success']) {
                $msg .= 'Picture4: ' . $uploadResult['msg'] . '<br>';
            } else {
                $picture4_file_token = $uploadResult['token'];
            }
        }
        if ($data['f_type'] == 'edit') {
            if ($picture1_file_token) {
                $company->picture1_file_token = $picture1_file_token;
            }
        } else {
            $company->picture1_file_token = $picture1_file_token;
        }
        if ($data['f_type'] == 'edit') {
            if ($picture2_file_token) {
                $company->picture2_file_token = $picture2_file_token;
            }
        } else {
            $company->picture2_file_token = $picture2_file_token;
        }
        if ($data['f_type'] == 'edit') {
            if ($picture3_file_token) {
                $company->picture3_file_token = $picture3_file_token;
            }
        } else {
            $company->picture3_file_token = $picture3_file_token;
        }
        if ($data['f_type'] == 'edit') {
            if ($picture4_file_token) {
                $company->picture4_file_token = $picture4_file_token;
            }
        } else {
            $company->picture4_file_token = $picture4_file_token;
        }
        // $company->picture1_file_token = $picture1_file_token;
        // $company->picture2_file_token = $picture2_file_token;
        // $company->picture3_file_token = $picture3_file_token;
        // $company->picture4_file_token = $picture4_file_token;

        $company->save();

        echo $company->id();

        break;

        //add_company1_post

    case 'add_company1_post':
        $data = ib_posted_data();
        $picture1_file_token = '';
        $picture2_file_token = '';

        if ($data['f_type'] == 'edit') {
            $company1 = Model::factory('Models_Company1')->find_one($data['cid']);

            if (!$company1) {
                i_close('Company Not Found');
            }
        } else {
            $company1 = Model::factory('Models_Company1')->create();
        }

        if ($data['types_of_equipment'] == '' && $data['types_of_equipment'] == '') {
            i_close($_L['either Other Types or types of equipment is required']);
        }

        if ($data['lsr_id'] == '') {
            i_close($_L['the selection of lsr is required']);
        }

        if ($data['url'] == 'http') {
            $data['url'] = '';
        }

        $company1->company_name = $data['company_name'];
        $company1->url = $data['url'];
        $company1->lsr_id = $data['lsr_id'];
        $company1->phone = $data['phone'];
        // $company2->logo_url = $data['logo_url'];
        // $company2->emails = $data['emails'];
        $company1->notes = $data['notes'];
        $company1->tags = $data['tags'];
        $company1->phone = $data['phone'];
        $company1->types_of_equipment = $data['types_of_equipment'];
        $company1->c2 = $data['c2'];
        $company1->c3 = $data['c3'];
        $company1->description = $data['description'];
        $company1->c4 = $data['c4'];
        $company1->other_type = $data['other_type'];
        $company1->start_date = $data['start_date'];
        $company1->number_of_rental_day = $data['number_of_rental_day'];
        $company1->end_date = $data['end_date'];
        $company1->delivery_location = $data['delivery_location'];
        $company1->observations = $data['observations'];
        $company1->pprice_per_hour = $data['pprice_per_hour'];


        if (array_key_exists('picture1', $_FILES) && !empty($_FILES['picture1'])) {
            $uploadResult = uploadFile('picture1');

            if (!$uploadResult['success']) {
                $msg .= 'Picture1: ' . $uploadResult['msg'] . '<br>';
            } else {
                $picture1_file_token = $uploadResult['token'];
            }
        }
        if (array_key_exists('picture2', $_FILES) && !empty($_FILES['picture2'])) {
            $uploadResult = uploadFile('picture2');

            if (!$uploadResult['success']) {
                $msg .= 'Picture2: ' . $uploadResult['msg'] . '<br>';
            } else {
                $picture2_file_token = $uploadResult['token'];
            }
        }
        if ($data['f_type'] == 'edit') {
            if ($picture1_file_token) {
                $company1->picture1_file_token = $picture1_file_token;
            }
        } else {
            $company1->picture1_file_token = $picture1_file_token;
        }
        if ($data['f_type'] == 'edit') {
            if ($picture2_file_token) {
                $company1->picture2_file_token = $picture2_file_token;
            }
        } else {
            $company1->picture2_file_token = $picture2_file_token;
        }

        // $company1->picture1_file_token = $picture1_file_token;
        // $company1->picture2_file_token = $picture2_file_token;
        $company1->description = $data['description'];
        $company1->save();

        echo $company1->id();

        break;

    case 'add_company2_post':
        $data = ib_posted_data();
        $picture1_file_token = '';
        $picture2_file_token = '';
        $picture3_file_token = '';
        $picture4_file_token = '';


        if ($data['f_type'] == 'edit') {
            $company2 = Model::factory('Models_Company2')->find_one($data['cid']);

            if (!$company2) {
                i_close('Company Not Found');
            }
        } else {
            $company2 = Model::factory('Models_Company2')->create();
        }

        // if ($data['company_name'] == '') {
        //     i_close($_L['Company Name is required']);
        // }

        if ($data['email'] != '' && !Validator::Email($data['email'])) {
            i_close($_L['Invalid Email']);
        }

        if ($data['url'] == 'http') {
            $data['url'] = '';
        }

        $company2->company_name = $data['company_name'];
        $company2->url = $data['url'];
        $company2->lsr_id = $data['lsr_id'];
        $company2->phone = $data['phone'];
        $company2->types_of_machine = $data['types_of_machine'];
        // $company2->emails = $data['emails'];
        $company2->notes = $data['notes'];
        $company2->tags = $data['tags'];
        $company2->phone = $data['phone'];
        $company2->c1 = $data['c1'];
        $company2->c2 = $data['c2'];
        $company2->c3 = $data['c3'];
        $company2->c4 = $data['c4'];
        $company2->c5 = $data['c5'];
        $company2->start_date = $data['start_date'];
        $company2->other_type = $data['other_type'];
        $company2->number_of_working_hours = $data['number_of_working_hours'];
        $company2->number_of_rental_day = $data['number_of_rental_day'];
        $company2->end_date = $data['end_date'];
        $company2->delivery_location = $data['delivery_location'];
        $company2->observations = $data['observations'];
        $company2->proposed_price_per_hours = $data['proposed_price_per_hours'];

        $company2->description = $data['description'];


        if (array_key_exists('picture1', $_FILES) && !empty($_FILES['picture1'])) {
            $uploadResult = uploadFile('picture1');

            if (!$uploadResult['success']) {
                $msg .= 'Picture1: ' . $uploadResult['msg'] . '<br>';
            } else {
                $picture1_file_token = $uploadResult['token'];
            }
        }
        if (array_key_exists('picture2', $_FILES) && !empty($_FILES['picture2'])) {
            $uploadResult = uploadFile('picture2');

            if (!$uploadResult['success']) {
                $msg .= 'Picture2: ' . $uploadResult['msg'] . '<br>';
            } else {
                $picture2_file_token = $uploadResult['token'];
            }
        }
        if (array_key_exists('picture3', $_FILES) && !empty($_FILES['picture3'])) {
            $uploadResult = uploadFile('picture3');

            if (!$uploadResult['success']) {
                $msg .= 'Picture3: ' . $uploadResult['msg'] . '<br>';
            } else {
                $picture3_file_token = $uploadResult['token'];
            }
        }
        if (array_key_exists('picture4', $_FILES) && !empty($_FILES['picture4'])) {
            $uploadResult = uploadFile('picture4');

            if (!$uploadResult['success']) {
                $msg .= 'Picture4: ' . $uploadResult['msg'] . '<br>';
            } else {
                $picture4_file_token = $uploadResult['token'];
            }
        }
        if ($data['f_type'] == 'edit') {
            if ($picture1_file_token) {
                $company2->picture1_file_token = $picture1_file_token;
            }
        } else {
            $company2->picture1_file_token = $picture1_file_token;
        }
        if ($data['f_type'] == 'edit') {
            if ($picture2_file_token) {
                $company2->picture2_file_token = $picture2_file_token;
            }
        } else {
            $company2->picture2_file_token = $picture2_file_token;
        }
        if ($data['f_type'] == 'edit') {
            if ($picture3_file_token) {
                $company2->picture3_file_token = $picture3_file_token;
            }
        } else {
            $company2->picture3_file_token = $picture3_file_token;
        }
        if ($data['f_type'] == 'edit') {
            if ($picture4_file_token) {
                $company2->picture4_file_token = $picture4_file_token;
            }
        } else {
            $company2->picture4_file_token = $picture4_file_token;
        }
        // $company2->picture1_file_token = $picture1_file_token;
        // $company2->picture2_file_token = $picture2_file_token;
        // $company2->picture3_file_token = $picture3_file_token;
        // $company2->picture4_file_token = $picture4_file_token;

        $company2->save();

        echo $company2->id();

        break;


    case 'add_company3_post':
        $data = ib_posted_data();

        if ($data['f_type'] == 'edit') {
            $company3 = Model::factory('Models_Company3')->find_one($data['cid']);

            if (!$company3) {
                i_close('Company Not Found');
            }
        } else {
            $company3 = Model::factory('Models_Company3')->create();
        }

        if ($data['name'] == '') {
            i_close($_L['the driver name is required']);
        }
        if ($data['permit_number'] == '') {
            i_close($_L['permit number is required']);
        }
        if ($data['phone'] == '') {
            i_close($_L['phone number is required']);
        }

        // if ($data['email'] != '' && !Validator::Email($data['email'])) {
        //     i_close($_L['Invalid Email']);
        // }
        // $phone = $data['phone'];
        // if ($phone != '') {
        //     $f = ORM::for_table('sys_companies3')
        //         ->where('phone', $phone)
        //         ->find_one();

        //     if ($f) {
        //         i_close($_L['Phone number already exist']);
        //     }
        // }

        if ($data['url'] == 'http') {
            $data['url'] = '';
        }

        $picture_permit_file_token = '';

        if (array_key_exists('picture_permit', $_FILES) && !empty($_FILES['picture_permit'])) {
            $uploadResult = uploadFile('picture_permit');

            if (!$uploadResult['success']) {
                $msg .= $_L['picture of permit'] . ': ' . $uploadResult['msg'] . '<br>';
            } else {
                $picture_permit_file_token = $uploadResult['token'];
            }
        }
        $company3->name = $data['name'];
        $company3->permit_number = $data['permit_number'];
        $company3->lsp_id = $data['lsp_id'];
        $company3->expiry_date = $data['expiry_date'];
        if ($data['f_type'] == 'edit') {
            if ($picture_permit_file_token) {
                $company3->picture_permit_file_token  = $picture_permit_file_token;
            }
        } else {
            $company3->picture_permit_file_token  = $picture_permit_file_token;
        }
        //$company3->picture_permit_file_token  = $picture_permit_file_token;
        $company3->permit_category = $data['permit_category'];
        $company3->truck_id = $data['truck_id'];
        $company3->phone = $data['phone'];
        $company3->logo_url = $data['logo_url'];
        $company3->logo_path = $data['logo_path'];
        $company3->description = $data['description'];
        $company3->suspend = $data['suspend'];
        $company3->comment = $data['comment'];

        $company3->save();

        echo $company3->id();

        break;
        // case 'add_company7_post':
        // $data = ib_posted_data();

        // if ($data['f_type'] == 'edit') {
        //     $company3 = Model::factory('Models_Company3')->find_one($data['cid']);

        //     if (!$company3) {
        //         i_close('Company Not Found');
        //     }
        // } else {
        //     $company3 = Model::factory('Models_Company3')->create();
        // }



        // $company3->suspend = $data['suspend'];
        // $company3->description = $data['description'];

        // $company3->save();

        // echo $company3->id();

        // break;

    case 'add_company4_post':
        $data = ib_posted_data();

        if ($data['f_type'] == 'edit') {
            $company4 = Model::factory('Models_Company4')->find_one($data['cid']);

            if (!$company4) {
                i_close('Company Not Found');
            }
        } else {
            $company4 = Model::factory('Models_Company4')->create();
        }

        if ($data['type_of_materials'] == '') {
            i_close($_L['the type of materials is required']);
        }

        if ($data['email'] != '' && !Validator::Email($data['email'])) {
            i_close($_L['Invalid Email']);
        }

        if ($data['url'] == 'http') {
            $data['url'] = '';
        }

        $company4->company_name = $data['company_name'];
        $company4->url = $data['url'];
        $company4->lsr_id = $data['lsr_id'];
        $company4->phone = $data['phone'];
        // $company4->type_of_materials = $data['type_of_materials'];
        $company4->address1 = $data['address1'];
        $company4->tags = $data['tags'];
        $company4->notes = $data['notes'];

        $company4->phone = $data['phone'];
        $company4->logo_url = $data['logo_url'];
        $company4->logo_path = $data['logo_path'];
        $company4->description = $data['description'];
        $company4->type_of_materials = $data['type_of_materials'];
        $company4->size = $data['size'];
        $company4->weight = $data['weight'];
        $company4->estimated_value = $data['estimated_value'];
        $company4->delivery_location = $data['delivery_location'];
        $company4->quantity = $data['quantity'];
        $company4->informations = $data['informations'];
        $company4->destination_country = $data['destination_country'];
        $company4->save();

        echo $company4->id();

        break;

    case 'add_company5_post':
        $data = ib_posted_data();

        if ($data['truck_immatriculation'] == '') {
            i_close($_L['truck immatriculation  is required']);
        }

        if ($data['f_type'] == 'edit') {
            $company5 = Model::factory('Models_Company5')->find_one($data['cid']);

            if (!$company5) {
                i_close('Company Not Found');
            }
        } else {
            $company5 = Model::factory('Models_Company5')->create();
        }


        $company5->company_name = $data['company_name'];
        $company5->url = $data['url'];
        // $company5->email = $data['email'];
        //$company5->phone = $data['phone'];

        $company5->lsp_id = $data['lsp_id'];
        $company5->emails = $data['emails'];
        $company5->tags = $data['tags'];
        $company5->phone = $data['phone'];
        $company5->logo_url = $data['logo_url'];
        $company5->date_of_entry = $data['date_of_entry'];
        $company5->chassis_number = $data['chassis_number'];
        $company5->truck_immatriculation = $data['truck_immatriculation'];
        $company5->type_of_truck = $data['type_of_truck'];
        $company5->insurance_start_date = $data['insurance_start_date'];
        $company5->truck_availability = $data['truck_availability'];
        $company5->insurance_expiration_date = $data['insurance_expiration_date'];
        $company5->Road_Worthiness = $data['Road_Worthiness'];

        $company5->notes = $data['notes'];
        $company5->description = $data['description'];
        $company5->address2 = $data['address2'];
        $company5->address1 = $data['address1'];

        $truck_picture_file_token = '';

        if (array_key_exists('truck_picture', $_FILES) && !empty($_FILES['truck_picture'])) {
            $uploadResult = uploadFile('truck_picture');

            if (!$uploadResult['success']) {
                $msg .= 'Truck picture: ' . $uploadResult['msg'] . '<br>';
            } else {
                $truck_picture_file_token = $uploadResult['token'];
            }
        }

        $truck_insurance_file_token = '';

        if (array_key_exists('truck_insurance', $_FILES) && !empty($_FILES['truck_insurance'])) {
            $uploadResult = uploadFile('truck_insurance');

            if (!$uploadResult['success']) {
                $msg .= 'Truck insurance: ' . $uploadResult['msg'] . '<br>';
            } else {
                $truck_insurance_file_token = $uploadResult['token'];
            }
        }


        $truck_patent_file_token = '';

        if (array_key_exists('truck_patent', $_FILES) && !empty($_FILES['truck_patent'])) {
            $uploadResult = uploadFile('truck_patent');

            if (!$uploadResult['success']) {
                $msg .= 'Truck patent: ' . $uploadResult['msg'] . '<br>';
            } else {
                $truck_patent_file_token = $uploadResult['token'];
            }
        }
        $truck_registration_document_file_token = '';

        if (array_key_exists('truck_registration_document', $_FILES) && !empty($_FILES['truck_registration_document'])) {
            $uploadResult = uploadFile('truck_registration_document');

            if (!$uploadResult['success']) {
                $msg .= 'Truck registration document: ' . $uploadResult['msg'] . '<br>';
            } else {
                $truck_registration_document_file_token = $uploadResult['token'];
            }
        }
        if ($data['f_type'] == 'edit') {
            if ($truck_picture_file_token) {
                $company5->truck_picture_file_token  = $truck_picture_file_token;
            }
        } else {
            $company5->truck_picture_file_token  = $truck_picture_file_token;
        }
        if ($data['f_type'] == 'edit') {
            if ($truck_insurance_file_token) {
                $company5->truck_insurance_file_token = $truck_insurance_file_token;
            }
        } else {
            $company5->truck_insurance_file_token   = $truck_insurance_file_token;
        }
        if ($data['f_type'] == 'edit') {
            if ($truck_patent_file_token) {
                $company5->truck_patent_file_token = $truck_patent_file_token;
            }
        } else {
            $company5->truck_patent_file_token  = $truck_patent_file_token;
        }
        if ($data['f_type'] == 'edit') {
            if ($truck_registration_document_file_token) {
                $company5->truck_registration_document_file_token = $truck_registration_document_file_token;
            }
        } else {
            $company5->truck_registration_document_file_token = $truck_registration_document_file_token;
        }

        // $company5->truck_picture_file_token               = $truck_picture_file_token;

        // $company5->truck_insurance_file_token             = $truck_insurance_file_token;
        // $company5->truck_patent_file_token                = $truck_patent_file_token;
        // $company5->truck_registration_document_file_token = $truck_registration_document_file_token;
        //dd($company5);
        $company5->save();

        echo $company5->id();

        break;

    case 'add_company6_post':
        $data = ib_posted_data();
        // var_dump($data); die();
        if ($data['f_type'] == 'edit') {
            $company6 = Model::factory('Models_Company6')->find_one($data['cid']);

            if (!$company6) {
                i_close('Company Not Found');
            }
        } else {
            $company6 = Model::factory('Models_Company6')->create();
        }

        if ($data['types_of_goods'] == '') {
            i_close($_L['Types of goods is required']);
        }

        if ($data['email'] != '' && !Validator::Email($data['email'])) {
            i_close($_L['Invalid Email']);
        }

        if ($data['url'] == 'http') {
            $data['url'] = '';
        }

        $bill_lading_file_token = '';

        if (array_key_exists('bill_lading', $_FILES) && !empty($_FILES['bill_lading'])) {
            $uploadResult = uploadFile('bill_lading');

            if (!$uploadResult['success']) {
                $msg .= $_L['Bill of lading'] . ': ' . $uploadResult['msg'] . '<br>';
            } else {
                $bill_lading_file_token = $uploadResult['token'];
            }
        }

        $company6->company_name = $data['company_name'];
        $company6->country = $data['country'];

        $company6->phone = $data['phone'];

        $company6->emails = $data['emails'];
        $company6->tags = $data['tags'];
        $company6->notes = $data['notes'];
        $company6->address1 = $data['address1'];
        $company6->address2 = $data['address2'];
        $company6->description = $data['description'];
        $company6->lsr_id = $data['lsr_id'];
        $company6->c1 = $data['c1'];
        $company6->c2 = $data['c2'];
        $company6->c3 = $data['c3'];
        $company6->c4 = $data['c4'];
        $company6->c5 = $data['c5'];
        $company6->logo_url = $data['logo_url'];
        $company6->source = $data['source'];
        $company6->city = $data['city'];
        $company6->pick_uplocation = $data['pick_uplocation'];
        $company6->recipient_name = $data['recipient_name'];
        $company6->types_of_goods = $data['types_of_goods'];
        $company6->estimated_value = $data['estimated_value'];
        $company6->weight = $data['weight'];
        $company6->origin_country = $data['origin_country'];
        $company6->destination_country = $data['destination_country'];
        $company6->delivery_location = $data['delivery_location'];
        $company6->transit = $data['transit'];
        $company6->loading_date = $data['loading_date'];
        $company6->off_loading_service = $data['off_loading_service'];
        $company6->loading_services = $data['loading_services'];
        $company6->observations = $data['observations'];
        $company6->transport_insurance = $data['transport_insurance'];
        $company6->tracking = $data['tracking'];
        if ($data['f_type'] == 'edit') {
            if ($bill_lading_file_token) {
                $company6->bill_lading_file_token = $bill_lading_file_token;
            }
        } else {
            $company6->bill_lading_file_token = $bill_lading_file_token;
        }
        //$company6->bill_lading_file_token = $bill_lading_file_token;
        $company6->save();

        echo $company6->id();

        break;



    case 'modal_edit_activity':
        $id = route(2);

        $id = str_replace('activity_', '', $id);

        $d = ORM::for_table('sys_activity')->find_one($id);

        if ($d) {
            $ui->assign('d', $d);
            $ui->display('modal_edit_activity.tpl');
        }

        break;

    case 'edit_activity_post':
        $edit_activity_id = _post('edit_activity_id');

        $d = ORM::for_table('sys_activity')->find_one($edit_activity_id);

        if ($d) {
            $message_text = $_POST['message_text'];
            $icon = $_POST['edit_activity_type'];
            $icon = str_replace('<a href="#"><i class="', '', $icon);
            $icon = str_replace('"></i></a>', '', $icon);
            if ($icon == '') {
                $icon = 'fa fa-check';
            }
            $d->icon = $icon;
            $d->msg = $message_text;
            $d->save();
            echo $d->id();
        }

        break;

    case 'orders':
        Event::trigger('contacts/orders/');

        $cid = _post('cid');
        $d = ORM::for_table('crm_accounts')->find_one($cid);
        if ($d) {
            $d = ORM::for_table('sys_orders')
                ->where('cid', $cid)
                ->find_array();
            $ui->assign('d', $d);
            $ui->display('contacts_orders.tpl');
        } else {
        }

        break;

    case 'files':
        Event::trigger('contacts/files/');

        $cid = _post('cid');

        $ui->assign('cid', $cid);

        // find all available files for this client

        $file_ids = ORM::for_table('ib_doc_rel')
            ->where('rtype', 'contact')
            ->where('rid', $cid)
            ->find_array();

        $ids = [];

        foreach ($file_ids as $f) {
            $ids[] = $f['did'];
        }

        if (!empty($ids)) {
            $d = ORM::for_table('sys_documents')
                ->where_in('id', $ids)
                ->find_many();
        } else {
            $d = [];
        }

        // select all files

        $files = ORM::for_table('sys_documents')->find_array();

        $ui->assign('files', $files);

        $ui->assign('d', $d);

        $ui->display('contacts_files.tpl');

        break;

    case 'assign_file':
        $cid = _post('cid');

        $did = _post('did');

        // find the customer

        // check if exist

        $check = ORM::for_table('ib_doc_rel')
            ->where('rtype', 'contact')
            ->where('rid', $cid)
            ->where('did', $did)
            ->find_one();

        if ($check) {
            i_close('This file is already available for this contact.');
        }

        $d = ORM::for_table('ib_doc_rel')->create();
        $d->rtype = 'contact';
        $d->rid = $cid;
        $d->did = $did;
        $d->save();

        echo $cid;

        break;

    case 'remove_file':
        $cid = route(2);
        $did = route(3);

        $d = ORM::for_table('ib_doc_rel')
            ->where('rtype', 'contact')
            ->where('rid', $cid)
            ->where('did', $did)
            ->find_one();

        if ($d) {
            $d->delete();
        }

        r2(U . 'contacts/view/' . $cid . '/files/', 's', $_L['Data Updated']);

        break;

    case 'gen_auto_login':
        $id = route(2);

        $d = ORM::for_table('crm_accounts')->find_one($id);

        if ($d) {
            $d->autologin = Ib_Str::random_string(20) . $id . time();
            $d->save();

            r2(
                U . 'contacts/view/' . $id . '/summary/',
                's',
                $_L['Created Successfully']
            );
        } else {
            echo 'Contact Not Found.';
        }

        break;

    case 'revoke_auto_login':
        $id = route(2);

        $d = ORM::for_table('crm_accounts')->find_one($id);

        if ($d) {
            $d->autologin = '';
            $d->save();

            r2(
                U . 'contacts/view/' . $id . '/summary/',
                's',
                $_L['Data Updated']
            );
        } else {
            echo 'Contact Not Found.';
        }

        break;

    case 'modal_view_company':
        $id = route(2);
        $id = str_replace('ae', '', $id);

        $extra_links = '';

        $id = route(2);
        $id = str_replace('ae', '', $id);

        $extra_links = '';

        $company = ORM::for_table('sys_companies')
            ->table_alias('c')
            ->select('c.*')
            ->select_expr('(SELECT account FROM crm_accounts_1 WHERE  id = c.lsr_id)', 'comp')
            ->select_expr('(SELECT email FROM crm_accounts_1 WHERE  id = c.lsr_id)', 'c_email')
            ->order_by_desc('c.id')
            ->find_one($cid);

        if ($company) {
            $ui->assign('company', $company);

            Event::trigger('contacts/modal_view_company/');

            $ui->assign('extra_links', $extra_links);

            $ui->display('modal_view_company.tpl');
        } else {
            echo 'Company Not Found';
        }


        break;

        //modal_view_company1

    case 'modal_view_company1':
        $id = route(2);
        $id = str_replace('ae', '', $id);

        $extra_links = '';

        $company1 = ORM::for_table('sys_companies1')
            ->table_alias('c')
            ->select('c.*')
            ->select_expr('(SELECT account FROM crm_accounts_1 WHERE  id = c.lsr_id)', 'comp')
            ->select_expr('(SELECT email FROM crm_accounts_1 WHERE  id = c.lsr_id)', 'c_email')
            ->order_by_desc('c.id')
            ->find_one($cid);

        if ($company1) {
            $ui->assign('company1', $company1);

            Event::trigger('contacts/modal_view_company1/');

            $ui->assign('extra_links', $extra_links);

            $ui->display('modal_view_company1.tpl');
        } else {
            echo 'Company Not Found';
        }

        break;
        //modal_view_company2

    case 'modal_view_company2':
        $id = route(2);
        $id = str_replace('ae', '', $id);

        $extra_links = '';

        $company2 = ORM::for_table('sys_companies2')
            ->table_alias('c')
            ->select('c.*')
            ->select_expr('(SELECT account FROM crm_accounts_1 WHERE  id = c.lsr_id)', 'comp')
            ->select_expr('(SELECT email FROM crm_accounts_1 WHERE  id = c.lsr_id)', 'c_email')
            ->order_by_desc('c.id')
            ->find_one($cid);

        if ($company2) {
            $ui->assign('company2', $company2);

            Event::trigger('contacts/modal_view_company2/');

            $ui->assign('extra_links', $extra_links);

            $ui->display('modal_view_company2.tpl');
        } else {
            echo 'Company Not Found';
        }

        break;
        //modal_view_company3

    case 'modal_view_company3':
        $id = route(2);
        $id = str_replace('ae', '', $id);

        $extra_links = '';

        $company3 = ORM::for_table('sys_companies3')
            ->table_alias('c')
            ->select('c.*')
            ->select_expr('(SELECT account FROM crm_accounts WHERE  id = c.lsp_id)', 'comp')
            ->select_expr('(SELECT email FROM crm_accounts WHERE  id = c.lsp_id)', 'c_email')
            ->order_by_desc('c.id')
            ->find_one($cid);

        if ($company3) {
            $ui->assign('company3', $company3);

            Event::trigger('contacts/modal_view_company3/');

            $ui->assign('extra_links', $extra_links);

            $ui->display('modal_view_company3.tpl');
        } else {
            echo 'Company Not Found';
        }

        break;

        //modal_view_company4

    case 'modal_view_company4':
        $id = route(2);
        $id = str_replace('ae', '', $id);

        $extra_links = '';

        $company4 = ORM::for_table('sys_companies4')
            ->table_alias('c')
            ->select('c.*')
            ->select_expr('(SELECT account FROM crm_accounts_1 WHERE  id = c.lsr_id)', 'comp')
            ->select_expr('(SELECT email FROM crm_accounts_1 WHERE  id = c.lsr_id)', 'c_email')
            ->order_by_desc('c.id')
            ->find_one($cid);

        if ($company4) {
            $ui->assign('company4', $company4);

            Event::trigger('contacts/modal_view_company4/');

            $ui->assign('extra_links', $extra_links);

            $ui->display('modal_view_company4.tpl');
        } else {
            echo 'Company Not Found';
        }

        break;
        //modal_view_company5

    case 'modal_view_company5':
        $id = route(2);
        $id = str_replace('ae', '', $id);

        $extra_links = '';

        $company5 = ORM::for_table('sys_companies5')
            ->table_alias('c')
            ->select('c.*')
            ->select_expr('(SELECT account FROM crm_accounts_1 WHERE  id = c.lsr_id)', 'comp')
            ->select_expr('(SELECT email FROM crm_accounts_1 WHERE  id = c.lsr_id)', 'c_email')
            ->order_by_desc('c.id')
            ->find_one($cid);

        if ($company5) {
            $ui->assign('company5', $company5);

            Event::trigger('contacts/modal_view_company5/');

            $ui->assign('extra_links', $extra_links);

            $ui->display('modal_view_company5.tpl');
        } else {
            echo 'Company Not Found';
        }

        break;

    case 'modal_view_company6':
        $id = route(2);
        $id = str_replace('ae', '', $id);

        $extra_links = '';

        $company6 = ORM::for_table('sys_companies6')
            ->table_alias('c')
            ->select('c.*')
            ->select_expr('(SELECT account FROM crm_accounts_1 WHERE  id = c.lsr_id)', 'comp')
            ->select_expr('(SELECT email FROM crm_accounts_1 WHERE  id = c.lsr_id)', 'c_email')
            ->order_by_desc('c.id')
            ->find_one($cid);

        if ($company6) {
            $ui->assign('company6', $company6);

            Event::trigger('contacts/modal_view_company6/');

            $ui->assign('extra_links', $extra_links);

            $ui->display('modal_view_company6.tpl');
        } else {
            echo 'Company Not Found';
        }

        break;

    case 'company_memo':
        $cid = _post('cid');

        $d = ORM::for_table('sys_companies')->find_one($cid);

        if ($d) {
            echo '<textarea class="form-control" id="v_memo" name="v_memo" rows="6">' .
                $d->notes .
                '</textarea> <button type="button" id="memo_update" class="btn btn-primary btn-block mt-sm act_memo_update">' .
                $_L['Save'] .
                '</button>';
        }

        break;

        //company1_memo

    case 'company1_memo':
        $cid = _post('cid');

        $d = ORM::for_table('sys_companies1')->find_one($cid);

        if ($d) {
            echo '<textarea class="form-control" id="v_memo" name="v_memo" rows="6">' .
                $d->notes .
                '</textarea> <button type="button" id="memo_update" class="btn btn-primary btn-block mt-sm act_memo_update">' .
                $_L['Save'] .
                '</button>';
        }

        break;


        //company2_memo

    case 'company2_memo':
        $cid = _post('cid');

        $d = ORM::for_table('sys_companies2')->find_one($cid);

        if ($d) {
            echo '<textarea class="form-control" id="v_memo" name="v_memo" rows="6">' .
                $d->notes .
                '</textarea> <button type="button" id="memo_update" class="btn btn-primary btn-block mt-sm act_memo_update">' .
                $_L['Save'] .
                '</button>';
        }

        break;

        //company3_memo

    case 'company3_memo':
        $cid = _post('cid');

        $d = ORM::for_table('sys_companies3')->find_one($cid);

        if ($d) {
            echo '<textarea class="form-control" id="v_memo" name="v_memo" rows="6">' .
                $d->notes .
                '</textarea> <button type="button" id="memo_update" class="btn btn-primary btn-block mt-sm act_memo_update">' .
                $_L['Save'] .
                '</button>';
        }

        break;

        //company4_memo

    case 'company4_memo':
        $cid = _post('cid');

        $d = ORM::for_table('sys_companies4')->find_one($cid);

        if ($d) {
            echo '<textarea class="form-control" id="v_memo" name="v_memo" rows="6">' .
                $d->notes .
                '</textarea> <button type="button" id="memo_update" class="btn btn-primary btn-block mt-sm act_memo_update">' .
                $_L['Save'] .
                '</button>';
        }

        break;

        //company5_memo

    case 'company5_memo':
        $cid = _post('cid');

        $d = ORM::for_table('crm_accounts')->find_one($cid);

        if ($d) {
            echo '<textarea class="form-control" id="v_memo" name="v_memo" rows="6">' .
                $d->notes .
                '</textarea> <button type="button" id="memo_update" class="btn btn-primary btn-block mt-sm act_memo_update">' .
                $_L['Save'] .
                '</button>';
        }

        break;

    case 'company6_memo':
        $cid = _post('cid');

        $d = ORM::for_table('sys_companies6')->find_one($cid);

        if ($d) {
            echo '<textarea class="form-control" id="v_memo" name="v_memo" rows="6">' .
                $d->notes .
                '</textarea> <button type="button" id="memo_update" class="btn btn-primary btn-block mt-sm act_memo_update">' .
                $_L['Save'] .
                '</button>';
        }

        break;

    case 'company_update_notes':
        $id = _post('id');

        $d = ORM::for_table('sys_companies')->find_one($id);

        if ($d) {
            $memo = $_POST['memo'];
            $d->notes = $memo;
            $d->save();
        }

        echo $_L['Data Updated'];

        break;
        //company_update_notes

    case 'company1_update_notes':
        $id = _post('id');

        $d = ORM::for_table('sys_companies1')->find_one($id);

        if ($d) {
            $memo = $_POST['memo'];
            $d->notes = $memo;
            $d->save();
        }

        echo $_L['Data Updated'];

        break;
    case 'company2_update_notes':
        $id = _post('id');

        $d = ORM::for_table('sys_companies2')->find_one($id);

        if ($d) {
            $memo = $_POST['memo'];
            $d->notes = $memo;
            $d->save();
        }

        echo $_L['Data Updated'];

        break;

    case 'company3_update_notes':
        $id = _post('id');

        $d = ORM::for_table('sys_companies3')->find_one($id);

        if ($d) {
            $memo = $_POST['memo'];
            $d->notes = $memo;
            $d->save();
        }

        echo $_L['Data Updated'];

        break;

    case 'company4_update_notes':
        $id = _post('id');

        $d = ORM::for_table('sys_companies4')->find_one($id);

        if ($d) {
            $memo = $_POST['memo'];
            $d->notes = $memo;
            $d->save();
        }

        echo $_L['Data Updated'];

        break;

    case 'company5_update_notes':
        $id = _post('id');

        $d = ORM::for_table('crm_accounts')->find_one($id);

        if ($d) {
            $memo = $_POST['memo'];
            $d->notes = $memo;
            $d->save();
        }

        echo $_L['Data Updated'];

        break;


    case 'company6_update_notes':
        $id = _post('id');

        $d = ORM::for_table('sys_companies6')->find_one($id);

        if ($d) {
            $memo = $_POST['memo'];
            $d->notes = $memo;
            $d->save();
        }

        echo $_L['Data Updated'];

        break;

    case 'company1_customers':
        $cid = _post('cid');
        // echo ($cid);

        $customers = ORM::for_table('crm_accounts_1')
            ->select('id')
            ->select('account')
            ->select('email')
            ->select('phone')
            ->where('cid', $cid)
            ->find_array();

        $tr_customers = '';

        foreach ($customers as $customer) {
            $tr_customers .=
                '<tr>
         <th scope="row"><a href="' .
                U .
                'contacts/view/' .
                $customer['id'] .
                '">' .
                $customer['id'] .
                '</a></th>
         <td><a href="' .
                U .
                'contacts/view/' .
                $customer['id'] .
                '">' .
                $customer['account'] .
                '</a></td>
         <td>' .
                $customer['email'] .
                '</td>
         <td>' .
                $customer['phone'] .
                '</td>
      </tr>';
        }

        if ($tr_customers == '') {
            $tr_customers =
                '<tr><td colspan="4">' .
                $_L['No Data Available'] .
                '</td></tr>';
        }

        echo '
<h4>' .
            $_L['LSR'] .
            '</h4>
<hr>

<hr>
<table class="table table-bordered">
   <thead>
      <tr>
         <th>#</th>
         <th>' .
            $_L['Name'] .
            '</th>
         <th>' .
            $_L['Email'] .
            '</th>
         <th>' .
            $_L['Phone'] .
            '</th>
      </tr>
   </thead>
   <tbody>
      ' .
            '<tr>
      <th scope="row"><a href="' .
            U .
            'contacts/view/' .
            $customer['id'] .
            '">' .
            $customer['id'] .
            '</a></th>
      <td><a href="' .
            U .
            'contacts/view/' .
            $customer['id'] .
            '">' .
            $customer['account'] .
            '</a></td>
      <td>' .
            $customer['email'] .
            '</td>
      <td>' .
            $customer['phone'] .
            '</td>
   </tr>';
        '
   </tbody>
</table>';

        break;
    case 'company2_customers':
        $cid = _post('cid');

        $customers = ORM::for_table('sys_companies1')
            ->table_alias('c')
            ->select('c.*')
            ->select_expr('(SELECT account FROM crm_accounts_1 WHERE  id = c.lsr_id)', 'comp')
            ->select_expr('(SELECT email FROM crm_accounts_1 WHERE  id = c.lsr_id)', 'c_email')
            ->order_by_desc('c.id')
            ->find_one($cid);

        $tr_customers = '';

        foreach ($customers as $customer) {
            $tr_customers .=
                '<tr>
         <th scope="row"><a href="' .
                U .
                'contacts/view/' .
                $customer['id'] .
                '">' .
                $customer['id'] .
                '</a></th>
         <td><a href="' .
                U .
                'contacts/view/' .
                $customer['id'] .
                '">' .
                $customer['account'] .
                '</a></td>
         <td>' .
                $customer['c_email'] .
                '</td>
         <td>' .
                $customer['phone'] .
                '</td>
      </tr>';
        }

        if ($tr_customers == '') {
            $tr_customers =
                '<tr><td colspan="4">' .
                $_L['No Data Available'] .
                '</td></tr>';
        }

        echo '
<h4>' .
            $_L['Customers'] .
            '</h4>
<hr>
<a class="btn btn-primary" href="' .
            U .
            'contacts/add/0/' .
            $cid .
            '">' .
            $_L['Add Customer'] .
            '</a>
<hr>
<table class="table table-bordered">
   <thead>
      <tr>
         <th>#</th>
         <th>' .
            $_L['Name'] .
            '</th>
         <th>' .
            $_L['Email'] .
            '</th>
         <th>' .
            $_L['Phone'] .
            '</th>
      </tr>
   </thead>
   <tbody>
      ' .
            $tr_customers .
            '
   </tbody>
</table>';

        break;
    case 'company4_customers':
        $cid = _post('cid');

        $customers = ORM::for_table('crm_accounts')
            ->select('id')
            ->select('account')
            ->select('email')
            ->select('phone')
            ->where('cid', $cid)
            ->find_array();

        $tr_customers = '';

        foreach ($customers as $customer) {
            $tr_customers .=
                '<tr>
         <th scope="row"><a href="' .
                U .
                'contacts/view/' .
                $customer['id'] .
                '">' .
                $customer['id'] .
                '</a></th>
         <td><a href="' .
                U .
                'contacts/view/' .
                $customer['id'] .
                '">' .
                $customer['account'] .
                '</a></td>
         <td>' .
                $customer['email'] .
                '</td>
         <td>' .
                $customer['phone'] .
                '</td>
      </tr>';
        }

        if ($tr_customers == '') {
            $tr_customers =
                '<tr><td colspan="4">' .
                $_L['No Data Available'] .
                '</td></tr>';
        }

        echo '
<h4>' .
            $_L['Customers'] .
            '</h4>
<hr>
<a class="btn btn-primary" href="' .
            U .
            'contacts/add/0/' .
            $cid .
            '">' .
            $_L['Add Customer'] .
            '</a>
<hr>
<table class="table table-bordered">
   <thead>
      <tr>
         <th>#</th>
         <th>' .
            $_L['Name'] .
            '</th>
         <th>' .
            $_L['Email'] .
            '</th>
         <th>' .
            $_L['Phone'] .
            '</th>
      </tr>
   </thead>
   <tbody>
      ' .
            $tr_customers .
            '
   </tbody>
</table>';

        break;
    case 'company5_customers':
        $cid = _post('cid');

        $customers = ORM::for_table('crm_accounts')
            ->select('id')
            ->select('account')
            ->select('email')
            ->select('phone')
            ->where('cid', $cid)
            ->find_array();

        $tr_customers = '';

        foreach ($customers as $customer) {
            $tr_customers .=
                '<tr>
         <th scope="row"><a href="' .
                U .
                'contacts/view/' .
                $customer['id'] .
                '">' .
                $customer['id'] .
                '</a></th>
         <td><a href="' .
                U .
                'contacts/view/' .
                $customer['id'] .
                '">' .
                $customer['account'] .
                '</a></td>
         <td>' .
                $customer['email'] .
                '</td>
         <td>' .
                $customer['phone'] .
                '</td>
      </tr>';
        }

        if ($tr_customers == '') {
            $tr_customers =
                '<tr><td colspan="4">' .
                $_L['No Data Available'] .
                '</td></tr>';
        }

        echo '
<h4>' .
            $_L['Customers'] .
            '</h4>
<hr>
<a class="btn btn-primary" href="' .
            U .
            'contacts/add/0/' .
            $cid .
            '">' .
            $_L['Add Customer'] .
            '</a>
<hr>
<table class="table table-bordered">
   <thead>
      <tr>
         <th>#</th>
         <th>' .
            $_L['Name'] .
            '</th>
         <th>' .
            $_L['Email'] .
            '</th>
         <th>' .
            $_L['Phone'] .
            '</th>
      </tr>
   </thead>
   <tbody>
      ' .
            $tr_customers .
            '
   </tbody>
</table>';

        break;
    case 'company6_customers':
        $cid = _post('cid');

        $customers = ORM::for_table('crm_accounts')
            ->select('id')
            ->select('account')
            ->select('email')
            ->select('phone')
            ->where('cid', $cid)
            ->find_array();

        $tr_customers = '';

        foreach ($customers as $customer) {
            $tr_customers .=
                '<tr>
         <th scope="row"><a href="' .
                U .
                'contacts/view/' .
                $customer['id'] .
                '">' .
                $customer['id'] .
                '</a></th>
         <td><a href="' .
                U .
                'contacts/view/' .
                $customer['id'] .
                '">' .
                $customer['account'] .
                '</a></td>
         <td>' .
                $customer['email'] .
                '</td>
         <td>' .
                $customer['phone'] .
                '</td>
      </tr>';
        }

        if ($tr_customers == '') {
            $tr_customers =
                '<tr><td colspan="4">' .
                $_L['No Data Available'] .
                '</td></tr>';
        }

        echo '
<h4>' .
            $_L['Customers'] .
            '</h4>
<hr>
<a class="btn btn-primary" href="' .
            U .
            'contacts/add/0/' .
            $cid .
            '">' .
            $_L['Add Customer'] .
            '</a>
<hr>
<table class="table table-bordered">
   <thead>
      <tr>
         <th>#</th>
         <th>' .
            $_L['Name'] .
            '</th>
         <th>' .
            $_L['Email'] .
            '</th>
         <th>' .
            $_L['Phone'] .
            '</th>
      </tr>
   </thead>
   <tbody>
      ' .
            $tr_customers .
            '
   </tbody>
</table>';

        break;
    case 'company_summary':
        $cid = _post('cid');

        $cid = str_replace('ae', '', $cid);
        echo ('2');
        $d = ORM::for_table('sys_companies')
            ->table_alias('c')
            ->select('c.*')
            ->select_expr('(SELECT account FROM crm_accounts_1 WHERE  id = c.lsr_id)', 'comp')
            ->select_expr('(SELECT email FROM crm_accounts_1 WHERE  id = c.lsr_id)', 'c_email')
            ->order_by_desc('c.id')
            ->find_one($cid);

        if ($d) {
            $url = $d->url;

            if ($url == 'http://') {
                $url = '';
            }

            echo '<p>

                            <strong>' .
                $_L['LSR'] .
                ': </strong>  ' .
                $d->comp . ',  <strong>email:  </strong>   ' . $d->c_email .
                '<br>
                            <strong>' .
                $_L['Types of vehicules'] .
                ': </strong>  ' .
                $d->types_of_equipment .
                '<br>
                <strong>' .
                $_L['Rental start date'] .
                ': </strong>  ' .
                $d->start_date .
                '<br>
                <strong>' .
                $_L['Rental end date'] .
                ': </strong>  ' .
                $d->end_date .
                '<br>
                            <strong>' .
                $_L['Delivery location'] .
                ': </strong>  ' .
                ($d->delivery_location != ''
                    ? '<a href="#" class="send_email">' . $d->delivery_location . '</a>'
                    : '') .
                '<br>
                            <strong>' .
                $_L['Proposed price per hours'] .
                ': </strong>  ' .
                $d->pprice_per_hour .
                '<br>
                         
                            
                            



                        </p>

                        

                        <a href="#" class="md-btn md-btn-primary cedit" id="me' .
                $d->id .
                '"><i class="fa fa-pencil"></i> ' .
                $_L['Edit'] .
                '</a>
                        
                        
                        <hr>
                        
                        <a href="#" class="md-btn md-btn-primary li_memo"><i class="fa fa-pencil"></i> ' .
                $_L['Memo'] .
                '</a>
                        
                        <hr>
                        
                        ' .
                $d->notes .
                '
                        
                        ';
        }

        break;
        //company1_summary

    case 'company1_summary':
        $cid = _post('cid');

        $cid = str_replace('ae', '', $cid);

        $d = ORM::for_table('sys_companies1')
            ->table_alias('c')
            ->select('c.*')
            ->select_expr('(SELECT account FROM crm_accounts_1 WHERE  id = c.lsr_id)', 'comp')
            ->select_expr('(SELECT email FROM crm_accounts_1 WHERE  id = c.lsr_id)', 'c_email')
            ->order_by_desc('c.id')
            ->find_one($cid);

        if ($d) {
            $url = $d->url;

            if ($url == 'http://') {
                $url = '';
            }

            echo '<p>

                            <strong>' .
                $_L['LSR'] .
                ': </strong>  ' .
                $d->comp . ',  <strong>email:  </strong>   ' . $d->c_email .
                '<br>
                            <strong>' .
                $_L['Types of vehicules'] .
                ': </strong>  ' .
                $d->types_of_equipment .
                '<br>
                <strong>' .
                $_L['Rental start date'] .
                ': </strong>  ' .
                $d->start_date .
                '<br>
                <strong>' .
                $_L['Rental end date'] .
                ': </strong>  ' .
                $d->end_date .
                '<br>
                            <strong>' .
                $_L['Delivery location'] .
                ': </strong>  ' .
                ($d->delivery_location != ''
                    ? '<a href="#" class="send_email">' . $d->delivery_location . '</a>'
                    : '') .
                '<br>
                            <strong>' .
                $_L['Proposed price per hours'] .
                ': </strong>  ' .
                $d->pprice_per_hour .
                '<br>
                         
                            
                            



                        </p>

                        

                        <a href="#" class="md-btn md-btn-primary cedit" id="me' .
                $d->id .
                '"><i class="fa fa-pencil"></i> ' .
                $_L['Edit'] .
                '</a>
                        
                        
                        <hr>
                        
                        <a href="#" class="md-btn md-btn-primary li_memo"><i class="fa fa-pencil"></i> ' .
                $_L['Memo'] .
                '</a>
                        
                        <hr>
                        
                        ' .
                $d->notes .
                '
                        
                        ';
        }

        break;
        //company1_summary

    case 'company2_summary':
        $cid = _post('cid');

        $cid = str_replace('ae', '', $cid);

        $d = ORM::for_table('sys_companies2')
            ->table_alias('c')
            ->select('c.*')
            ->select_expr('(SELECT id FROM sys_documents WHERE  file_dl_token = c.picture1_file_token)', 'picture1_file_id')
            ->select_expr('(SELECT id FROM sys_documents WHERE  file_dl_token = c.picture2_file_token)', 'picture2_file_id')
            ->select_expr('(SELECT id FROM sys_documents WHERE  file_dl_token = c.picture3_file_token)', 'picture3_file_id')
            ->select_expr('(SELECT id FROM sys_documents WHERE  file_dl_token = c.picture4_file_token)', 'picture4_file_id')
            ->select_expr('(SELECT account FROM crm_accounts_1 WHERE  id = c.lsr_id)', 'comp')
            ->select_expr('(SELECT email FROM crm_accounts_1 WHERE  id = c.lsr_id)', 'c_email')
            ->order_by_desc('c.id')
            ->find_one($cid);

        if ($d) {
            $url = $d->url;

            if ($url == 'http://') {
                $url = '';
            }

            echo '<p>

                            <strong>' .
                $_L['LSR'] .
                ': </strong>  ' .
                $d->comp . ',  <strong>email:  </strong>   ' . $d->c_email .
                '<br>
                <strong>' .
                $_L['Type of Machine'] .
                ': </strong>  ' .
                $d->types_of_machine .
                '<br>
                <strong>' .
                $_L['Other Types'] .
                ': </strong>  ' .
                $d->other_type .
                '<br>
                <strong>' .
                $_L['Rental start date'] .
                ': </strong>  ' .
                $d->start_date .
                '<br>
                <strong>' .
                $_L['Rental end date'] .
                ': </strong>  ' .
                $d->end_date .
                '<br>
                <strong>' .
                $_L['Number of rental day'] .
                ': </strong>  ' .
                $d->number_of_rental_day .
                '<br>
                            <strong>' .
                $_L['Proposed price per hours'] .
                ': </strong>  ' .
                $d->proposed_price_per_hours .
                '<br>
                            <strong>' .
                $_L['Number of working hours'] .
                ': </strong>  ' .
                $d->number_of_working_hours .
                '<br>
                <strong>' .
                '
                            <strong>' .
                $_L['Observations'] .
                ': </strong>  ' .
                $d->observations .
                '<br>
                         
                            
                            



                        </p>

                        

                        <a href="#" class="md-btn md-btn-primary cedit" id="me' .
                $d->id .
                '"><i class="fa fa-pencil"></i> ' .
                $_L['Edit'] .
                '</a>
                        
                        
                        <hr>
                        
                        <a href="#" class="md-btn md-btn-primary li_memo"><i class="fa fa-pencil"></i> ' .
                $_L['Memo'] .
                '</a>
                        
                        <hr>
                        
                        ' .
                $d->notes .
                '
                        
                        ';
        }

        break;


    case 'company3_summary':
        $cid = _post('cid');

        $cid = str_replace('ae', '', $cid);

        $d = ORM::for_table('sys_companies3')
            ->table_alias('c')
            ->select('c.*')
            ->select_expr('(SELECT truck_immatriculation FROM sys_companies5 WHERE  id = c.truck_id)', 'truck_immatriculation')
            ->select_expr('(SELECT account FROM crm_accounts WHERE  id = c.lsp_id)', 'comp')
            ->select_expr('(SELECT email FROM crm_accounts WHERE  id = c.lsp_id)', 'c_email')
            ->order_by_desc('c.id')
            ->find_one($cid);

        if ($d) {
            $url = $d->url;

            if ($url == 'http://') {
                $url = '';
            }

            echo '<p>

                        <strong>' .
                $_L['lsp'] .
                ': </strong>  ' .
                $d->comp . ',  <strong>email:  </strong>   ' . $d->c_email .
                '<br>
            <strong>' .
                $_L['Truck Immatriculation'] .
                ': </strong>  ' .
                $d->truck_immatriculation .
                '<br>
            <strong>' .
                $_L['name'] .
                ': </strong>  ' .
                $d->name .
                '<br>
            <strong>' .
                $_L['N° phone'] .
                ': </strong>  ' .
                $d->phone .
                '<br>
            <strong>' .
                $_L['N° permit'] .
                ': </strong>  ' .
                $d->permit_number .
                '<br>
            <strong>' .
                $_L['Permit Category'] .
                ': </strong>  ' .
                $d->permit_category .
                '<br>
                        <strong>' .
                $_L['Expiry Date'] .
                ': </strong>  ' .
                $d->expiry_date .
                '<br>
                        <strong>' .
                $_L['Suspend'] .
                ': </strong>  ' .
                $d->suspend .
                '<br>
            <strong>' .
                '
                        <strong>' .
                $_L['Reason for suspend'] .
                ': </strong>  ' .
                $d->comment .
                '<br>
                     
                        
                        



                    </p>

                    

                    <a href="#" class="md-btn md-btn-primary cedit" id="me' .
                $d->id .
                '"><i class="fa fa-pencil"></i> ' .
                $_L['Edit'] .
                '</a>
                    
                    
                    <hr>
                    
                    <a href="#" class="md-btn md-btn-primary li_memo"><i class="fa fa-pencil"></i> ' .
                $_L['Memo'] .
                '</a>
                    
                    <hr>
                    
                    ' .
                $d->notes .
                '
                    
                    ';
        }

        break;




    case 'company4_summary':
        $cid = _post('cid');

        $cid = str_replace('ae', '', $cid);

        $d = ORM::for_table('sys_companies4')
            ->table_alias('c')
            ->select('c.*')
            ->select_expr('(SELECT account FROM crm_accounts_1 WHERE  id = c.lsr_id)', 'comp')
            ->select_expr('(SELECT email FROM crm_accounts_1 WHERE  id = c.lsr_id)', 'c_email')
            ->order_by_desc('c.id')
            ->find_one($cid);

        if ($d) {
            $url = $d->url;

            if ($url == 'http://') {
                $url = '';
            }

            echo '<p>

                        <strong>' .
                $_L['LSR'] .
                ': </strong>  ' .
                $d->comp . ',  <strong>email:  </strong>   ' . $d->c_email .
                '<br>
            <strong>' .
                $_L['Type of packaging material'] .
                ': </strong>  ' .
                $d->type_of_materials .
                '<br>
            <strong>' .
                $_L['Size'] .
                ': </strong>  ' .
                $d->size .
                '<br>
            <strong>' .
                $_L['Weight'] .
                ': </strong>  ' .
                $d->weight .
                '<br>
            <strong>' .
                $_L['Estimated value'] .
                ': </strong>  ' .
                $d->estimated_value .
                '<br>
            <strong>' .
                $_L['Destination country'] .
                ': </strong>  ' .
                $d->destination_country .
                '<br>
                        <strong>' .
                $_L['Delivery location'] .
                ': </strong>  ' .
                $d->delivery_location .
                '<br>
                        <strong>' .
                $_L['Quantity'] .
                ': </strong>  ' .
                $d->quantity .
                '<br>
            <strong>' .
                '
                        <strong>' .
                $_L['Informations'] .
                ': </strong>  ' .
                $d->informations .
                '<br>
                     
                        
                        



                    </p>

                    

                    <a href="#" class="md-btn md-btn-primary cedit" id="me' .
                $d->id .
                '"><i class="fa fa-pencil"></i> ' .
                $_L['Edit'] .
                '</a>
                    
                    
                    <hr>
                    
                    <a href="#" class="md-btn md-btn-primary li_memo"><i class="fa fa-pencil"></i> ' .
                $_L['Memo'] .
                '</a>
                    
                    <hr>
                    
                    ' .
                $d->notes .
                '
                    
                    ';
        }

        break;




    case 'company5_summary':
        $cid = _post('cid');

        $cid = str_replace('ae', '', $cid);

        $d = ORM::for_table('sys_companies5')
            ->table_alias('c')
            ->select('c.*')
            ->select_expr('(SELECT account FROM crm_accounts WHERE  id = c.lsp_id)', 'comp')
            ->select_expr('(SELECT email FROM crm_accounts WHERE  id = c.lsp_id)', 'c_email')
            ->order_by_desc('c.id')
            ->find_one($cid);

        if ($d) {
            $url = $d->url;

            if ($url == 'http://') {
                $url = '';
            }

            echo '<p>

                        <strong>' .
                $_L['lsp'] .
                ': </strong>  ' .
                $d->comp . ',  <strong>email:  </strong>   ' . $d->c_email .
                '<br>
            <strong>' .
                $_L['Truck Immatriculation'] .
                ': </strong>  ' .
                $d->truck_immatriculation .
                '<br>
            <strong>' .
                $_L['Type of truck'] .
                ': </strong>  ' .
                $d->type_of_truck .
                '<br>
            <strong>' .
                $_L['Truck Insurance start date'] .
                ': </strong>  ' .
                $d->insurance_start_date .
                '<br>
            <strong>' .
                $_L['Truck Insurance expiration date'] .
                ': </strong>  ' .
                $d->insurance_expiration_date .
                '<br>
            <strong>' .
                $_L['Truck availability'] .
                ': </strong>  ' .
                $d->truck_availability .
                '<br>
                        <strong>' .
                $_L['Road Worthiness'] .
                ': </strong>  ' .
                $d->Road_Worthiness .
                '<br>
                        <strong>' .
                $_L['Date of entry into circulation'] .
                ': </strong>  ' .
                $d->date_of_entry .
                '<br>
            <strong>' .
                '
                        <strong>' .
                $_L['Chassis number'] .
                ': </strong>  ' .
                $d->chassis_number .
                '<br>
                     
                        
                        



                    </p>

                    

                    <a href="#" class="md-btn md-btn-primary cedit" id="me' .
                $d->id .
                '"><i class="fa fa-pencil"></i> ' .
                $_L['Edit'] .
                '</a>
                    
                    
                    <hr>
                    
                    <a href="#" class="md-btn md-btn-primary li_memo"><i class="fa fa-pencil"></i> ' .
                $_L['Memo'] .
                '</a>
                    
                    <hr>
                    
                    ' .
                $d->notes .
                '
                    
                    ';
        }

        break;



    case 'company6_summary':
        $cid = _post('cid');

        $cid = str_replace('ae', '', $cid);

        $d = ORM::for_table('sys_companies6')
            ->table_alias('c')
            ->select('c.*')
            ->select_expr('(SELECT account FROM crm_accounts_1 WHERE  id = c.lsr_id)', 'comp')
            ->select_expr('(SELECT email FROM crm_accounts_1 WHERE  id = c.lsr_id)', 'c_email')
            ->order_by_desc('c.id')
            ->find_one($cid);

        if ($d) {
            $url = $d->url;

            if ($url == 'http://') {
                $url = '';
            }

            echo '<p>

                        <strong>' .
                $_L['LSR'] .
                ': </strong>  ' .
                $d->comp . ',  <strong>email:  </strong>   ' . $d->c_email .
                '<br>
            <strong>' .
                $_L['Types of goods'] .
                ': </strong>  ' .
                $d->types_of_goods .
                '<br>
            <strong>' .
                $_L['Estimated value (XAF)'] .
                ': </strong>  ' .
                $d->estimated_value .
                '<br>
            <strong>' .
                $_L['Weight (Kg)'] .
                ': </strong>  ' .
                $d->weight .
                '<br>
            <strong>' .
                $_L['Origin Country'] .
                ': </strong>  ' .
                $d->origin_country .
                '<br>
            <strong>' .
                $_L['Destination country'] .
                ': </strong>  ' .
                $d->destination_country .
                '<br>
                        <strong>' .
                $_L['Pick-up Location'] .
                ': </strong>  ' .
                $d->pick_uplocation .
                '<br>
                        <strong>' .
                $_L['Delivery Location'] .
                ': </strong>  ' .
                $d->delivery_location .
                '<br>
            <strong>' .
                $_L['Transit'] .
                ': </strong>  ' .
                $d->transit .
                '<br>
            <strong>' .
                $_L['Loading Date'] .
                ': </strong>  ' .
                $d->loading_date .
                '<br>
            <strong>' .
                $_L['Loading Services'] .
                ': </strong>  ' .
                $d->loading_services .
                '<br>
            <strong>' .
                $_L['Off-loading Service'] .
                ': </strong>  ' .
                $d->off_loading_service .
                '<br>
            <strong>' .
                $_L['Recipient name'] .
                ': </strong>  ' .
                $d->recipient_name .
                '<br>
            <strong>' .
                $_L['transport insurance'] .
                ': </strong>  ' .
                $d->transport_insurance .
                '<br>
            <strong>' .
                $_L['Do you need tracking ?'] .
                ': </strong>  ' .
                $d->tracking .
                '<br>
            <strong>' .
                '
                        <strong>' .
                $_L['Observations'] .
                ': </strong>  ' .
                $d->observations .
                '<br>
                     
                        
                        



                    </p>

                    

                    <a href="#" class="md-btn md-btn-primary cedit" id="me' .
                $d->id .
                '"><i class="fa fa-pencil"></i> ' .
                $_L['Edit'] .
                '</a>
                    
                    
                    <hr>
                    
                    <a href="#" class="md-btn md-btn-primary li_memo"><i class="fa fa-pencil"></i> ' .
                $_L['Memo'] .
                '</a>
                    
                    <hr>
                    
                    ' .
                $d->notes .
                '
                    
                    ';
        }

        break;





    case 'company_invoices':
        $cid = _post('cid');
        $d = ORM::for_table('sys_companies')->find_one($cid);

        if ($d) {
            $customers = Contacts::findByCompany($cid);

            if ($customers) {
                $invoices = ORM::for_table('sys_invoices')
                    ->where_in('userid', $customers)
                    ->find_array();

                $dt = '';

                foreach ($invoices as $invoice) {
                    $dt .=
                        '<tr>
            <td><a href="' .
                        U .
                        'invoices/view/' .
                        $invoice['id'] .
                        '/">' .
                        $invoice['invoicenum'] .
                        ' ' .
                        ($invoice['cn'] != ''
                            ? $invoice['cn']
                            : $invoice['id']) .
                        '</a> </td>
            <td><a href="' .
                        U .
                        'contacts/view/' .
                        $invoice['userid'] .
                        '/">' .
                        $invoice['account'] .
                        '</a></td>
            <td class="amount" data-a-dec="." data-a-sep="," data-a-pad="true" data-p-sign="p" data-a-sign="$ " data-d-group="3">' .
                        $invoice['total'] .
                        '</td>
            <td>' .
                        $invoice['date'] .
                        '</td>
            <td>' .
                        $invoice['duedate'] .
                        '</td>
            <td>' .
                        $invoice['status'] .
                        '</td>
            <td>
                <a href="' .
                        U .
                        'invoices/view/' .
                        $invoice['id'] .
                        '/" class="btn btn-primary btn-xs"><i class="fa fa-check"></i> </a>
                <a href="' .
                        U .
                        'invoices/edit/' .
                        $invoice['id'] .
                        '/" class="btn btn-info btn-xs"><i class="fa fa-pencil"></i> </a>
            </td>
        </tr>';
                }

                if ($dt == '') {
                    $tds =
                        '<tr><td colspan="7">' .
                        $_L['No Data Available'] .
                        '</td> </tr>';
                } else {
                    $tds = $dt;
                }
            } else {
                $tds =
                    '<tr><td colspan="7">' .
                    $_L['No Data Available'] .
                    '</td> </tr>';
            }

            echo '<table class="table table-bordered table-hover sys_table">
    <thead>
    <tr>
        <th>#</th>
        <th>' .
                $_L['Customer'] .
                '</th>
        <th>' .
                $_L['Amount'] .
                '</th>
        <th>' .
                $_L['Invoice Date'] .
                '</th>
        <th>' .
                $_L['Due Date'] .
                '</th>
        <th>' .
                $_L['Status'] .
                '</th>
        <th class="text-right">' .
                $_L['Manage'] .
                '</th>
    </tr>
    </thead>
    <tbody>

            
           ' .
                $tds .
                ' 
    

    </tbody>
</table>';
        }

        break;

        //company1_invoices
    case 'company1_invoices':
        $cid = _post('cid');
        $d = ORM::for_table('sys_companies1')->find_one($cid);

        if ($d) {
            $customers = Contacts::findByCompany($cid);

            if ($customers) {
                $invoices = ORM::for_table('sys_invoices')
                    ->where_in('userid', $customers)
                    ->find_array();

                $dt = '';

                foreach ($invoices as $invoice) {
                    $dt .=
                        '<tr>
            <td><a href="' .
                        U .
                        'invoices/view/' .
                        $invoice['id'] .
                        '/">' .
                        $invoice['invoicenum'] .
                        ' ' .
                        ($invoice['cn'] != ''
                            ? $invoice['cn']
                            : $invoice['id']) .
                        '</a> </td>
            <td><a href="' .
                        U .
                        'contacts/view/' .
                        $invoice['userid'] .
                        '/">' .
                        $invoice['account'] .
                        '</a></td>
            <td class="amount" data-a-dec="." data-a-sep="," data-a-pad="true" data-p-sign="p" data-a-sign="$ " data-d-group="3">' .
                        $invoice['total'] .
                        '</td>
            <td>' .
                        $invoice['date'] .
                        '</td>
            <td>' .
                        $invoice['duedate'] .
                        '</td>
            <td>' .
                        $invoice['status'] .
                        '</td>
            <td>
                <a href="' .
                        U .
                        'invoices/view/' .
                        $invoice['id'] .
                        '/" class="btn btn-primary btn-xs"><i class="fa fa-check"></i> </a>
                <a href="' .
                        U .
                        'invoices/edit/' .
                        $invoice['id'] .
                        '/" class="btn btn-info btn-xs"><i class="fa fa-pencil"></i> </a>
            </td>
        </tr>';
                }

                if ($dt == '') {
                    $tds =
                        '<tr><td colspan="7">' .
                        $_L['No Data Available'] .
                        '</td> </tr>';
                } else {
                    $tds = $dt;
                }
            } else {
                $tds =
                    '<tr><td colspan="7">' .
                    $_L['No Data Available'] .
                    '</td> </tr>';
            }

            echo '<table class="table table-bordered table-hover sys_table">
    <thead>
    <tr>
        <th>#</th>
        <th>' .
                $_L['Customer'] .
                '</th>
        <th>' .
                $_L['Amount'] .
                '</th>
        <th>' .
                $_L['Invoice Date'] .
                '</th>
        <th>' .
                $_L['Due Date'] .
                '</th>
        <th>' .
                $_L['Status'] .
                '</th>
        <th class="text-right">' .
                $_L['Manage'] .
                '</th>
    </tr>
    </thead>
    <tbody>

            
           ' .
                $tds .
                ' 
    

    </tbody>
</table>';
        }

        break;

        //company2_invoices
    case 'company2_invoices':
        $cid = _post('cid');
        $d = ORM::for_table('sys_companies2')->find_one($cid);

        if ($d) {
            $customers = Contacts::findByCompany($cid);

            if ($customers) {
                $invoices = ORM::for_table('sys_invoices')
                    ->where_in('userid', $customers)
                    ->find_array();

                $dt = '';

                foreach ($invoices as $invoice) {
                    $dt .=
                        '<tr>
              <td><a href="' .
                        U .
                        'invoices/view/' .
                        $invoice['id'] .
                        '/">' .
                        $invoice['invoicenum'] .
                        ' ' .
                        ($invoice['cn'] != ''
                            ? $invoice['cn']
                            : $invoice['id']) .
                        '</a> </td>
              <td><a href="' .
                        U .
                        'contacts/view/' .
                        $invoice['userid'] .
                        '/">' .
                        $invoice['account'] .
                        '</a></td>
              <td class="amount" data-a-dec="." data-a-sep="," data-a-pad="true" data-p-sign="p" data-a-sign="$ " data-d-group="3">' .
                        $invoice['total'] .
                        '</td>
              <td>' .
                        $invoice['date'] .
                        '</td>
              <td>' .
                        $invoice['duedate'] .
                        '</td>
              <td>' .
                        $invoice['status'] .
                        '</td>
              <td>
                  <a href="' .
                        U .
                        'invoices/view/' .
                        $invoice['id'] .
                        '/" class="btn btn-primary btn-xs"><i class="fa fa-check"></i> </a>
                  <a href="' .
                        U .
                        'invoices/edit/' .
                        $invoice['id'] .
                        '/" class="btn btn-info btn-xs"><i class="fa fa-pencil"></i> </a>
              </td>
          </tr>';
                }

                if ($dt == '') {
                    $tds =
                        '<tr><td colspan="7">' .
                        $_L['No Data Available'] .
                        '</td> </tr>';
                } else {
                    $tds = $dt;
                }
            } else {
                $tds =
                    '<tr><td colspan="7">' .
                    $_L['No Data Available'] .
                    '</td> </tr>';
            }

            echo '<table class="table table-bordered table-hover sys_table">
      <thead>
      <tr>
          <th>#</th>
          <th>' .
                $_L['Customer'] .
                '</th>
          <th>' .
                $_L['Amount'] .
                '</th>
          <th>' .
                $_L['Invoice Date'] .
                '</th>
          <th>' .
                $_L['Due Date'] .
                '</th>
          <th>' .
                $_L['Status'] .
                '</th>
          <th class="text-right">' .
                $_L['Manage'] .
                '</th>
      </tr>
      </thead>
      <tbody>
  
              
             ' .
                $tds .
                ' 
      
  
      </tbody>
  </table>';
        }

        break;

        //company2_invoices
    case 'company3_invoices':
        $cid = _post('cid');
        $d = ORM::for_table('sys_companies3')->find_one($cid);

        if ($d) {
            $customers = Contacts::findByCompany($cid);

            if ($customers) {
                $invoices = ORM::for_table('sys_invoices')
                    ->where_in('userid', $customers)
                    ->find_array();

                $dt = '';

                foreach ($invoices as $invoice) {
                    $dt .=
                        '<tr>
               <td><a href="' .
                        U .
                        'invoices/view/' .
                        $invoice['id'] .
                        '/">' .
                        $invoice['invoicenum'] .
                        ' ' .
                        ($invoice['cn'] != ''
                            ? $invoice['cn']
                            : $invoice['id']) .
                        '</a> </td>
               <td><a href="' .
                        U .
                        'contacts/view/' .
                        $invoice['userid'] .
                        '/">' .
                        $invoice['account'] .
                        '</a></td>
               <td class="amount" data-a-dec="." data-a-sep="," data-a-pad="true" data-p-sign="p" data-a-sign="$ " data-d-group="3">' .
                        $invoice['total'] .
                        '</td>
               <td>' .
                        $invoice['date'] .
                        '</td>
               <td>' .
                        $invoice['duedate'] .
                        '</td>
               <td>' .
                        $invoice['status'] .
                        '</td>
               <td>
                   <a href="' .
                        U .
                        'invoices/view/' .
                        $invoice['id'] .
                        '/" class="btn btn-primary btn-xs"><i class="fa fa-check"></i> </a>
                   <a href="' .
                        U .
                        'invoices/edit/' .
                        $invoice['id'] .
                        '/" class="btn btn-info btn-xs"><i class="fa fa-pencil"></i> </a>
               </td>
           </tr>';
                }

                if ($dt == '') {
                    $tds =
                        '<tr><td colspan="7">' .
                        $_L['No Data Available'] .
                        '</td> </tr>';
                } else {
                    $tds = $dt;
                }
            } else {
                $tds =
                    '<tr><td colspan="7">' .
                    $_L['No Data Available'] .
                    '</td> </tr>';
            }

            echo '<table class="table table-bordered table-hover sys_table">
       <thead>
       <tr>
           <th>#</th>
           <th>' .
                $_L['Customer'] .
                '</th>
           <th>' .
                $_L['Amount'] .
                '</th>
           <th>' .
                $_L['Invoice Date'] .
                '</th>
           <th>' .
                $_L['Due Date'] .
                '</th>
           <th>' .
                $_L['Status'] .
                '</th>
           <th class="text-right">' .
                $_L['Manage'] .
                '</th>
       </tr>
       </thead>
       <tbody>
   
               
              ' .
                $tds .
                ' 
       
   
       </tbody>
   </table>';
        }

        break;

        //company2_invoices
    case 'company4_invoices':
        $cid = _post('cid');
        $d = ORM::for_table('sys_companies4')->find_one($cid);

        if ($d) {
            $customers = Contacts::findByCompany($cid);

            if ($customers) {
                $invoices = ORM::for_table('sys_invoices')
                    ->where_in('userid', $customers)
                    ->find_array();

                $dt = '';

                foreach ($invoices as $invoice) {
                    $dt .=
                        '<tr>
              <td><a href="' .
                        U .
                        'invoices/view/' .
                        $invoice['id'] .
                        '/">' .
                        $invoice['invoicenum'] .
                        ' ' .
                        ($invoice['cn'] != ''
                            ? $invoice['cn']
                            : $invoice['id']) .
                        '</a> </td>
              <td><a href="' .
                        U .
                        'contacts/view/' .
                        $invoice['userid'] .
                        '/">' .
                        $invoice['account'] .
                        '</a></td>
              <td class="amount" data-a-dec="." data-a-sep="," data-a-pad="true" data-p-sign="p" data-a-sign="$ " data-d-group="3">' .
                        $invoice['total'] .
                        '</td>
              <td>' .
                        $invoice['date'] .
                        '</td>
              <td>' .
                        $invoice['duedate'] .
                        '</td>
              <td>' .
                        $invoice['status'] .
                        '</td>
              <td>
                  <a href="' .
                        U .
                        'invoices/view/' .
                        $invoice['id'] .
                        '/" class="btn btn-primary btn-xs"><i class="fa fa-check"></i> </a>
                  <a href="' .
                        U .
                        'invoices/edit/' .
                        $invoice['id'] .
                        '/" class="btn btn-info btn-xs"><i class="fa fa-pencil"></i> </a>
              </td>
          </tr>';
                }

                if ($dt == '') {
                    $tds =
                        '<tr><td colspan="7">' .
                        $_L['No Data Available'] .
                        '</td> </tr>';
                } else {
                    $tds = $dt;
                }
            } else {
                $tds =
                    '<tr><td colspan="7">' .
                    $_L['No Data Available'] .
                    '</td> </tr>';
            }

            echo '<table class="table table-bordered table-hover sys_table">
      <thead>
      <tr>
          <th>#</th>
          <th>' .
                $_L['Customer'] .
                '</th>
          <th>' .
                $_L['Amount'] .
                '</th>
          <th>' .
                $_L['Invoice Date'] .
                '</th>
          <th>' .
                $_L['Due Date'] .
                '</th>
          <th>' .
                $_L['Status'] .
                '</th>
          <th class="text-right">' .
                $_L['Manage'] .
                '</th>
      </tr>
      </thead>
      <tbody>
  
              
             ' .
                $tds .
                ' 
      
  
      </tbody>
  </table>';
        }

        break;

        //company2_invoices
    case 'company5_invoices':
        $cid = _post('cid');
        $d = ORM::for_table('crm_accounts')->find_one($cid);

        if ($d) {
            $customers = Contacts::findByCompany($cid);

            if ($customers) {
                $invoices = ORM::for_table('sys_invoices')
                    ->where_in('userid', $customers)
                    ->find_array();

                $dt = '';

                foreach ($invoices as $invoice) {
                    $dt .=
                        '<tr>
               <td><a href="' .
                        U .
                        'invoices/view/' .
                        $invoice['id'] .
                        '/">' .
                        $invoice['invoicenum'] .
                        ' ' .
                        ($invoice['cn'] != ''
                            ? $invoice['cn']
                            : $invoice['id']) .
                        '</a> </td>
               <td><a href="' .
                        U .
                        'contacts/view/' .
                        $invoice['userid'] .
                        '/">' .
                        $invoice['account'] .
                        '</a></td>
               <td class="amount" data-a-dec="." data-a-sep="," data-a-pad="true" data-p-sign="p" data-a-sign="$ " data-d-group="3">' .
                        $invoice['total'] .
                        '</td>
               <td>' .
                        $invoice['date'] .
                        '</td>
               <td>' .
                        $invoice['duedate'] .
                        '</td>
               <td>' .
                        $invoice['status'] .
                        '</td>
               <td>
                   <a href="' .
                        U .
                        'invoices/view/' .
                        $invoice['id'] .
                        '/" class="btn btn-primary btn-xs"><i class="fa fa-check"></i> </a>
                   <a href="' .
                        U .
                        'invoices/edit/' .
                        $invoice['id'] .
                        '/" class="btn btn-info btn-xs"><i class="fa fa-pencil"></i> </a>
               </td>
           </tr>';
                }

                if ($dt == '') {
                    $tds =
                        '<tr><td colspan="7">' .
                        $_L['No Data Available'] .
                        '</td> </tr>';
                } else {
                    $tds = $dt;
                }
            } else {
                $tds =
                    '<tr><td colspan="7">' .
                    $_L['No Data Available'] .
                    '</td> </tr>';
            }

            echo '<table class="table table-bordered table-hover sys_table">
       <thead>
       <tr>
           <th>#</th>
           <th>' .
                $_L['Customer'] .
                '</th>
           <th>' .
                $_L['Amount'] .
                '</th>
           <th>' .
                $_L['Invoice Date'] .
                '</th>
           <th>' .
                $_L['Due Date'] .
                '</th>
           <th>' .
                $_L['Status'] .
                '</th>
           <th class="text-right">' .
                $_L['Manage'] .
                '</th>
       </tr>
       </thead>
       <tbody>
   
               
              ' .
                $tds .
                ' 
       
   
       </tbody>
   </table>';
        }

        break;

    case 'company6_invoices':
        $cid = _post('cid');
        $d = ORM::for_table('sys_companies6')->find_one($cid);

        if ($d) {
            $customers = Contacts::findByCompany($cid);

            if ($customers) {
                $invoices = ORM::for_table('sys_invoices')
                    ->where_in('userid', $customers)
                    ->find_array();

                $dt = '';

                foreach ($invoices as $invoice) {
                    $dt .=
                        '<tr>
               <td><a href="' .
                        U .
                        'invoices/view/' .
                        $invoice['id'] .
                        '/">' .
                        $invoice['invoicenum'] .
                        ' ' .
                        ($invoice['cn'] != ''
                            ? $invoice['cn']
                            : $invoice['id']) .
                        '</a> </td>
               <td><a href="' .
                        U .
                        'contacts/view/' .
                        $invoice['userid'] .
                        '/">' .
                        $invoice['account'] .
                        '</a></td>
               <td class="amount" data-a-dec="." data-a-sep="," data-a-pad="true" data-p-sign="p" data-a-sign="$ " data-d-group="3">' .
                        $invoice['total'] .
                        '</td>
               <td>' .
                        $invoice['date'] .
                        '</td>
               <td>' .
                        $invoice['duedate'] .
                        '</td>
               <td>' .
                        $invoice['status'] .
                        '</td>
               <td>
                   <a href="' .
                        U .
                        'invoices/view/' .
                        $invoice['id'] .
                        '/" class="btn btn-primary btn-xs"><i class="fa fa-check"></i> </a>
                   <a href="' .
                        U .
                        'invoices/edit/' .
                        $invoice['id'] .
                        '/" class="btn btn-info btn-xs"><i class="fa fa-pencil"></i> </a>
               </td>
           </tr>';
                }

                if ($dt == '') {
                    $tds =
                        '<tr><td colspan="7">' .
                        $_L['No Data Available'] .
                        '</td> </tr>';
                } else {
                    $tds = $dt;
                }
            } else {
                $tds =
                    '<tr><td colspan="7">' .
                    $_L['No Data Available'] .
                    '</td> </tr>';
            }

            echo '<table class="table table-bordered table-hover sys_table">
       <thead>
       <tr>
           <th>#</th>
           <th>' .
                $_L['Customer'] .
                '</th>
           <th>' .
                $_L['Amount'] .
                '</th>
           <th>' .
                $_L['Invoice Date'] .
                '</th>
           <th>' .
                $_L['Due Date'] .
                '</th>
           <th>' .
                $_L['Status'] .
                '</th>
           <th class="text-right">' .
                $_L['Manage'] .
                '</th>
       </tr>
       </thead>
       <tbody>
   
               
              ' .
                $tds .
                ' 
       
   
       </tbody>
   </table>';
        }

        break;

    case 'company_quotes':
        $cid = _post('cid');
        $d = ORM::for_table('sys_companies')->find_one($cid);

        if ($d) {
            $customers = Contacts::findByCompany($cid);

            if ($customers) {
                $quotes = ORM::for_table('sys_quotes')
                    ->where_in('userid', $customers)
                    ->find_array();

                $dt = '';

                foreach ($quotes as $quote) {
                    $dt .=
                        '<tr>
            <td>' .
                        $quote['id'] .
                        ' </td>
            <td><a href="' .
                        U .
                        'contacts/view/' .
                        $quote['userid'] .
                        '/">' .
                        $quote['account'] .
                        '</a></td>
            <td><a href="' .
                        U .
                        'quotes/view/' .
                        $quote['id'] .
                        '/">' .
                        $quote['subject'] .
                        '</a></td>
            <td class="amount" data-a-dec="." data-a-sep="," data-a-pad="true" data-p-sign="p" data-a-sign="$ " data-d-group="3">' .
                        $quote['total'] .
                        '</td>
            <td>' .
                        $quote['datecreated'] .
                        '</td>
            <td>' .
                        $quote['validuntil'] .
                        '</td>
            <td>' .
                        $quote['stage'] .
                        '</td>
            <td>
                <a href="' .
                        U .
                        'quotes/view/' .
                        $quote['id'] .
                        '/" class="btn btn-primary btn-xs"><i class="fa fa-check"></i></a>
                <a href="' .
                        U .
                        'quotes/edit/' .
                        $quote['id'] .
                        '/" class="btn btn-info btn-xs"><i class="fa fa-repeat"></i></a>
            </td>
        </tr>';
                }

                if ($dt == '') {
                    $tds =
                        '<tr><td colspan="7">' .
                        $_L['No Data Available'] .
                        '</td> </tr>';
                } else {
                    $tds = $dt;
                }
            } else {
                $tds =
                    '<tr><td colspan="7">' .
                    $_L['No Data Available'] .
                    '</td> </tr>';
            }

            echo '<table class="table table-bordered table-hover sys_table">
    <thead>
    <tr>
        <th>#</th>
        <th>' .
                $_L['Customer'] .
                '</th>
        <th>' .
                $_L['Subject'] .
                '</th>
        <th>' .
                $_L['Amount'] .
                '</th>
        <th>' .
                $_L['Date Created'] .
                '</th>
        <th>' .
                $_L['Expiry Date'] .
                '</th>
        <th>' .
                $_L['Stage'] .
                '</th>
        <th class="text-right">' .
                $_L['Manage'] .
                '</th>
    </tr>
    </thead>
    <tbody>

            
           ' .
                $tds .
                ' 
    

    </tbody>
</table>';
        }

        break;

        //company1_quotes

    case 'company1_quotes':
        $cid = _post('cid');
        $d = ORM::for_table('sys_companies1')->find_one($cid);

        if ($d) {
            $customers = Contacts::findByCompany($cid);

            if ($customers) {
                $quotes = ORM::for_table('sys_quotes')
                    ->where_in('userid', $customers)
                    ->find_array();

                $dt = '';

                foreach ($quotes as $quote) {
                    $dt .=
                        '<tr>
            <td>' .
                        $quote['id'] .
                        ' </td>
            <td><a href="' .
                        U .
                        'contacts/view/' .
                        $quote['userid'] .
                        '/">' .
                        $quote['account'] .
                        '</a></td>
            <td><a href="' .
                        U .
                        'quotes/view/' .
                        $quote['id'] .
                        '/">' .
                        $quote['subject'] .
                        '</a></td>
            <td class="amount" data-a-dec="." data-a-sep="," data-a-pad="true" data-p-sign="p" data-a-sign="$ " data-d-group="3">' .
                        $quote['total'] .
                        '</td>
            <td>' .
                        $quote['datecreated'] .
                        '</td>
            <td>' .
                        $quote['validuntil'] .
                        '</td>
            <td>' .
                        $quote['stage'] .
                        '</td>
            <td>
                <a href="' .
                        U .
                        'quotes/view/' .
                        $quote['id'] .
                        '/" class="btn btn-primary btn-xs"><i class="fa fa-check"></i></a>
                <a href="' .
                        U .
                        'quotes/edit/' .
                        $quote['id'] .
                        '/" class="btn btn-info btn-xs"><i class="fa fa-repeat"></i></a>
            </td>
        </tr>';
                }

                if ($dt == '') {
                    $tds =
                        '<tr><td colspan="7">' .
                        $_L['No Data Available'] .
                        '</td> </tr>';
                } else {
                    $tds = $dt;
                }
            } else {
                $tds =
                    '<tr><td colspan="7">' .
                    $_L['No Data Available'] .
                    '</td> </tr>';
            }

            echo '<table class="table table-bordered table-hover sys_table">
    <thead>
    <tr>
        <th>#</th>
        <th>' .
                $_L['Customer'] .
                '</th>
        <th>' .
                $_L['Subject'] .
                '</th>
        <th>' .
                $_L['Amount'] .
                '</th>
        <th>' .
                $_L['Date Created'] .
                '</th>
        <th>' .
                $_L['Expiry Date'] .
                '</th>
        <th>' .
                $_L['Stage'] .
                '</th>
        <th class="text-right">' .
                $_L['Manage'] .
                '</th>
    </tr>
    </thead>
    <tbody>

            
           ' .
                $tds .
                ' 
    

    </tbody>
</table>';
        }

        break;

        //company2_quotes

    case 'company2_quotes':
        $cid = _post('cid');
        $d = ORM::for_table('sys_companies2')->find_one($cid);

        if ($d) {
            $customers = Contacts::findByCompany($cid);

            if ($customers) {
                $quotes = ORM::for_table('sys_quotes')
                    ->where_in('userid', $customers)
                    ->find_array();

                $dt = '';

                foreach ($quotes as $quote) {
                    $dt .=
                        '<tr>
          <td>' .
                        $quote['id'] .
                        ' </td>
          <td><a href="' .
                        U .
                        'contacts/view/' .
                        $quote['userid'] .
                        '/">' .
                        $quote['account'] .
                        '</a></td>
          <td><a href="' .
                        U .
                        'quotes/view/' .
                        $quote['id'] .
                        '/">' .
                        $quote['subject'] .
                        '</a></td>
          <td class="amount" data-a-dec="." data-a-sep="," data-a-pad="true" data-p-sign="p" data-a-sign="$ " data-d-group="3">' .
                        $quote['total'] .
                        '</td>
          <td>' .
                        $quote['datecreated'] .
                        '</td>
          <td>' .
                        $quote['validuntil'] .
                        '</td>
          <td>' .
                        $quote['stage'] .
                        '</td>
          <td>
              <a href="' .
                        U .
                        'quotes/view/' .
                        $quote['id'] .
                        '/" class="btn btn-primary btn-xs"><i class="fa fa-check"></i></a>
              <a href="' .
                        U .
                        'quotes/edit/' .
                        $quote['id'] .
                        '/" class="btn btn-info btn-xs"><i class="fa fa-repeat"></i></a>
          </td>
      </tr>';
                }

                if ($dt == '') {
                    $tds =
                        '<tr><td colspan="7">' .
                        $_L['No Data Available'] .
                        '</td> </tr>';
                } else {
                    $tds = $dt;
                }
            } else {
                $tds =
                    '<tr><td colspan="7">' .
                    $_L['No Data Available'] .
                    '</td> </tr>';
            }

            echo '<table class="table table-bordered table-hover sys_table">
  <thead>
  <tr>
      <th>#</th>
      <th>' .
                $_L['Customer'] .
                '</th>
      <th>' .
                $_L['Subject'] .
                '</th>
      <th>' .
                $_L['Amount'] .
                '</th>
      <th>' .
                $_L['Date Created'] .
                '</th>
      <th>' .
                $_L['Expiry Date'] .
                '</th>
      <th>' .
                $_L['Stage'] .
                '</th>
      <th class="text-right">' .
                $_L['Manage'] .
                '</th>
  </tr>
  </thead>
  <tbody>

          
         ' .
                $tds .
                ' 
  

  </tbody>
</table>';
        }
        break;

    case 'company3_quotes':
        $cid = _post('cid');
        $d = ORM::for_table('sys_companies3')->find_one($cid);

        if ($d) {
            $customers = Contacts::findByCompany($cid);

            if ($customers) {
                $quotes = ORM::for_table('sys_quotes')
                    ->where_in('userid', $customers)
                    ->find_array();

                $dt = '';

                foreach ($quotes as $quote) {
                    $dt .=
                        '<tr>
     <td>' .
                        $quote['id'] .
                        ' </td>
     <td><a href="' .
                        U .
                        'contacts/view/' .
                        $quote['userid'] .
                        '/">' .
                        $quote['account'] .
                        '</a></td>
     <td><a href="' .
                        U .
                        'quotes/view/' .
                        $quote['id'] .
                        '/">' .
                        $quote['subject'] .
                        '</a></td>
     <td class="amount" data-a-dec="." data-a-sep="," data-a-pad="true" data-p-sign="p" data-a-sign="$ " data-d-group="3">' .
                        $quote['total'] .
                        '</td>
     <td>' .
                        $quote['datecreated'] .
                        '</td>
     <td>' .
                        $quote['validuntil'] .
                        '</td>
     <td>' .
                        $quote['stage'] .
                        '</td>
     <td>
         <a href="' .
                        U .
                        'quotes/view/' .
                        $quote['id'] .
                        '/" class="btn btn-primary btn-xs"><i class="fa fa-check"></i></a>
         <a href="' .
                        U .
                        'quotes/edit/' .
                        $quote['id'] .
                        '/" class="btn btn-info btn-xs"><i class="fa fa-repeat"></i></a>
     </td>
 </tr>';
                }

                if ($dt == '') {
                    $tds =
                        '<tr><td colspan="7">' .
                        $_L['No Data Available'] .
                        '</td> </tr>';
                } else {
                    $tds = $dt;
                }
            } else {
                $tds =
                    '<tr><td colspan="7">' .
                    $_L['No Data Available'] .
                    '</td> </tr>';
            }

            echo '<table class="table table-bordered table-hover sys_table">
<thead>
<tr>
 <th>#</th>
 <th>' .
                $_L['Customer'] .
                '</th>
 <th>' .
                $_L['Subject'] .
                '</th>
 <th>' .
                $_L['Amount'] .
                '</th>
 <th>' .
                $_L['Date Created'] .
                '</th>
 <th>' .
                $_L['Expiry Date'] .
                '</th>
 <th>' .
                $_L['Stage'] .
                '</th>
 <th class="text-right">' .
                $_L['Manage'] .
                '</th>
</tr>
</thead>
<tbody>

     
    ' .
                $tds .
                ' 


</tbody>
</table>';
        }
        break;


    case 'company4_quotes':
        $cid = _post('cid');
        $d = ORM::for_table('sys_companies4')->find_one($cid);

        if ($d) {
            $customers = Contacts::findByCompany($cid);

            if ($customers) {
                $quotes = ORM::for_table('sys_quotes')
                    ->where_in('userid', $customers)
                    ->find_array();

                $dt = '';

                foreach ($quotes as $quote) {
                    $dt .=
                        '<tr>
    <td>' .
                        $quote['id'] .
                        ' </td>
    <td><a href="' .
                        U .
                        'contacts/view/' .
                        $quote['userid'] .
                        '/">' .
                        $quote['account'] .
                        '</a></td>
    <td><a href="' .
                        U .
                        'quotes/view/' .
                        $quote['id'] .
                        '/">' .
                        $quote['subject'] .
                        '</a></td>
    <td class="amount" data-a-dec="." data-a-sep="," data-a-pad="true" data-p-sign="p" data-a-sign="$ " data-d-group="3">' .
                        $quote['total'] .
                        '</td>
    <td>' .
                        $quote['datecreated'] .
                        '</td>
    <td>' .
                        $quote['validuntil'] .
                        '</td>
    <td>' .
                        $quote['stage'] .
                        '</td>
    <td>
        <a href="' .
                        U .
                        'quotes/view/' .
                        $quote['id'] .
                        '/" class="btn btn-primary btn-xs"><i class="fa fa-check"></i></a>
        <a href="' .
                        U .
                        'quotes/edit/' .
                        $quote['id'] .
                        '/" class="btn btn-info btn-xs"><i class="fa fa-repeat"></i></a>
    </td>
</tr>';
                }

                if ($dt == '') {
                    $tds =
                        '<tr><td colspan="7">' .
                        $_L['No Data Available'] .
                        '</td> </tr>';
                } else {
                    $tds = $dt;
                }
            } else {
                $tds =
                    '<tr><td colspan="7">' .
                    $_L['No Data Available'] .
                    '</td> </tr>';
            }

            echo '<table class="table table-bordered table-hover sys_table">
<thead>
<tr>
<th>#</th>
<th>' .
                $_L['Customer'] .
                '</th>
<th>' .
                $_L['Subject'] .
                '</th>
<th>' .
                $_L['Amount'] .
                '</th>
<th>' .
                $_L['Date Created'] .
                '</th>
<th>' .
                $_L['Expiry Date'] .
                '</th>
<th>' .
                $_L['Stage'] .
                '</th>
<th class="text-right">' .
                $_L['Manage'] .
                '</th>
</tr>
</thead>
<tbody>

    
   ' .
                $tds .
                ' 


</tbody>
</table>';
        }
        break;


    case 'company5_quotes':
        $cid = _post('cid');
        $d = ORM::for_table('crm_accounts')->find_one($cid);

        if ($d) {
            $customers = Contacts::findByCompany($cid);

            if ($customers) {
                $quotes = ORM::for_table('sys_quotes')
                    ->where_in('userid', $customers)
                    ->find_array();

                $dt = '';

                foreach ($quotes as $quote) {
                    $dt .=
                        '<tr>
    <td>' .
                        $quote['id'] .
                        ' </td>
    <td><a href="' .
                        U .
                        'contacts/view/' .
                        $quote['userid'] .
                        '/">' .
                        $quote['account'] .
                        '</a></td>
    <td><a href="' .
                        U .
                        'quotes/view/' .
                        $quote['id'] .
                        '/">' .
                        $quote['subject'] .
                        '</a></td>
    <td class="amount" data-a-dec="." data-a-sep="," data-a-pad="true" data-p-sign="p" data-a-sign="$ " data-d-group="3">' .
                        $quote['total'] .
                        '</td>
    <td>' .
                        $quote['datecreated'] .
                        '</td>
    <td>' .
                        $quote['validuntil'] .
                        '</td>
    <td>' .
                        $quote['stage'] .
                        '</td>
    <td>
        <a href="' .
                        U .
                        'quotes/view/' .
                        $quote['id'] .
                        '/" class="btn btn-primary btn-xs"><i class="fa fa-check"></i></a>
        <a href="' .
                        U .
                        'quotes/edit/' .
                        $quote['id'] .
                        '/" class="btn btn-info btn-xs"><i class="fa fa-repeat"></i></a>
    </td>
</tr>';
                }

                if ($dt == '') {
                    $tds =
                        '<tr><td colspan="7">' .
                        $_L['No Data Available'] .
                        '</td> </tr>';
                } else {
                    $tds = $dt;
                }
            } else {
                $tds =
                    '<tr><td colspan="7">' .
                    $_L['No Data Available'] .
                    '</td> </tr>';
            }

            echo '<table class="table table-bordered table-hover sys_table">
<thead>
<tr>
<th>#</th>
<th>' .
                $_L['Customer'] .
                '</th>
<th>' .
                $_L['Subject'] .
                '</th>
<th>' .
                $_L['Amount'] .
                '</th>
<th>' .
                $_L['Date Created'] .
                '</th>
<th>' .
                $_L['Expiry Date'] .
                '</th>
<th>' .
                $_L['Stage'] .
                '</th>
<th class="text-right">' .
                $_L['Manage'] .
                '</th>
</tr>
</thead>
<tbody>

    
   ' .
                $tds .
                ' 


</tbody>
</table>';
        }
        break;


    case 'company6_quotes':
        $cid = _post('cid');
        $d = ORM::for_table('sys_companies6')->find_one($cid);

        if ($d) {
            $customers = Contacts::findByCompany($cid);

            if ($customers) {
                $quotes = ORM::for_table('sys_quotes')
                    ->where_in('userid', $customers)
                    ->find_array();

                $dt = '';

                foreach ($quotes as $quote) {
                    $dt .=
                        '<tr>
    <td>' .
                        $quote['id'] .
                        ' </td>
    <td><a href="' .
                        U .
                        'contacts/view/' .
                        $quote['userid'] .
                        '/">' .
                        $quote['account'] .
                        '</a></td>
    <td><a href="' .
                        U .
                        'quotes/view/' .
                        $quote['id'] .
                        '/">' .
                        $quote['subject'] .
                        '</a></td>
    <td class="amount" data-a-dec="." data-a-sep="," data-a-pad="true" data-p-sign="p" data-a-sign="$ " data-d-group="3">' .
                        $quote['total'] .
                        '</td>
    <td>' .
                        $quote['datecreated'] .
                        '</td>
    <td>' .
                        $quote['validuntil'] .
                        '</td>
    <td>' .
                        $quote['stage'] .
                        '</td>
    <td>
        <a href="' .
                        U .
                        'quotes/view/' .
                        $quote['id'] .
                        '/" class="btn btn-primary btn-xs"><i class="fa fa-check"></i></a>
        <a href="' .
                        U .
                        'quotes/edit/' .
                        $quote['id'] .
                        '/" class="btn btn-info btn-xs"><i class="fa fa-repeat"></i></a>
    </td>
</tr>';
                }

                if ($dt == '') {
                    $tds =
                        '<tr><td colspan="7">' .
                        $_L['No Data Available'] .
                        '</td> </tr>';
                } else {
                    $tds = $dt;
                }
            } else {
                $tds =
                    '<tr><td colspan="7">' .
                    $_L['No Data Available'] .
                    '</td> </tr>';
            }

            echo '<table class="table table-bordered table-hover sys_table">
<thead>
<tr>
<th>#</th>
<th>' .
                $_L['Customer'] .
                '</th>
<th>' .
                $_L['Subject'] .
                '</th>
<th>' .
                $_L['Amount'] .
                '</th>
<th>' .
                $_L['Date Created'] .
                '</th>
<th>' .
                $_L['Expiry Date'] .
                '</th>
<th>' .
                $_L['Stage'] .
                '</th>
<th class="text-right">' .
                $_L['Manage'] .
                '</th>
</tr>
</thead>
<tbody>

    
   ' .
                $tds .
                ' 


</tbody>
</table>';
        }
        break;



    case 'company_orders':
        $cid = _post('cid');
        $d = ORM::for_table('sys_companies')->find_one($cid);

        if ($d) {
            // find all customers with that company_id

            $customers = Contacts::findByCompany($cid);

            //  var_dump($invoices);

            if ($customers) {
                $orders = ORM::for_table('sys_orders')
                    ->where_in('cid', $customers)
                    ->find_array();

                $dt = '';

                foreach ($orders as $order) {
                    $dt .=
                        '<tr>
           
            <td><a href="' .
                        U .
                        'orders/view/' .
                        $order['id'] .
                        '">' .
                        $order['ordernum'] .
                        '</a> </td>
            <td>' .
                        date($config['df'], strtotime($order['date_added'])) .
                        '</td>
            <td><a href="' .
                        U .
                        'contacts/view/' .
                        $order['cid'] .
                        '">' .
                        $order['cname'] .
                        '</a> </td>
            <td>' .
                        $order['amount'] .
                        '</td>
            <td>' .
                        $order['status'] .
                        '</td>
            
            
        </tr>';
                }

                if ($dt == '') {
                    $tds =
                        '<tr><td colspan="6">' .
                        $_L['No Data Available'] .
                        '</td> </tr>';
                } else {
                    $tds = $dt;
                }
            } else {
                $tds =
                    '<tr><td colspan="6">' .
                    $_L['No Data Available'] .
                    '</td> </tr>';
            }

            echo '<table class="table table-bordered table-hover sys_table">
    <thead>
    <tr>
        
                        <th>' .
                $_L['Order'] .
                ' #</th>
                        <th>' .
                $_L['Date'] .
                '</th>
                        <th>' .
                $_L['Customer'] .
                '</th>
                        <th>' .
                $_L['Total'] .
                '</th>
                        <th>' .
                $_L['Status'] .
                '</th>
                        
    </tr>
    </thead>
    <tbody>

            
           ' .
                $tds .
                ' 
    

    </tbody>
</table>';
        }

        break;
        //company1_orders
    case 'company1_orders':
        $cid = _post('cid');
        $d = ORM::for_table('sys_companies1')->find_one($cid);

        if ($d) {
            // find all customers with that company_id

            $customers = Contacts::findByCompany($cid);

            //  var_dump($invoices);

            if ($customers) {
                $orders = ORM::for_table('sys_orders')
                    ->where_in('cid', $customers)
                    ->find_array();

                $dt = '';

                foreach ($orders as $order) {
                    $dt .=
                        '<tr>
           
            <td><a href="' .
                        U .
                        'orders/view/' .
                        $order['id'] .
                        '">' .
                        $order['ordernum'] .
                        '</a> </td>
            <td>' .
                        date($config['df'], strtotime($order['date_added'])) .
                        '</td>
            <td><a href="' .
                        U .
                        'contacts/view/' .
                        $order['cid'] .
                        '">' .
                        $order['cname'] .
                        '</a> </td>
            <td>' .
                        $order['amount'] .
                        '</td>
            <td>' .
                        $order['status'] .
                        '</td>
            
            
        </tr>';
                }

                if ($dt == '') {
                    $tds =
                        '<tr><td colspan="6">' .
                        $_L['No Data Available'] .
                        '</td> </tr>';
                } else {
                    $tds = $dt;
                }
            } else {
                $tds =
                    '<tr><td colspan="6">' .
                    $_L['No Data Available'] .
                    '</td> </tr>';
            }

            echo '<table class="table table-bordered table-hover sys_table">
    <thead>
    <tr>
        
                        <th>' .
                $_L['Order'] .
                ' #</th>
                        <th>' .
                $_L['Date'] .
                '</th>
                        <th>' .
                $_L['Customer'] .
                '</th>
                        <th>' .
                $_L['Total'] .
                '</th>
                        <th>' .
                $_L['Status'] .
                '</th>
                        
    </tr>
    </thead>
    <tbody>

            
           ' .
                $tds .
                ' 
    

    </tbody>
</table>';
        }

        break;
        //company2_orders
    case 'company2_orders':
        $cid = _post('cid');
        $d = ORM::for_table('sys_companies2')->find_one($cid);

        if ($d) {
            // find all customers with that company_id

            $customers = Contacts::findByCompany($cid);

            //  var_dump($invoices);

            if ($customers) {
                $orders = ORM::for_table('sys_orders')
                    ->where_in('cid', $customers)
                    ->find_array();

                $dt = '';

                foreach ($orders as $order) {
                    $dt .=
                        '<tr>
           
            <td><a href="' .
                        U .
                        'orders/view/' .
                        $order['id'] .
                        '">' .
                        $order['ordernum'] .
                        '</a> </td>
            <td>' .
                        date($config['df'], strtotime($order['date_added'])) .
                        '</td>
            <td><a href="' .
                        U .
                        'contacts/view/' .
                        $order['cid'] .
                        '">' .
                        $order['cname'] .
                        '</a> </td>
            <td>' .
                        $order['amount'] .
                        '</td>
            <td>' .
                        $order['status'] .
                        '</td>
            
            
        </tr>';
                }

                if ($dt == '') {
                    $tds =
                        '<tr><td colspan="6">' .
                        $_L['No Data Available'] .
                        '</td> </tr>';
                } else {
                    $tds = $dt;
                }
            } else {
                $tds =
                    '<tr><td colspan="6">' .
                    $_L['No Data Available'] .
                    '</td> </tr>';
            }

            echo '<table class="table table-bordered table-hover sys_table">
    <thead>
    <tr>
        
                        <th>' .
                $_L['Order'] .
                ' #</th>
                        <th>' .
                $_L['Date'] .
                '</th>
                        <th>' .
                $_L['Customer'] .
                '</th>
                        <th>' .
                $_L['Total'] .
                '</th>
                        <th>' .
                $_L['Status'] .
                '</th>
                        
    </tr>
    </thead>
    <tbody>

            
           ' .
                $tds .
                ' 
    

    </tbody>
</table>';
        }

        break;


        //company3_orders
    case 'company3_orders':
        $cid = _post('cid');
        $d = ORM::for_table('sys_companies3')->find_one($cid);

        if ($d) {
            // find all customers with that company_id

            $customers = Contacts::findByCompany($cid);

            //  var_dump($invoices);

            if ($customers) {
                $orders = ORM::for_table('sys_orders')
                    ->where_in('cid', $customers)
                    ->find_array();

                $dt = '';

                foreach ($orders as $order) {
                    $dt .=
                        '<tr>
           
            <td><a href="' .
                        U .
                        'orders/view/' .
                        $order['id'] .
                        '">' .
                        $order['ordernum'] .
                        '</a> </td>
            <td>' .
                        date($config['df'], strtotime($order['date_added'])) .
                        '</td>
            <td><a href="' .
                        U .
                        'contacts/view/' .
                        $order['cid'] .
                        '">' .
                        $order['cname'] .
                        '</a> </td>
            <td>' .
                        $order['amount'] .
                        '</td>
            <td>' .
                        $order['status'] .
                        '</td>
            
            
        </tr>';
                }

                if ($dt == '') {
                    $tds =
                        '<tr><td colspan="6">' .
                        $_L['No Data Available'] .
                        '</td> </tr>';
                } else {
                    $tds = $dt;
                }
            } else {
                $tds =
                    '<tr><td colspan="6">' .
                    $_L['No Data Available'] .
                    '</td> </tr>';
            }

            echo '<table class="table table-bordered table-hover sys_table">
    <thead>
    <tr>
        
                        <th>' .
                $_L['Order'] .
                ' #</th>
                        <th>' .
                $_L['Date'] .
                '</th>
                        <th>' .
                $_L['Customer'] .
                '</th>
                        <th>' .
                $_L['Total'] .
                '</th>
                        <th>' .
                $_L['Status'] .
                '</th>
                        
    </tr>
    </thead>
    <tbody>

            
           ' .
                $tds .
                ' 
    

    </tbody>
</table>';
        }

        break;
        //company4_orders
    case 'company4_orders':
        $cid = _post('cid');
        $d = ORM::for_table('sys_companies4')->find_one($cid);

        if ($d) {
            // find all customers with that company_id

            $customers = Contacts::findByCompany($cid);

            //  var_dump($invoices);

            if ($customers) {
                $orders = ORM::for_table('sys_orders')
                    ->where_in('cid', $customers)
                    ->find_array();

                $dt = '';

                foreach ($orders as $order) {
                    $dt .=
                        '<tr>
           
            <td><a href="' .
                        U .
                        'orders/view/' .
                        $order['id'] .
                        '">' .
                        $order['ordernum'] .
                        '</a> </td>
            <td>' .
                        date($config['df'], strtotime($order['date_added'])) .
                        '</td>
            <td><a href="' .
                        U .
                        'contacts/view/' .
                        $order['cid'] .
                        '">' .
                        $order['cname'] .
                        '</a> </td>
            <td>' .
                        $order['amount'] .
                        '</td>
            <td>' .
                        $order['status'] .
                        '</td>
            
            
        </tr>';
                }

                if ($dt == '') {
                    $tds =
                        '<tr><td colspan="6">' .
                        $_L['No Data Available'] .
                        '</td> </tr>';
                } else {
                    $tds = $dt;
                }
            } else {
                $tds =
                    '<tr><td colspan="6">' .
                    $_L['No Data Available'] .
                    '</td> </tr>';
            }

            echo '<table class="table table-bordered table-hover sys_table">
    <thead>
    <tr>
        
                        <th>' .
                $_L['Order'] .
                ' #</th>
                        <th>' .
                $_L['Date'] .
                '</th>
                        <th>' .
                $_L['Customer'] .
                '</th>
                        <th>' .
                $_L['Total'] .
                '</th>
                        <th>' .
                $_L['Status'] .
                '</th>
                        
    </tr>
    </thead>
    <tbody>

            
           ' .
                $tds .
                ' 
    

    </tbody>
</table>';
        }

        break;


        //company2_orders
    case 'company5_orders':
        $cid = _post('cid');
        $d = ORM::for_table('crm_accounts')->find_one($cid);

        if ($d) {
            // find all customers with that company_id

            $customers = Contacts::findByCompany($cid);

            //  var_dump($invoices);

            if ($customers) {
                $orders = ORM::for_table('sys_orders')
                    ->where_in('cid', $customers)
                    ->find_array();

                $dt = '';

                foreach ($orders as $order) {
                    $dt .=
                        '<tr>
           
            <td><a href="' .
                        U .
                        'orders/view/' .
                        $order['id'] .
                        '">' .
                        $order['ordernum'] .
                        '</a> </td>
            <td>' .
                        date($config['df'], strtotime($order['date_added'])) .
                        '</td>
            <td><a href="' .
                        U .
                        'contacts/view/' .
                        $order['cid'] .
                        '">' .
                        $order['cname'] .
                        '</a> </td>
            <td>' .
                        $order['amount'] .
                        '</td>
            <td>' .
                        $order['status'] .
                        '</td>
            
            
        </tr>';
                }

                if ($dt == '') {
                    $tds =
                        '<tr><td colspan="6">' .
                        $_L['No Data Available'] .
                        '</td> </tr>';
                } else {
                    $tds = $dt;
                }
            } else {
                $tds =
                    '<tr><td colspan="6">' .
                    $_L['No Data Available'] .
                    '</td> </tr>';
            }

            echo '<table class="table table-bordered table-hover sys_table">
    <thead>
    <tr>
        
                        <th>' .
                $_L['Order'] .
                ' #</th>
                        <th>' .
                $_L['Date'] .
                '</th>
                        <th>' .
                $_L['Customer'] .
                '</th>
                        <th>' .
                $_L['Total'] .
                '</th>
                        <th>' .
                $_L['Status'] .
                '</th>
                        
    </tr>
    </thead>
    <tbody>

            
           ' .
                $tds .
                ' 
    

    </tbody>
</table>';
        }

        break;


    case 'company6_orders':
        $cid = _post('cid');
        $d = ORM::for_table('sys_companies6')->find_one($cid);

        if ($d) {
            // find all customers with that company_id

            $customers = Contacts::findByCompany($cid);

            //  var_dump($invoices);

            if ($customers) {
                $orders = ORM::for_table('sys_orders')
                    ->where_in('cid', $customers)
                    ->find_array();

                $dt = '';

                foreach ($orders as $order) {
                    $dt .=
                        '<tr>
           
            <td><a href="' .
                        U .
                        'orders/view/' .
                        $order['id'] .
                        '">' .
                        $order['ordernum'] .
                        '</a> </td>
            <td>' .
                        date($config['df'], strtotime($order['date_added'])) .
                        '</td>
            <td><a href="' .
                        U .
                        'contacts/view/' .
                        $order['cid'] .
                        '">' .
                        $order['cname'] .
                        '</a> </td>
            <td>' .
                        $order['amount'] .
                        '</td>
            <td>' .
                        $order['status'] .
                        '</td>
            
            
        </tr>';
                }

                if ($dt == '') {
                    $tds =
                        '<tr><td colspan="6">' .
                        $_L['No Data Available'] .
                        '</td> </tr>';
                } else {
                    $tds = $dt;
                }
            } else {
                $tds =
                    '<tr><td colspan="6">' .
                    $_L['No Data Available'] .
                    '</td> </tr>';
            }

            echo '<table class="table table-bordered table-hover sys_table">
    <thead>
    <tr>
        
                        <th>' .
                $_L['Order'] .
                ' #</th>
                        <th>' .
                $_L['Date'] .
                '</th>
                        <th>' .
                $_L['Customer'] .
                '</th>
                        <th>' .
                $_L['Total'] .
                '</th>
                        <th>' .
                $_L['Status'] .
                '</th>
                        
    </tr>
    </thead>
    <tbody>

            
           ' .
                $tds .
                ' 
    

    </tbody>
</table>';
        }

        break;


    case 'company_files':
        break;

    case 'company_transactions':
        $cid = _post('cid');
        $d = ORM::for_table('sys_companies')->find_one($cid);

        if ($d) {
            // find all customers with that company_id

            $customers = Contacts::findByCompany($cid);

            //  var_dump($invoices);

            if ($customers) {
                $transactions_payer = ORM::for_table('sys_transactions')
                    ->where_in('payerid', $customers)
                    ->find_array();
                $transactions_payee = ORM::for_table('sys_transactions')
                    ->where_in('payeeid', $customers)
                    ->find_array();

                $transactions = array_merge(
                    $transactions_payer,
                    $transactions_payee
                );

                $dt = '';

                foreach ($transactions as $transaction) {
                    $dt .=
                        '<tr>
            <td>' .
                        $transaction['id'] .
                        ' </td>
            <td>' .
                        $transaction['date'] .
                        '</td>
            <td>' .
                        $transaction['account'] .
                        '</td>
            <td>' .
                        $transaction['type'] .
                        '</td>
          
            <td class="amount" data-a-dec="." data-a-sep="," data-a-pad="true" data-p-sign="p" data-a-sign="$ " data-d-group="3">' .
                        $transaction['amount'] .
                        '</td>
            <td>' .
                        $transaction['description'] .
                        '</td>
            <td>' .
                        $transaction['dr'] .
                        '</td>
            <td>' .
                        $transaction['cr'] .
                        '</td>
            <td>' .
                        $transaction['bal'] .
                        '</td>
            <td>
                <a href="' .
                        U .
                        'transactions/manage/' .
                        $transaction['id'] .
                        '/" class="btn btn-primary btn-xs"><i class="fa fa-check"></i></a>
                
            </td>
        </tr>';
                }

                if ($dt == '') {
                    $tds =
                        '<tr><td colspan="7">' .
                        $_L['No Data Available'] .
                        '</td> </tr>';
                } else {
                    $tds = $dt;
                }
            } else {
                $tds =
                    '<tr><td colspan="7">' .
                    $_L['No Data Available'] .
                    '</td> </tr>';
            }

            echo '<table class="table table-bordered table-hover sys_table">
    <thead>
    <tr>
        <th>#</th>
        <th>' .
                $_L['Date'] .
                '</th>
        <th>' .
                $_L['Account'] .
                '</th>
        <th>' .
                $_L['Type'] .
                '</th>
        <th>' .
                $_L['Amount'] .
                '</th>
        <th>' .
                $_L['Description'] .
                '</th>
        <th>' .
                $_L['Dr'] .
                '</th>
        <th>' .
                $_L['Cr'] .
                '</th>
        <th>' .
                $_L['Balance'] .
                '</th>
        <th class="text-right">' .
                $_L['Manage'] .
                '</th>
    </tr>
    </thead>
    <tbody>

            
           ' .
                $tds .
                ' 
    

    </tbody>
</table>';
        }

        break;

    case 'company1_transactions':
        $cid = _post('cid');
        $d = ORM::for_table('sys_companies1')->find_one($cid);

        if ($d) {
            // find all customers with that company_id

            $customers = Contacts::findByCompany($cid);

            //  var_dump($invoices);

            if ($customers) {
                $transactions_payer = ORM::for_table('sys_transactions')
                    ->where_in('payerid', $customers)
                    ->find_array();
                $transactions_payee = ORM::for_table('sys_transactions')
                    ->where_in('payeeid', $customers)
                    ->find_array();

                $transactions = array_merge(
                    $transactions_payer,
                    $transactions_payee
                );

                $dt = '';

                foreach ($transactions as $transaction) {
                    $dt .=
                        '<tr>
            <td>' .
                        $transaction['id'] .
                        ' </td>
            <td>' .
                        $transaction['date'] .
                        '</td>
            <td>' .
                        $transaction['account'] .
                        '</td>
            <td>' .
                        $transaction['type'] .
                        '</td>
          
            <td class="amount" data-a-dec="." data-a-sep="," data-a-pad="true" data-p-sign="p" data-a-sign="$ " data-d-group="3">' .
                        $transaction['amount'] .
                        '</td>
            <td>' .
                        $transaction['description'] .
                        '</td>
            <td>' .
                        $transaction['dr'] .
                        '</td>
            <td>' .
                        $transaction['cr'] .
                        '</td>
            <td>' .
                        $transaction['bal'] .
                        '</td>
            <td>
                <a href="' .
                        U .
                        'transactions/manage/' .
                        $transaction['id'] .
                        '/" class="btn btn-primary btn-xs"><i class="fa fa-check"></i></a>
                
            </td>
        </tr>';
                }

                if ($dt == '') {
                    $tds =
                        '<tr><td colspan="7">' .
                        $_L['No Data Available'] .
                        '</td> </tr>';
                } else {
                    $tds = $dt;
                }
            } else {
                $tds =
                    '<tr><td colspan="7">' .
                    $_L['No Data Available'] .
                    '</td> </tr>';
            }

            echo '<table class="table table-bordered table-hover sys_table">
    <thead>
    <tr>
        <th>#</th>
        <th>' .
                $_L['Date'] .
                '</th>
        <th>' .
                $_L['Account'] .
                '</th>
        <th>' .
                $_L['Type'] .
                '</th>
        <th>' .
                $_L['Amount'] .
                '</th>
        <th>' .
                $_L['Description'] .
                '</th>
        <th>' .
                $_L['Dr'] .
                '</th>
        <th>' .
                $_L['Cr'] .
                '</th>
        <th>' .
                $_L['Balance'] .
                '</th>
        <th class="text-right">' .
                $_L['Manage'] .
                '</th>
    </tr>
    </thead>
    <tbody>

            
           ' .
                $tds .
                ' 
    

    </tbody>
</table>';
        }

        break;

    case 'company2_transactions':
        $cid = _post('cid');
        $d = ORM::for_table('sys_companies2')->find_one($cid);

        if ($d) {
            // find all customers with that company_id

            $customers = Contacts::findByCompany($cid);

            //  var_dump($invoices);

            if ($customers) {
                $transactions_payer = ORM::for_table('sys_transactions')
                    ->where_in('payerid', $customers)
                    ->find_array();
                $transactions_payee = ORM::for_table('sys_transactions')
                    ->where_in('payeeid', $customers)
                    ->find_array();

                $transactions = array_merge(
                    $transactions_payer,
                    $transactions_payee
                );

                $dt = '';

                foreach ($transactions as $transaction) {
                    $dt .=
                        '<tr>
            <td>' .
                        $transaction['id'] .
                        ' </td>
            <td>' .
                        $transaction['date'] .
                        '</td>
            <td>' .
                        $transaction['account'] .
                        '</td>
            <td>' .
                        $transaction['type'] .
                        '</td>
          
            <td class="amount" data-a-dec="." data-a-sep="," data-a-pad="true" data-p-sign="p" data-a-sign="$ " data-d-group="3">' .
                        $transaction['amount'] .
                        '</td>
            <td>' .
                        $transaction['description'] .
                        '</td>
            <td>' .
                        $transaction['dr'] .
                        '</td>
            <td>' .
                        $transaction['cr'] .
                        '</td>
            <td>' .
                        $transaction['bal'] .
                        '</td>
            <td>
                <a href="' .
                        U .
                        'transactions/manage/' .
                        $transaction['id'] .
                        '/" class="btn btn-primary btn-xs"><i class="fa fa-check"></i></a>
                
            </td>
        </tr>';
                }

                if ($dt == '') {
                    $tds =
                        '<tr><td colspan="7">' .
                        $_L['No Data Available'] .
                        '</td> </tr>';
                } else {
                    $tds = $dt;
                }
            } else {
                $tds =
                    '<tr><td colspan="7">' .
                    $_L['No Data Available'] .
                    '</td> </tr>';
            }

            echo '<table class="table table-bordered table-hover sys_table">
    <thead>
    <tr>
        <th>#</th>
        <th>' .
                $_L['Date'] .
                '</th>
        <th>' .
                $_L['Account'] .
                '</th>
        <th>' .
                $_L['Type'] .
                '</th>
        <th>' .
                $_L['Amount'] .
                '</th>
        <th>' .
                $_L['Description'] .
                '</th>
        <th>' .
                $_L['Dr'] .
                '</th>
        <th>' .
                $_L['Cr'] .
                '</th>
        <th>' .
                $_L['Balance'] .
                '</th>
        <th class="text-right">' .
                $_L['Manage'] .
                '</th>
    </tr>
    </thead>
    <tbody>

            
           ' .
                $tds .
                ' 
    

    </tbody>
</table>';
        }

        break;

    case 'company3_transactions':
        $cid = _post('cid');
        $d = ORM::for_table('sys_companies3')->find_one($cid);

        if ($d) {
            // find all customers with that company_id

            $customers = Contacts::findByCompany($cid);

            //  var_dump($invoices);

            if ($customers) {
                $transactions_payer = ORM::for_table('sys_transactions')
                    ->where_in('payerid', $customers)
                    ->find_array();
                $transactions_payee = ORM::for_table('sys_transactions')
                    ->where_in('payeeid', $customers)
                    ->find_array();

                $transactions = array_merge(
                    $transactions_payer,
                    $transactions_payee
                );

                $dt = '';

                foreach ($transactions as $transaction) {
                    $dt .=
                        '<tr>
            <td>' .
                        $transaction['id'] .
                        ' </td>
            <td>' .
                        $transaction['date'] .
                        '</td>
            <td>' .
                        $transaction['account'] .
                        '</td>
            <td>' .
                        $transaction['type'] .
                        '</td>
          
            <td class="amount" data-a-dec="." data-a-sep="," data-a-pad="true" data-p-sign="p" data-a-sign="$ " data-d-group="3">' .
                        $transaction['amount'] .
                        '</td>
            <td>' .
                        $transaction['description'] .
                        '</td>
            <td>' .
                        $transaction['dr'] .
                        '</td>
            <td>' .
                        $transaction['cr'] .
                        '</td>
            <td>' .
                        $transaction['bal'] .
                        '</td>
            <td>
                <a href="' .
                        U .
                        'transactions/manage/' .
                        $transaction['id'] .
                        '/" class="btn btn-primary btn-xs"><i class="fa fa-check"></i></a>
                
            </td>
        </tr>';
                }

                if ($dt == '') {
                    $tds =
                        '<tr><td colspan="7">' .
                        $_L['No Data Available'] .
                        '</td> </tr>';
                } else {
                    $tds = $dt;
                }
            } else {
                $tds =
                    '<tr><td colspan="7">' .
                    $_L['No Data Available'] .
                    '</td> </tr>';
            }

            echo '<table class="table table-bordered table-hover sys_table">
    <thead>
    <tr>
        <th>#</th>
        <th>' .
                $_L['Date'] .
                '</th>
        <th>' .
                $_L['Account'] .
                '</th>
        <th>' .
                $_L['Type'] .
                '</th>
        <th>' .
                $_L['Amount'] .
                '</th>
        <th>' .
                $_L['Description'] .
                '</th>
        <th>' .
                $_L['Dr'] .
                '</th>
        <th>' .
                $_L['Cr'] .
                '</th>
        <th>' .
                $_L['Balance'] .
                '</th>
        <th class="text-right">' .
                $_L['Manage'] .
                '</th>
    </tr>
    </thead>
    <tbody>

            
           ' .
                $tds .
                ' 
    

    </tbody>
</table>';
        }

        break;

    case 'company4_transactions':
        $cid = _post('cid');
        $d = ORM::for_table('sys_companies4')->find_one($cid);

        if ($d) {
            // find all customers with that company_id

            $customers = Contacts::findByCompany($cid);

            //  var_dump($invoices);

            if ($customers) {
                $transactions_payer = ORM::for_table('sys_transactions')
                    ->where_in('payerid', $customers)
                    ->find_array();
                $transactions_payee = ORM::for_table('sys_transactions')
                    ->where_in('payeeid', $customers)
                    ->find_array();

                $transactions = array_merge(
                    $transactions_payer,
                    $transactions_payee
                );

                $dt = '';

                foreach ($transactions as $transaction) {
                    $dt .=
                        '<tr>
            <td>' .
                        $transaction['id'] .
                        ' </td>
            <td>' .
                        $transaction['date'] .
                        '</td>
            <td>' .
                        $transaction['account'] .
                        '</td>
            <td>' .
                        $transaction['type'] .
                        '</td>
          
            <td class="amount" data-a-dec="." data-a-sep="," data-a-pad="true" data-p-sign="p" data-a-sign="$ " data-d-group="3">' .
                        $transaction['amount'] .
                        '</td>
            <td>' .
                        $transaction['description'] .
                        '</td>
            <td>' .
                        $transaction['dr'] .
                        '</td>
            <td>' .
                        $transaction['cr'] .
                        '</td>
            <td>' .

                        '</td>
            <td>
                <a href="' .
                        U .
                        'transactions/manage/' .
                        $transaction['id'] .
                        '/" class="btn btn-primary btn-xs"><i class="fa fa-check"></i></a>
                
            </td>
        </tr>';
                }

                if ($dt == '') {
                    $tds =
                        '<tr><td colspan="7">' .
                        $_L['No Data Available'] .
                        '</td> </tr>';
                } else {
                    $tds = $dt;
                }
            } else {
                $tds =
                    '<tr><td colspan="7">' .
                    $_L['No Data Available'] .
                    '</td> </tr>';
            }

            echo '<table class="table table-bordered table-hover sys_table">
    <thead>
    <tr>
        <th>#</th>
        <th>' .
                $_L['Date'] .
                '</th>
        <th>' .
                $_L['Account'] .
                '</th>
        <th>' .
                $_L['Type'] .
                '</th>
        <th>' .
                $_L['Amount'] .
                '</th>
        <th>' .
                $_L['Description'] .
                '</th>
        <th>' .
                $_L['Dr'] .
                '</th>
        <th>' .
                $_L['Cr'] .
                '</th>
        <th>' .
                $_L['Balance'] .
                '</th>
        <th class="text-right">' .
                $_L['Manage'] .
                '</th>
    </tr>
    </thead>
    <tbody>

            
           ' .
                $tds .
                ' 
    

    </tbody>
</table>';
        }

        break;


    case 'company5_transactions':
        $cid = _post('cid');
        $d = ORM::for_table('crm_accounts')->find_one($cid);

        if ($d) {
            // find all customers with that company_id

            $customers = Contacts::findByCompany($cid);

            //  var_dump($invoices);

            if ($customers) {
                $transactions_payer = ORM::for_table('sys_transactions')
                    ->where_in('payerid', $customers)
                    ->find_array();
                $transactions_payee = ORM::for_table('sys_transactions')
                    ->where_in('payeeid', $customers)
                    ->find_array();

                $transactions = array_merge(
                    $transactions_payer,
                    $transactions_payee
                );

                $dt = '';

                foreach ($transactions as $transaction) {
                    $dt .=
                        '<tr>
            <td>' .
                        $transaction['id'] .
                        ' </td>
            <td>' .
                        $transaction['date'] .
                        '</td>
            <td>' .
                        $transaction['account'] .
                        '</td>
            <td>' .
                        $transaction['type'] .
                        '</td>
          
            <td class="amount" data-a-dec="." data-a-sep="," data-a-pad="true" data-p-sign="p" data-a-sign="$ " data-d-group="3">' .
                        $transaction['amount'] .
                        '</td>
            <td>' .
                        $transaction['description'] .
                        '</td>
            <td>' .
                        $transaction['dr'] .
                        '</td>
            <td>' .
                        $transaction['cr'] .
                        '</td>
            <td>' .
                        $transaction['bal'] .
                        '</td>
            <td>
                <a href="' .
                        U .
                        'transactions/manage/' .
                        $transaction['id'] .
                        '/" class="btn btn-primary btn-xs"><i class="fa fa-check"></i></a>
                
            </td>
        </tr>';
                }

                if ($dt == '') {
                    $tds =
                        '<tr><td colspan="7">' .
                        $_L['No Data Available'] .
                        '</td> </tr>';
                } else {
                    $tds = $dt;
                }
            } else {
                $tds =
                    '<tr><td colspan="7">' .
                    $_L['No Data Available'] .
                    '</td> </tr>';
            }

            echo '<table class="table table-bordered table-hover sys_table">
    <thead>
    <tr>
        <th>#</th>
        <th>' .
                $_L['Date'] .
                '</th>
        <th>' .
                $_L['Account'] .
                '</th>
        <th>' .
                $_L['Type'] .
                '</th>
        <th>' .
                $_L['Amount'] .
                '</th>
        <th>' .
                $_L['Description'] .
                '</th>
        <th>' .
                $_L['Dr'] .
                '</th>
        <th>' .
                $_L['Cr'] .
                '</th>
        <th>' .
                $_L['Balance'] .
                '</th>
        <th class="text-right">' .
                $_L['Manage'] .
                '</th>
    </tr>
    </thead>
    <tbody>

            
           ' .
                $tds .
                ' 
    

    </tbody>
</table>';
        }

        break;


    case 'company6_transactions':
        $cid = _post('cid');
        $d = ORM::for_table('sys_companies6')->find_one($cid);

        if ($d) {
            // find all customers with that company_id

            $customers = Contacts::findByCompany($cid);

            //  var_dump($invoices);

            if ($customers) {
                $transactions_payer = ORM::for_table('sys_transactions')
                    ->where_in('payerid', $customers)
                    ->find_array();
                $transactions_payee = ORM::for_table('sys_transactions')
                    ->where_in('payeeid', $customers)
                    ->find_array();

                $transactions = array_merge(
                    $transactions_payer,
                    $transactions_payee
                );

                $dt = '';

                foreach ($transactions as $transaction) {
                    $dt .=
                        '<tr>
            <td>' .
                        $transaction['id'] .
                        ' </td>
            <td>' .
                        $transaction['date'] .
                        '</td>
            <td>' .
                        $transaction['account'] .
                        '</td>
            <td>' .
                        $transaction['type'] .
                        '</td>
          
            <td class="amount" data-a-dec="." data-a-sep="," data-a-pad="true" data-p-sign="p" data-a-sign="$ " data-d-group="3">' .
                        $transaction['amount'] .
                        '</td>
            <td>' .
                        $transaction['description'] .
                        '</td>
            <td>' .
                        $transaction['dr'] .
                        '</td>
            <td>' .
                        $transaction['cr'] .
                        '</td>
            <td>' .
                        $transaction['bal'] .
                        '</td>
            <td>
                <a href="' .
                        U .
                        'transactions/manage/' .
                        $transaction['id'] .
                        '/" class="btn btn-primary btn-xs"><i class="fa fa-check"></i></a>
                
            </td>
        </tr>';
                }

                if ($dt == '') {
                    $tds =
                        '<tr><td colspan="7">' .
                        $_L['No Data Available'] .
                        '</td> </tr>';
                } else {
                    $tds = $dt;
                }
            } else {
                $tds =
                    '<tr><td colspan="7">' .
                    $_L['No Data Available'] .
                    '</td> </tr>';
            }

            echo '<table class="table table-bordered table-hover sys_table">
    <thead>
    <tr>
        <th>#</th>
        <th>' .
                $_L['Date'] .
                '</th>
        <th>' .
                $_L['Account'] .
                '</th>
        <th>' .
                $_L['Type'] .
                '</th>
        <th>' .
                $_L['Amount'] .
                '</th>
        <th>' .
                $_L['Description'] .
                '</th>
        <th>' .
                $_L['Dr'] .
                '</th>
        <th>' .
                $_L['Cr'] .
                '</th>
        <th>' .
                $_L['Balance'] .
                '</th>
        <th class="text-right">' .
                $_L['Manage'] .
                '</th>
    </tr>
    </thead>
    <tbody>

            
           ' .
                $tds .
                ' 
    

    </tbody>
</table>';
        }

        break;
    case 'viewdoc':
        $id = route(2);

        $doc = ORM::for_table('sys_documents')->find_one($id);

        if ($doc) {
            $ext = pathinfo($doc->file_path, PATHINFO_EXTENSION);

            $ui->assign('ext', $ext);

            $ui->assign('doc', $doc);

            $ui->display('documents_view.tpl');
        } else {
            i_close('Not Found');
        }

        break;

    case 'download':
        $id = route(2);

        $doc = ORM::for_table('sys_documents')->find_one($id);

        if ($doc) {
            $file = 'application/storage/docs/' . $doc->file_path;

            $c_type = mime_content_type($file);

            if (file_exists($file)) {
                $basename = basename($file);
                $mime = mime_content_type($file);
                $size = filesize($file);
                $fp = fopen($file, "rb");
                if (!($mime && $size && $fp)) {
                    return;
                }

                header("Content-type: " . $mime);
                header("Content-Length: " . $size);
                header(
                    "Content-Disposition: attachment; filename=" . $basename
                );
                header('Content-Transfer-Encoding: binary');
                header(
                    'Cache-Control: must-revalidate, post-check=0, pre-check=0'
                );
                fpassthru($fp);
            }
        } else {
            i_close('Not Found');
        }

        break;


    default:
        echo 'action not defined';
}
