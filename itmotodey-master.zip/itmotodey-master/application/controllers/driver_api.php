<?php

$version = route(1);


switch ($version) {
    case 'v2':
    
        if (isset($_GET['_METHOD'])) {
            $method = $_GET['_METHOD'];
        } else {
            $method = $_SERVER['REQUEST_METHOD'];
        }
        

        header('Access-Control-Allow-Origin: *');

        apiAuth();

        $object = route(2);

        switch ($object) {
            case 'auth':
            switch ($method) {
              
               case 'POST':
                           $email = _post('username');
                           $password = _post('password');
                   
                           $remember_me = _post('remember_me');
                   
                           $auth = Contacts2::login($email, $password);
                           if($auth){
                                
                            jsonResponse(['tokent'=>$auth,
                           'user'=>ORM::for_table('crm_accounts2')
                           ->where('token', $auth)
                           ->find_array(),
                            ]
                       );
                        echo 'login succesful';
                        
                        }
                        else{
                        echo 'error';
                        }
                   break;
           
                   default:
                   jsonResponse([
                       'error' => true,
                       'message' => 'Unknown Method!',
                   ]);

                   break;
           }
            break;
            case 'lsps':
                switch ($method) {
                    case 'GET':
                        jsonResponse(
                            Contact::orderBy('id', 'desc')
                                ->get()
                                ->toArray()
                        );

                        break;

                    case 'POST':
                        break;

                    case 'PUT':
                        break;

                    case 'DELETE':
                        break;

                    default:
                        jsonResponse([
                            'error' => true,
                            'message' => 'Unknown Method!',
                        ]);

                        break;
                }

                break;

                case 'tradelist':
                
                switch ($method) {
                    case 'GET': $purchasePackagingMaterialCount    = ORM::for_table('sys_companies4')->count();

                        jsonResponse([
                            'Submited Transport Request' =>  Company6::orderBy('id', 'desc') ->count(),
                            'Submited Rental of Agricultural Equipment' =>  Company1::orderBy('id', 'desc') ->count(),
                            'Submited Rental Heavy Machine' =>  Company2::orderBy('id', 'desc') ->count(),
                            'Submited Purchase construction material' =>  Company::orderBy('id', 'desc') ->count(),
                            'Submited Purchase packaging material' =>  Company4::orderBy('id', 'desc') ->count(),
                            'Submited Purchase packaging materials' => ORM::for_table('sys_companies4')->count()

                               
                        ]);

                        break;

                    case 'POST':
                        break;

                    case 'PUT':
                        break;

                    case 'DELETE':
                        break;

                    default:
                        jsonResponse([
                            'error' => true,
                            'message' => 'Unknown Method!',
                        ]);

                        break;
                }

                break;
                case 'motodey_rental_heavy_machine_trade':
                
                switch ($method) {
                    case 'GET': 
                    $tradeId = route(3);
                    $hasConversations = false;
                    $itemTable = 'sys_companies2';
                    $trade = ORM::for_table($itemTable)
                        ->table_alias('c')
                        ->select('c.*')
                        ->select_expr('(SELECT account FROM crm_accounts_1 WHERE  id = c.lsr_id)', 'comp')
                        ->select_expr('(SELECT email FROM crm_accounts_1 WHERE  id = c.lsr_id)', 'lsr_email')
                        ->where('id', $tradeId)
                        ->find_array();

                    // the 'trades table' content
                    $tradeContent = ORM::for_table('trades')->where(array(
                        'item_id' => $tradeId,
                        'item_table' => $itemTable,
                    ))->find_array();
                    if ($tradeContent) {
                        $hasConversations = true;
                    }
                    
                    $lsps    = ORM::for_table('crm_accounts')->find_array();

                        jsonResponse([
                             $tradeContent,
                            'trade' =>  Company2::orderBy('id', 'desc') ->find($tradeId),
                            'hasConversations' =>  $hasConversations,
                            
                            'lsps' =>$lsps 

                               
                        ]);

                        break;

                    case 'POST':
                        break;

                    case 'PUT':
                        break;

                    case 'DELETE':
                        break;

                    default:
                        jsonResponse([
                            'error' => true,
                            'message' => 'Unknown Method!',
                        ]);

                        break;
                }

                break;
             case 'lsp_rental_heavy_machine_trade':
                
                switch ($method) {
                    case 'GET': 
                    $tradeId = route(3);
                    $hasConversations = false;
                    $itemTable = 'sys_companies2';
                    $trade = ORM::for_table($itemTable)
                        ->table_alias('c')
                        ->select('c.*')
                        ->select_expr('(SELECT account FROM crm_accounts_1 WHERE  id = c.lsr_id)', 'comp')
                        ->select_expr('(SELECT email FROM crm_accounts_1 WHERE  id = c.lsr_id)', 'lsr_email')
                        ->where('id', $tradeId)
                        ->find_array();

                    // the 'trades table' content
                    $tradeContent = ORM::for_table('trades')->where(array(
                        'item_id' => $tradeId,
                        'item_table' => $itemTable,
                    ))->find_array();
                    if ($tradeContent) {
                        $hasConversations = true;
                    }
                    
                    $lsps    = ORM::for_table('crm_accounts')->find_array();

                        jsonResponse([
                             $tradeContent,
                            'trade' =>  Company2::orderBy('id', 'desc') ->find($tradeId),
                            'hasConversations' =>  $hasConversations,
                            
                            'lsps' =>$lsps 

                               
                        ]);

                        break;

                    case 'POST':
                        break;

                    case 'PUT':
                        break;

                    case 'DELETE':
                        break;

                    default:
                        jsonResponse([
                            'error' => true,
                            'message' => 'Unknown Method!',
                        ]);

                        break;
                }

                break;
                case 'motodey_submit_lsr_trade':
                
                switch ($method) {
                    case 'GET': 
                    $tradeId = route(3);
                    $hasConversations = false;
                    $itemTable = 'sys_companies6';
                    $trade = ORM::for_table($itemTable)
                        ->table_alias('c')
                        ->select('c.*')
                        ->select_expr('(SELECT account FROM crm_accounts_1 WHERE  id = c.lsr_id)', 'comp')
                        ->select_expr('(SELECT email FROM crm_accounts_1 WHERE  id = c.lsr_id)', 'lsr_email')
                        ->where('id', $tradeId)
                        ->find_array();

                    // the 'trades table' content
                    $tradeContent = ORM::for_table('trades')->where(array(
                        'item_id' => $tradeId,
                        'item_table' => $itemTable,
                    ))->find_array();
                    if ($tradeContent) {
                        $hasConversations = true;
                    }
                    
                    $lsps    = ORM::for_table('crm_accounts')->find_array();

                        jsonResponse([
                             $tradeContent,
                            'trade' =>  Company6::orderBy('id', 'desc') ->find($tradeId),
                            'hasConversations' =>  $hasConversations,
                            
                            'lsps' =>$lsps 

                               
                        ]);

                        break;

                    case 'POST':
                        break;

                    case 'PUT':
                        break;

                    case 'DELETE':
                        break;

                    default:
                        jsonResponse([
                            'error' => true,
                            'message' => 'Unknown Method!',
                        ]);

                        break;
                }

                break;

                case 'motodey_rental_of_agricultural_equipment':
                
                switch ($method) {
                    case 'GET': 
                    $tradeId = route(3);
                    $hasConversations = false;
                    $itemTable = 'sys_companies1';
                    $trade = ORM::for_table($itemTable)
                        ->table_alias('c')
                        ->select('c.*')
                        ->select_expr('(SELECT account FROM crm_accounts_1 WHERE  id = c.lsr_id)', 'comp')
                        ->select_expr('(SELECT email FROM crm_accounts_1 WHERE  id = c.lsr_id)', 'lsr_email')
                        ->where('id', $tradeId)
                        ->find_array();

                    // the 'trades table' content
                    $tradeContent = ORM::for_table('trades')->where(array(
                        'item_id' => $tradeId,
                        'item_table' => $itemTable,
                    ))->find_array();
                    if ($tradeContent) {
                        $hasConversations = true;
                    }
                    
                    $lsps    = ORM::for_table('crm_accounts')->find_array();

                        jsonResponse([
                             $tradeContent,
                            'trade' =>  Company1::orderBy('id', 'desc') ->find($tradeId),
                            'hasConversations' =>  $hasConversations,
                            
                            'lsps' =>$lsps 

                               
                        ]);

                        break;

                    case 'POST':
                        break;

                    case 'PUT':
                        break;

                    case 'DELETE':
                        break;

                    default:
                        jsonResponse([
                            'error' => true,
                            'message' => 'Unknown Method!',
                        ]);

                        break;
                }

                break;
                case 'motodey_purchase_construction_material':
                
                switch ($method) {
                    case 'GET': 
                    $tradeId = route(3);
                    $hasConversations = false;
                    $itemTable = 'sys_companies';
                    $trade = ORM::for_table($itemTable)
                        ->table_alias('c')
                        ->select('c.*')
                        ->select_expr('(SELECT account FROM crm_accounts_1 WHERE  id = c.lsr_id)', 'comp')
                        ->select_expr('(SELECT email FROM crm_accounts_1 WHERE  id = c.lsr_id)', 'lsr_email')
                        ->where('id', $tradeId)
                        ->find_array();

                    // the 'trades table' content
                    $tradeContent = ORM::for_table('trades')->where(array(
                        'item_id' => $tradeId,
                        'item_table' => $itemTable,
                    ))->find_array();
                    if ($tradeContent) {
                        $hasConversations = true;
                    }
                    
                    $lsps    = ORM::for_table('crm_accounts')->find_array();

                        jsonResponse([
                             $tradeContent,
                            'trade' =>  Company::orderBy('id', 'desc') ->find($tradeId),
                            'hasConversations' =>  $hasConversations,
                            
                            'lsps' =>$lsps 

                               
                        ]);

                        break;

                    case 'POST':
                        break;

                    case 'PUT':
                        break;

                    case 'DELETE':
                        break;

                    default:
                        jsonResponse([
                            'error' => true,
                            'message' => 'Unknown Method!',
                        ]);

                        break;
                }

                break;
                case 'motodey_purchase_packaging_material':
                
                switch ($method) {
                    case 'GET': 
                    $tradeId = route(3);
                    $hasConversations = false;
                    $itemTable = 'sys_companies4';
                    $trade = ORM::for_table($itemTable)
                        ->table_alias('c')
                        ->select('c.*')
                        ->select_expr('(SELECT account FROM crm_accounts_1 WHERE  id = c.lsr_id)', 'comp')
                        ->select_expr('(SELECT email FROM crm_accounts_1 WHERE  id = c.lsr_id)', 'lsr_email')
                        ->where('id', $tradeId)
                        ->find_array();

                    // the 'trades table' content
                    $tradeContent = ORM::for_table('trades')->where(array(
                        'item_id' => $tradeId,
                        'item_table' => $itemTable,
                    ))->find_array();
                    if ($tradeContent) {
                        $hasConversations = true;
                    }
                    
                    $lsps    = ORM::for_table('crm_accounts')->find_array();

                        jsonResponse([
                             $tradeContent,
                            'trade' =>  Company4::orderBy('id', 'desc') ->find($tradeId),
                            'hasConversations' =>  $hasConversations,
                            
                            'lsps' =>$lsps 

                               
                        ]);

                        break;

                    case 'POST':
                        break;

                    case 'PUT':
                        break;

                    case 'DELETE':
                        break;

                    default:
                        jsonResponse([
                            'error' => true,
                            'message' => 'Unknown Method!',
                        ]);

                        break;
                }

                break;
                case 'lsrs':
                switch ($method) {
                    case 'GET':
                        jsonResponse(
                            Contact1::orderBy('id', 'desc')
                                ->get()
                                ->toArray()
                        );

                        break;

                    case 'POST':
                        break;

                    case 'PUT':
                        break;

                    case 'DELETE':
                        break;

                    default:
                        jsonResponse([
                            'error' => true,
                            'message' => 'Unknown Method!',
                        ]);

                        break;
                }

                break;
                case 'drivers':
                switch ($method) {
                    case 'GET':
                        jsonResponse(
                            Contact2::orderBy('id', 'desc')
                                ->get()
                                ->toArray()
                        );

                        break;

                    case 'POST':
                        break;

                    case 'PUT':
                        break;

                    case 'DELETE':
                        break;

                    default:
                        jsonResponse([
                            'error' => true,
                            'message' => 'Unknown Method!',
                        ]);

                        break;
                }

                break;
                case 'Rental_of_Agricultural_Equipments':
                switch ($method) {
                    case 'GET':
                        jsonResponse(
                            Company1::orderBy('id', 'desc')
                                ->get()
                                ->toArray()
                        );

                        break;

                    case 'POST':
                        break;

                    case 'PUT':
                        break;

                    case 'DELETE':
                        break;

                    default:
                        jsonResponse([
                            'error' => true,
                            'message' => 'Unknown Method!',
                        ]);

                        break;
                }

                break;
                case 'lsp_drivers':
                switch ($method) {
                    case 'GET':
                        jsonResponse(
                            Company3::orderBy('id', 'desc')
                                ->get()
                                ->toArray()
                        );

                        break;

                    case 'POST':
                        break;

                    case 'PUT':
                        break;

                    case 'DELETE':
                        break;

                    default:
                        jsonResponse([
                            'error' => true,
                            'message' => 'Unknown Method!',
                        ]);

                        break;
                }

                break;
                case 'Rental_Heavy_Machines':
                switch ($method) {
                    case 'GET':
                        jsonResponse(
                            Company2::orderBy('id', 'desc')
                                ->get()
                                ->toArray()
                        );

                        break;

                    case 'POST':
                        break;

                    case 'PUT':
                        break;

                    case 'DELETE':
                        break;

                    default:
                        jsonResponse([
                            'error' => true,
                            'message' => 'Unknown Method!',
                        ]);

                        break;
                }

                break;
                case 'Purchase_Construction_Materials':
                switch ($method) {
                    case 'GET':
                        jsonResponse(
                            Company::orderBy('id', 'desc')
                                ->get()
                                ->toArray()
                        );

                        break;

                    case 'POST':
                        break;

                    case 'PUT':
                        break;

                    case 'DELETE':
                        break;

                    default:
                        jsonResponse([
                            'error' => true,
                            'message' => 'Unknown Method!',
                        ]);

                        break;
                }

                break;
                case 'Purchase_Parkaging_Materials':
                switch ($method) {
                    case 'GET':
                        jsonResponse(
                            Company4::orderBy('id', 'desc')
                                ->get()
                                ->toArray()
                        );

                        break;

                    case 'POST':
                        break;

                    case 'PUT':
                        break;

                    case 'DELETE':
                        break;

                    default:
                        jsonResponse([
                            'error' => true,
                            'message' => 'Unknown Method!',
                        ]);

                        break;
                }

                break;
                case 'Submit_Transport_Requests':
                switch ($method) {
                    case 'GET':
                        jsonResponse(
                            Company6::orderBy('id', 'desc')
                                ->get()
                                ->toArray()
                        );

                        break;

                    case 'POST':
                        break;

                    case 'PUT':
                        break;

                    case 'DELETE':
                        break;
                        

                    default:
                        jsonResponse([
                            'error' => true,
                            'message' => 'Unknown Method!',
                        ]);

                        break;
                }

                break;
                case 'Trucks_Registrations':
                switch ($method) {
                    case 'GET':
                        jsonResponse(
                            Company5::orderBy('id', 'desc')
                                ->get()
                                ->toArray()
                        );

                        break;

                    case 'POST':
                        break;

                    case 'PUT':
                        break;

                    case 'DELETE':
                        break;

                    default:
                        jsonResponse([
                            'error' => true,
                            'message' => 'Unknown Method!',
                        ]);

                        break;
                }

                break;

            case 'lsp':
                switch ($method) {
                    case 'GET':
                   
                        $id = route(3);

                        $contact = Contact::find($id)->toArray();

                        if ($contact) {
                           
                            jsonResponse($contact);
                        } else {
                            jsonResponse([
                                'error' => true,
                                'message' => 'Contact not found!',
                            ]);
                        }

                        break;

                    case 'POST':
                        $errors = [];

                        $account = _post('account');

                        $type_customer = _post('customer');
                        $type_supplier = _post('supplier');

                        $type = $type_customer . ',' . $type_supplier;
                        $type = trim($type, ',');

                        if ($type == '') {
                            $type = 'Customer';
                        }

                         $company = _post('company');

                        $company_id = _post('company_id');

                        $company = '';
                        $cid = 0;

                        $email = _post('email');
                        $username = _post('username');
                        $phone = _post('phone');
                        $currency = _post('currency');

                        $address = _post('address');
                        $city = _post('city');
                        $state = _post('state');
                        $zip = _post('zip');
                        $country = _post('country');
                        $trucks = _post('trucks');
                        $fname = _post('fname');
                        $lname = _post('fname');

                        // $owner_id = _post('owner_id');

                        // if ($owner_id == '') {
                        //     $owner_id = 0;
                        // }

                        // if ($company_id != '') {
                        //     if ($company_id != '0') {
                        //         $company_db = db_find_one(
                        //             'sys_companies',
                        //             $company_id
                        //         );

                        //         if ($company_db) {
                        //             $company = $company_db->company_name;
                        //             $cid = $company_id;
                        //         }
                        //     }
                        // } elseif (_post('company') != '') {
                        //     // create compnay
                        //     $company = _post('company');
                        //     $c = new Company();

                        //     $c->company_name = $company;
                        //     $c->email = $email;
                        //     $c->phone = $phone;
                                                                                
                        //     $c->address1 = $address;
                        //     $c->city = $city;
                        //     $c->state = $state;
                        //     $c->zip = $zip;
                        //     $c->country = $country;

                        //     $c->save();

                        //     $cid = $c->id;
                        // }

                        // if ($currency == '') {
                        //     $currency = '0';
                        // }

                        // if (isset($_POST['tags']) and $_POST['tags'] != '') {
                        //     $tags = $_POST['tags'];
                        // } else {
                        //     $tags = '';
                        // }

                        if ($account == '') {
                            $errors[] = $_L['Account Name is required'];
                        }

                        if ($email != '') {
                            if (Validator::Email($email) == false) {
                                $errors[] = $_L['Invalid Email'];
                            }
                            $f = ORM::for_table('crm_accounts')
                                ->where('email', $email)
                                ->find_one();

                            if ($f) {
                                $errors[] = $_L['Email already exist'];
                            }
                        }

                        if ($phone != '') {
                            $f = ORM::for_table('crm_accounts')
                                ->where('phone', $phone)
                                ->find_one();

                            if ($f) {
                                $errors[] = $_L['Phone number already exist'];
                            }
                        }

                        // $gid = _post('group');

                        // if ($gid != '') {
                        //     $g = db_find_one('crm_groups', $gid);
                        //     $gname = $g['gname'];
                        // } else {
                        //     $gid = 0;
                        //     $gname = '';
                        // }

                        $password = _post('password');

                        $u_password = '';

                        if ($password != '') {
                            if (!Validator::Length($password, 15, 5)) {
                                $errors[] =
                                    'Password should be between 6 to 15 characters';
                            }

                            $u_password = $password;
                            $password = Password::_crypt($password);
                            $admin_file_token = '';
                            $trucks_files_token = '';
                            $transport_license_file_token = '';
                    
                            if (array_key_exists('adminfile', $_FILES)) {
                                $uploadResult = uploadFile('adminfile');
                    
                                if (!$uploadResult['success']) {
                                    $msg .= 'Administrative file: ' . $uploadResult['msg'] . '<br>';
                                } else {
                                    $admin_file_token = $uploadResult['token'];
                                }
                            }
                    
                            if (array_key_exists('trucksfiles', $_FILES)) {
                                $uploadResult = uploadFile('trucksfiles');
                    
                                if (!$uploadResult['success']) {
                                    $msg .= 'Trucks files: ' . $uploadResult['msg'] . '<br>';
                                } else {
                                    $trucks_files_token = $uploadResult['token'];
                                }
                            }
                    
                            if (array_key_exists('transport_license', $_FILES)) {
                                $uploadResult = uploadFile('transport_license');
                    
                                if (!$uploadResult['success']) {
                                    $msg .= 'Transport License: ' . $uploadResult['msg'] . '<br>';
                                } else {
                                    $transport_license_file_token = $uploadResult['token'];
                                }
                            }
                        }
                       
                        if (empty($errors)) {
                            // Tags::save($tags, 'Contacts');

                            $data = [];

                            $data['created_at'] = date('Y-m-d H:i:s');
                            $data['updated_at'] = date('Y-m-d H:i:s');

                            //  $type = _post('type');

                            $d = ORM::for_table('crm_accounts')->create();

                            $d->account = $account;
                            $d->email = $email;
                            $d->phone = $phone;
                            $d->address = $address;
                            $d->city = $city;
                            $d->zip = $zip;
                            $d->admin_file_token             = $admin_file_token;
                            $d->trucks_files_token           = $trucks_files_token;
                            $d->transport_license_file_token = $transport_license_file_token;
            
                            $d->state = $state;
                            $d->country = $country;
                           // $d->tags = Arr::arr_to_str($tags);

                            //others
                            $d->trucks = $trucks;
                            $d->fname =  $fname;
                            $d->lname =  $lname;
                            $d->company = $company;
                            // $d->jobtitle = '';
                            $d->cid = $cid;
                            // $d->o = $owner_id;
                            $d->balance = '0.00';
                            $d->status = 'Active';
                            $d->notes = '';
                            $d->password = $password;
                            $d->token = '';
                            $d->tags = '';
                            $d->ts = '';
                            $d->img = '';
                            $d->web = '';
                            $d->facebook = '';
                            $d->google = '';
                            $d->linkedin = '';

                            // v 4.2

                           // $d->gname = $gname;
                           // $d->gid = $gid;

                            // build 4550

                         //   $d->currency = $currency;

                            //

                            $d->created_at = $data['created_at'];

                            //$d->type = $type;

                            //

                            // $d->business_number = _post('business_number');

                            // $d->fax = _post('fax');

                            //

                            //

                            // $drive = time() . Ib_Str::random_string(12);

                            // $d->drive = $drive;

                            //
                            try {
                                $d->save();
                                jsonResponse([
                                    'error' => false,
                                    'contact_id' => $cid,
                                    'message' =>
                                        $_L['account_created_successfully'],
                                ]);
                            } catch (Exception $error) {
                            
                                jsonResponse($error);
                                exit();
                            
                            }
                            $cid = $d->id();
                           
                            _log(
                                $_L['New Contact Added'] .
                                    ' ' .
                                    $account .
                                    ' [CID: ' .
                                    $cid .
                                    ']',
                                'Admin',
                                $owner_id
                            );

                            Event::trigger('contacts/add-post/_on_finished');

                            // send welcome email if needed

                            $send_client_signup_email = _post(
                                'send_client_signup_email'
                            );

                            if (
                                $email != '' &&
                                $send_client_signup_email == 'Yes' &&
                                $u_password != ''
                            ) {
                                $email_data = [];
                                $email_data['account'] = $account;
                                $email_data['company'] = $company;
                                $email_data['password'] = $u_password;
                                $email_data['email'] = $email;

                                $send_email = Ib_Email::send_client_welcome_email(
                                    $email_data
                                );
                            }

                            // Create Drive if this feature is enabled

                            if ($config['client_drive'] == '1') {
                                if (
                                    !file_exists(
                                        'storage/drive/customers/' .
                                            $drive .
                                            '/storage'
                                    )
                                ) {
                                    mkdir(
                                        'storage/drive/customers/' .
                                            $drive .
                                            '/storage',
                                        0777,
                                        true
                                    );
                                }
                            }

                            //

                            jsonResponse([
                                'error' => false,
                                'contact_id' => $cid,
                                'message' =>
                                    $_L['account_created_successfully'],
                            ]);
                        } else {
                            jsonResponse([
                                'error' => true,
                                'message' => $errors,
                            ]);
                        }

                        break;

                    case 'PUT':
                   
                    
                        break;

                    case 'DELETE':
                     $id = route(3);
                         $lsp = Model::factory('Models_Contact');

                          $c = $lsp->find_one($id);

                                if ($c) {
                                    $c->delete();
                                    if($c){
                                        echo 'Account deleted successfully';
                                    }

                                  //  r2(U . 'contacts1', 's', $_L['Deleted Successzfully']); 
                                }
                        break;

                    default:
                        jsonResponse([
                            'error' => true,
                            'message' => 'Unknown Method!',
                        ]);

                        break;
                }

                break;
                
                case 'lsr':
                switch ($method) {
                    case 'GET':
                   
                        $id = route(3);

                        $contact = Contact1::find($id)->toArray();

                        if ($contact) {
                           // die ('hi');
                            jsonResponse($contact);
                        } else {
                            jsonResponse([
                                'error' => true,
                                'message' => 'Contact not found!',
                            ]);
                        }

                        break;

                    case 'POST':
                    $errors = [];

                    $account = _post('account');

                    $type_customer = _post('customer');
                    $type_supplier = _post('supplier');

                    $type = $type_customer . ',' . $type_supplier;
                    $type = trim($type, ',');

                    if ($type == '') {
                        $type = 'Customer';
                    }

                     $company = _post('company');

                    $company_id = _post('company_id');

                    $company = '';
                    $cid = 0;

                    $email = _post('email');
                    $username = _post('username');
                    $phone = _post('phone');
                    $currency = _post('currency');

                    $address = _post('address');
                    $city = _post('city');
                    $state = _post('state');
                    $zip = _post('zip');
                    $country = _post('country');
                    $trucks = _post('trucks');
                    $fname = _post('fname');
                    $lname = _post('lname');

                    if ($account == '') {
                        $errors[] = $_L['Account Name is required'];
                    }

                    if ($email != '') {
                        if (Validator::Email($email) == false) {
                            $errors[] = $_L['Invalid Email'];
                        }
                        $f = ORM::for_table('crm_accounts_1')
                            ->where('email', $email)
                            ->find_one();

                        if ($f) {
                            $errors[] = $_L['Email already exist'];
                        }
                    }

                    if ($phone != '') {
                        $f = ORM::for_table('crm_accounts_1')
                            ->where('phone', $phone)
                            ->find_one();

                        if ($f) {
                            $errors[] = $_L['Phone number already exist'];
                        }
                    }
                    $password = _post('password');

                    $u_password = '';

                    if ($password != '') {
                        if (!Validator::Length($password, 15, 5)) {
                            $errors[] =
                                'Password should be between 6 to 15 characters';
                        }

                        $u_password = $password;
                        $password = Password::_crypt($password);
                       
                
                        
                    }
                   
                    if (empty($errors)) {
                        // Tags::save($tags, 'Contacts');

                        $data = [];

                        $data['created_at'] = date('Y-m-d H:i:s');
                        $data['updated_at'] = date('Y-m-d H:i:s');

                        //  $type = _post('type');

                        $d = ORM::for_table('crm_accounts_1')->create();

                        $d->account = $account;
                        $d->email = $email;
                        $d->phone = $phone;
                        $d->address = $address;
                        $d->city = $city;
                        $d->zip = $zip;
                      
                        $d->state = $state;
                        $d->country = $country;
                       
                        $d->fname =  $fname;
                        $d->lname =  $lname;
                        $d->company = $company;
                        $d->jobtitle = '';
                        $d->cid = $cid;
                      
                        $d->balance = '0.00';
                        $d->status = 'Active';
                        $d->notes = '';
                        $d->password = $password;
                        $d->token = '';
                        $d->tags = '';
                        $d->ts = '';
                        $d->img = '';
                        $d->web = '';
                        $d->facebook = '';
                        $d->google = '';
                        $d->linkedin = '';

                     

                        $d->created_at = $data['created_at'];

                      
                        try {
                            $d->save();
                            jsonResponse([
                                'error' => false,
                                'contact_id' => $cid,
                                'message' =>
                                    $_L['account_created_successfully'],
                            ]);
                        } catch (Exception $error) {
                        
                            jsonResponse($error);
                            exit();
                        
                        }
                        $cid = $d->id();
                       
                        _log(
                            $_L['New Contact Added'] .
                                ' ' .
                                $account .
                                ' [CID: ' .
                                $cid .
                                ']',
                            'Admin',
                            $owner_id
                        );

                        Event::trigger('contacts1/add-post/_on_finished');

                        // send welcome email if needed

                        $send_client_signup_email = _post(
                            'send_client_signup_email'
                        );

                        if (
                            $email != '' &&
                            $send_client_signup_email == 'Yes' &&
                            $u_password != ''
                        ) {
                            $email_data = [];
                            $email_data['account'] = $account;
                            $email_data['company'] = $company;
                            $email_data['password'] = $u_password;
                            $email_data['email'] = $email;

                            $send_email = Ib_Email::send_client_welcome_email(
                                $email_data
                            );
                        }

                        // Create Drive if this feature is enabled

                        if ($config['client_drive'] == '1') {
                            if (
                                !file_exists(
                                    'storage/drive/customers/' .
                                        $drive .
                                        '/storage'
                                )
                            ) {
                                mkdir(
                                    'storage/drive/customers/' .
                                        $drive .
                                        '/storage',
                                    0777,
                                    true
                                );
                            }
                        }

                        //

                        jsonResponse([
                            'error' => false,
                            'contact_id' => $cid,
                            'message' =>
                                $_L['account_created_successfully'],
                        ]);
                    } else {
                        jsonResponse([
                            'error' => true,
                            'message' => $errors,
                        ]);
                    }

                        break;

                    case 'PUT':
                    $id = route(3);
                    $lsr = Model::factory('Models_Contact1');

                    $d= $lsr->find_one($id);
                   // $d = ORM::for_table('crm_accounts_1')->find_one($id);
                    if ($d) {
                        $old_account = $d->account;
                        $account = _post('account');
                        $company = '';
                        $cid = 0;
                        $email = _post('edit_email');
                        $phone = _post('phone');
                        $address = _post('address');
                        $city = _post('city');
                        $fname = _post('fname');
                        $lname = _post('lname');
                        $notes = _post('notes');
            
                        $state = _post('state');
                        $zip = _post('zip');
                        $country = _post('country');
                        $msg = '';
            
                        if ($account == '') {
                            $msg .= $_L['Account Name is required'] . ' <br>';
                        }
                        if ($email != '') {
                            if ($email != $d['email']) {
                                $f = ORM::for_table('crm_accounts')
                                    ->where('email', $email)
                                    ->find_one();
            
                                if ($f) {
                                    $msg .= $_L['Email already exist'] . ' <br>';
                                }
                            }
                            if (Validator::Email($email) == false) {
                                $msg .= $_L['Invalid Email'] . ' <br>';
                            }
                        }
                        $password = _post('password');
                        if ($msg == '') {
                            $d = ORM::for_table('crm_accounts_1')->find_one($id);
                            $d->account = $account;
                            $d->company = $company;
                            $d->cid = $company_id;
                            $d->email = $email;
                            $d->phone = $phone;
                            $d->address = $address;
                            $d->fname = $fname;
                            $d->lname = $lname;
                            $d->city = $city;
                            $d->notes = $notes;
                            $d->zip = $zip;
                            $d->state = $state;
                            $d->country = $country;
                            $d->gname = $gname;
                            $d->gid = $gid;
            
                            $d->currency = $currency;
            
                            if ($password != '') {
                                $d->password = Password::_crypt($password);
                            }
                            $d->save();
                            if ($account != $old_account) {
                                $sql = "update sys_invoices set account='$account' where account='$old_account'";
            
                                ORM::execute($sql);
                            }
            
                            _msglog('s', $_L['account_updated_successfully']);
            
                            echo $id;
                        } else {
                            echo $msg;
                        }
                    } 
            
                        break;

                    case 'DELETE':
                    $id = route(3);
                         $lsr = Model::factory('Models_Contact1');

                          $c = $lsr->find_one($id);

                                if ($c) {
                                    $c->delete();
                                    if($c){
                                        echo 'Delete successful';
                                    }

                                  //  r2(U . 'contacts1', 's', $_L['Deleted Successzfully']); 
                                }
                        break;

                    default:
                        jsonResponse([
                            'error' => true,
                            'message' => 'Unknown Method!',
                        ]);

                        break;
                }

                break;
                case 'driver':
                switch ($method) {
                    case 'GET':
                   
                        $id = route(3);

                        $contact = Contact2::find($id)->toArray();

                        if ($contact) {
                          
                            jsonResponse($contact);
                        } else {
                            jsonResponse([
                                'error' => true,
                                'message' => 'Contact not found!',
                            ]);
                        }

                        break;

                    case 'POST':
                    $errors = [];

                    $account = _post('account');

                    $type_customer = _post('customer');
                    $type_supplier = _post('supplier');

                    $type = $type_customer . ',' . $type_supplier;
                    $type = trim($type, ',');

                    if ($type == '') {
                        $type = 'Customer';
                    }

                     $company = _post('company');

                    $company_id = _post('company_id');

                    $company = '';
                    $cid = 0;

                    $email = _post('email');
                    $username = _post('username');
                    $phone = _post('phone');
                    $currency = _post('currency');

                    $address = _post('address');
                    $city = _post('city');
                    $state = _post('state');
                    $zip = _post('zip');
                    $country = _post('country');
                    $trucks = _post('trucks');
                    $fname = _post('fname');
                    $lname = _post('lname');
                    $notes = _post('notes');

                    if ($account == '') {
                        $errors[] = $_L['Account Name is required'];
                    }

                    if ($email != '') {
                        if (Validator::Email($email) == false) {
                            $errors[] = $_L['Invalid Email'];
                        }
                        $f = ORM::for_table('crm_accounts2')
                            ->where('email', $email)
                            ->find_one();

                        if ($f) {
                            $errors[] = $_L['Email already exist'];
                        }
                    }

                    if ($phone != '') {
                        $f = ORM::for_table('crm_accounts2')
                            ->where('phone', $phone)
                            ->find_one();

                        if ($f) {
                            $errors[] = $_L['Phone number already exist'];
                        }
                    }
                    $password = _post('password');

                    $u_password = '';

                    if ($password != '') {
                        if (!Validator::Length($password, 15, 5)) {
                            $errors[] =
                                'Password should be between 6 to 15 characters';
                        }

                        $u_password = $password;
                        $password = Password::_crypt($password);
                       
                
                        
                    }
                    $picture_of_truck_token = '';
                    $picture_permit_token = '';
                  //  $transport_license_file_token = '';
            
                    if (array_key_exists('picture_permit', $_FILES)) {
                        $uploadResult = uploadFile('picture_permit');
            
                        if (!$uploadResult['success']) {
                            $msg .= 'picture_permit: ' . $uploadResult['msg'] . '<br>';
                        } else {
                            $picture_permit_token = $uploadResult['token'];
                        }
                    }
            
                    if (array_key_exists('picture_of_truck', $_FILES)) {
                        $uploadResult = uploadFile('picture_of_truck');
            
                        if (!$uploadResult['success']) {
                            $msg .= 'picture_of_truck: ' . $uploadResult['msg'] . '<br>';
                        } else {
                            $picture_of_truck_token = $uploadResult['token'];
                        }
                    }
                   
                    if (empty($errors)) {
                        // Tags::save($tags, 'Contacts');

                        $data = [];

                        $data['created_at'] = date('Y-m-d H:i:s');
                        $data['updated_at'] = date('Y-m-d H:i:s');

                        //  $type = _post('type');

                        $d = ORM::for_table('crm_accounts2')->create();

                        $d->account = $account;
                        $d->email = $email;
                        $d->phone = $phone;
                        $d->address = $address;
                        $d->city = $city;
                        $d->zip = $zip;
                        $d->notes = $notes;
                        $d->picture_of_truck_token             = $picture_of_truck_token;
                        $d->picture_permit_token           = $picture_permit_token;
                        $d->state = $state;
                        $d->country = $country;
                       
                        $d->fname =  $fname;
                        $d->lname =  $lname;
                        $d->company = $company;
                        $d->jobtitle = '';
                        $d->cid = $cid;
                      
                        $d->balance = '0.00';
                        $d->status = 'Active';
                        $d->notes = '';
                        $d->password = $password;
                        $d->token = '';
                        $d->tags = '';
                        $d->ts = '';
                        $d->img = '';
                        $d->web = '';
                        $d->facebook = '';
                        $d->google = '';
                        $d->linkedin = '';

                     

                        $d->created_at = $data['created_at'];

                      
                        try {
                            $d->save();
                            jsonResponse([
                                'error' => false,
                                'contact_id' => $cid,
                                'message' =>
                                    $_L['account_created_successfully'],
                            ]);
                        } catch (Exception $error) {
                        
                            jsonResponse($error);
                            exit();
                        
                        }
                        $cid = $d->id();
                       
                        _log(
                            $_L['New Contact Added'] .
                                ' ' .
                                $account .
                                ' [CID: ' .
                                $cid .
                                ']',
                            'Admin',
                            $owner_id
                        );

                        Event::trigger('contacts2/add-post/_on_finished');

                        // send welcome email if needed

                        $send_client_signup_email = _post(
                            'send_client_signup_email'
                        );

                        if (
                            $email != '' &&
                            $send_client_signup_email == 'Yes' &&
                            $u_password != ''
                        ) {
                            $email_data = [];
                            $email_data['account'] = $account;
                            $email_data['company'] = $company;
                            $email_data['password'] = $u_password;
                            $email_data['email'] = $email;

                            $send_email = Ib_Email::send_client_welcome_email(
                                $email_data
                            );
                        }

                        // Create Drive if this feature is enabled

                        if ($config['client_drive'] == '1') {
                            if (
                                !file_exists(
                                    'storage/drive/customers/' .
                                        $drive .
                                        '/storage'
                                )
                            ) {
                                mkdir(
                                    'storage/drive/customers/' .
                                        $drive .
                                        '/storage',
                                    0777,
                                    true
                                );
                            }
                        }

                        //

                        jsonResponse([
                            'error' => false,
                            'contact_id' => $cid,
                            'message' =>
                                $_L['account_created_successfully'],
                        ]);
                    } else {
                        jsonResponse([
                            'error' => true,
                            'message' => $errors,
                        ]);
                    }

                        break;

                    case 'PUT':
                    $id = route(3);
                    $driver = Model::factory('Models_Contact2');

                    $d= $driver->find_one($id);
                   // $d = ORM::for_table('crm_accounts_1')->find_one($id);
                    if ($d) {
                        $old_account = $d->account;
                        $account = _post('account');
                        $company = '';
                        $cid = 0;
                        $email = _post('edit_email');
                        $phone = _post('phone');
                        $address = _post('address');
                        $city = _post('city');
                        $fname = _post('fname');
                        $lname = _post('lname');
                        $notes = _post('notes');
            
                        $state = _post('state');
                        $zip = _post('zip');
                        $country = _post('country');
                        $msg = '';
                        $picture_of_truck_token = '';
                        $picture_permit_token = '';
                      //  $transport_license_file_token = '';
                
                        if (array_key_exists('picture_permit', $_FILES)) {
                            $uploadResult = uploadFile('picture_permit');
                
                            if (!$uploadResult['success']) {
                                $msg .= 'picture_permit: ' . $uploadResult['msg'] . '<br>';
                            } else {
                                $picture_permit_token = $uploadResult['token'];
                            }
                        }
                
                        if (array_key_exists('picture_of_truck', $_FILES)) {
                            $uploadResult = uploadFile('picture_of_truck');
                
                            if (!$uploadResult['success']) {
                                $msg .= 'picture_of_truck: ' . $uploadResult['msg'] . '<br>';
                            } else {
                                $picture_of_truck_token = $uploadResult['token'];
                            }
                        }
                
            
                        if ($account == '') {
                            $msg .= $_L['Account Name is required'] . ' <br>';
                        }
                        if ($email != '') {
                            if ($email != $d['email']) {
                                $f = ORM::for_table('crm_accounts2')
                                    ->where('email', $email)
                                    ->find_one();
            
                                if ($f) {
                                    $msg .= $_L['Email already exist'] . ' <br>';
                                }
                            }
                            if (Validator::Email($email) == false) {
                                $msg .= $_L['Invalid Email'] . ' <br>';
                            }
                        }
                        $password = _post('password');
                        if ($msg == '') {
                            $d = ORM::for_table('crm_accounts2')->find_one($id);
                            $d->account = $account;
                          //  $d->company = $company;
                            //$d->cid = $company_id;
                            $d->email = $email;
                            $d->phone = $phone;
                            $d->address = $address;
                            $d->fname = $fname;
                            $d->lname = $lname;
                            $d->city = $city;
                            $d->notes = $notes;
                            $d->zip = $zip;
                            $d->state = $state;
                            $d->country = $country;
                            // $d->gname = $gname; 
                            $d->picture_of_truck_token = $picture_of_truck_token;
                           $d->picture_permit_token  = $picture_permit_token;
                            // $d->gid = $gid;
            
                           // $d->currency = $currency;
            
                            if ($password != '') {
                                $d->password = Password::_crypt($password);
                            }
                            $d->save();
                            if ($account != $old_account) {
                                $sql = "update sys_invoices set account='$account' where account='$old_account'";
            
                                ORM::execute($sql);
                            }
            
                            _msglog('s', $_L['account_updated_successfully']);
            
                            echo $id;
                        } else {
                            echo $msg;
                        }
                    } 
            
                        break;

                    case 'DELETE':
                    $id = route(3);
                         $lsr = Model::factory('Models_Contact2');

                          $c = $lsr->find_one($id);

                                if ($c) {
                                    $c->delete();
                                    if($c){
                                        echo 'Delete successful';
                                    }

                                  //  r2(U . 'contacts1', 's', $_L['Deleted Successzfully']); 
                                }
                        break;

                    default:
                        jsonResponse([
                            'error' => true,
                            'message' => 'Unknown Method!',
                        ]);

                        break;
                }

                break;
                case 'Rental_of_Agricultural_Equipment':
                switch ($method) {
                    case 'GET':
                   
                        $id = route(3);

                        $contact = Company1::find($id)->toArray();

                        if ($contact) {
                          
                            jsonResponse($contact);
                        } else {
                            jsonResponse([
                                'error' => true,
                                'message' => 'Contact not found!',
                            ]);
                        }

                        break;

                    case 'POST':
                    $errors = [];

                    $company_name = _post('company_name');
                     $url = _post('url');

                    $emails = _post('emails');
                    $phone = _post('phone');
                    $username = _post('username');
                    $phone = _post('phone');
                    $logo_url = _post('logo_url');

                    $types_of_equipment = _post('types_of_equipment');
                    $pprice_per_hour = _post('pprice_per_hour');
                    $notes = _post('notes');
                    $description = _post('description');
                    $other_type = _post('other_type');
                    $start_date = _post('start_date');
                    $number_of_rental_day = _post('number_of_rental_day');
                    $end_date = _post('end_date');
                    $delivery_location = _post('delivery_location');
                    $observations = _post('observations');
                    $lsr_id = _post('lsr_id');
                    $picture_of_truck_token = '';
                    $picture_permit_token = '';
    
                  $picture1_file_token = '';
                  $picture2_file_token = '';
                  $data = [];
                  if ($types_of_equipment == '' && $other_type == '') {
                      i_close($_L['either Other Types or types of equipment is required']);
                  }
                  if (array_key_exists('picture1', $_FILES) && !empty($_FILES['picture1'])) {
                    $uploadResult = uploadFile('picture1');
        
                    if (!$uploadResult['success']) {
                        $msg .= 'Picture1: ' . $uploadResult['msg'] . '<br>';
                    } else {
                        $picture1_file_token = $uploadResult['token'];
                    }
                }
                if (array_key_exists('picture2', $_FILES) && !empty($_FILES['picture2'])) {
                    $uploadResult = uploadFile('picture2');
        
                    if (!$uploadResult['success']) {
                        $msg .= 'Picture2: ' . $uploadResult['msg'] . '<br>';
                    } else {
                        $picture2_file_token = $uploadResult['token'];
                    }
                }
        
                    if (empty($errors)) {
                        // Tags::save($tags, 'Contacts');

                     
                        $data['created_at'] = date('Y-m-d H:i:s');
                        $data['updated_at'] = date('Y-m-d H:i:s');

                       
       
                        $company1 = ORM::for_table('sys_companies1')->create();

                        $company1->company_name = $company_name;
                        $company1->url = $url;
                        $company1->lsr_id = $lsr_id;
                        $company1->notes = $notes;
                        $company1->tags = $tags;
                        $company1->phone = $phone;
                        $company1->types_of_equipment = $types_of_equipment;
                     
                        $company1->other_type = $other_type;
                        $company1->start_date = $start_date;
                        $company1->number_of_rental_day = $number_of_rental_day;
                        $company1->end_date = $end_date;
                        $company1->delivery_location = $delivery_location;
                        $company1->observations = $observations;
                        $company1->pprice_per_hour = $pprice_per_hour;
                
                       
                        $company1->picture1_file_token = $picture1_file_token;
                        $company1->picture2_file_token = $picture2_file_token;
                        $company1->description = $data['description'];
                        $company1->created_at = $data['created_at'];
                        $company1->updated_at = $data['updated_at'];

                      
                        try {
                            $company1->save();
                            echo $company1->id();
                            jsonResponse([
                                'error' => false,
                                'contact_id' => $cid,
                                'message' =>
                                    $_L['account_created_successfully'],
                            ]);
                        } catch (Exception $error) {
                        
                            jsonResponse($error);
                            exit();
                        
                        }
                        $cid = $d->id();
                       
                        _log(
                            $_L['New Contact Added'] .
                                ' ' .
                                $account .
                                ' [CID: ' .
                                $cid .
                                ']',
                            'Admin',
                            $owner_id
                        );

                       

                        jsonResponse([
                            'error' => false,
                            'contact_id' => $cid,
                            'message' =>
                                $_L['account_created_successfully'],
                        ]);
                    } else {
                        jsonResponse([
                            'error' => true,
                            'message' => $errors,
                        ]);
                    }

                        break;

                    case 'PUT':
                    
            
                        break;

                    case 'DELETE':
                    $id = route(3);
                         $lsr = Model::factory('Models_Company1');

                          $c = $lsr->find_one($id);

                                if ($c) {
                                    $c->delete();
                                    if($c){
                                        echo 'Delete successful';
                                    }

                                  //  r2(U . 'contacts1', 's', $_L['Deleted Successzfully']); 
                                }
                        break;

                    default:
                        jsonResponse([
                            'error' => true,
                            'message' => 'Unknown Method!',
                        ]);

                        break;
                }

                break;
                case 'Rental_Heavy_Machine':
                switch ($method) {
                    case 'GET':
                   
                        $id = route(3);

                        $contact = Company2::find($id)->toArray();

                        if ($contact) {
                          
                            jsonResponse($contact);
                        } else {
                            jsonResponse([
                                'error' => true,
                                'message' => 'Contact not found!',
                            ]);
                        }

                        break;

                    case 'POST':
                    $errors = [];

                    $company_name = _post('company_name');
                     $url = _post('url');

                    $emails = _post('emails');
                    $phone = _post('phone');
                    $username = _post('username');
                    $phone = _post('phone');
                    $logo_url = _post('logo_url');
                   
                    $number_of_rental_day = _post('number_of_rental_day');

                    $types_of_machine = _post('types_of_machine');
                    $number_of_working_hours = _post('number_of_working_hours');
                    $notes = _post('notes');
                    $description = _post('description');
                    $other_type = _post('other_type');
                    $start_date = _post('start_date');
                    $number_of_rental_day = _post('number_of_rental_day');
                    $end_date = _post('end_date');
                    $delivery_location = _post('delivery_location');
                    $observations = _post('observations');
                    $lsr_id = _post('lsr_id');
                    $picture1_file_token = '';
                    $picture2_file_token = '';
                    $picture3_file_token = '';
                    $picture4_file_token = '';
                  $data = [];
                  if ($types_of_equipment == '' && $other_type == '') {
                      i_close($_L['either Other Types or types of equipment is required']);
                  }
                  if (array_key_exists('picture1', $_FILES) && !empty($_FILES['picture1'])) {
                    $uploadResult = uploadFile('picture1');
        
                    if (!$uploadResult['success']) {
                        $msg .= 'Picture1: ' . $uploadResult['msg'] . '<br>';
                    } else {
                        $picture1_file_token = $uploadResult['token'];
                    }
                }
                if (array_key_exists('picture2', $_FILES) && !empty($_FILES['picture2'])) {
                    $uploadResult = uploadFile('picture2');
        
                    if (!$uploadResult['success']) {
                        $msg .= 'Picture2: ' . $uploadResult['msg'] . '<br>';
                    } else {
                        $picture2_file_token = $uploadResult['token'];
                    }
                }
                if (array_key_exists('picture3', $_FILES) && !empty($_FILES['picture3'])) {
                    $uploadResult = uploadFile('picture3');
        
                    if (!$uploadResult['success']) {
                        $msg .= 'Picture3: ' . $uploadResult['msg'] . '<br>';
                    } else {
                        $picture3_file_token = $uploadResult['token'];
                    }
                }
                if (array_key_exists('picture4', $_FILES) && !empty($_FILES['picture4'])) {
                    $uploadResult = uploadFile('picture4');
        
                    if (!$uploadResult['success']) {
                        $msg .= 'Picture4: ' . $uploadResult['msg'] . '<br>';
                    } else {
                        $picture4_file_token = $uploadResult['token'];
                    }
                }
                    if (empty($errors)) {
                        // Tags::save($tags, 'Contacts');

                     
                        $data['created_at'] = date('Y-m-d H:i:s');
                        $data['updated_at'] = date('Y-m-d H:i:s');

                       
       
                        $company2 = ORM::for_table('sys_companies2')->create();

                        $company2->company_name = $company_name;
                        $company2->url = $url;
                        $company2->lsr_id = $lsr_id;
                        $company2->notes = $notes;
                        $company2->tags = $tags;
                        $company2->phone = $phone;
                        $company2->types_of_machine = $types_of_machine;
                     
                        $company2->other_type = $other_type;
                        $company2->start_date = $start_date;
                        $company2->number_of_working_hours = $number_of_working_hours;
                        $company2->number_of_rental_day = $number_of_rental_day;
                        $company2->end_date = $end_date;
                        $company2->delivery_location = $delivery_location;
                        $company2->observations = $observations;
                        $company2->proposed_price_per_hours = $proposed_price_per_hours;
                
                       
                        $company2->picture1_file_token = $picture1_file_token;
                        $company2->picture2_file_token = $picture2_file_token;
                        $company2->picture3_file_token = $picture3_file_token;
                        $company2->picture4_file_token = $picture4_file_token;
                        $company2->description = $description;
                        $company2->created_at = $data['created_at'];
                        $company2->updated_at = $data['updated_at'];

                      
                        try {
                            $company2->save();
                            echo $company2->id();
                            jsonResponse([
                                'error' => false,
                                'contact_id' => $cid,
                                'message' =>
                                    $_L['account_created_successfully'],
                            ]);
                        } catch (Exception $error) {
                        
                            jsonResponse($error);
                            exit();
                        
                        }
                        $cid = $d->id();
                       
                        _log(
                            $_L['New Contact Added'] .
                                ' ' .
                                $account .
                                ' [CID: ' .
                                $cid .
                                ']',
                            'Admin',
                            $owner_id
                        );

                       

                        jsonResponse([
                            'error' => false,
                            'contact_id' => $cid,
                            'message' =>
                                $_L['account_created_successfully'],
                        ]);
                    } else {
                        jsonResponse([
                            'error' => true,
                            'message' => $errors,
                        ]);
                    }


                        break;

                    case 'PUT':
                    
                        break;

                    case 'DELETE':
                    $id = route(3);
                         $lsr = Model::factory('Models_Company2');

                          $c = $lsr->find_one($id);

                                if ($c) {
                                    $c->delete();
                                    if($c){
                                        echo 'Delete successful';
                                    }

                                  //  r2(U . 'contacts1', 's', $_L['Deleted Successzfully']); 
                                }
                        break;

                    default:
                        jsonResponse([
                            'error' => true,
                            'message' => 'Unknown Method!',
                        ]);

                        break;
                }

                break;
                case 'Purchase_Construction_Material':
                switch ($method) {
                    case 'GET':
                   
                        $id = route(3);

                        $contact = Company::find($id)->toArray();

                        if ($contact) {
                          
                            jsonResponse($contact);
                        } else {
                            jsonResponse([
                                'error' => true,
                                'message' => 'Contact not found!',
                            ]);
                        }

                        break;

                    case 'POST':
                    $errors = [];

                    $company_name = _post('company_name');


                     $url = _post('url');

                    $tags = _post('tags');

                    $quantity = _post('quantity');
                    $description = _post('description');
                    $delivery_time = _post('delivery_time');
                    $type_of_materials = _post('type_of_materials');

                    $weight = _post('weight');
                    $observations = _post('observations');
                    $delivery_location = _post('delivery_location');
                    $c1 = _post('c1');
                    $c2 = _post('c2');
                    $c3 = _post('c3');
                    $c4 = _post('c4');
                    $lsr_id = _post('lsr_id');
                    $logo_url = _post('logo_url');

                  

                   

                   
                    $password = _post('password');

                    $picture1_file_token = '';
                    $picture2_file_token = '';
                    $picture3_file_token = '';
                    $picture4_file_token = '';
                    if (array_key_exists('picture1', $_FILES) && !empty($_FILES['picture1'])) {
                        $uploadResult = uploadFile('picture1');
            
                        if (!$uploadResult['success']) {
                            $msg .= 'Picture1: ' . $uploadResult['msg'] . '<br>';
                        } else {
                            $picture1_file_token = $uploadResult['token'];
                        }
                    }
                    if (array_key_exists('picture2', $_FILES) && !empty($_FILES['picture2'])) {
                        $uploadResult = uploadFile('picture2');
            
                        if (!$uploadResult['success']) {
                            $msg .= 'Picture2: ' . $uploadResult['msg'] . '<br>';
                        } else {
                            $picture2_file_token = $uploadResult['token'];
                        }
                    }
                    if (array_key_exists('picture3', $_FILES) && !empty($_FILES['picture3'])) {
                        $uploadResult = uploadFile('picture3');
            
                        if (!$uploadResult['success']) {
                            $msg .= 'Picture3: ' . $uploadResult['msg'] . '<br>';
                        } else {
                            $picture3_file_token = $uploadResult['token'];
                        }
                    }
                    if (array_key_exists('picture4', $_FILES) && !empty($_FILES['picture4'])) {
                        $uploadResult = uploadFile('picture4');
            
                        if (!$uploadResult['success']) {
                            $msg .= 'Picture4: ' . $uploadResult['msg'] . '<br>';
                        } else {
                            $picture4_file_token = $uploadResult['token'];
                        }
                    }
                   
                    if (empty($errors)) {
                        // Tags::save($tags, 'Contacts');

                        $data = [];

                        $data['created_at'] = date('Y-m-d H:i:s');
                        $data['updated_at'] = date('Y-m-d H:i:s');

                        //  $type = _post('type');

                        $company = ORM::for_table('sys_companies')->create();

                        $company->company_name = $company_name;
                        $company->url = $url;
                        $company->tags = $tags;
                        $company->quantity = $quantity;
                        $company->description = $description;
                        $company->delivery_time = $delivery_time;
                        $company->type_of_materials = $type_of_materials;
                        $company->weight = $weight;
                        $company->observations = $observations;
                        $company->delivery_location = $delivery_location;
                        $company->c1 = $c1;
                        $company->c2 = $c2;
                        $company->c3 = $c3;
                        $company->c4 = $c4;
                        $company->lsr_id = $lsr_id;
                        $company->logo_url = $logo_url;
                        $company->picture1_file_token = $picture1_file_token;
                        $company->picture2_file_token = $picture2_file_token;
                        $company->picture3_file_token = $picture3_file_token;
                        $company->picture4_file_token = $picture4_file_token;
                
                        $company->created_at = $data['created_at'];
                        $company->updated_at = $data['updated_at'];

                        try {
                            $company->save();
                            jsonResponse([
                                'error' => false,
                                'contact_id' => $cid,
                                'message' =>
                                    $_L['account_created_successfully'],
                            ]);
                        } catch (Exception $error) {
                        
                            jsonResponse($error);
                            exit();
                        
                        }
                        $cid = $d->id();
                       
                        _log(
                            $_L['New Contact Added'] .
                                ' ' .
                                $account .
                                ' [CID: ' .
                                $cid .
                                ']',
                            'Admin',
                            $owner_id
                        );

                    

                        // Create Drive if this feature is enabled

                        //

                        jsonResponse([
                            'error' => false,
                            'contact_id' => $cid,
                            'message' =>
                                $_L['account_created_successfully'],
                        ]);
                    } else {
                        jsonResponse([
                            'error' => true,
                            'message' => $errors,
                        ]);
                    }

                        break;

                    case 'PUT':

                    break;

                    case 'DELETE':
                    $id = route(3);
                         $lsr = Model::factory('Models_Company');

                          $c = $lsr->find_one($id);

                                if ($c) {
                                    $c->delete();
                                    if($c){
                                        echo 'Delete successful';
                                    }

                                  //  r2(U . 'contacts1', 's', $_L['Deleted Successzfully']); 
                                }
                        break;

                    default:
                        jsonResponse([
                            'error' => true,
                            'message' => 'Unknown Method!',
                        ]);

                        break;
                }

                break;
                case 'Purchase_Parkaging_Material':
                switch ($method) {
                    case 'GET':
                   
                        $id = route(3);

                        $contact = Company4::find($id)->toArray();

                        if ($contact) {
                          
                            jsonResponse($contact);
                        } else {
                            jsonResponse([
                                'error' => true,
                                'message' => 'Contact not found!',
                            ]);
                        }

                        break;

                    case 'POST':
                    $errors = [];

                    $company_name = _post('company_name');

                    $url = _post('url');
                    $lsr_id = _post('lsr_id');


                     $address1 = _post('address1');

                    $tags = _post('tags');


                    $notes = _post('notes');
                    $logo_url = _post('logo_url');
                    $phone = _post('phone');
                    $logo_path = _post('logo_path');

                    $description = _post('description');
                    $type_of_materials = _post('type_of_materials');
                    $size = _post('size');
                    $weight = _post('weight');
                    $estimated_value = _post('estimated_value');
                    $delivery_location = _post('delivery_location');
                    $quantity = _post('quantity');
                    $informations = _post('informations');
                    $destination_country = _post('destination_country');

                    if ($type_of_materials == '') {
                        i_close($_L['the type of materials is required']);
                    }

                   
                    if (empty($errors)) {
                        // Tags::save($tags, 'Contacts');

                        $data = [];

                        $data['created_at'] = date('Y-m-d H:i:s');
                        $data['updated_at'] = date('Y-m-d H:i:s');

                        //  $type = _post('type');

                        $company4 = ORM::for_table('sys_companies4')->create();

                        $company4->company_name = $company_name;
                        $company4->url = $url;
                        $company4->lsr_id = $lsr_id;
                        $company4->phone = $phone;
                        // $company4->type_of_materials = $data['type_of_materials'];
                        $company4->address1 = $address1;
                        $company4->tags = $tags;
                        $company4->notes = $notes;
                
                        $company4->phone = $phone;
                        $company4->logo_url = $logo_url;
                        $company4->logo_path = $logo_path;
                        $company4->description = $description;
                        $company4->type_of_materials = $type_of_materials;
                        $company4->size = $size;
                        $company4->weight = $weight;
                        $company4->estimated_value = $estimated_value;
                        $company4->delivery_location = $delivery_location;
                        $company4->quantity = $quantity;
                        $company4->informations = $informations;
                        $company4->destination_country = $destination_country;
                        $company4->created_at = $data['created_at'];
                        $company4->updated_at = $data['updated_at'];

                        try {
                            $company4->save();
                            jsonResponse([
                                'error' => false,
                                'contact_id' => $cid,
                                'message' =>
                                    $_L['account_created_successfully'],
                            ]);
                        } catch (Exception $error) {
                        
                            jsonResponse($error);
                            exit();
                        
                        }
                        $cid = $d->id();
                       
                        _log(
                            $_L['New Contact Added'] .
                                ' ' .
                                $account .
                                ' [CID: ' .
                                $cid .
                                ']',
                            'Admin',
                            $owner_id
                        );


                        //

                        jsonResponse([
                            'error' => false,
                            'contact_id' => $cid,
                            'message' =>
                                $_L['account_created_successfully'],
                        ]);
                    } else {
                        jsonResponse([
                            'error' => true,
                            'message' => $errors,
                        ]);
                    }

                        break;

                    case 'PUT':
                    

                        break;

                    case 'DELETE':
                    $id = route(3);
                         $lsr = Model::factory('Models_Company4');

                          $c = $lsr->find_one($id);

                                if ($c) {
                                    $c->delete();
                                    if($c){
                                        echo 'Delete successful';
                                    }

                                  //  r2(U . 'contacts1', 's', $_L['Deleted Successzfully']); 
                                }
                        break;

                    default:
                        jsonResponse([
                            'error' => true,
                            'message' => 'Unknown Method!',
                        ]);

                        break;
                }

                break;
                case 'lsp_driver':
                switch ($method) {
                    case 'GET':
                   
                        $id = route(3);

                        $contact = Company3  ::find($id)->toArray();

                        if ($contact) {
                          
                            jsonResponse($contact);
                        } else {
                            jsonResponse([
                                'error' => true,
                                'message' => 'Contact not found!',
                            ]);
                        }

                        break;

                    case 'POST':
                    $errors = [];

                    $name = _post('name');

                    $permit_number = _post('permit_number');
                    $lsp_id = _post('lsp_id');

                  

                     $truck_id = _post('truck_id');

                    $expiry_date = _post('expiry_date');

                    $logo_url = _post('logo_url');
                    $logo_path = _post('logo_path');
                    $phone = _post('phone');
                    $description = _post('description');

                    $suspend = _post('suspend');
                    $comment = _post('comment');
                    $permit_category = _post('permit_category');
                    $picture_permit_file_token = '';

        if (array_key_exists('picture_permit', $_FILES) && !empty($_FILES['picture_permit'])) {
            $uploadResult = uploadFile('picture_permit');

            if (!$uploadResult['success']) {
                $msg .= $_L['picture of permit'] . ': ' . $uploadResult['msg'] . '<br>';
            } else {
                $picture_permit_file_token = $uploadResult['token'];
            }
        }

                    if ($phone != '') {
                        $f = ORM::for_table('crm_accounts2')
                            ->where('phone', $phone)
                            ->find_one();

                        if ($f) {
                            $errors[] = $_L['Phone number already exist'];
                        }
                    }
                    if ($name== '') {
                        i_close($_L['the driver name is required']);
                    }
                    if ($permit_number == '') {
                        i_close($_L['permit number is required']);
                    }
                    if ($phone == '') {
                        i_close($_L['phone number is required']);
                    }
                  
                   
                    if (empty($errors)) {
                        // Tags::save($tags, 'Contacts');

                        $data = [];

                        $data['created_at'] = date('Y-m-d H:i:s');
                        $data['updated_at'] = date('Y-m-d H:i:s');

                        //  $type = _post('type');

                        $company3 = ORM::for_table('sys_companies3')->create();
                        $company3->name = $name;
                        $company3->permit_number = $permit_number;
                        $company3->lsp_id = $lsp_id;
                        $company3->expiry_date = $expiry_date;
                        $company3->picture_permit_file_token  = $picture_permit_file_token;
                        $company3->permit_category = $permit_category;
                        $company3->truck_id = $truck_id;
                        $company3->phone = $phone;
                        $company3->logo_url = $logo_url;
                        $company3->logo_path = $logo_path;
                        $company3->description = $description;
                        $company3->suspend = $suspend;
                        $company3->comment = $comment;
                

                        $d->created_at = $data['created_at'];
                        $d->updated_at = $data['updated_at'];

                      
                        try {
                            $company3->save();
                            echo $company3->id();
                            jsonResponse([
                                'error' => false,
                                'contact_id' => $cid,
                                'message' =>
                                    $_L['account_created_successfully'],
                            ]);
                        } catch (Exception $error) {
                        
                            jsonResponse($error);
                            exit();
                        
                        }
                        $cid = $d->id();
                       
                        _log(
                            $_L['New Contact Added'] .
                                ' ' .
                                $account .
                                ' [CID: ' .
                                $cid .
                                ']',
                            'Admin',
                            $owner_id
                        );

                       
                        jsonResponse([
                            'error' => false,
                            'contact_id' => $cid,
                            'message' =>
                                $_L['account_created_successfully'],
                        ]);
                    } else {
                        jsonResponse([
                            'error' => true,
                            'message' => $errors,
                        ]);
                    }

                        break;

                    case 'PUT':
                  
                        break;

                    case 'DELETE':
                    $id = route(3);
                         $lsr = Model::factory('Models_Company3');

                          $c = $lsr->find_one($id);

                                if ($c) {
                                    $c->delete();
                                    if($c){
                                        echo 'Delete successful';
                                    }

                                  //  r2(U . 'contacts1', 's', $_L['Deleted Successzfully']); 
                                }
                        break;

                    default:
                        jsonResponse([
                            'error' => true,
                            'message' => 'Unknown Method!',
                        ]);

                        break;
                }

                break;
                  case 'Submit_Transport_Request':
                switch ($method) {
                    case 'GET':
                   
                        $id = route(3);

                        $contact = Company6::find($id)->toArray();

                        if ($contact) {
                          
                            jsonResponse($contact);
                        } else {
                            jsonResponse([
                                'error' => true,
                                'message' => 'Contact not found!',
                            ]);
                        }

                        break;

                    case 'POST':
                    $errors = [];

                    $company_name = _post('company_name');

                    $phone = _post('phone');
                    $emails = _post('emails');

                    

                     $tags = _post('tags');

                    $notes = _post('notes');

                  

                    $address1 = _post('address1');
                    $address2 = _post('address2');
                    $description = _post('description');
                    $lsr_id = _post('lsr_id');
                    $source = _post('source');
                    $city = _post('city');
                    $pick_uplocation = _post('pick_uplocation');
                    $recipient_name = _post('recipient_name');
                    $types_of_goods = _post('types_of_goods');
                    $estimated_value = _post('estimated_value');
                    $weight = _post('weight');
                    $origin_country = _post('origin_country');
                    $destination_country = _post('destination_country');
                    $delivery_location = _post('delivery_location');
                    $transit = _post('transit');
                    $loading_date = _post('loading_date');
                    $off_loading_service = _post('off_loading_service');
                    $loading_services = _post('loading_services');
                    $observations = _post('observations');
                    $transport_insurance = _post('transport_insurance');
                    $tracking = _post('tracking');
                   
                    $bill_lading_file_token = '';

                    if (array_key_exists('bill_lading', $_FILES) && !empty($_FILES['bill_lading'])) {
                        $uploadResult = uploadFile('bill_lading');
            
                        if (!$uploadResult['success']) {
                            $msg .= $_L['Bill of lading'] . ': ' . $uploadResult['msg'] . '<br>';
                        } else {
                            $bill_lading_file_token = $uploadResult['token'];
                        }
                    }
                    if ($types_of_goods == '') {
                        i_close($_L['Types of goods is required']);
                    }

                    

                   
                   
                    if (empty($errors)) {
                        // Tags::save($tags, 'Contacts');

                        $data = [];

                        $data['created_at'] = date('Y-m-d H:i:s');
                        $data['updated_at'] = date('Y-m-d H:i:s');

                        //  $type = _post('type');

                        $company6 = ORM::for_table('sys_companies6')->create();

                        $company6->company_name = $company_name;
                        $company6->country = $country;
                      
                        $company6->phone = $phone;
                     
                        $company6->emails = $emails;
                        $company6->tags = $tags;
                        $company6->notes = $notes;
                            $company6->address1 = $address1;
                        $company6->address2 = $address2;
                        $company6->description = $description;
                        $company6->lsr_id = $lsr_id;
                      
                        $company6->logo_url = $logo_url;
                        $company6->source = $source;
                        $company6->city = $city;
                        $company6->pick_uplocation = $pick_uplocation;
                        $company6->recipient_name = $recipient_name;
                        $company6->types_of_goods = $types_of_goods;
                        $company6->estimated_value = $estimated_value;
                        $company6->weight = $weight;
                        $company6->origin_country = $origin_country;
                        $company6->delivery_location = $delivery_location;
                        $company6->transit = $transit;
                        $company6->loading_date = $loading_date;
                        $company6->off_loading_service = $off_loading_service;
                        $company6->loading_services = $loading_services;
                        $company6->observations = $observations;
                        $company6->transport_insurance = $transport_insurance;
                        $company6->tracking = $tracking;
                        $company6->bill_lading_file_token = $bill_lading_file_token;
                     

                     

                        $d->created_at = $data['created_at'];

                      
                        try {
                            $company6->save();
                            echo $company6->id();
                            jsonResponse([
                                'error' => false,
                                'contact_id' => $cid,
                                'message' =>
                                    $_L['account_created_successfully'],
                            ]);
                        } catch (Exception $error) {
                        
                            jsonResponse($error);
                            exit();
                        
                        }
                        $cid = $d->id();
                       
                        _log(
                            $_L['New Contact Added'] .
                                ' ' .
                                $account .
                                ' [CID: ' .
                                $cid .
                                ']',
                            'Admin',
                            $owner_id
                        );

                      

                        jsonResponse([
                            'error' => false,
                            'contact_id' => $cid,
                            'message' =>
                                $_L['account_created_successfully'],
                        ]);
                    } else {
                        jsonResponse([
                            'error' => true,
                            'message' => $errors,
                        ]);
                    }

                        break;

                    case 'PUT':
                    
            
                        break;

                    case 'DELETE':
                    $id = route(3);
                         $lsr = Model::factory('Models_Company6');

                          $c = $lsr->find_one($id);

                                if ($c) {
                                    $c->delete();
                                    if($c){
                                        echo 'Delete successful';
                                    }

                                  //  r2(U . 'contacts1', 's', $_L['Deleted Successzfully']); 
                                }
                        break;

                    default:
                        jsonResponse([
                            'error' => true,
                            'message' => 'Unknown Method!',
                        ]);

                        break;
                }

                break;

                case 'Trucks_Registration':
                switch ($method) {
                    case 'GET':
                   
                        $id = route(3);

                        $contact = Company5::find($id)->toArray();

                        if ($contact) {
                          
                            jsonResponse($contact);
                        } else {
                            jsonResponse([
                                'error' => true,
                                'message' => 'Contact not found!',
                            ]);
                        }

                        break;

                    case 'POST':
                    $errors = [];

                    $company_name = _post('company_name');

                    $url = _post('url');
                    $phone = _post('phone');

                    
                     $lsp_id = _post('lsp_id');

                    $emails = _post('emails');



                    $tags = _post('tags');
                    $logo_url = _post('logo_url');
                    $date_of_entry = _post('date_of_entry');
                    $chassis_number = _post('chassis_number');

                    $truck_immatriculation = _post('truck_immatriculation');
                    $type_of_truck = _post('type_of_truck');
                    $insurance_start_date = _post('insurance_start_date');
                    $truck_availability = _post('truck_availability');
                    $insurance_expiration_date = _post('insurance_expiration_date');
                    $Road_Worthiness = _post('Road_Worthiness');
                    $notes = _post('notes');
                    $description = _post('description');
                    $address2 = _post('address2');
                    $address1 = _post('address1');
                   

                  
                    if ($truck_immatriculation == '') {
                        i_close($_L['truck immatriculation  is required']);
                    }
                    $truck_picture_file_token = '';

                    if (array_key_exists('truck_picture', $_FILES) && !empty($_FILES['truck_picture'])) {
                        $uploadResult = uploadFile('truck_picture');
            
                        if (!$uploadResult['success']) {
                            $msg .= 'Truck picture: ' . $uploadResult['msg'] . '<br>';
                        } else {
                            $truck_picture_file_token = $uploadResult['token'];
                        }
                    }
            
                    $truck_insurance_file_token = '';
            
                    if (array_key_exists('truck_insurance', $_FILES) && !empty($_FILES['truck_insurance'])) {
                        $uploadResult = uploadFile('truck_insurance');
            
                        if (!$uploadResult['success']) {
                            $msg .= 'Truck insurance: ' . $uploadResult['msg'] . '<br>';
                        } else {
                            $truck_insurance_file_token = $uploadResult['token'];
                        }
                    }
            
            
                    $truck_patent_file_token = '';
            
                    if (array_key_exists('truck_patent', $_FILES) && !empty($_FILES['truck_patent'])) {
                        $uploadResult = uploadFile('truck_patent');
            
                        if (!$uploadResult['success']) {
                            $msg .= 'Truck patent: ' . $uploadResult['msg'] . '<br>';
                        } else {
                            $truck_patent_file_token = $uploadResult['token'];
                        }
                    }
                    $truck_registration_document_file_token = '';
            
                    if (array_key_exists('truck_registration_document', $_FILES) && !empty($_FILES['truck_registration_document'])) {
                        $uploadResult = uploadFile('truck_registration_document');
            
                        if (!$uploadResult['success']) {
                            $msg .= 'Truck registration document: ' . $uploadResult['msg'] . '<br>';
                        } else {
                            $truck_registration_document_file_token = $uploadResult['token'];
                        }
                    }
                   
                   
                    if (empty($errors)) {
                        // Tags::save($tags, 'Contacts');

                        $data = [];

                        $data['created_at'] = date('Y-m-d H:i:s');
                        $data['updated_at'] = date('Y-m-d H:i:s');

                        //  $type = _post('type');

                        $company5 = ORM::for_table('sys_companies5')->create();

                        $company5->company_name = $company_name;
                        $company5->url = $url;
                        // $company5->email = $data['email'];
                        //$company5->phone = $data['phone'];
                        
                        $company5->lsp_id = $lsp_id;
                        $company5->emails = $emails;
                        $company5->tags = $tags;
                        $company5->phone = $phone;
                        $company5->logo_url = $logo_url;
                        $company5->date_of_entry = $date_of_entry;
                        $company5->chassis_number = $chassis_number;
                        $company5->truck_immatriculation = $truck_immatriculation;
                        $company5->type_of_truck = $type_of_truck;
                        $company5->insurance_start_date = $insurance_start_date;
                        $company5->truck_availability = $truck_availability;
                        $company5->insurance_expiration_date = $insurance_expiration_date;
                        $company5->Road_Worthiness = $Road_Worthines;

                        $company5->notes = $notes;
                        $company5->description = $description;
                        $company5->address2 = $address2;
                        $company5->address1 = $address1;
                    
                        $company5->truck_picture_file_token               = $truck_picture_file_token;

                        $company5->truck_insurance_file_token             = $truck_insurance_file_token;
                        $company5->truck_patent_file_token                = $truck_patent_file_token;
                        $company5->truck_registration_document_file_token = $truck_registration_document_file_token;
       

                     

                        $d->created_at = $data['created_at'];

                      
                        try {
                            $company5->save();
                            echo $company5->id();
                            jsonResponse([
                                'error' => false,
                                'contact_id' => $cid,
                                'message' =>
                                    $_L['account_created_successfully'],
                            ]);
                        } catch (Exception $error) {
                        
                            jsonResponse($error);
                            exit();
                        
                        }
                        $cid = $d->id();
                       
                        _log(
                            $_L['New Contact Added'] .
                                ' ' .
                                $account .
                                ' [CID: ' .
                                $cid .
                                ']',
                            'Admin',
                            $owner_id
                        );

                      
                        //

                        jsonResponse([
                            'error' => false,
                            'contact_id' => $cid,
                            'message' =>
                                $_L['account_created_successfully'],
                        ]);
                    } else {
                        jsonResponse([
                            'error' => true,
                            'message' => $errors,
                        ]);
                    }

                        break;

                        case 'PUT':
                        $id = route(3);

                        $Company5 = Company5::find($id);
                       
                        if ($Company5) {
                            parse_str(
                                file_get_contents("php://input"),
                                $params
                            );

                            // if (isset($params['status'])) {
                            //    // $lsp_id = _post('lsp_id');
                            //     $Company5->status = $params['status'];
                            //     // $Company5->lsp_id = $lsp_id;
                            // }
                            
                                $lsp_id = _post('lsp_id');
                                $truck_immatriculation = _post('truck_immatriculation');
                                $Company5->lsp_id = $lsp_id;
                               
                               $Company5->truck_immatriculation = $truck_immatriculation;
                               var_dump($truck_immatriculation);
                            
                          
                            $Company5->save();

                            jsonResponse([
                                'truck_id' => $Company5,
                                'message' => 'truck updated!',
                            ]);
                        } else {
                            jsonResponse([
                                'error' => true,
                                'message' => 'Invoice not found!',
                            ]);
                        }
                        break;

                        case 'DELETE':
                        $id = route(3);
                             $lsr = Model::factory('Models_Company5');
    
                              $c = $lsr->find_one($id);
    
                                    if ($c) {
                                        $c->delete();
                                        if($c){
                                            echo 'Delete successful';
                                        }
    
                                      //  r2(U . 'contacts1', 's', $_L['Deleted Successzfully']); 
                                    }
                            break;


                    default:
                        jsonResponse([
                            'error' => true,
                            'message' => 'Unknown Method!',
                        ]);

                        break;
                }

                break;

                case 'transactions':
                switch ($method) {
                    case 'GET':
                        jsonResponse(
                            Transaction::orderBy('id', 'desc')
                                ->get()
                                ->toArray()
                        );

                        break;

                    case 'POST':
                        break;

                    case 'PUT':
                        break;

                    case 'DELETE':
                        break;

                    default:
                        jsonResponse([
                            'error' => true,
                            'message' => 'Unknown Method!',
                        ]);

                        break;
                }

                break;
                case 'new-lsps-offer':
                switch ($method) {
                    case 'GET':
                        // jsonResponse(
                        //     Transaction::orderBy('id', 'desc')
                        //         ->get()
                        //         ->toArray()
                        // );

                        break;

                    case 'POST':
                    $msg = '';
                    $lsrId = _post('lsr_id');
                    $itemId = _post('item_id');
                    $itemTable = _post('item_table');
                    $recipientTable = "crm_accounts";
                    $item = ORM::for_table($itemTable)->find_one($itemId);

                    $subject = _post('subject');
                    $recipientsIds = $_POST['recipients'];
                    
                    $content = _post('content');
                    
                    $notifyBySms = _post('sms');
                    $send_lsp_email = _post('send_lsp_email');
                   // echo ($send_lsp_email);
                    $file = $_FILES['file'];


                    $allowedExtensions = [
                        "pdf",
                        "jpg",
                        "jpeg",
                        "png",
                        "PNG",
                        "doc"
                    ];

                    $fileExtension = pathinfo($file['name'], PATHINFO_EXTENSION);

                    if (!empty($fileExtension) && !in_array($fileExtension, $allowedExtensions)) {
                        $msg .= 'This file is not allowed<br>';
                    } else if ($file['size'] > 10000000) { // the file is > 10MB
                        $msg .= 'Your file is too big<br>';
                    }
                    if ($subject == '') {
                        $msg .= 'The subject cannot be empty<br>';
                    }
                    if ($content == '') {
                        $msg .= 'The message cannot be empty<br>';
                    }
                    if (empty($recipientsIds)) {
                        $msg .= 'Please select at least one recipient<br>';
                    }

                    if ($msg != '') {
                        echo $msg;
                    } else {
                        $item = ORM::for_table($itemTable)->find_one($itemId);

                        if ($item->status == 1) {
                            $item->set('status', 2); // In progress
                            $item->save();
                                
                        }
                       
                        /** Retrieve lsps infos */
                        $lsps = ORM::for_table($recipientTable)->where_id_in(array($recipientsIds))->find_array();
                            //jsonResponse($lsps);
                           
                        $trade = ORM::for_table('trades')->where([
                            'item_id' => $itemId,
                            'item_table' => $itemTable,
                        ])->findOne();
                        // echo '$hi';

                        if ($trade) {
                            $trade->set('contacted_lsp', 1);
                            // echo $trade->contacted_lsp;
                        } else {

                            $trade = ORM::for_table('trades')->create();
                            $trade->lsr_id = $item->lsr_id;
                            $trade->item_id = $itemId;
                            $trade->item_table = $itemTable;
                            $trade->contacted_lsp = 1;
                        }


                        /** Saving the trade */
                        $trade->save();
                            if(!$trade){
                                echo('error');
                            }
                        $file_token = '';
                        if (array_key_exists('file', $_FILES) && !empty($_FILES['file'])) {
                            $uploadResult        = uploadFile('file');
                            $file_token          = $uploadResult['token'];
                        }

                        /** send email to lsps */
                     
                        foreach ($lsps as $lsp) {
                            if ($send_lsp_email == 'Yes') {
                                $send_email = Ib_Email::sendEmail($lsp['email'], $subject, $content);
                                   
                            }
                            if ($notifyBySms == 'Yes') {
                                notifyBySMS($lsp['phone']);
                            }
                          //  echo ($send_lsp_email);
                            /** Creating a new trade conversation */
                            $conversation                 = ORM::for_table('trade_conversations')->create();
                            $conversation->trade_id       = $trade->id();
                            $conversation->subject        = $subject;
                            $conversation->recipient_type = 'lsp';
                            $conversation->recipient_id   = $lsp['id'];
                            $conversation->content        = $content;
                            $conversation->sender_id      = $user->id;
                            $conversation->sender_type    = "admin";
                            $conversation->send_by_email  = $send_lsp_email;
                            $conversation->send_by_sms    = $notifyBySms;

                            $conversation->save();

                               
                            /** Saving message */
                            $message = ORM::for_table('conversation_message')->create();
                            
                            $message->trade_conversation_id = $conversation->id();
                            $message->sender_id             = $user->id;
                            $message->sender_table          = 'sys_users';
                            $message->recipient_id          = $lsp['id'];
                            $message->recipient_table       = $recipientTable;
                            $message->content               = $content;
                            $message->file_token            = $file_token;
                           
                            $message->save();
                          
                            if(!$message){
                                    echo 'no mesage';
                            }

                            // notifications
                            $event = ORM::for_table('events')->create();
                            $event->type = "Motodey";
                            $event->text = mb_strimwidth($content, 0, 20, "...");

                            // making the link to the conversation
                            $event->link = "trades/";
                            $trade = ORM::for_table('trades')->find_one($conversation->trade_id);

                            // making the link to the conversation
                            $event->link = "trades/";
                            $trade = ORM::for_table('trades')->find_one($conversation->trade_id);
                            switch ($trade->item_table) {
                                case 'sys_companies':
                                    $event->link .= "purchase-construction-material/";
                                    break;
                                case 'sys_companies4':
                                    $event->link .= "purchase-packaging-material/";
                                    break;
                                case 'sys_companies1':
                                    $event->link .= "rental-of-agricultural-equipment/";
                                    break;
                                case 'sys_companies2':
                                    $event->link .= "rental-heavy-machine/";
                                    break;
                                case 'sys_companies6':
                                    $event->link .= "submit-lsr/";
                                    break;

                                default:
                                    # code...
                                    break;
                            }

                            // remove extra '0' at the beginning
                            $trdId = ltrim($trade->item_id, '0');

                            $event->link .= $trdId;
                            $event->save();

                            $notif                             = ORM::for_table('notifications')->create();
                            $notif->user_to_notify             = $lsp['id'];
                            $notif->user_to_notify_table       = $recipientTable;
                            $notif->user_who_fired_event       = $user->id;
                            $notif->user_who_fired_event_table = "sys_users";
                            $notif->event_id                   = $event->id();
                            $notif->save();
                        }

                        echo '1';
                    }
                        break;

                    case 'PUT':
                        break;

                    case 'DELETE':
                        break;

                    default:
                        jsonResponse([
                            'error' => true,
                            'message' => 'Unknown Method!',
                        ]);

                        break;
                }

                break;
            
            case 'motodey-trade':
                    _auth();
                    $user = User::_info();
                    $action = route(3);
                 switch($action){
                    case 'auth-user':
                    switch ($method) {
                        case 'GET':
                        echo json_encode([
                            "id"        => $user->id,
                            "username"  => $user->username,
                            "fullname"  => $user->fullname,
                            "user_type" => $user->user_type,
                        ]);
    
                            break;
    
                        case 'POST':
                            break;
    
                        case 'PUT':
                            break;
    
                        case 'DELETE':
                            break;
    
                        default:
                            jsonResponse([
                                'error' => true,
                                'message' => 'Unknown Method!',
                            ]);
    
                            break;
                    }
                    case 'current-trade':
                    switch ($method) {
                        case 'GET':
                        $tradeId = _get('tradeId');
                        $itemTable = _get('itemTable');
                        $trade = ORM::for_table($itemTable)->find_one($tradeId);
                
                        echo json_encode([
                            "id"           => $trade->id,
                            "status"       => $trade->status,
                        ]);
                            break;
    
                        case 'POST':
                            break;
    
                        case 'PUT':
                        $tradeId = _get('tradeId');
                        $status = _get('status');
                        $itemTable = _get('itemTable');
                
                        $trade = ORM::for_table($itemTable)->find_one($tradeId);
                        $trade->status = $status;
                        $trade->save();
                
                        echo json_encode([
                            "id"           => $trade->id,
                            "company_name" => $trade->company_name,
                            "status"       => $trade->status,
                           ]);
                            break;
    
                        case 'DELETE':
                            break;
    
                        default:
                            jsonResponse([
                                'error' => true,
                                'message' => 'Unknown Method!',
                            ]);
    
                            break;
                    }
                  
                    break;
                //  case 'update-trade-status':
                //     switch ($method) {
                //         case 'GET':
                       
                //             break;
    
                //         case 'POST':
                //             break;
    
                //         case 'PUT':
                       
                //             break;
    
                //         case 'DELETE':
                //             break;
    
                //         default:
                //             jsonResponse([
                //                 'error' => true,
                //                 'message' => 'Unknown Method!',
                //             ]);
    
                //             break;
                //     }
                  
                //     break;

                    case 'lsps-trade-conversations':
                    switch ($method) {
                        case 'GET':
                        $tradeId = _get("ID");

                            $tradeConversations = ORM::for_table("trade_conversations")
                                ->table_alias('conv')
                                ->select('conv.*')
                                ->select('lsp.id', 'lsp_id')
                                ->select('lsp.account', 'lsp_account')
                                ->select('lsp.email', 'lsp_email')
                                ->where([
                                    "trade_id"       => $tradeId,
                                    "recipient_type" => "lsp",
                                ])->join('crm_accounts', [
                                    'conv.recipient_id', '=', 'lsp.id'
                                ], 'lsp')->find_array();

                            echo json_encode($tradeConversations);
                            break;
    
                        case 'POST':
                            break;
    
                        case 'PUT':
                            break;
    
                        case 'DELETE':
                            break;
    
                        default:
                            jsonResponse([
                                'error' => true,
                                'message' => 'Unknown Method!',
                            ]);
    
                            break;
                    }
                  
                    break;
                    case 'lsr-trade-conversation':
                    switch ($method) {
                        case 'GET':
                        $tradeId = _get("ID");

                        $tradeConversation = ORM::for_table("trade_conversations")
                            ->table_alias('conv')
                            ->select('conv.*')
                            ->select('lsr.id', 'lsr_id')
                            ->select('lsr.account', 'lsr_account')
                            ->select('lsr.email', 'lsr_email')
                            ->where([
                                "trade_id"       => $tradeId,
                                "recipient_type" => "lsr",
                            ])->join('crm_accounts_1', [
                                'conv.recipient_id', '=', 'lsr.id'
                            ], 'lsr')->find_array();
                
                        echo json_encode($tradeConversation);
                            break;
    
                        case 'POST':
                            break;
    
                        case 'PUT':
                            break;
    
                        case 'DELETE':
                            break;
    
                        default:
                            jsonResponse([
                                'error' => true,
                                'message' => 'Unknown Method!',
                            ]);
    
                            break;
                    }
                  
                    break;
                    case 'trade-messages':
                    switch ($method) {
                        case 'GET':
                                        $conversationId = _get("ID");
                        $messages = ORM::for_table('conversation_message')
                            ->table_alias('c')
                            ->select('c.*')
                            ->select('doc.id', 'file_id')
                            ->select('doc.title', 'file_name')
                            ->select('doc.file_mime_type', 'file_ext')
                            ->select('doc.file_dl_token', 'file_dl_token')
                            ->select('doc.file_path', 'file_path')
                            ->left_outer_join("sys_documents", ['c.file_token', '=', 'doc.file_dl_token'], 'doc')
                            ->where([
                                'c.trade_conversation_id' => $conversationId
                            ])
                            ->order_by_asc('c.created_at')
                            ->find_array();

                        jsonResponse($messages);
                            break;
    
                        case 'POST':
                            break;
    
                        case 'PUT':
                            break;
    
                        case 'DELETE':
                            break;
    
                        default:
                            jsonResponse([
                                'error' => true,
                                'message' => 'Unknown Method!',
                            ]);
    
                            break;
                    }
                  
                    break;
                    case 'trade-lsr-messages':
                    switch ($method) {
                        case 'GET':
                        $conversationId = _get("ID");
                        $messages = ORM::for_table('conversation_message')->where([
                            'trade_conversation_id' => $conversationId
                        ])->find_array();
                
                        echo json_encode($messages);
                            break;
    
                        case 'POST':
                        $conversationId = _post('tradeConversationId');
                        $userId         = _post('senderId');
                        $content        = _post('content');
                        $recipientId    = _post('recipientId');
                        $file = $_FILES['file'];
                        $recipientTable = "crm_accounts_1";
                
                        $file_token = '';
                        if (array_key_exists('file', $_FILES) && !empty($_FILES['file'])) {
                            $uploadResult        = uploadFile('file');
                            $file_token          = $uploadResult['token'];
                        }
                
                        /** Saving message */
                        $message = ORM::for_table('conversation_message')->create();
                
                        $message->trade_conversation_id = $conversationId;
                        $message->sender_id             = $userId;
                        $message->sender_table          = 'sys_users';
                        $message->recipient_id          = $recipientId;
                        $message->recipient_table       = $recipientTable;
                        $message->content               = $content;
                        $message->file_token            = $file_token;
                
                        $message->save();
                
                        $conversation = ORM::for_table('trade_conversations')->find_one($conversationId);
                
                        // notifications
                        $event = ORM::for_table('events')->create();
                
                        $event->type = "Motodey";
                        $event->text = mb_strimwidth($content, 0, 20, "...");
                
                        // making the link to the conversation
                        $event->link = "trades/";
                        $trade = ORM::for_table('trades')->find_one($conversation->trade_id);
                        switch ($trade->item_table) {
                            case 'sys_companies':
                                $event->link .= "purchase-construction-material/";
                                break;
                            case 'sys_companies4':
                                $event->link .= "purchase-packaging-material/";
                                break;
                            case 'sys_companies1':
                                $event->link .= "rental-of-agricultural-equipment/";
                                break;
                            case 'sys_companies2':
                                $event->link .= "rental-heavy-machine/";
                                break;
                            case 'sys_companies6':
                                $event->link .= "submit-lsr/";
                                break;
                
                            default:
                                # code...
                                break;
                        }
                
                        // remove extra '0' at the beginning
                        $trdId = ltrim($trade->item_id, '0');
                
                        $event->link .= $trdId;
                        $event->save();
                
                        $notif                             = ORM::for_table('notifications')->create();
                        $notif->user_to_notify             = $recipientId;
                        $notif->user_to_notify_table       = $recipientTable;
                        $notif->user_who_fired_event       = $userId;
                        $notif->user_who_fired_event_table = "sys_users";
                        $notif->event_id                   = $event->id();
                        $notif->save();
                
                
                        if ($conversation->send_by_sms == "Yes") {
                            // notify by sms
                            $lsr = ORM::for_table($recipientTable)->find_one($recipientId);
                            notifyBySMS($lsr['phone']);
                        }
                        if ($conversation->send_by_email == "Yes") {
                            // notify by email
                            $lsr = ORM::for_table($recipientTable)->find_one($recipientId);
                            notifyByEmail($lsr['email']);
                        }
                
                        header('Content-Type: application/json');
                        echo "ok";
                            break;
    
                        case 'PUT':
                            break;
    
                        case 'DELETE':
                            break;
    
                        default:
                            jsonResponse([
                                'error' => true,
                                'message' => 'Unknown Method!',
                            ]);
    
                            break;
                    }
                  
                    break;

                    case 'trade-lsp-messages':
                    switch ($method) {
                        case 'GET':
                       
                            break;
    
                        case 'POST':
                            $conversationId = _post('tradeConversationId');
                            $userId         = _post('senderId');
                            $content        = _post('content');
                            $recipientId    = _post('recipientId');
                            $file = $_FILES['file'];

                            $file_token = '';
                            if (array_key_exists('file', $_FILES) && !empty($_FILES['file'])) {
                                $uploadResult        = uploadFile('file');
                                $file_token          = $uploadResult['token'];
                            }

                            /** Saving message */
                            $message = ORM::for_table('conversation_message')->create();

                            $message->trade_conversation_id = $conversationId;
                            $message->sender_id             = $userId;
                            $message->sender_table          = 'sys_users';
                            $message->recipient_id          = $recipientId;
                            $message->recipient_table       = 'crm_accounts';
                            $message->content               = $content;
                            $message->file_token            = $file_token;

                            $message->save();

                            $conversation = ORM::for_table('trade_conversations')->find_one($conversationId);

                            // notifications
                            $event = ORM::for_table('events')->create();
                            $event->type = "Motodey";
                            $event->text = mb_strimwidth($content, 0, 20, "...");

                            // making the link to the conversation
                            $event->link = "trades/";
                            $trade = ORM::for_table('trades')->find_one($conversation->trade_id);
                            switch ($trade->item_table) {
                                case 'sys_companies':
                                    $event->link .= "purchase-construction-material/";
                                    break;
                                case 'sys_companies4':
                                    $event->link .= "purchase-packaging-material/";
                                    break;
                                case 'sys_companies1':
                                    $event->link .= "rental-of-agricultural-equipment/";
                                    break;
                                case 'sys_companies2':
                                    $event->link .= "rental-heavy-machine/";
                                    break;
                                case 'sys_companies6':
                                    $event->link .= "submit-lsr/";
                                    break;

                                default:
                                    # code...
                                    break;
                            }

                            // remove extra '0' at the beginning
                            $trdId = ltrim($trade->item_id, '0');

                            $event->link .= $trdId;
                            $event->save();

                            $notif                             = ORM::for_table('notifications')->create();
                            $notif->user_to_notify             = $recipientId;
                            $notif->user_to_notify_table       = 'crm_accounts';
                            $notif->user_who_fired_event       = $userId;
                            $notif->user_who_fired_event_table = "sys_users";
                            $notif->event_id                   = $event->id();
                            $notif->save();


                            if ($conversation->send_by_sms == "Yes") {
                                // notify by sms
                                $lsp = ORM::for_table('crm_accounts')->find_one($recipientId);
                                notifyBySMS($lsp['phone']);
                            }
                            if ($conversation->send_by_email == "Yes") {
                                // notify by email
                                $lsp = ORM::for_table('crm_accounts')->find_one($recipientId);
                                notifyByEmail($lsp['email']);
                            }

                            header('Content-Type: application/json');
                            echo "ok";

                            break;
    
                        case 'PUT':
                            break;
    
                        case 'DELETE':
                            break;
    
                        default:
                            jsonResponse([
                                'error' => true,
                                'message' => 'Unknown Method!',
                            ]);
    
                            break;
                            
                    }
                  
                    break;
                    default:
                    # code...
                    break;

                 }

            break; 
            case 'lsr-trade':
           
            $action = route(3);
            switch($action){
             case 'auth-lsr':
                switch ($method) {
                    case 'GET':
                    $user = Contacts1::details();
                    echo json_encode([
                        "id"      => $user->id,
                        "account" => $user->account,
                        "email"   => $user->email
                    ]);

                     break;

                    case 'POST':
                        break;

                    case 'PUT':
                        break;

                    case 'DELETE':
                        break;

                    default:
                        jsonResponse([
                            'error' => true,
                            'message' => 'Unknown Method!',
                        ]);

                        break;
                }
                case 'current-trade':
                switch ($method) {
                    case 'GET':
                    $tradeId = _get('tradeId');
                    $itemTable = _get('itemTable');
                    $trade = ORM::for_table($itemTable)->find_one($tradeId);
            
                    echo json_encode([
                        "id"           => $trade->id,
                        "company_name" => $trade->company_name,
                        "status"       => $trade->status,
                    ]);
                        break;

                    case 'POST':
                        break;

                    case 'PUT':
                        break;

                    case 'DELETE':
                        break;

                    default:
                        jsonResponse([
                            'error' => true,
                            'message' => 'Unknown Method!',
                        ]);

                        break;
                }
              
                break;
            

             
                case 'lsr-trade-conversation':
                switch ($method) {
                    case 'GET':
                    $user = Contacts1::details();
                    $tradeId = _get("ID");
                    $tradeConversation = ORM::for_table("trade_conversations")
                        ->where([
                            "trade_id"       => $tradeId,
                            "recipient_type" => "lsr",
                            "recipient_id" => $user->id,
                        ])->find_array();

                    header('Content-Type: application/json; charset=utf-8');
                    echo json_encode($tradeConversation);
                        break;

                    case 'POST':
                        break;

                    case 'PUT':
                        break;

                    case 'DELETE':
                        break;

                    default:
                        jsonResponse([
                            'error' => true,
                            'message' => 'Unknown Method!',
                        ]);

                        break;
                }
              
                break;
               
                case 'trade-lsr-messages':
                switch ($method) {
                    case 'GET':
                    $conversationId = _get("ID");
                    $messages = ORM::for_table('conversation_message')
                        ->table_alias('c')
                        ->select('c.*')
                        ->select('doc.id', 'file_id')
                        ->select('doc.title', 'file_name')
                        ->select('doc.file_mime_type', 'file_ext')
                        ->select('doc.file_dl_token', 'file_dl_token')
                        ->select('doc.file_path', 'file_path')
                        ->left_outer_join("sys_documents", ['c.file_token', '=', 'doc.file_dl_token'], 'doc')
                        ->where([
                            'c.trade_conversation_id' => $conversationId
                        ])
                        ->order_by_asc('c.created_at')
                        ->find_array();

                    jsonResponse($messages);
                        break;

                    case 'POST':
                    $user = Contacts1::details();
                        $conversationId = _post('tradeConversationId');
                        $userId         = $user->id;
                        $content        = _post('content');
                        $recipientId    = _post('recipientId');
                        $file = $_FILES['file'];

                        $file_token = '';
                        if (array_key_exists('file', $_FILES) && !empty($_FILES['file'])) {
                            $uploadResult        = uploadFile('file');
                            $file_token          = $uploadResult['token'];
                        }
                        /** Saving message */
                        $message = ORM::for_table('conversation_message')->create();

                        $message->trade_conversation_id = $conversationId;
                        $message->sender_id             = $userId;
                        $message->sender_table          = 'crm_accounts_1';
                        $message->recipient_id          = $recipientId;
                        $message->recipient_table       = 'sys_users';
                        $message->content               = $content;
                        $message->file_token            = $file_token;

                        $message->save();

                        $conversation = ORM::for_table('trade_conversations')->find_one($conversationId);

                        // notifications
                        $event = ORM::for_table('events')->create();
                        $event->type = $user->account;
                        $event->text = mb_strimwidth($content, 0, 20, "...");

                        // making the link to the conversation
                        $event->link = "trades/list/";
                        $trade = ORM::for_table('trades')->find_one($conversation->trade_id);
                        switch ($trade->item_table) {
                            case 'sys_companies':
                                $event->link .= "purchase-construction-material/show/";
                                break;
                            case 'sys_companies4':
                                $event->link .= "purchase-packaging-material/show/";
                                break;
                            case 'sys_companies1':
                                $event->link .= "rental-of-agricultural-equipment/show/";
                                break;
                            case 'sys_companies2':
                                $event->link .= "rental-heavy-machine/show/";
                                break;
                            case 'sys_companies6':
                                $event->link .= "submit-lsr/show/";
                                break;

                            default:
                                # code...
                                break;
                        }

                        // remove extra '0' at the beginning
                        $trdId = ltrim($trade->item_id, '0');

                        $event->link .= $trdId;
                        $event->save();

                        $notif                             = ORM::for_table('notifications')->create();
                        $notif->user_to_notify             = $recipientId;
                        $notif->user_to_notify_table       = 'sys_users';
                        $notif->user_who_fired_event       = $userId;
                        $notif->user_who_fired_event_table = "crm_accounts_1";
                        $notif->event_id                   = $event->id();
                        $notif->save();

                        header('Content-Type: application/json; charset=utf-8');
                        echo "ok";
                        break;

                    case 'PUT':
                        break;

                    case 'DELETE':
                        break;

                    default:
                        jsonResponse([
                            'error' => true,
                            'message' => 'Unknown Method!',
                        ]);

                        break;
                }
              
                break;

               case 'list':
               $action2 = route(4);
               $user = Contacts1::details();
               switch($action2){
                case '':
                switch ($method) {
                    case 'GET': 
                   

                        jsonResponse([
                            'Submited Transport Request' =>  Company6::orderBy('id', 'desc')->where('lsr_id', $user->id)->count(),
                            'Submited Rental of Agricultural Equipment' =>  Company1::orderBy('id', 'desc') ->where('lsr_id', $user->id) ->count(),
                            'Submited Rental Heavy Machine' =>  Company2::orderBy('id', 'desc')->where('lsr_id', $user->id) ->count(),
                            'Submited Purchase construction material' =>  Company::orderBy('id', 'desc')->where('lsr_id', $user->id) ->count(),
                            'Submited Purchase packaging material' =>  Company4::orderBy('id', 'desc')->where('lsr_id', $user->id)->count(),
                            'Submited Purchase packaging materials' => ORM::for_table('sys_companies4')->where('lsr_id', $user->id)->count()

                               
                        ]);

                        break;

                    case 'POST':
                        break;

                    case 'PUT':
                        break;

                    case 'DELETE':
                        break;

                    default:
                        jsonResponse([
                            'error' => true,
                            'message' => 'Unknown Method!',
                        ]);

                        break;
                }
                break;
                case 'submit-lsr':
                switch ($method) {
                         case 'GET':

                                $trades = ORM::for_table('sys_companies6')
                                            ->table_alias('c')
                                            ->select('c.*')
                                            ->select_expr('(SELECT account FROM crm_accounts_1 WHERE  id = c.lsr_id)', 'comp')
                                            ->where('lsr_id', $user->id)
                                            ->order_by_desc('c.id')
                                            ->find_array();                                          
                        jsonResponse($trades );

                        break;

                    case 'POST':
                        break;

                    case 'PUT':
                        break;

                    case 'DELETE':
                        break;

                    default:
                        jsonResponse([
                            'error' => true,
                            'message' => 'Unknown Method!',
                        ]);

                        break;
                }
                case 'rental-of-agricultural-equipment':
                switch ($method) {
                    case 'GET': 
                   
                    $trades = ORM::for_table('sys_companies1')
                    ->table_alias('c')
                    ->select('c.*')
                    ->select_expr('(SELECT account FROM crm_accounts_1 WHERE  id = c.lsr_id)', 'comp')
                    ->where('lsr_id', $user->id)
                    ->order_by_desc('c.id')
                    ->find_array();
                        jsonResponse($trades);

                        break;

                    case 'POST':
                        break;

                    case 'PUT':
                        break;

                    case 'DELETE':
                        break;

                    default:
                        jsonResponse([
                            'error' => true,
                            'message' => 'Unknown Method!',
                        ]);

                        break;
                }
                case 'rental-heavy-machine':
                switch ($method) {
                                    case 'GET':

                                        $trades = ORM::for_table('sys_companies2')
                                            ->table_alias('c')
                                            ->select('c.*')
                                            ->select_expr('(SELECT account FROM crm_accounts_1 WHERE  id = c.lsr_id)', 'comp')
                                            ->where('lsr_id', $user->id)
                                            ->order_by_desc('c.id')
                                            ->find_array();
                        jsonResponse($trades );

                        break;

                    case 'POST':
                        break;

                    case 'PUT':
                        break;

                    case 'DELETE':
                        break;

                    default:
                        jsonResponse([
                            'error' => true,
                            'message' => 'Unknown Method!',
                        ]);

                        break;
                }
                case 'purchase-construction-material':
                switch ($method) {
                                    case 'GET':
                                        $trades = ORM::for_table('sys_companies')
                                            ->table_alias('c')
                                            ->select('c.*')
                                            ->select_expr('(SELECT account FROM crm_accounts_1 WHERE  id = c.lsr_id)', 'comp')
                                            ->where('lsr_id', $user->id)
                                            ->order_by_desc('c.id')
                                            ->find_array();

                        jsonResponse($trades );

                        break;

                    case 'POST':
                        break;

                    case 'PUT':
                        break;

                    case 'DELETE':
                        break;

                    default:
                        jsonResponse([
                            'error' => true,
                            'message' => 'Unknown Method!',
                        ]);

                        break;
                }
                case 'purchase-packaging-material':
                switch ($method) {
                    case 'GET': 
                   

                        jsonResponse($trades = ORM::for_table('sys_companies4')
                        ->table_alias('c')
                        ->select('c.*')
                        ->select_expr('(SELECT account FROM crm_accounts_1 WHERE  id = c.lsr_id)', 'comp')
                        ->where('lsr_id', $user->id)
                        ->order_by_desc('c.id')
                        ->find_array()
);

                        break;

                    case 'POST':
                        break;

                    case 'PUT':
                        break;

                    case 'DELETE':
                        break;

                    default:
                        jsonResponse([
                            'error' => true,
                            'message' => 'Unknown Method!',
                        ]);

                        break;
                }

                default:
                # code...
                break;
               }
               break;
               case 'submit-lsr':
               switch ($method) {
                case 'GET': 
                $tradeId = route(3);
                $hasConversations = false;
                
                $trade = ORM::for_table('sys_companies6')
                    ->table_alias('c')
                    ->select('c.*')
                    ->select_expr('(SELECT account FROM crm_accounts_1 WHERE  id = c.lsr_id)', 'comp')
                    ->select_expr('(SELECT email FROM crm_accounts_1 WHERE  id = c.lsr_id)', 'lsr_email')
                    ->where('id', $tradeId)
                    ->find_array();

                // the 'trades table' content
                $tradeContent = ORM::for_table('trades')->where(array(
                    'item_id' => $tradeId,
                    'item_table' => 'sys_companies6',
                ))->find_array();
                if ($tradeContent) {
                    $hasConversations = true;
                }
                
               

                    jsonResponse([
                         $tradeContent,
                        'trade' =>  Company6::orderBy('id', 'desc') ->find($tradeId),
                        'hasConversations' =>  $hasConversations,
                        
                        

                           
                    ]);

                    break;

                case 'POST':
                    break;

                case 'PUT':
                    break;

                case 'DELETE':
                    break;

                default:
                    jsonResponse([
                        'error' => true,
                        'message' => 'Unknown Method!',
                    ]);

                    break;
            }
               break;
               case 'rental-of-agricultural-equipment':
               switch ($method) {
                case 'GET': 
                $tradeId = route(3);
                $hasConversations = false;
                
                $trade = ORM::for_table('sys_companies1')
                    ->table_alias('c')
                    ->select('c.*')
                    ->select_expr('(SELECT account FROM crm_accounts_1 WHERE  id = c.lsr_id)', 'comp')
                    ->select_expr('(SELECT email FROM crm_accounts_1 WHERE  id = c.lsr_id)', 'lsr_email')
                    ->where('id', $tradeId)
                    ->find_array();

                // the 'trades table' content
                $tradeContent = ORM::for_table('trades')->where(array(
                    'item_id' => $tradeId,
                    'item_table' => 'sys_companies1',
                ))->find_array();
                if ($tradeContent) {
                    $hasConversations = true;
                }
                
               

                    jsonResponse([
                         $tradeContent,
                        'trade' =>  Company1::orderBy('id', 'desc') ->find($tradeId),
                        'hasConversations' =>  $hasConversations,
                        
                       

                           
                    ]);

                    break;

                case 'POST':
                    break;

                case 'PUT':
                    break;

                case 'DELETE':
                    break;

                default:
                    jsonResponse([
                        'error' => true,
                        'message' => 'Unknown Method!',
                    ]);

                    break;
            }
               break;
               case 'rental-heavy-machine':
               switch ($method) {
                case 'GET': 
                $tradeId = route(3);
                $hasConversations = false;
                
                $trade = ORM::for_table('sys_companies2')
                    ->table_alias('c')
                    ->select('c.*')
                    ->select_expr('(SELECT account FROM crm_accounts_1 WHERE  id = c.lsr_id)', 'comp')
                    ->select_expr('(SELECT email FROM crm_accounts_1 WHERE  id = c.lsr_id)', 'lsr_email')
                    ->where('id', $tradeId)
                    ->find_array();

                // the 'trades table' content
                $tradeContent = ORM::for_table('trades')->where(array(
                    'item_id' => $tradeId,
                    'item_table' => 'sys_companies2',
                ))->find_array();
                if ($tradeContent) {
                    $hasConversations = true;
                }
                
              

                    jsonResponse([
                         $tradeContent,
                        'trade' =>  Company2::orderBy('id', 'desc') ->find($tradeId),
                        'hasConversations' =>  $hasConversations,
                        
                     

                           
                    ]);

                    break;

                case 'POST':
                    break;

                case 'PUT':
                    break;

                case 'DELETE':
                    break;

                default:
                    jsonResponse([
                        'error' => true,
                        'message' => 'Unknown Method!',
                    ]);

                    break;
            }
               break;
               case 'purchase-construction-material':
               switch ($method) {
                case 'GET': 
                $tradeId = route(3);
                $hasConversations = false;
                
                $trade = ORM::for_table('sys_companies')
                    ->table_alias('c')
                    ->select('c.*')
                    ->select_expr('(SELECT account FROM crm_accounts_1 WHERE  id = c.lsr_id)', 'comp')
                    ->select_expr('(SELECT email FROM crm_accounts_1 WHERE  id = c.lsr_id)', 'lsr_email')
                    ->where('id', $tradeId)
                    ->find_array();

                // the 'trades table' content
                $tradeContent = ORM::for_table('trades')->where(array(
                    'item_id' => $tradeId,
                    'item_table' => 'sys_companies',
                ))->find_array();
                if ($tradeContent) {
                    $hasConversations = true;
                }

                    jsonResponse([
                         $tradeContent,
                        'trade' =>  Company::orderBy('id', 'desc') ->find($tradeId),
                        'hasConversations' =>  $hasConversations,
                        
                        'lsps' =>$lsps 

                           
                    ]);

                    break;

                case 'POST':
                    break;

                case 'PUT':
                    break;

                case 'DELETE':
                    break;

                default:
                    jsonResponse([
                        'error' => true,
                        'message' => 'Unknown Method!',
                    ]);

                    break;
            }
               break;
               case 'purchase-packaging-material':
               switch ($method) {
                case 'GET': 
                $tradeId = route(3);
                $hasConversations = false;
                
                $trade = ORM::for_table('sys_companies4')
                    ->table_alias('c')
                    ->select('c.*')
                    ->select_expr('(SELECT account FROM crm_accounts_1 WHERE  id = c.lsr_id)', 'comp')
                    ->select_expr('(SELECT email FROM crm_accounts_1 WHERE  id = c.lsr_id)', 'lsr_email')
                    ->where('id', $tradeId)
                    ->find_array();

                // the 'trades table' content
                $tradeContent = ORM::for_table('trades')->where(array(
                    'item_id' => $tradeId,
                    'item_table' => 'sys_companies4',
                ))->find_array();
                if ($tradeContent) {
                    $hasConversations = true;
                }
                
             

                    jsonResponse([
                         $tradeContent,
                        'trade' =>  Company4::orderBy('id', 'desc') ->find($tradeId),
                        'hasConversations' =>  $hasConversations,
                        
                      

                           
                    ]);

                    break;

                case 'POST':
                    break;

                case 'PUT':
                    break;

                case 'DELETE':
                    break;

                default:
                    jsonResponse([
                        'error' => true,
                        'message' => 'Unknown Method!',
                    ]);

                    break;
            }
               break;

                default:
                # code...
                break;

             }
            break;
            case 'lsp-trade':
            $action = route(3);
            switch($action){
             case 'auth-lsp':
                switch ($method) {
                    case 'GET':
                    $user = Contacts::details();
                    echo json_encode([
                        "id"      => $user->id,
                        "account" => $user->account,
                        "email"   => $user->email
                    ]);

                     break;

                    case 'POST':
                        break;

                    case 'PUT':
                        break;

                    case 'DELETE':
                        break;

                    default:
                        jsonResponse([
                            'error' => true,
                            'message' => 'Unknown Method!',
                        ]);

                        break;
                }
                case 'current-trade':
                switch ($method) {
                    case 'GET':
                    $tradeId = _get('tradeId');
                    $itemTable = _get('itemTable');
                    $trade = ORM::for_table($itemTable)->find_one($tradeId);
            
                    echo json_encode([
                        "id"           => $trade->id,
                        "company_name" => $trade->company_name,
                        "status"       => $trade->status,
                    ]);
                        break;

                    case 'POST':
                        break;

                    case 'PUT':
                        break;

                    case 'DELETE':
                        break;

                    default:
                        jsonResponse([
                            'error' => true,
                            'message' => 'Unknown Method!',
                        ]);

                        break;
                }
              
                break;
            

             
                case 'lsp-trade-conversation':
                switch ($method) {
                    case 'GET':
                    $user = Contacts::details();
                    $tradeId = _get("ID");
                    $tradeConversation = ORM::for_table("trade_conversations")
                        ->where([
                            "trade_id"       => $tradeId,
                            "recipient_type" => "lsr",
                            "recipient_id" => $user->id,
                        ])->find_array();

                    header('Content-Type: application/json; charset=utf-8');
                    echo json_encode($tradeConversation);
                        break;

                    case 'POST':
                        break;

                    case 'PUT':
                        break;

                    case 'DELETE':
                        break;

                    default:
                        jsonResponse([
                            'error' => true,
                            'message' => 'Unknown Method!',
                        ]);

                        break;
                }
              
                break;
               
                case 'trade-lsp-messages':
                switch ($method) {
                    case 'GET':
                    $conversationId = _get("ID");
                    $messages = ORM::for_table('conversation_message')
                        ->table_alias('c')
                        ->select('c.*')
                        ->select('doc.id', 'file_id')
                        ->select('doc.title', 'file_name')
                        ->select('doc.file_mime_type', 'file_ext')
                        ->select('doc.file_dl_token', 'file_dl_token')
                        ->select('doc.file_path', 'file_path')
                        ->left_outer_join("sys_documents", ['c.file_token', '=', 'doc.file_dl_token'], 'doc')
                        ->where([
                            'c.trade_conversation_id' => $conversationId
                        ])
                        ->order_by_asc('c.created_at')
                        ->find_array();

                    jsonResponse($messages);
                        break;

                    case 'POST':
                    $user = Contacts::details();
                        $conversationId = _post('tradeConversationId');
                        $userId         = $user->id;
                        $content        = _post('content');
                        $recipientId    = _post('recipientId');
                        $file = $_FILES['file'];

                        $file_token = '';
                        if (array_key_exists('file', $_FILES) && !empty($_FILES['file'])) {
                            $uploadResult        = uploadFile('file');
                            $file_token          = $uploadResult['token'];
                        }
                        /** Saving message */
                        $message = ORM::for_table('conversation_message')->create();

                        $message->trade_conversation_id = $conversationId;
                        $message->sender_id             = $userId;
                        $message->sender_table          = 'crm_accounts';
                        $message->recipient_id          = $recipientId;
                        $message->recipient_table       = 'sys_users';
                        $message->content               = $content;
                        $message->file_token            = $file_token;

                        $message->save();

                        $conversation = ORM::for_table('trade_conversations')->find_one($conversationId);

                        // notifications
                        $event = ORM::for_table('events')->create();
                        $event->type = $user->account;
                        $event->text = mb_strimwidth($content, 0, 20, "...");

                        // making the link to the conversation
                        $event->link = "trades/list/";
                        $trade = ORM::for_table('trades')->find_one($conversation->trade_id);
                        switch ($trade->item_table) {
                            case 'sys_companies':
                                $event->link .= "purchase-construction-material/show/";
                                break;
                            case 'sys_companies4':
                                $event->link .= "purchase-packaging-material/show/";
                                break;
                            case 'sys_companies1':
                                $event->link .= "rental-of-agricultural-equipment/show/";
                                break;
                            case 'sys_companies2':
                                $event->link .= "rental-heavy-machine/show/";
                                break;
                            case 'sys_companies6':
                                $event->link .= "submit-lsr/show/";
                                break;

                            default:
                                # code...
                                break;
                        }

                        // remove extra '0' at the beginning
                        $trdId = ltrim($trade->item_id, '0');

                        $event->link .= $trdId;
                        $event->save();

                        $notif                             = ORM::for_table('notifications')->create();
                        $notif->user_to_notify             = $recipientId;
                        $notif->user_to_notify_table       = 'sys_users';
                        $notif->user_who_fired_event       = $userId;
                        $notif->user_who_fired_event_table = "crm_accounts_1";
                        $notif->event_id                   = $event->id();
                        $notif->save();

                        header('Content-Type: application/json; charset=utf-8');
                        echo "ok";
                        break;

                    case 'PUT':
                        break;

                    case 'DELETE':
                        break;

                    default:
                        jsonResponse([
                            'error' => true,
                            'message' => 'Unknown Method!',
                        ]);

                        break;
                }
              
                break;
                case 'list':
                $action2 = route(4);
                $user = Contacts::details();
                switch($action2){
                 case '':
                 switch ($method) {
                     case 'GET': 
                     $lspTrades = ORM::for_table('trade_conversations')
                     ->table_alias('conv')
                     ->select('conv.*')
                     ->select('trd.*')
                     ->left_outer_join('trades', ['conv.trade_id', '=', 'trd.id'], 'trd')
                     ->where([
                         'recipient_type' => 'lsp',
                         'recipient_id' => $user->id,
                     ])
                     ->find_array();
                     
                     $submitLsr = array_filter($lspTrades, function ($trade) {
                        return $trade['item_table'] == 'sys_companies6';
                    });
                    $rentalAgricultalEquipments = array_filter($lspTrades, function ($trade) {
                        return $trade['item_table'] == 'sys_companies1';
                    });
                    $rentalHeavyMachine = array_filter($lspTrades, function ($trade) {
                        return $trade['item_table'] == 'sys_companies2';
                    });
                    $purchaseMaterialConstruction = array_filter($lspTrades, function ($trade) {
                        return $trade['item_table'] == 'sys_companies';
                    });
                    $purchasePackagingMaterial = array_filter($lspTrades, function ($trade) {
                        return $trade['item_table'] == 'sys_companies4';
                    });
 
                         jsonResponse([
                             'Submited Transport Request' =>   count($submitLsr),
                             'Submited Rental of Agricultural Equipment' => count($rentalAgricultalEquipments),
                             'Submited Rental Heavy Machine' =>  count($rentalHeavyMachine),
                             'Submited Purchase construction material' =>  count($purchaseMaterialConstruction),
                             'Submited Purchase packaging material' =>  count($purchasePackagingMaterial),
                            
 
                                
                         ]);
 
                         break;
 
                     case 'POST':
                         break;
 
                     case 'PUT':
                         break;
 
                     case 'DELETE':
                         break;
 
                     default:
                         jsonResponse([
                             'error' => true,
                             'message' => 'Unknown Method!',
                         ]);
 
                         break;
                 }
                 break;
                 case 'submit-lsr':
                 switch ($method) {
                                    case 'GET':
                                    
                        $lspTrades = ORM::for_table('trade_conversations')
                          ->table_alias('conv')
                          ->select('conv.*')
                          ->select('trd.*')
                          ->left_outer_join('trades', ['conv.trade_id', '=', 'trd.id'], 'trd')
                          ->where([
                              'recipient_type' => 'lsp',
                              'recipient_id' => $user->id,
                          ])
                          ->find_array();
                          
                          $submitLsrConv = array_filter($lspTrades, function ($trade) {
                            return $trade['item_table'] == 'sys_companies6';
                        });
                        

                        $trdIds = [];
                        foreach ($submitLsrConv as $trd) {
                            $trdIds[] = $trd['item_id'];
                        }

                        $trades = ORM::for_table('sys_companies6')
                            ->table_alias('c')
                            ->select('c.*')
                            ->select_expr('(SELECT account FROM crm_accounts_1 WHERE  id = c.lsr_id)', 'comp')
                            ->where_id_in($trdIds)
                            ->order_by_desc('c.id')
                            ->find_array();
                                      
                                     
                         jsonResponse($trades );
 
                         break;
 
                     case 'POST':
                         break;
 
                     case 'PUT':
                         break;
 
                     case 'DELETE':
                         break;
 
                     default:
                         jsonResponse([
                             'error' => true,
                             'message' => 'Unknown Method!',
                         ]);
 
                         break;
                 }
                 case 'rental-of-agricultural-equipment':
                 switch ($method) {
                     case 'GET': 
                    
                     $lspTrades = ORM::for_table('trade_conversations')
                            ->table_alias('conv')
                            ->select('conv.*')
                            ->select('trd.*')
                            ->left_outer_join('trades', ['conv.trade_id', '=', 'trd.id'], 'trd')
                            ->where([
                                'recipient_type' => 'lsp',
                                'recipient_id' => $user->id,
                            ])
                            ->find_array();

                        $submitLsrConv = array_filter($lspTrades, function ($trade) {
                            return $trade['item_table'] == 'sys_companies1';
                        });

                        $trdIds = [];
                        foreach ($submitLsrConv as $trd) {
                            $trdIds[] = $trd['item_id'];
                        }
                        $trades = [];

                        $trades = ORM::for_table('sys_companies1')
                            ->table_alias('c')
                            ->select('c.*')
                            ->select_expr('(SELECT account FROM crm_accounts_1 WHERE  id = c.lsr_id)', 'comp')
                            ->where_id_in($trdIds)
                            ->order_by_desc('c.id')
                            ->find_array();
                         jsonResponse($trades);
 
                         break;
 
                     case 'POST':
                         break;
 
                     case 'PUT':
                         break;
 
                     case 'DELETE':
                         break;
 
                     default:
                         jsonResponse([
                             'error' => true,
                             'message' => 'Unknown Method!',
                         ]);
 
                         break;
                 }
                 case 'rental-heavy-machine':
                 switch ($method) {
                         case 'GET':
 
                                     $lspTrades = ORM::for_table('trade_conversations')
                                     ->table_alias('conv')
                                     ->select('conv.*')
                                     ->select('trd.*')
                                     ->left_outer_join('trades', ['conv.trade_id', '=', 'trd.id'], 'trd')
                                     ->where([
                                         'recipient_type' => 'lsp',
                                         'recipient_id' => $user->id,
                                     ])
                                     ->find_array();
         
                                 $submitLsrConv = array_filter($lspTrades, function ($trade) {
                                     return $trade['item_table'] == 'sys_companies2';
                                 });
         
                                 $trdIds = [];
                                 foreach ($submitLsrConv as $trd) {
                                     $trdIds[] = $trd['item_id'];
                                 }
                                 $trades = [];
         
                                 $trades = ORM::for_table('sys_companies2')
                                     ->table_alias('c')
                                     ->select('c.*')
                                     ->select_expr('(SELECT account FROM crm_accounts_1 WHERE  id = c.lsr_id)', 'comp')
                                     ->where_id_in($trdIds)
                                     ->order_by_desc('c.id')
                                     ->find_array();
         
                         jsonResponse($trades );
 
                         break;
 
                     case 'POST':
                         break;
 
                     case 'PUT':
                         break;
 
                     case 'DELETE':
                         break;
 
                     default:
                         jsonResponse([
                             'error' => true,
                             'message' => 'Unknown Method!',
                         ]);
 
                         break;
                 }
                 case 'purchase-construction-material':
                 switch ($method) {
                                     case 'GET':
                                     $lspTrades = ORM::for_table('trade_conversations')
                                     ->table_alias('conv')
                                     ->select('conv.*')
                                     ->select('trd.*')
                                     ->left_outer_join('trades', ['conv.trade_id', '=', 'trd.id'], 'trd')
                                     ->where([
                                         'recipient_type' => 'lsp',
                                         'recipient_id' => $user->id,
                                     ])
                                     ->find_array();
         
                                 $submitLsrConv = array_filter($lspTrades, function ($trade) {
                                     return $trade['item_table'] == 'sys_companies';
                                 });
         
                                 $trdIds = [];
                                 foreach ($submitLsrConv as $trd) {
                                     $trdIds[] = $trd['item_id'];
                                 }
                                 $trades = [];
         
                                 $trades = ORM::for_table('sys_companies')
                                     ->table_alias('c')
                                     ->select('c.*')
                                     ->select_expr('(SELECT account FROM crm_accounts_1 WHERE  id = c.lsr_id)', 'comp')
                                     ->where_id_in($trdIds)
                                     ->order_by_desc('c.id')
                                     ->find_array();
 
                         jsonResponse($trades );
 
                         break;
 
                     case 'POST':
                         break;
 
                     case 'PUT':
                         break;
 
                     case 'DELETE':
                         break;
 
                     default:
                         jsonResponse([
                             'error' => true,
                             'message' => 'Unknown Method!',
                         ]);
 
                         break;
                 }
                 case 'purchase-packaging-material':
                 switch ($method) {
                     case 'GET': 
                    
                     $lspTrades = ORM::for_table('trade_conversations')
                     ->table_alias('conv')
                     ->select('conv.*')
                     ->select('trd.*')
                     ->left_outer_join('trades', ['conv.trade_id', '=', 'trd.id'], 'trd')
                     ->where([
                         'recipient_type' => 'lsp',
                         'recipient_id' => $user->id,
                     ])
                     ->find_array();

                 $submitLsrConv = array_filter($lspTrades, function ($trade) {
                     return $trade['item_table'] == 'sys_companies4';
                 });

                 $trdIds = [];
                 foreach ($submitLsrConv as $trd) {
                     $trdIds[] = $trd['item_id'];
                 }
                 $trades = [];

                 $trades = ORM::for_table('sys_companies4')
                     ->table_alias('c')
                     ->select('c.*')
                     ->select_expr('(SELECT account FROM crm_accounts_1 WHERE  id = c.lsr_id)', 'comp')
                     ->where_id_in($trdIds)
                     ->order_by_desc('c.id')
                     ->find_array();

                         jsonResponse($trades );
 
                         break;
 
                     case 'POST':
                         break;
 
                     case 'PUT':
                         break;
 
                     case 'DELETE':
                         break;
 
                     default:
                         jsonResponse([
                             'error' => true,
                             'message' => 'Unknown Method!',
                         ]);
 
                         break;
                 }
 
                 default:
                 # code...
                 break;
                }
                break;
                case 'submit-lsr':
                switch ($method) {
                 case 'GET': 
                 $tradeId = route(3);
                 $hasConversations = false;
                 
                 $trade = ORM::for_table('sys_companies6')
                     ->table_alias('c')
                     ->select('c.*')
                     ->select_expr('(SELECT account FROM crm_accounts_1 WHERE  id = c.lsr_id)', 'comp')
                     ->select_expr('(SELECT email FROM crm_accounts_1 WHERE  id = c.lsr_id)', 'lsr_email')
                     ->where('id', $tradeId)
                     ->find_array();
 
                 // the 'trades table' content
                 $tradeContent = ORM::for_table('trades')->where(array(
                     'item_id' => $tradeId,
                     'item_table' => 'sys_companies6',
                 ))->find_array();
                 if ($tradeContent) {
                     $hasConversations = true;
                 }
                 
                
 
                     jsonResponse([
                          $tradeContent,
                         'trade' =>  Company6::orderBy('id', 'desc') ->find($tradeId),
                         'hasConversations' =>  $hasConversations,
                         
                         
 
                            
                     ]);
 
                     break;
 
                 case 'POST':
                     break;
 
                 case 'PUT':
                     break;
 
                 case 'DELETE':
                     break;
 
                 default:
                     jsonResponse([
                         'error' => true,
                         'message' => 'Unknown Method!',
                     ]);
 
                     break;
             }
                break;
                case 'rental-of-agricultural-equipment':
                switch ($method) {
                 case 'GET': 
                 $tradeId = route(3);
                 $hasConversations = false;
                 
                 $trade = ORM::for_table('sys_companies1')
                     ->table_alias('c')
                     ->select('c.*')
                     ->select_expr('(SELECT account FROM crm_accounts_1 WHERE  id = c.lsr_id)', 'comp')
                     ->select_expr('(SELECT email FROM crm_accounts_1 WHERE  id = c.lsr_id)', 'lsr_email')
                     ->where('id', $tradeId)
                     ->find_array();
 
                 // the 'trades table' content
                 $tradeContent = ORM::for_table('trades')->where(array(
                     'item_id' => $tradeId,
                     'item_table' => 'sys_companies1',
                 ))->find_array();
                 if ($tradeContent) {
                     $hasConversations = true;
                 }
                 
                
 
                     jsonResponse([
                          $tradeContent,
                         'trade' =>  Company1::orderBy('id', 'desc') ->find($tradeId),
                         'hasConversations' =>  $hasConversations,
                         
                        
 
                            
                     ]);
 
                     break;
 
                 case 'POST':
                     break;
 
                 case 'PUT':
                     break;
 
                 case 'DELETE':
                     break;
 
                 default:
                     jsonResponse([
                         'error' => true,
                         'message' => 'Unknown Method!',
                     ]);
 
                     break;
             }
                break;
                case 'rental-heavy-machine':
                switch ($method) {
                 case 'GET': 
                 $tradeId = route(3);
                 $hasConversations = false;
                 
                 $trade = ORM::for_table('sys_companies2')
                     ->table_alias('c')
                     ->select('c.*')
                     ->select_expr('(SELECT account FROM crm_accounts_1 WHERE  id = c.lsr_id)', 'comp')
                     ->select_expr('(SELECT email FROM crm_accounts_1 WHERE  id = c.lsr_id)', 'lsr_email')
                     ->where('id', $tradeId)
                     ->find_array();
 
                 // the 'trades table' content
                 $tradeContent = ORM::for_table('trades')->where(array(
                     'item_id' => $tradeId,
                     'item_table' => 'sys_companies2',
                 ))->find_array();
                 if ($tradeContent) {
                     $hasConversations = true;
                 }
                 
               
 
                     jsonResponse([
                          $tradeContent,
                         'trade' =>  Company2::orderBy('id', 'desc') ->find($tradeId),
                         'hasConversations' =>  $hasConversations,
                         
                      
 
                            
                     ]);
 
                     break;
 
                 case 'POST':
                     break;
 
                 case 'PUT':
                     break;
 
                 case 'DELETE':
                     break;
 
                 default:
                     jsonResponse([
                         'error' => true,
                         'message' => 'Unknown Method!',
                     ]);
 
                     break;
             }
                break;
                case 'purchase-construction-material':
                switch ($method) {
                 case 'GET': 
                 $tradeId = route(3);
                 $hasConversations = false;
                 
                 $trade = ORM::for_table('sys_companies')
                     ->table_alias('c')
                     ->select('c.*')
                     ->select_expr('(SELECT account FROM crm_accounts_1 WHERE  id = c.lsr_id)', 'comp')
                     ->select_expr('(SELECT email FROM crm_accounts_1 WHERE  id = c.lsr_id)', 'lsr_email')
                     ->where('id', $tradeId)
                     ->find_array();
 
                 // the 'trades table' content
                 $tradeContent = ORM::for_table('trades')->where(array(
                     'item_id' => $tradeId,
                     'item_table' => 'sys_companies',
                 ))->find_array();
                 if ($tradeContent) {
                     $hasConversations = true;
                 }
 
                     jsonResponse([
                          $tradeContent,
                         'trade' =>  Company::orderBy('id', 'desc') ->find($tradeId),
                         'hasConversations' =>  $hasConversations,
                         
                         'lsps' =>$lsps 
 
                            
                     ]);
 
                     break;
 
                 case 'POST':
                     break;
 
                 case 'PUT':
                     break;
 
                 case 'DELETE':
                     break;
 
                 default:
                     jsonResponse([
                         'error' => true,
                         'message' => 'Unknown Method!',
                     ]);
 
                     break;
             }
                break;
                case 'purchase-packaging-material':
                switch ($method) {
                 case 'GET': 
                 $tradeId = route(3);
                 $hasConversations = false;
                 
                 $trade = ORM::for_table('sys_companies4')
                     ->table_alias('c')
                     ->select('c.*')
                     ->select_expr('(SELECT account FROM crm_accounts_1 WHERE  id = c.lsr_id)', 'comp')
                     ->select_expr('(SELECT email FROM crm_accounts_1 WHERE  id = c.lsr_id)', 'lsr_email')
                     ->where('id', $tradeId)
                     ->find_array();
 
                 // the 'trades table' content
                 $tradeContent = ORM::for_table('trades')->where(array(
                     'item_id' => $tradeId,
                     'item_table' => 'sys_companies4',
                 ))->find_array();
                 if ($tradeContent) {
                     $hasConversations = true;
                 }
                 
              
 
                     jsonResponse([
                          $tradeContent,
                         'trade' =>  Company4::orderBy('id', 'desc') ->find($tradeId),
                         'hasConversations' =>  $hasConversations,
                         
                       
 
                            
                     ]);
 
                     break;
 
                 case 'POST':
                     break;
 
                 case 'PUT':
                     break;
 
                 case 'DELETE':
                     break;
 
                 default:
                     jsonResponse([
                         'error' => true,
                         'message' => 'Unknown Method!',
                     ]);
 
                     break;
             }
                break;
               
                default:
                # code...
                break;

             }
            break;
            case 'new-lsr-message':
                switch ($method) {
                    case 'GET':
                        jsonResponse(
                            Transaction::orderBy('id', 'desc')
                                ->get()
                                ->toArray()
                        );

                        break;

                    case 'POST':
                    $msg = '';

                    /** getting hidden fields */
                    $lsrId = _post('lsr_id');
                    $itemId = _post('item_id');
                    $itemTable = _post('item_table');
                    $recipientTable = "crm_accounts_1";
                    // echo($recipientTable);
                    $subject = _post('subject');
                    $content = _post('content');
                    $notifyBySms = _post('sms');
                    $file = $_FILES['file'];
                    $send_lsr_email = _post('send_lsr_email');
            
                    $allowedExtensions = [
                        "pdf",
                        "jpg",
                        "jpeg",
                        "doc",
                        "png"
                    ];
            
                    $fileExtension = pathinfo($file['name'], PATHINFO_EXTENSION);
            
                    if (!empty($fileExtension) && !in_array($fileExtension, $allowedExtensions)) {
                        $msg .= 'This file is not allowed<br>';
                    } else if ($file['size'] > 10000000) { // the file is > 10MB
                        $msg .= 'Your file is too big<br>';
                    }
                    if ($subject == '') {
                        $msg .= 'The subject cannot be empty<br>';
                    }
                    if ($content == '') {
                        $msg .= 'The message cannot be empty<br>';
                    }
            
                    if ($msg != '') {
                        echo $msg;
                    } else {
            
                        $item = ORM::for_table($itemTable)->find_one($itemId);
            
                        if ($item->status == 1) {
                            $item->set('status', 2); // In progress
                            $item->save();
                        }
            
                        $trade = ORM::for_table('trades')->where([
                            'item_id' => $itemId,
                            'item_table' => $itemTable,
                        ])->find_one();
            
                        if ($trade) {
                            $trade->set('contacted_lsr', 1);
                        } else {
                            $trade = ORM::for_table('trades')->create();
                            $trade->lsr_id = $lsrId;
                            $trade->item_id = $itemId;
                            $trade->item_table = $itemTable;
                            $trade->contacted_lsr = 1;
                        }
            
                        /** Saving the trade */
                        $trade->save();
                        if (!$trade){
                                echo 'no trade';
                        }
                        $file_token = '';
                        if (array_key_exists('file', $_FILES) && !empty($_FILES['file'])) {
                            $uploadResult        = uploadFile('file');
                            $file_token          = $uploadResult['token'];
                        }
            
                        /** Creating a new trade conversation */
                        $conversation                 = ORM::for_table('trade_conversations')->create();
                        $conversation->trade_id       = $trade->id();
                        $conversation->subject        = $subject;
                        $conversation->recipient_type = 'lsr';
                        $conversation->recipient_id   = $lsrId;
                        $conversation->content        = $content;
                        $conversation->sender_id      = $user->id;
                        $conversation->sender_type    = "admin";
                        $conversation->send_by_email  = $send_lsr_email;
                        $conversation->send_by_sms    = $notifyBySms;
            
                        $conversation->save();
                        if (!$conversation){
                                echo ('error');
                        }
            
                        /** Saving message */
                        $message = ORM::for_table('conversation_message')->create();
            
                        $message->trade_conversation_id = $conversation->id();
                        $message->sender_id             = $user->id;
                        $message->sender_table          = 'sys_users';
                        $message->recipient_id          = $lsrId;
                        $message->recipient_table       = $recipientTable;
                        $message->content               = $content;
                        $message->file_token            = $file_token;
            
                        $message->save();
                        if(!$message){
                                echo ('no message');
                        }
            
                        if ($send_lsr_email == 'Yes') {
                            $lsr = ORM::for_table($recipientTable)->find_one($lsrId);
                            $send_email = Ib_Email::sendEmail($lsr['email'], $subject, $content);
                        }
            
                        if ($notifyBySms == 'Yes') {
                            $lsr = ORM::for_table($recipientTable)->find_one($lsrId);
                            notifyBySMS($lsr['phone']);
                        }
            
                        // notifications
                        $event = ORM::for_table('events')->create();
                        $event->type = "Motodey";
                        $event->text = mb_strimwidth($content, 0, 20, "...");
            
                        // making the link to the conversation
                        $event->link = "trades/";
                        $trade = ORM::for_table('trades')->find_one($conversation->trade_id);
            
                        // making the link to the conversation
                        $event->link = "trades/";
                        $trade = ORM::for_table('trades')->find_one($conversation->trade_id);
                        switch ($trade->item_table) {
                            case 'sys_companies':
                                $event->link .= "purchase-construction-material/";
                                break;
                            case 'sys_companies4':
                                $event->link .= "purchase-packaging-material/";
                                break;
                            case 'sys_companies1':
                                $event->link .= "rental-of-agricultural-equipment/";
                                break;
                            case 'sys_companies2':
                                $event->link .= "rental-heavy-machine/";
                                break;
                            case 'sys_companies6':
                                $event->link .= "submit-lsr/";
                                break;
            
                            default:
                                # code...
                                break;
                        }
            
                        // remove extra '0' at the beginning
                        $trdId = ltrim($trade->item_id, '0');
            
                        $event->link .= $trdId;
                        $event->save();
            
                        $notif                             = ORM::for_table('notifications')->create();
                        $notif->user_to_notify             = $lsr['id'];
                        $notif->user_to_notify_table       = $recipientTable;
                        $notif->user_who_fired_event       = $user->id;
                        $notif->user_who_fired_event_table = "sys_users";
                        $notif->event_id                   = $event->id();
                        $notif->save();
            
                        echo '1';
                    }
                        break;

                    case 'PUT':
                        break;

                    case 'DELETE':
                        break;

                    default:
                        jsonResponse([
                            'error' => true,
                            'message' => 'Unknown Method!',
                        ]);

                        break;
                }

                break;

            case 'accounts':
                switch ($method) {
                    case 'GET':
                        jsonResponse(
                            Contact::orderBy('id', 'desc')
                                ->get()
                                ->toArray()
                        );

                        break;

                    case 'POST':
                        break;

                    case 'PUT':
                        break;

                    case 'DELETE':
                        break;

                    default:
                        jsonResponse([
                            'error' => true,
                            'message' => 'Unknown Method!',
                        ]);

                        break;
                }

                break;

            case 'users':
                switch ($method) {
                    case 'GET':
                        jsonResponse(
                            User::orderBy('id', 'desc')
                                ->get()
                                ->toArray()
                        );

                        break;

                    default:
                        jsonResponse([
                            'error' => true,
                            'message' => 'Unknown Method!',
                        ]);

                        break;
                }

                break;

            case 'user':
                switch ($method) {
                    case 'GET':
                        $id = route(3);

                        $user = User::find($id)->toArray();

                        if ($user) {
                            jsonResponse($user);
                        } else {
                            jsonResponse([
                                'error' => true,
                                'message' => 'User not found!',
                            ]);
                        }

                        break;

                    case 'POST':
                        $username = _post('u.sername');
                        $fullname = _post('fullname');
                        $password = _post('password');
                        $user_type = _post('user_type');

                        $r = M::factory('Models_Role')->find_one($user_type);

                        if ($r) {
                            $role = $r->rname;
                            $roleid = $user_type;
                            $user_type = $r->rname;
                        } else {
                            $role = '';
                            $roleid = 0;
                            $user_type = 'Admin';
                        }

                        $errors = [];
                        if (Validator::Email($username) == false) {
                            $errors[] = $_L['notice_email_as_username'];
                        }
                        if (Validator::Length($fullname, 26, 2) == false) {
                            $errors[] =
                                'Full Name should be between 3 to 25 characters';
                        }
                        if (!Validator::Length($password, 15, 5)) {
                            $errors[] =
                                'Password should be between 6 to 15 characters';
                        }

                        //check with same name account is exist
                        $d = ORM::for_table('sys_users')
                            ->where('username', $username)
                            ->find_one();
                        if ($d) {
                            $errors[] = $_L['account_already_exist'];
                        }

                        // create Roles

                        if (empty($errors)) {
                            $password = Password::_crypt($password);
                            // Add Account
                            $d = ORM::for_table('sys_users')->create();
                            $d->username = $username;
                            $d->password = $password;
                            $d->fullname = $fullname;
                            $d->user_type = $user_type;

                            //others
                            $d->phonenumber = '';
                            $d->last_login = date('Y-m-d H:i:s');
                            $d->email = '';
                            $d->creationdate = date('Y-m-d H:i:s');
                            $d->pin = '';
                            $d->img = '';
                            $d->otp = 'No';
                            $d->pin_enabled = 'No';
                            $d->api = 'No';
                            $d->pwresetkey = '';
                            $d->keyexpire = '';
                            $d->status = 'Active';
                            $d->role = $role;
                            $d->roleid = $roleid;

                            //

                            $d->save();

                            // r2(U . 'settings/users', 's', $_L['account_created_successfully']);

                            jsonResponse([
                                'error' => false,
                                'user_id' => $d->id(),
                                'message' =>
                                    $_L['account_created_successfully'],
                            ]);
                        } else {
                            jsonResponse([
                                'error' => true,
                                'message' => $errors,
                            ]);
                        }

                        break;

                    case 'PUT':
                        break;

                    case 'DELETE':
                        break;

                    default:
                        jsonResponse([
                            'error' => true,
                            'message' => 'Unknown Method!',
                        ]);

                        break;
                }

                break;

            case 'invoice':
                switch ($method) {
                    case 'GET':
                        $id = route(3);

                        $invoice = Invoice::find($id)->toArray();

                        if ($invoice) {
                            $items = InvoiceItem::where('invoiceid', $id)
                                
                                ->toArray();
                            jsonResponse([
                                'invoice' => $invoice,
                                'items' => $items,
                            ]);
                        } else {
                            jsonResponse([
                                'error' => true,
                                'message' => 'Invoice not found!',
                            ]);
                        }

                        break;

                    case 'POST':
                        $items = $_POST['items'];

                        $i = 0;

                        $description = [];
                        $item_number = [];
                        $qty = [];
                        $amount = [];
                        $tax_rate = [];

                        foreach ($items as $api_item) {
                            $description[$i] = $api_item['description'];
                            $item_number[$i] = $api_item['item_code'];
                            $qty[$i] = $api_item['qty'];
                            $amount[$i] = $api_item['amount'];
                            $taxed[$i] = $api_item['taxed'];

                            $i++;
                        }

                        $cid = _post('cid');
                        $admin_id = _post('admin_id');

                        if ($admin_id == '') {
                            $admin_id = 0;
                        }

                        // find user with cid

                        $u = ORM::for_table('crm_accounts_1')->find_one($cid);
                        $errors = [];
                        if ($cid == '') {
                            $errors[] = $_L['select_a_contact'];
                        }

                        $notes = _post('notes');

                        $show_quantity_as = _post('show_quantity_as');

                        // find currency

                        $currency_id = _post('currency');
                        $currency_find = Currency::where(
                            'iso_code',
                            $currency_id
                        )->first();
                        if ($currency_find) {
                            $currency = $currency_find->id;
                            $currency_symbol = $currency_find->symbol;
                            $currency_rate = $currency_find->rate;
                        } else {
                            $currency = 0;
                            $currency_symbol = $config['currency_code'];
                            $currency_rate = 1.0;
                        }

                        if (empty($amount)) {
                            $errors[] = $_L['at_least_one_item_required'];
                        }

                        $idate = _post('idate');
                        $its = strtotime($idate);
                        $duedate = _post('duedate');
                        $dd = '';
                        if ($duedate == 'due_on_receipt') {
                            $dd = $idate;
                        } elseif ($duedate == 'days3') {
                            $dd = date('Y-m-d', strtotime('+3 days', $its));
                        } elseif ($duedate == 'days5') {
                            $dd = date('Y-m-d', strtotime('+5 days', $its));
                        } elseif ($duedate == 'days7') {
                            $dd = date('Y-m-d', strtotime('+7 days', $its));
                        } elseif ($duedate == 'days10') {
                            $dd = date('Y-m-d', strtotime('+10 days', $its));
                        } elseif ($duedate == 'days15') {
                            $dd = date('Y-m-d', strtotime('+15 days', $its));
                        } elseif ($duedate == 'days30') {
                            $dd = date('Y-m-d', strtotime('+30 days', $its));
                        } elseif ($duedate == 'days45') {
                            $dd = date('Y-m-d', strtotime('+45 days', $its));
                        } elseif ($duedate == 'days60') {
                            $dd = date('Y-m-d', strtotime('+60 days', $its));
                        } else {
                            $errors[] = 'Invalid Date';
                        }

                        if (!$dd) {
                            $errors[] = 'Date Parsing Error';
                        }

                        $repeat = _post('repeat');
                        $nd = $idate;
                        if ($repeat == '0') {
                            $r = '0';
                        } elseif ($repeat == 'daily') {
                            $r = '+1 day';
                            $nd = date('Y-m-d', strtotime('+1 day', $its));
                        } elseif ($repeat == 'week1') {
                            $r = '+1 week';
                            $nd = date('Y-m-d', strtotime('+1 week', $its));
                        } elseif ($repeat == 'weeks2') {
                            $r = '+2 weeks';
                            $nd = date('Y-m-d', strtotime('+2 weeks', $its));
                        } elseif ($repeat == 'weeks3') {
                            $r = '+3 weeks';
                            $nd = date('Y-m-d', strtotime('+3 weeks', $its));
                        } elseif ($repeat == 'weeks4') {
                            $r = '+4 weeks';
                            $nd = date('Y-m-d', strtotime('+4 weeks', $its));
                        } elseif ($repeat == 'month1') {
                            $r = '+1 month';
                            $nd = date('Y-m-d', strtotime('+1 month', $its));
                        } elseif ($repeat == 'months2') {
                            $r = '+2 months';
                            $nd = date('Y-m-d', strtotime('+2 months', $its));
                        } elseif ($repeat == 'months3') {
                            $r = '+3 months';
                            $nd = date('Y-m-d', strtotime('+3 months', $its));
                        } elseif ($repeat == 'months6') {
                            $r = '+6 months';
                            $nd = date('Y-m-d', strtotime('+6 months', $its));
                        } elseif ($repeat == 'year1') {
                            $r = '+1 year';
                            $nd = date('Y-m-d', strtotime('+1 year', $its));
                        } elseif ($repeat == 'years2') {
                            $r = '+2 years';
                            $nd = date('Y-m-d', strtotime('+2 years', $its));
                        } elseif ($repeat == 'years3') {
                            $r = '+3 years';
                            $nd = date('Y-m-d', strtotime('+3 years', $its));
                        } else {
                            $errors[] = 'Date Parsing Error';
                        }

                        if (empty($errors)) {
                            // $qty = $_POST['qty'];
                            //  $item_number = $_POST['item_code'];

                            //                            if (isset($_POST['taxed'])) {
                            //                                $taxed = $_POST['taxed'];
                            //                            }
                            //                            else {
                            //                                $taxed = false;
                            //                            }

                            $sTotal = '0';
                            $taxTotal = '0';
                            $i = '0';
                            $a = [];

                            $taxval = '0.00';
                            $taxname = '';
                            $taxrate = '0.00';

                            $taxed_amount = 0.0;
                            $lamount = 0.0;

                            foreach ($amount as $samount) {
                                $samount = Finance::amount_fix($samount);
                                $a[$i] = $samount;

                                $sqty = $qty[$i];
                                $sqty = Finance::amount_fix($sqty);

                                $lTaxRate = $taxed[$i];
                                $lTaxRate = Finance::amount_fix($lTaxRate);

                                $sTotal += $samount * $sqty;
                                $lamount = $samount * $sqty;

                                $lTaxVal = ($lamount * $lTaxRate) / 100;

                                $taxed_amount += $lTaxVal;

                                $i++;
                            }

                            $invoicenum = _post('invoicenum');
                            $cn = _post('cn');
                            $fTotal = $sTotal;
                            $discount_amount = _post('discount_amount');
                            $discount_type = _post('discount_type');
                            $discount_value = '0.00';
                            if (
                                $discount_amount == '0' or
                                $discount_amount == ''
                            ) {
                                $actual_discount = '0.00';
                            } else {
                                if ($discount_type == 'f') {
                                    $actual_discount = $discount_amount;
                                    $discount_value = $discount_amount;
                                } else {
                                    $discount_type = 'p';
                                    $actual_discount =
                                        ($sTotal * $discount_amount) / 100;
                                    $discount_value = $discount_amount;
                                }
                            }

                            $actual_discount = number_format(
                                (float) $actual_discount,
                                2,
                                '.',
                                ''
                            );
                            $fTotal =
                                $fTotal + $taxed_amount - $actual_discount;

                            $status = _post('status');
                            if ($status != 'Draft') {
                                $status = 'Unpaid';
                            }

                            $receipt_number = _post('receipt_number');

                            $datetime = date("Y-m-d H:i:s");
                            $vtoken = _raid(10);
                            $ptoken = _raid(10);
                            $d = ORM::for_table('sys_invoices')->create();
                            $d->userid = $cid;
                            $d->account = $u['account'];
                            $d->date = $idate;
                            $d->duedate = $dd;
                            $d->datepaid = $datetime;
                            $d->subtotal = $sTotal;
                            $d->discount_type = $discount_type;
                            $d->discount_value = $discount_value;
                            $d->discount = $actual_discount;
                            $d->total = $fTotal;
                            $d->tax = $taxed_amount;
                            $d->taxname = '';
                            $d->taxrate = 0.0;
                            $d->vtoken = $vtoken;
                            $d->ptoken = $ptoken;
                            $d->status = $status;
                            $d->notes = $notes;
                            $d->r = $r;
                            $d->nd = $nd;

                            $d->aid = $admin_id;

                            $d->show_quantity_as = $show_quantity_as;

                            $d->invoicenum = $invoicenum;
                            $d->cn = $cn;
                            $d->tax2 = '0.00';
                            $d->taxrate2 = '0.00';
                            $d->paymentmethod = '';

                            $d->currency = $currency;
                            $d->currency_symbol = $currency_symbol;
                            $d->currency_rate = $currency_rate;

                            $d->receipt_number = $receipt_number;

                            $d->save();
                            $invoiceid = $d->id();
                            //  $description = $_POST['desc'];

                            $i = '0';

                            foreach ($description as $item) {
                                $samount = $a[$i];
                                $samount = Finance::amount_fix($samount);
                                if ($item == '' && $samount == '0.00') {
                                    $i++;
                                    continue;
                                }

                                $tax_rate = $taxed[$i];

                                $sqty = $qty[$i];
                                $sqty = Finance::amount_fix($sqty);
                                $ltotal = $samount * $sqty;
                                $d = ORM::for_table(
                                    'sys_invoiceitems'
                                )->create();
                                $d->invoiceid = $invoiceid;
                                $d->userid = $cid;
                                $d->description = $item;
                                $d->qty = $sqty;
                                $d->amount = $samount;
                                $d->total = $ltotal;

                                if ($tax_rate == '' || $tax_rate == '0') {
                                    $tax_rate = 0.0;
                                    $d->taxed = '0';
                                } else {
                                    $tax_rate = $taxed[$i];
                                    $d->taxed = '1';
                                }

                                $d->tax_rate = $tax_rate;

                                $d->type = '';
                                $d->relid = '0';
                                $d->itemcode = $item_number[$i];
                                $d->taxamount = '0.00';
                                $d->duedate = date('Y-m-d');
                                $d->paymentmethod = '';
                                $d->notes = '';

                                $d->save();

                                Inventory::decreaseByItemNumber(
                                    $item_number[$i],
                                    $sqty
                                );

                                $item_r = Item::where('name', $item)->first();
                                if ($item_r) {
                                    $item_r->sold_count =
                                        $item_r->sold_count + $sqty;
                                    $item_r->total_amount =
                                        $item_r->total_amount + $samount;
                                    $item_r->save();
                                }

                                $i++;
                            }

                            jsonResponse([
                                'error' => false,
                                'invoice_id' => $d->id(),
                                'message' => 'Invoice created successfully',
                            ]);
                        } else {
                            jsonResponse([
                                'error' => true,
                                'message' => $errors,
                            ]);
                        }

                        break;

                    case 'PUT':
                        $id = route(3);

                        $invoice = Invoice::find($id);

                        if ($invoice) {
                            parse_str(
                                file_get_contents("php://input"),
                                $params
                            );

                            if (isset($params['status'])) {
                                $invoice->status = $params['status'];
                            }

                            $invoice->save();

                            jsonResponse([
                                'invoice_id' => $id,
                                'message' => 'Invoice updated!',
                            ]);
                        } else {
                            jsonResponse([
                                'error' => true,
                                'message' => 'Invoice not found!',
                            ]);
                        }
                        break;

                    case 'DELETE':
                        break;

                    default:
                        jsonResponse([
                            'error' => true,
                            'message' => 'Unknown Method!',
                        ]);

                        break;
                }

                break;

            case 'roles':
                switch ($method) {
                    case 'GET':
                        jsonResponse(
                            DB::table('sys_roles')
                                ->get()
                                ->toArray()
                        );

                        break;

                    case 'POST':
                        break;

                    case 'PUT':
                        break;

                    case 'DELETE':
                        break;

                    default:
                        jsonResponse([
                            'error' => true,
                            'message' => 'Unknown Method!',
                        ]);

                        break;
                }

                break;

            case 'system':
                if ($_app_stage == 'Demo') {
                    jsonResponse([
                        'error' => true,
                        'message' => 'Not available in demo!',
                    ]);
                }

                switch ($method) {
                    case 'GET':
                        jsonResponse(Util::systemInfo());

                        break;

                    case 'POST':
                        $cmd = _post('cmd');

                        switch ($cmd) {
                            case 'backup_files':
                                clxPerformLongProcess();

                                $taskId = _post('task_id');

                                if ($taskId == '') {
                                    jsonResponse([
                                        'error' => true,
                                        'message' =>
                                            'Please provide a task id.',
                                    ]);
                                }

                                $backup = Util::backupFiles($taskId);

                                jsonResponse($backup);

                                break;

                            case 'backup_database':
                                clxPerformLongProcess();
                                $taskId = _post('task_id');

                                if ($taskId == '') {
                                    jsonResponse([
                                        'error' => true,
                                        'message' =>
                                            'Please provide a task id.',
                                    ]);
                                }

                                $backup = Util::backupDatabase($taskId);

                                jsonResponse($backup);

                                break;

                            case 'task_log':
                                $taskId = _post('task_id');

                                if ($taskId == '') {
                                    jsonResponse([
                                        'error' => true,
                                        'message' =>
                                            'Please provide a task id.',
                                    ]);
                                }

                                jsonResponse(Util::getTaskLog($taskId));

                                break;

                            case 'upload_file':
                                $upload = Util::fileUpload();
                                jsonResponse($upload);

                                break;

                            case 'download_file':
                                $file_url = _post('file_url');
                                $file_name = _post('file_name');

                                $download = Util::downloadFile(
                                    $file_url,
                                    $file_name
                                );
                                jsonResponse($download);

                                break;

                            case 'unzip_file':
                                $file_name = _post('file_name');

                                $unzip = Util::extractFile($file_name);

                                jsonResponse($unzip);

                                break;

                            case 'schema_update':
                                $message = Update::singleCommand();
                                updateOption('build', $file_build);
                                jsonResponse([
                                    'success' => true,
                                    'message' => $message,
                                ]);

                                break;
                        }

                        break;

                    case 'PUT':
                        break;

                    case 'DELETE':
                        break;

                    default:
                        jsonResponse([
                            'error' => true,
                            'message' => 'Unknown Method!',
                        ]);

                        break;
                }

                break;

            default:
                jsonResponse([
                    'error' => true,
                    'message' => 'Unknown resources requested!',
                ]);

                break;
        }

        break;

    default:
        jsonResponse([
            'error' => true,
            'message' => 'Unknown API version!',
        ]);

        break;
}
