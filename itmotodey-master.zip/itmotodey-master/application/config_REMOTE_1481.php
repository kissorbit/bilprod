<?php
$db_host        = 'localhost';
$db_user        = 'root';
$db_password    = '';
$db_name        = 'ibilling';
define('APP_URL', 'https://itmotodey.test');
$_app_stage = 'Live'; // You can set this variable Live to Dev to enable ibilling Debug