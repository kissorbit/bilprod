<?php
$db_host 		= "localhost"; # Database Host
$db_user 		= 'root'; # Database Username
$db_password 	= ''; # Database Password
$db_name 		= 'ibilling'; # Database Name
define('APP_URL', 'http://localhost/ibilling'); # Application URL.
#Please include http and do not use trailing slash after the url. For example use in this format- http://www.example.com Or http://www.example.com/finance
$_app_stage = 'Live'; # Change Live to Dev to enable Debug
