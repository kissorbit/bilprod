<?php
// Select the database table
$t = new Schema('app_notes');
// Drop the table
$t->drop();