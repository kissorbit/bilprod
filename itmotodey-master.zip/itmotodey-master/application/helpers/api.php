

 



<?php
use Illuminate\Database\Eloquent\Model;
// if (!defined('APP_RUN')) {
//     exit('No direct access allowed');
// }
// echo 'hellow';


  header('Access-Control-Allow-Origin: *');
  header('Content-Type: application/json');
  ///require 'C:/wamp/www/ibilling/application/helpers/ibilling_api.php';
  $d = ORM::for_table('crm_accounts')->find_array();

  $data['result'] = $d;
// return json_encode($data
echo 'hellow';
// api_response($data);


   ?>



  