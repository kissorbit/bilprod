<?php
if (!defined('APP_RUN')) {
    exit('No direct access allowed');
}
if (!function_exists('convert2cen')) {
    function convert2cen($value,$unit){
        if($unit=='C'){
            return $value;
        }else if($unit=='F'){
            $cen = ($value - 32) / 1.8;
            return round($cen,2);
            }
    }
}