<?php
if (!defined('APP_RUN')) {
    exit('No direct access allowed');
}

function ib_api_auth()
{
    $data = [];
    $data['success'] = false;
    $data['msg'] = '';

    if (function_exists('getallheaders')) {
        $headers = getallheaders();
    } elseif (function_exists(apache_request_headers)) {
        $headers = apache_request_headers();
    } else {
        $data['msg'] =
            'This Server is not Supported Bearer Token Authentication. Please Upgrade your Server to Latest PHP.';

        return $data;
    }

    if (!isset($headers['Authorization'])) {
        $data['msg'] = 'Authorization token not found with the Request.';

        return $data;
    }

    $token = $headers['Authorization'];
    $token = str_replace('Bearer', '', $token);
    $token = trim($token);

    $d = ORM::for_table('sys_users')
        ->where('at', $token)
        ->find_one();

    if ($d) {
        $data['msg'] = 'Authentication Successful';
        $data['success'] = true;
    } else {
        $data['msg'] = 'Invalid Authentication Token';
    }

    return $data;
}
  //
//   $cache_file = 'data.json';
//   if(file_exists($cache_file)){
//   $data = json_decode(file_get_contents($cache_file));
//   }else{
//   $api_url = 'https://content.api.nytimes.com/svc/weather/v2/current-and-seven-day-forecast.json';
//   $data = file_get_contents($api_url);
//   file_put_contents($cache_file, $data);
//   $data = json_decode($data);
//   }
//   $current = $data->results->current[0];
//   $forecast = $data->results->seven_day_forecast;
//   function convert2cen($value,$unit){
//       if($unit=='C'){
//         return $value;
//       }else if($unit=='F'){
//         $cen = ($value - 32) / 1.8;
//           return round($cen,2);
//         }
//     }
//     $convert2cen=convert2cen($current->temp,$current->temp_unit);
//     $ui->assign('convert2cen', $convert2cen);
//     $ui->assign('forecast', $forecast);
//     $ui->assign('current', $current);